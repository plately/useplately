import { useState, useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { ErrorBoundary } from "@/components/error-boundary";
import { queryClient } from "./lib/queryClient";
import { useTheme } from "@/hooks/use-theme";

// Layouts
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";

// Pages
import Dashboard from "@/pages/dashboard";
import Workspace from "@/pages/workspace-enhanced";
import Chat from "@/pages/chat";
import Calendar from "@/pages/calendar";
import Tasks from "@/pages/tasks";
import Graph from "@/pages/graph";
import PlanningRoom from "@/pages/planning-room";



import Integrations from "@/pages/integrations";
import AdminDashboard from "@/pages/admin";
import NotFound from "@/pages/not-found";


function AppLayout({ children }: { children: React.ReactNode }) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [location] = useLocation();
  
  // Extract current page from location
  const currentPage = location === "/" ? "dashboard" : location.replace("/", "");

  // Check for mobile devices
  const [isMobile, setIsMobile] = useState(false);
  
  useEffect(() => {
    // Function to check screen width
    const checkScreenWidth = () => {
      const mobileWidth = 768; // Breakpoint for mobile devices
      const isMobileDevice = window.innerWidth < mobileWidth;
      setIsMobile(isMobileDevice);
      
      // Auto-collapse sidebar on mobile
      if (isMobileDevice) {
        setSidebarCollapsed(false); // Don't collapse on mobile, just hide
        setSidebarVisible(false);
      } else {
        setSidebarVisible(true);
        setSidebarCollapsed(false);
      }
    };
    
    // Initial check
    checkScreenWidth();
    
    // Listen for resize events
    window.addEventListener('resize', checkScreenWidth);
    window.addEventListener('orientationchange', checkScreenWidth);
    
    // Cleanup
    return () => {
      window.removeEventListener('resize', checkScreenWidth);
      window.removeEventListener('orientationchange', checkScreenWidth);
    };
  }, []);
  
  const toggleSidebarVisibility = () => {
    setSidebarVisible(!sidebarVisible);
  };

  return (
    <div className="flex h-screen bg-background">
      {/* Mobile Backdrop */}
      {isMobile && sidebarVisible && (
        <div 
          className="fixed inset-0 bg-black/50 z-40" 
          onClick={() => setSidebarVisible(false)}
        />
      )}
      
      {/* Sidebar */}
      {(sidebarVisible || !isMobile) && (
        <div className={`${isMobile ? 'fixed inset-y-0 left-0 z-50 w-64' : ''}`}>
          <Sidebar 
            collapsed={isMobile ? false : sidebarCollapsed}
            onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} 
            currentPage={currentPage}
            onClose={isMobile ? () => setSidebarVisible(false) : undefined}
            isMobile={isMobile}
          />
        </div>
      )}
      
      <main className="flex-1 flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900">
        <Header 
          onMenuClick={isMobile ? toggleSidebarVisibility : undefined} 
          showMenuButton={isMobile}
        />
        <div className="flex-1 overflow-auto">
          {children}
        </div>
      </main>
    </div>
  );
}

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/workspace" component={Workspace} />
        <Route path="/chat" component={Chat} />
        <Route path="/calendar" component={Calendar} />
        <Route path="/tasks" component={Tasks} />
        <Route path="/graph" component={Graph} />
        <Route path="/planning" component={PlanningRoom} />


        <Route path="/integrations" component={Integrations} />
        <Route path="/admin" component={AdminDashboard} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" colorScheme="blue">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;