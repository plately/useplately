import { useState, useRef, useCallback, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format, startOfDay, addHours } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Node, InsertNode } from "@shared/schema";
import {
  CheckCircle2,
  Circle,
  Plus,
  Upload,
  Link,
  Hash,
  Brain,
  Target,
  BarChart3,
  Paperclip,
  Zap,
  FileText,
  Image,
  File,
  Play,
  Pause,
  Check,
  ChevronDown,
  ChevronRight,
  Users,
  Tag,
  MessageSquare,
  ExternalLink,
  Timer,
  AlertCircle,
  CheckCheck,
  ArrowRight,
  Share2,
  Download,
  Copy,
  Settings,
  Search,
  Webhook,
  Database,
  Globe,
  Send,
  Rocket,
  GitBranch,
  Mail,
  FolderOpen,
  Smartphone,
  Monitor,
  Cloud,
  Workflow,
  Calendar as CalendarIcon,
  TrendingUp,
  Activity,
  Briefcase,
  Star,
  Award,
  Layers,
  Grid3X3,
  Layout,
  MoreHorizontal,
  Bell,
  Bookmark,
  Focus,
  Expand,
  Clock,
  MapPin,
  Eye,
  Filter
} from "lucide-react";

// Core interfaces for the node-centric workspace
interface WorkspaceTask {
  id: string;
  title: string;
  description?: string;
  status: 'todo' | 'in-progress' | 'done' | 'blocked';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assignedTo?: string;
  dueDate?: Date;
  tags: string[];
  subtasks: WorkspaceTask[];
  linkedNodes: number[];
  createdAt: Date;
  parentNodeId?: number;
  integrations?: IntegrationAction[];
}

interface WorkspaceFile {
  id: string;
  name: string;
  type: string;
  size: number;
  url: string;
  preview?: string;
  uploadedAt: Date;
  linkedNodes: number[];
  tags: string[];
  source?: 'local' | 'figma' | 'drive' | 'github';
}

interface IntegrationAction {
  id: string;
  platform: 'slack' | 'notion' | 'github' | 'drive' | 'linear' | 'figma' | 'stripe' | 'zapier';
  action: string;
  status: 'pending' | 'success' | 'failed';
  data?: any;
  triggeredAt: Date;
  linkedNodeId?: number;
}

interface NodeContext {
  node: Node;
  tasks: WorkspaceTask[];
  files: WorkspaceFile[];
  integrations: IntegrationAction[];
  progress: {
    totalTasks: number;
    completedTasks: number;
    percentage: number;
  };
}

const integrationPlatforms = [
  {
    id: 'slack',
    name: 'Slack',
    icon: <MessageSquare className="h-4 w-4" />,
    color: 'bg-purple-500',
    actions: ['Send Update', 'Create Channel', 'Post Progress']
  },
  {
    id: 'notion',
    name: 'Notion',
    icon: <FileText className="h-4 w-4" />,
    color: 'bg-gray-800',
    actions: ['Create Page', 'Update Database', 'Link Doc']
  },
  {
    id: 'github',
    name: 'GitHub',
    icon: <GitBranch className="h-4 w-4" />,
    color: 'bg-gray-900',
    actions: ['Create Issue', 'Create PR', 'Update Project']
  },
  {
    id: 'drive',
    name: 'Google Drive',
    icon: <Cloud className="h-4 w-4" />,
    color: 'bg-yellow-500',
    actions: ['Upload File', 'Share Folder', 'Create Doc']
  },
  {
    id: 'linear',
    name: 'Linear',
    icon: <Target className="h-4 w-4" />,
    color: 'bg-blue-600',
    actions: ['Create Issue', 'Update Status', 'Link to Epic']
  },
  {
    id: 'figma',
    name: 'Figma',
    icon: <Layers className="h-4 w-4" />,
    color: 'bg-pink-500',
    actions: ['Import Design', 'Create Frame', 'Get Comments']
  },
  {
    id: 'stripe',
    name: 'Stripe',
    icon: <Database className="h-4 w-4" />,
    color: 'bg-indigo-600',
    actions: ['Setup Product', 'Create Checkout', 'Track Revenue']
  }
];

export default function Workspace() {
  const [selectedNodeId, setSelectedNodeId] = useState<number | null>(null);
  const [nodeContext, setNodeContext] = useState<NodeContext | null>(null);
  const [tasks, setTasks] = useState<WorkspaceTask[]>([]);
  const [files, setFiles] = useState<WorkspaceFile[]>([]);
  const [integrations, setIntegrations] = useState<IntegrationAction[]>([]);
  
  // Form states
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [taskPriority, setTaskPriority] = useState<WorkspaceTask['priority']>('medium');
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [assignedTo, setAssignedTo] = useState('');
  const [taskTags, setTaskTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');
  
  // Dialog states
  const [isIntegrationsDialogOpen, setIsIntegrationsDialogOpen] = useState(false);
  const [isNodeSelectorOpen, setIsNodeSelectorOpen] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Query for all nodes
  const { data: nodes = [] } = useQuery<Node[]>({
    queryKey: ['/api/nodes'],
  });

  // Auto-select a project node if available or create one
  useEffect(() => {
    if (nodes.length > 0 && !selectedNodeId) {
      // Look for a project-type node or select the first one
      const projectNode = nodes.find(node => 
        node.nodeType === 'project' || 
        node.title.toLowerCase().includes('mvp') ||
        node.title.toLowerCase().includes('project')
      ) || nodes[0];
      
      setSelectedNodeId(projectNode.id);
    }
  }, [nodes, selectedNodeId]);

  // Load context when node is selected
  useEffect(() => {
    if (selectedNodeId) {
      const node = nodes.find(n => n.id === selectedNodeId);
      if (node) {
        // Filter tasks for this node
        const nodeTasks = tasks.filter(task => task.parentNodeId === selectedNodeId);
        const nodeFiles = files.filter(file => file.linkedNodes.includes(selectedNodeId));
        const nodeIntegrations = integrations.filter(int => int.linkedNodeId === selectedNodeId);
        
        const completedTasks = nodeTasks.filter(task => task.status === 'done').length;
        const totalTasks = nodeTasks.length;
        
        setNodeContext({
          node,
          tasks: nodeTasks,
          files: nodeFiles,
          integrations: nodeIntegrations,
          progress: {
            totalTasks,
            completedTasks,
            percentage: totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0
          }
        });
      }
    }
  }, [selectedNodeId, nodes, tasks, files, integrations]);

  // Create node mutation
  const createNodeMutation = useMutation({
    mutationFn: (nodeData: InsertNode) => apiRequest('/api/nodes', {
      method: 'POST',
      body: JSON.stringify(nodeData),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/nodes'] });
      toast({
        title: "Node created",
        description: "New project node has been created",
      });
    },
  });

  const addTask = useCallback(() => {
    if (!newTaskTitle.trim() || !selectedNodeId) return;

    const task: WorkspaceTask = {
      id: Date.now().toString(),
      title: newTaskTitle,
      status: 'todo',
      priority: taskPriority,
      tags: taskTags,
      subtasks: [],
      linkedNodes: [selectedNodeId],
      createdAt: new Date(),
      parentNodeId: selectedNodeId,
      assignedTo: assignedTo || undefined
    };

    setTasks(prev => [...prev, task]);
    setNewTaskTitle('');
    setTaskTags([]);
    setAssignedTo('');
    setIsAddingTask(false);
    
    toast({
      title: "Task added",
      description: `Task added to ${nodeContext?.node.title}`,
    });
  }, [newTaskTitle, selectedNodeId, taskPriority, taskTags, assignedTo, nodeContext]);

  const updateTaskStatus = (taskId: string, newStatus: WorkspaceTask['status']) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, status: newStatus } : task
    ));
    
    toast({
      title: "Task updated",
      description: `Task marked as ${newStatus.replace('-', ' ')}`,
    });
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = Array.from(event.target.files || []);
    
    uploadedFiles.forEach(file => {
      const workspaceFile: WorkspaceFile = {
        id: Date.now().toString() + Math.random(),
        name: file.name,
        type: file.type,
        size: file.size,
        url: URL.createObjectURL(file),
        uploadedAt: new Date(),
        linkedNodes: selectedNodeId ? [selectedNodeId] : [],
        tags: [],
        source: 'local'
      };
      
      setFiles(prev => [...prev, workspaceFile]);
    });

    toast({
      title: "Files uploaded",
      description: `${uploadedFiles.length} file(s) linked to ${nodeContext?.node.title}`,
    });
  };

  const executeIntegration = async (platform: string, action: string) => {
    if (!selectedNodeId) return;

    const integration: IntegrationAction = {
      id: Date.now().toString(),
      platform: platform as IntegrationAction['platform'],
      action,
      status: 'pending',
      triggeredAt: new Date(),
      linkedNodeId: selectedNodeId
    };

    setIntegrations(prev => [...prev, integration]);

    // Simulate API call
    setTimeout(() => {
      setIntegrations(prev => prev.map(int => 
        int.id === integration.id 
          ? { ...int, status: 'success' }
          : int
      ));
      
      toast({
        title: "Integration successful",
        description: `${action} executed in ${platform}`,
      });
    }, 1500);

    toast({
      title: "Integration started",
      description: `Executing ${action} in ${platform}...`,
    });
  };

  const addTag = () => {
    if (newTag.trim() && !taskTags.includes(newTag.trim())) {
      setTaskTags([...taskTags, newTag.trim()]);
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTaskTags(taskTags.filter(tag => tag !== tagToRemove));
  };

  if (!nodeContext) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center space-y-4">
          <Briefcase className="h-12 w-12 text-muted-foreground mx-auto" />
          <h2 className="text-xl font-semibold">Select a Project Node</h2>
          <p className="text-muted-foreground">Choose a node to start working in the workspace</p>
          <Button onClick={() => setIsNodeSelectorOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Select Node
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Project Header */}
      <div className="border-b bg-background/95 backdrop-blur-sm sticky top-0 z-30">
        <div className="p-4 space-y-4">
          {/* Node Selection and Progress */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button 
                variant="outline" 
                onClick={() => setIsNodeSelectorOpen(true)}
                className="flex items-center gap-2"
              >
                <Briefcase className="h-4 w-4" />
                {nodeContext.node.title}
                <ChevronDown className="h-4 w-4" />
              </Button>
              <Badge variant="secondary" className="bg-primary/10">
                {nodeContext.node.nodeType}
              </Badge>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="text-sm text-muted-foreground">
                {nodeContext.progress.completedTasks}/{nodeContext.progress.totalTasks} tasks
              </div>
              <div className="w-24">
                <Progress value={nodeContext.progress.percentage} className="h-2" />
              </div>
              <span className="text-sm font-medium">
                {Math.round(nodeContext.progress.percentage)}%
              </span>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2">
            <Button 
              size="sm" 
              onClick={() => setIsAddingTask(true)}
              className="h-8"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Task
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => fileInputRef.current?.click()}
              className="h-8"
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload Files
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => setIsIntegrationsDialogOpen(true)}
              className="h-8"
            >
              <Workflow className="h-4 w-4 mr-2" />
              Integrate
            </Button>
            <Button 
              size="sm" 
              variant="outline"
              className="h-8"
            >
              <Share2 className="h-4 w-4 mr-2" />
              Share
            </Button>
          </div>
        </div>
      </div>

      {/* Main Workspace Content */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full overflow-y-auto">
          <div className="p-6 space-y-6">
            {/* Quick Task Input */}
            {isAddingTask && (
              <Card className="border-2 border-primary/20">
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-primary" />
                    <h3 className="font-medium">Add New Task</h3>
                  </div>
                  
                  <Input
                    placeholder="e.g., Build landing page, Design user onboarding..."
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addTask()}
                    autoFocus
                  />
                  
                  <div className="flex items-center gap-2 flex-wrap">
                    <Select value={taskPriority} onValueChange={(value: WorkspaceTask['priority']) => setTaskPriority(value)}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Input
                      placeholder="Assign to..."
                      value={assignedTo}
                      onChange={(e) => setAssignedTo(e.target.value)}
                      className="w-32"
                    />
                    
                    {taskTags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                        #{tag}
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-auto p-0 w-4 h-4"
                          onClick={() => removeTag(tag)}
                        >
                          ×
                        </Button>
                      </Badge>
                    ))}
                    
                    <div className="flex items-center gap-2">
                      <Input
                        placeholder="Add tag..."
                        value={newTag}
                        onChange={(e) => setNewTag(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && addTag()}
                        className="w-24 h-7"
                      />
                      <Button size="sm" variant="ghost" onClick={addTag}>
                        <Hash className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-end gap-2">
                    <Button variant="outline" onClick={() => setIsAddingTask(false)}>
                      Cancel
                    </Button>
                    <Button onClick={addTask}>
                      Add Task
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Tasks Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* To Do */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <Circle className="h-4 w-4 text-gray-500" />
                    To Do
                    <Badge variant="secondary">{nodeContext.tasks.filter(t => t.status === 'todo').length}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {nodeContext.tasks.filter(task => task.status === 'todo').map((task) => (
                    <Card key={task.id} className="p-3 hover:shadow-sm transition-shadow group">
                      <div className="space-y-2">
                        <div className="flex items-start justify-between">
                          <h4 className="font-medium text-sm">{task.title}</h4>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="opacity-0 group-hover:opacity-100 h-6 w-6 p-0"
                            onClick={() => updateTaskStatus(task.id, 'in-progress')}
                          >
                            <Play className="h-3 w-3" />
                          </Button>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Badge 
                            variant="outline" 
                            className={`text-xs ${
                              task.priority === 'urgent' ? 'border-red-500 text-red-600' :
                              task.priority === 'high' ? 'border-orange-500 text-orange-600' :
                              task.priority === 'medium' ? 'border-yellow-500 text-yellow-600' :
                              'border-green-500 text-green-600'
                            }`}
                          >
                            {task.priority}
                          </Badge>
                          {task.assignedTo && (
                            <Badge variant="secondary" className="text-xs">
                              {task.assignedTo}
                            </Badge>
                          )}
                        </div>
                        
                        {task.tags.length > 0 && (
                          <div className="flex gap-1 flex-wrap">
                            {task.tags.map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                #{tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </Card>
                  ))}
                </CardContent>
              </Card>

              {/* In Progress */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <Play className="h-4 w-4 text-blue-500" />
                    In Progress
                    <Badge variant="secondary">{nodeContext.tasks.filter(t => t.status === 'in-progress').length}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {nodeContext.tasks.filter(task => task.status === 'in-progress').map((task) => (
                    <Card key={task.id} className="p-3 hover:shadow-sm transition-shadow group border-blue-200">
                      <div className="space-y-2">
                        <div className="flex items-start justify-between">
                          <h4 className="font-medium text-sm">{task.title}</h4>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="opacity-0 group-hover:opacity-100 h-6 w-6 p-0"
                            onClick={() => updateTaskStatus(task.id, 'done')}
                          >
                            <Check className="h-3 w-3" />
                          </Button>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Badge 
                            variant="outline" 
                            className={`text-xs ${
                              task.priority === 'urgent' ? 'border-red-500 text-red-600' :
                              task.priority === 'high' ? 'border-orange-500 text-orange-600' :
                              task.priority === 'medium' ? 'border-yellow-500 text-yellow-600' :
                              'border-green-500 text-green-600'
                            }`}
                          >
                            {task.priority}
                          </Badge>
                          {task.assignedTo && (
                            <Badge variant="secondary" className="text-xs">
                              {task.assignedTo}
                            </Badge>
                          )}
                        </div>
                        
                        {task.tags.length > 0 && (
                          <div className="flex gap-1 flex-wrap">
                            {task.tags.map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                #{tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </Card>
                  ))}
                </CardContent>
              </Card>

              {/* Done */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    Done
                    <Badge variant="secondary">{nodeContext.tasks.filter(t => t.status === 'done').length}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {nodeContext.tasks.filter(task => task.status === 'done').map((task) => (
                    <Card key={task.id} className="p-3 hover:shadow-sm transition-shadow border-green-200 opacity-80">
                      <div className="space-y-2">
                        <h4 className="font-medium text-sm line-through">{task.title}</h4>
                        
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs border-green-500 text-green-600">
                            {task.priority}
                          </Badge>
                          {task.assignedTo && (
                            <Badge variant="secondary" className="text-xs">
                              {task.assignedTo}
                            </Badge>
                          )}
                          <CheckCircle2 className="h-4 w-4 text-green-500 ml-auto" />
                        </div>
                        
                        {task.tags.length > 0 && (
                          <div className="flex gap-1 flex-wrap">
                            {task.tags.map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                #{tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </Card>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Files Section */}
            {nodeContext.files.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FolderOpen className="h-5 w-5" />
                    Linked Files
                    <Badge variant="secondary">{nodeContext.files.length}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {nodeContext.files.map((file) => (
                      <Card key={file.id} className="p-3 hover:shadow-sm transition-shadow">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded bg-blue-100 text-blue-600">
                            <File className="h-4 w-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{file.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {(file.size / 1024).toFixed(1)} KB • {format(file.uploadedAt, 'MMM d')}
                            </p>
                          </div>
                          <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                            <ExternalLink className="h-3 w-3" />
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Integrations Activity */}
            {nodeContext.integrations.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Workflow className="h-5 w-5" />
                    Integration Activity
                    <Badge variant="secondary">{nodeContext.integrations.length}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {nodeContext.integrations.slice(-5).map((integration) => (
                      <div key={integration.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                        <div className={`p-1 rounded ${integration.status === 'success' ? 'bg-green-100 text-green-600' : 'bg-yellow-100 text-yellow-600'}`}>
                          {integrationPlatforms.find(p => p.id === integration.platform)?.icon}
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{integration.action}</p>
                          <p className="text-xs text-muted-foreground">
                            {integrationPlatforms.find(p => p.id === integration.platform)?.name} • {format(integration.triggeredAt, 'h:mm a')}
                          </p>
                        </div>
                        <Badge variant={integration.status === 'success' ? 'default' : 'secondary'}>
                          {integration.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={handleFileUpload}
      />

      {/* Node Selector Dialog */}
      <Dialog open={isNodeSelectorOpen} onOpenChange={setIsNodeSelectorOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Briefcase className="h-5 w-5" />
              Select Project Node
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-2 max-h-64 overflow-y-auto">
              {nodes.map((node) => (
                <Button
                  key={node.id}
                  variant={selectedNodeId === node.id ? "default" : "outline"}
                  className="h-auto p-4 flex items-center justify-start gap-3"
                  onClick={() => {
                    setSelectedNodeId(node.id);
                    setIsNodeSelectorOpen(false);
                  }}
                >
                  <div className="flex-1 text-left">
                    <div className="font-medium">{node.title}</div>
                    <div className="text-sm text-muted-foreground">
                      {node.nodeType} • {format(node.createdAt, 'MMM d, yyyy')}
                    </div>
                  </div>
                  {selectedNodeId === node.id && (
                    <CheckCircle2 className="h-4 w-4" />
                  )}
                </Button>
              ))}
            </div>
            
            <Separator />
            
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => {
                createNodeMutation.mutate({
                  title: "New Project",
                  content: "Project workspace for managing tasks and files",
                  nodeType: "project",
                  createdBy: 1
                });
                setIsNodeSelectorOpen(false);
              }}
            >
              <Plus className="h-4 w-4 mr-2" />
              Create New Project Node
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Integrations Dialog */}
      <Dialog open={isIntegrationsDialogOpen} onOpenChange={setIsIntegrationsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Workflow className="h-5 w-5" />
              Connect Integrations
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Seamlessly sync actions with your favorite tools for {nodeContext?.node.title}
            </p>
            
            <div className="grid grid-cols-2 gap-3">
              {integrationPlatforms.map((platform) => (
                <div key={platform.id} className="space-y-2">
                  <div className="flex items-center gap-2 p-3 border rounded-lg">
                    <div className={`p-2 rounded text-white ${platform.color}`}>
                      {platform.icon}
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-sm">{platform.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {platform.actions.length} actions
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    {platform.actions.slice(0, 2).map((action) => (
                      <Button
                        key={action}
                        variant="outline"
                        size="sm"
                        className="w-full text-xs"
                        onClick={() => {
                          executeIntegration(platform.id, action);
                          setIsIntegrationsDialogOpen(false);
                        }}
                      >
                        {action}
                      </Button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}