import { useState, useRef, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format, startOfDay, addHours } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Node, InsertNode } from "@shared/schema";
import {
  Calendar,
  Clock,
  CheckCircle2,
  Circle,
  Plus,
  Upload,
  Mic,
  Video,
  Link,
  Hash,
  Brain,
  Target,
  BarChart3,
  Paperclip,
  Zap,
  Sun,
  CloudDrizzle,
  Moon,
  Coffee,
  Lightbulb,
  FileText,
  Image,
  File,
  Play,
  Pause,
  Square,
  ChevronDown,
  ChevronRight,
  Users,
  Tag,
  MessageSquare,
  Archive,
  Trash2,
  ExternalLink,
  Maximize2,
  PlusCircle,
  Timer,
  MapPin,
  AlertCircle,
  CheckCheck,
  ArrowRight,
  Eye,
  EyeOff,
  Share2,
  Download,
  Copy,
  Settings,
  Filter,
  Search,
  Webhook,
  Database,
  Globe,
  Send,
  Rocket,
  GitBranch,
  Mail,
  FolderOpen,
  Smartphone,
  Monitor,
  Cloud,
  Workflow,
  Calendar as CalendarIcon,
  TrendingUp,
  Activity,
  Briefcase,
  Star,
  Award,
  Layers,
  Grid3X3,
  Layout,
  MoreHorizontal,
  Bell,
  Bookmark,
  Focus,
  Expand
} from "lucide-react";

// Keep all existing interfaces
interface WorkspaceEntry {
  id: string;
  type: 'note' | 'task' | 'checkin' | 'file' | 'voice' | 'meeting' | 'idea';
  content: string;
  timestamp: Date;
  completed?: boolean;
  tags: string[];
  mood?: 'great' | 'good' | 'neutral' | 'stressed' | 'blocked';
  assignedTo?: string;
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  linkedNodes?: number[];
  files?: WorkspaceFile[];
  metadata?: Record<string, any>;
}

interface WorkspaceFile {
  id: string;
  name: string;
  type: string;
  size: number;
  url: string;
  preview?: string;
  visibility: 'private' | 'public';
  linkedTo?: string[];
  tags: string[];
}

interface Task {
  id: string;
  title: string;
  description?: string;
  status: 'todo' | 'doing' | 'done';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assignedTo?: string;
  dueDate?: Date;
  tags: string[];
  subtasks: Task[];
  linkedNodes: number[];
  createdAt: Date;
  integrations?: Integration[];
}

interface Integration {
  id: string;
  platform: 'google' | 'github' | 'zapier' | 'drive' | 'outlook' | 'excel' | 'slack' | 'notion' | 'trello' | 'asana' | 'jira' | 'teams' | 'calendar' | 'sheets';
  action: string;
  config: Record<string, any>;
  status: 'pending' | 'success' | 'failed';
  lastSync?: Date;
}

interface AutomationRule {
  id: string;
  name: string;
  trigger: {
    type: 'task_complete' | 'entry_added' | 'file_uploaded' | 'time_based';
    conditions: Record<string, any>;
  };
  actions: Array<{
    platform: Integration['platform'];
    action: string;
    config: Record<string, any>;
  }>;
  enabled: boolean;
}

const moodIcons = {
  great: { emoji: '😊', color: 'text-green-600' },
  good: { emoji: '🙂', color: 'text-blue-600' },
  neutral: { emoji: '😐', color: 'text-gray-600' },
  stressed: { emoji: '😰', color: 'text-orange-600' },
  blocked: { emoji: '😤', color: 'text-red-600' }
};

const priorityColors = {
  low: 'bg-gray-100 text-gray-800 border-gray-200',
  medium: 'bg-blue-100 text-blue-800 border-blue-200',
  high: 'bg-orange-100 text-orange-800 border-orange-200',
  urgent: 'bg-red-100 text-red-800 border-red-200'
};

export default function Workspace() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [tasks, setTasks] = useState<Task[]>([]);
  const [files, setFiles] = useState<WorkspaceFile[]>([]);
  const [workspaceEntries, setWorkspaceEntries] = useState<WorkspaceEntry[]>([]);
  
  // Form states
  const [newEntry, setNewEntry] = useState('');
  const [entryType, setEntryType] = useState<WorkspaceEntry['type']>('note');
  const [selectedMood, setSelectedMood] = useState<WorkspaceEntry['mood']>('neutral');
  const [entryTags, setEntryTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');
  const [selectedPriority, setSelectedPriority] = useState<Task['priority']>('medium');
  
  // Dialog states
  const [isAIDialogOpen, setIsAIDialogOpen] = useState(false);
  const [isNodeDialogOpen, setIsNodeDialogOpen] = useState(false);
  const [isFileDialogOpen, setIsFileDialogOpen] = useState(false);
  const [isIntegrationsDialogOpen, setIsIntegrationsDialogOpen] = useState(false);
  const [isAutomationDialogOpen, setIsAutomationDialogOpen] = useState(false);
  
  // Other states
  const [aiPrompt, setAiPrompt] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [automationRules, setAutomationRules] = useState<AutomationRule[]>([]);
  const [selectedIntegration, setSelectedIntegration] = useState<Integration['platform'] | ''>('');
  const [activeView, setActiveView] = useState<'overview' | 'tasks' | 'files' | 'integrations'>('overview');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Query for nodes
  const { data: nodes = [] } = useQuery<Node[]>({
    queryKey: ['/api/nodes'],
  });

  // Create node mutation
  const createNodeMutation = useMutation({
    mutationFn: (nodeData: InsertNode) => apiRequest('/api/nodes', {
      method: 'POST',
      body: JSON.stringify(nodeData),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/nodes'] });
      toast({
        title: "Node created",
        description: "Your entry has been converted to a node",
      });
    },
  });

  // Integration platform configurations
  const integrationPlatforms = [
    {
      id: 'google',
      name: 'Google Workspace',
      icon: <Globe className="h-4 w-4" />,
      color: 'bg-blue-500',
      actions: ['Create Doc', 'Add to Calendar', 'Send Email', 'Create Sheet']
    },
    {
      id: 'github',
      name: 'GitHub',
      icon: <GitBranch className="h-4 w-4" />,
      color: 'bg-gray-900',
      actions: ['Create Issue', 'Create PR', 'Add to Project', 'Commit Code']
    },
    {
      id: 'zapier',
      name: 'Zapier',
      icon: <Workflow className="h-4 w-4" />,
      color: 'bg-orange-500',
      actions: ['Trigger Zap', 'Create Automation', 'Send Webhook']
    },
    {
      id: 'drive',
      name: 'Google Drive',
      icon: <Cloud className="h-4 w-4" />,
      color: 'bg-yellow-500',
      actions: ['Upload File', 'Create Folder', 'Share Document']
    },
    {
      id: 'outlook',
      name: 'Microsoft Outlook',
      icon: <Mail className="h-4 w-4" />,
      color: 'bg-blue-600',
      actions: ['Send Email', 'Create Meeting', 'Add to Calendar']
    },
    {
      id: 'excel',
      name: 'Microsoft Excel',
      icon: <Database className="h-4 w-4" />,
      color: 'bg-green-600',
      actions: ['Create Workbook', 'Add Row', 'Update Cell', 'Generate Chart']
    },
    {
      id: 'slack',
      name: 'Slack',
      icon: <MessageSquare className="h-4 w-4" />,
      color: 'bg-purple-500',
      actions: ['Send Message', 'Create Channel', 'Post Update']
    },
    {
      id: 'notion',
      name: 'Notion',
      icon: <FileText className="h-4 w-4" />,
      color: 'bg-gray-800',
      actions: ['Create Page', 'Add to Database', 'Update Property']
    },
    {
      id: 'trello',
      name: 'Trello',
      icon: <Target className="h-4 w-4" />,
      color: 'bg-blue-400',
      actions: ['Create Card', 'Move Card', 'Add Checklist']
    },
    {
      id: 'asana',
      name: 'Asana',
      icon: <CheckCircle2 className="h-4 w-4" />,
      color: 'bg-red-500',
      actions: ['Create Task', 'Add to Project', 'Set Due Date']
    },
    {
      id: 'jira',
      name: 'Jira',
      icon: <AlertCircle className="h-4 w-4" />,
      color: 'bg-blue-700',
      actions: ['Create Issue', 'Update Status', 'Add Comment']
    },
    {
      id: 'teams',
      name: 'Microsoft Teams',
      icon: <Users className="h-4 w-4" />,
      color: 'bg-purple-600',
      actions: ['Send Message', 'Schedule Meeting', 'Share File']
    }
  ];

  const addWorkspaceEntry = useCallback(() => {
    if (!newEntry.trim()) return;

    const entry: WorkspaceEntry = {
      id: Date.now().toString(),
      type: entryType,
      content: newEntry,
      timestamp: new Date(),
      tags: entryTags,
      mood: entryType === 'checkin' ? selectedMood : undefined,
      completed: entryType === 'task' ? false : undefined,
      priority: entryType === 'task' ? selectedPriority : undefined,
    };

    setWorkspaceEntries(prev => [entry, ...prev]);

    // Auto-suggest converting to node for ideas
    if (entryType === 'idea' || newEntry.toLowerCase().includes('idea') || newEntry.toLowerCase().includes('concept')) {
      setTimeout(() => {
        if (window.confirm('Would you like to turn this into a node?')) {
          createNodeFromEntry(entry);
        }
      }, 500);
    }

    resetForm();
    
    toast({
      title: "Entry added",
      description: `${entryType} added to workspace`,
    });
  }, [newEntry, entryType, entryTags, selectedMood, selectedPriority]);

  const resetForm = () => {
    setNewEntry('');
    setEntryTags([]);
  };

  const addTag = () => {
    if (newTag.trim() && !entryTags.includes(newTag.trim())) {
      setEntryTags([...entryTags, newTag.trim()]);
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setEntryTags(entryTags.filter(tag => tag !== tagToRemove));
  };

  const createNodeFromEntry = (entry: WorkspaceEntry) => {
    createNodeMutation.mutate({
      title: entry.content.substring(0, 50) + (entry.content.length > 50 ? '...' : ''),
      content: entry.content,
      nodeType: entry.type === 'task' ? 'task' : entry.type === 'idea' ? 'idea' : 'note',
      tags: entry.tags,
      createdBy: 1,
    });
  };

  const addTask = (status: Task['status'] = 'todo') => {
    if (!newEntry.trim()) return;

    const task: Task = {
      id: Date.now().toString(),
      title: newEntry,
      status,
      priority: selectedPriority,
      tags: entryTags,
      subtasks: [],
      linkedNodes: [],
      createdAt: new Date()
    };

    setTasks(prev => [task, ...prev]);
    resetForm();
    
    toast({
      title: "Task created",
      description: "New task added to workspace",
    });
  };

  const updateTaskStatus = (taskId: string, newStatus: Task['status']) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, status: newStatus } : task
    ));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = Array.from(event.target.files || []);
    
    uploadedFiles.forEach(file => {
      const workspaceFile: WorkspaceFile = {
        id: Date.now().toString() + Math.random(),
        name: file.name,
        type: file.type,
        size: file.size,
        url: URL.createObjectURL(file),
        visibility: 'private',
        linkedTo: [],
        tags: []
      };
      
      setFiles(prev => [workspaceFile, ...prev]);
    });

    toast({
      title: "Files uploaded",
      description: `${uploadedFiles.length} file(s) added to workspace`,
    });
  };

  const executeIntegration = async (platform: Integration['platform'], action: string, data: any) => {
    const integration: Integration = {
      id: Date.now().toString(),
      platform,
      action,
      config: data,
      status: 'pending'
    };

    setIntegrations(prev => [integration, ...prev]);

    // Simulate API call with realistic delay
    setTimeout(() => {
      setIntegrations(prev => prev.map(int => 
        int.id === integration.id 
          ? { ...int, status: 'success', lastSync: new Date() }
          : int
      ));
      
      toast({
        title: "Integration successful",
        description: `${action} executed in ${integrationPlatforms.find(p => p.id === platform)?.name}`,
      });
    }, 1500);

    toast({
      title: "Integration started",
      description: `Executing ${action} in ${integrationPlatforms.find(p => p.id === platform)?.name}...`,
    });
  };

  const getDailyStats = () => {
    const completedTasks = tasks.filter(task => task.status === 'done').length;
    const totalTasks = tasks.length;
    const todayEntries = workspaceEntries.filter(entry => 
      new Date(entry.timestamp).toDateString() === selectedDate.toDateString()
    ).length;
    const todayFiles = files.filter(file => 
      new Date(file.id).toDateString() === selectedDate.toDateString()
    ).length;
    
    return {
      totalEntries: workspaceEntries.length,
      todayEntries,
      tasksCompleted: completedTasks,
      totalTasks,
      filesUploaded: todayFiles,
      nodesLinked: workspaceEntries.reduce((acc, entry) => acc + (entry.linkedNodes?.length || 0), 0),
      activeIntegrations: integrations.filter(int => int.status === 'success').length
    };
  };

  const getProgressPercentage = () => {
    const stats = getDailyStats();
    return stats.totalTasks > 0 ? (stats.tasksCompleted / stats.totalTasks) * 100 : 0;
  };

  const stats = getDailyStats();

  // Main workspace views
  const OverviewView = () => (
    <div className="space-y-6">
      {/* Daily Progress Card */}
      <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-blue-950 dark:to-indigo-900">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-xl font-bold">Today's Progress</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                {format(selectedDate, 'EEEE, MMMM do, yyyy')}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5 text-blue-600" />
              <Badge variant="secondary" className="font-semibold">
                {Math.round(getProgressPercentage())}% Complete
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.todayEntries}</div>
              <div className="text-xs text-muted-foreground">Entries Today</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{stats.tasksCompleted}</div>
              <div className="text-xs text-muted-foreground">Tasks Done</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{stats.filesUploaded}</div>
              <div className="text-xs text-muted-foreground">Files Added</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">{stats.activeIntegrations}</div>
              <div className="text-xs text-muted-foreground">Integrations</div>
            </div>
          </div>
          <Progress value={getProgressPercentage()} className="h-2" />
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Button variant="outline" className="h-auto py-3 flex flex-col gap-2" onClick={() => setEntryType('note')}>
              <FileText className="h-5 w-5" />
              <span className="text-xs">Add Note</span>
            </Button>
            <Button variant="outline" className="h-auto py-3 flex flex-col gap-2" onClick={() => setEntryType('task')}>
              <CheckCircle2 className="h-5 w-5" />
              <span className="text-xs">New Task</span>
            </Button>
            <Button variant="outline" className="h-auto py-3 flex flex-col gap-2" onClick={() => fileInputRef.current?.click()}>
              <Upload className="h-5 w-5" />
              <span className="text-xs">Upload File</span>
            </Button>
            <Button variant="outline" className="h-auto py-3 flex flex-col gap-2" onClick={() => setIsIntegrationsDialogOpen(true)}>
              <Workflow className="h-5 w-5" />
              <span className="text-xs">Integrate</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-64">
            <div className="space-y-3">
              {workspaceEntries.slice(0, 10).map((entry) => (
                <div key={entry.id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mt-2"></div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline" className="text-xs">
                        {entry.type}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {format(entry.timestamp, 'h:mm a')}
                      </span>
                    </div>
                    <p className="text-sm line-clamp-2">{entry.content}</p>
                    {entry.tags.length > 0 && (
                      <div className="flex gap-1 mt-2">
                        {entry.tags.map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            #{tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );

  const TasksView = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Task Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Todo Column */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 pb-2 border-b">
                <Circle className="h-4 w-4 text-gray-500" />
                <h3 className="font-medium">To Do</h3>
                <Badge variant="secondary">{tasks.filter(t => t.status === 'todo').length}</Badge>
              </div>
              <ScrollArea className="h-64">
                <div className="space-y-2">
                  {tasks.filter(task => task.status === 'todo').map((task) => (
                    <Card key={task.id} className="p-3 cursor-pointer hover:shadow-md transition-shadow">
                      <div className="space-y-2">
                        <p className="font-medium text-sm">{task.title}</p>
                        <div className="flex items-center justify-between">
                          <Badge className={priorityColors[task.priority]}>{task.priority}</Badge>
                          <Button size="sm" variant="ghost" onClick={() => updateTaskStatus(task.id, 'doing')}>
                            <Play className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </div>

            {/* In Progress Column */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 pb-2 border-b">
                <Play className="h-4 w-4 text-blue-500" />
                <h3 className="font-medium">In Progress</h3>
                <Badge variant="secondary">{tasks.filter(t => t.status === 'doing').length}</Badge>
              </div>
              <ScrollArea className="h-64">
                <div className="space-y-2">
                  {tasks.filter(task => task.status === 'doing').map((task) => (
                    <Card key={task.id} className="p-3 cursor-pointer hover:shadow-md transition-shadow border-blue-200">
                      <div className="space-y-2">
                        <p className="font-medium text-sm">{task.title}</p>
                        <div className="flex items-center justify-between">
                          <Badge className={priorityColors[task.priority]}>{task.priority}</Badge>
                          <Button size="sm" variant="ghost" onClick={() => updateTaskStatus(task.id, 'done')}>
                            <CheckCircle2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </div>

            {/* Done Column */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 pb-2 border-b">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <h3 className="font-medium">Done</h3>
                <Badge variant="secondary">{tasks.filter(t => t.status === 'done').length}</Badge>
              </div>
              <ScrollArea className="h-64">
                <div className="space-y-2">
                  {tasks.filter(task => task.status === 'done').map((task) => (
                    <Card key={task.id} className="p-3 cursor-pointer hover:shadow-md transition-shadow border-green-200 opacity-80">
                      <div className="space-y-2">
                        <p className="font-medium text-sm line-through">{task.title}</p>
                        <div className="flex items-center justify-between">
                          <Badge className={priorityColors[task.priority]}>{task.priority}</Badge>
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const FilesView = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FolderOpen className="h-5 w-5" />
            File Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {files.map((file) => (
              <Card key={file.id} className="p-4 hover:shadow-md transition-shadow">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <File className="h-5 w-5 text-blue-500" />
                    <span className="font-medium text-sm truncate">{file.name}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {(file.size / 1024).toFixed(1)} KB • {file.type}
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={file.visibility === 'public' ? 'default' : 'secondary'}>
                      {file.visibility}
                    </Badge>
                    <Button size="sm" variant="ghost">
                      <Download className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const IntegrationsView = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Workflow className="h-5 w-5" />
            Active Integrations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {integrationPlatforms.map((platform) => (
              <Card key={platform.id} className="p-4 hover:shadow-md transition-shadow">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg text-white ${platform.color}`}>
                      {platform.icon}
                    </div>
                    <div>
                      <h3 className="font-medium text-sm">{platform.name}</h3>
                      <p className="text-xs text-muted-foreground">
                        {platform.actions.length} actions available
                      </p>
                    </div>
                  </div>
                  <div className="space-y-1">
                    {platform.actions.slice(0, 2).map((action) => (
                      <Button
                        key={action}
                        variant="outline"
                        size="sm"
                        className="w-full text-xs"
                        onClick={() => executeIntegration(platform.id as Integration['platform'], action, {})}
                      >
                        {action}
                      </Button>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Integration Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Recent Integration Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-48">
            <div className="space-y-3">
              {integrations.slice(0, 10).map((integration) => (
                <div key={integration.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <div className={`p-1 rounded ${integration.status === 'success' ? 'bg-green-100 text-green-600' : integration.status === 'failed' ? 'bg-red-100 text-red-600' : 'bg-yellow-100 text-yellow-600'}`}>
                    {integrationPlatforms.find(p => p.id === integration.platform)?.icon}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{integration.action}</p>
                    <p className="text-xs text-muted-foreground">
                      {integrationPlatforms.find(p => p.id === integration.platform)?.name}
                    </p>
                  </div>
                  <Badge 
                    variant={integration.status === 'success' ? 'default' : integration.status === 'failed' ? 'destructive' : 'secondary'}
                  >
                    {integration.status}
                  </Badge>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Professional Header */}
      <div className="border-b bg-background/95 backdrop-blur-sm sticky top-0 z-30">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Briefcase className="h-6 w-6 text-primary" />
              <h1 className="text-2xl font-bold">Workspace</h1>
            </div>
            <Badge variant="outline" className="bg-primary/10">
              {format(selectedDate, 'MMM d')}
            </Badge>
          </div>
          
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setIsAIDialogOpen(true)}>
              <Brain className="h-4 w-4 mr-2" />
              AI Assistant
            </Button>
            <Button variant="outline" size="sm" onClick={() => setIsNodeDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Node
            </Button>
            <Button size="sm" onClick={() => fileInputRef.current?.click()}>
              <Upload className="h-4 w-4 mr-2" />
              Upload
            </Button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-4 pb-2">
          <Tabs value={activeView} onValueChange={(value) => setActiveView(value as any)} className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <Layout className="h-4 w-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="tasks" className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                Tasks
              </TabsTrigger>
              <TabsTrigger value="files" className="flex items-center gap-2">
                <FolderOpen className="h-4 w-4" />
                Files
              </TabsTrigger>
              <TabsTrigger value="integrations" className="flex items-center gap-2">
                <Workflow className="h-4 w-4" />
                Integrations
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full overflow-y-auto">
          <div className="p-6">
            {/* Content Input Section */}
            <Card className="mb-6 border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <Select value={entryType} onValueChange={(value: WorkspaceEntry['type']) => setEntryType(value)}>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Entry type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="note">📝 Note</SelectItem>
                        <SelectItem value="task">✅ Task</SelectItem>
                        <SelectItem value="idea">💡 Idea</SelectItem>
                        <SelectItem value="checkin">😊 Check-in</SelectItem>
                        <SelectItem value="meeting">🤝 Meeting</SelectItem>
                        <SelectItem value="file">📎 File</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    {entryType === 'task' && (
                      <Select value={selectedPriority} onValueChange={(value: Task['priority']) => setSelectedPriority(value)}>
                        <SelectTrigger className="w-32">
                          <SelectValue placeholder="Priority" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="urgent">Urgent</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                    
                    {entryType === 'checkin' && (
                      <Select value={selectedMood} onValueChange={(value: WorkspaceEntry['mood']) => setSelectedMood(value)}>
                        <SelectTrigger className="w-32">
                          <SelectValue placeholder="Mood" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="great">😊 Great</SelectItem>
                          <SelectItem value="good">🙂 Good</SelectItem>
                          <SelectItem value="neutral">😐 Neutral</SelectItem>
                          <SelectItem value="stressed">😰 Stressed</SelectItem>
                          <SelectItem value="blocked">😤 Blocked</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  </div>

                  <Textarea
                    placeholder={`Add a ${entryType}...`}
                    value={newEntry}
                    onChange={(e) => setNewEntry(e.target.value)}
                    className="min-h-24 resize-none"
                  />

                  <div className="flex items-center gap-2 flex-wrap">
                    {entryTags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                        #{tag}
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-auto p-0 w-4 h-4"
                          onClick={() => removeTag(tag)}
                        >
                          ×
                        </Button>
                      </Badge>
                    ))}
                    <div className="flex items-center gap-2">
                      <Input
                        placeholder="Add tag..."
                        value={newTag}
                        onChange={(e) => setNewTag(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && addTag()}
                        className="w-24 h-7"
                      />
                      <Button size="sm" variant="ghost" onClick={addTag}>
                        <Hash className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="sm">
                        <Link className="h-4 w-4 mr-2" />
                        Link Node
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Mic className="h-4 w-4 mr-2" />
                        Voice
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Video className="h-4 w-4 mr-2" />
                        Video
                      </Button>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {entryType === 'task' ? (
                        <Button onClick={() => addTask()}>
                          Add Task
                        </Button>
                      ) : (
                        <Button onClick={addWorkspaceEntry}>
                          Add {entryType}
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Dynamic Content Based on Active View */}
            {activeView === 'overview' && <OverviewView />}
            {activeView === 'tasks' && <TasksView />}
            {activeView === 'files' && <FilesView />}
            {activeView === 'integrations' && <IntegrationsView />}
          </div>
        </div>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={handleFileUpload}
      />

      {/* All existing dialogs maintained */}
      <Dialog open={isAIDialogOpen} onOpenChange={setIsAIDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              AI Assistant
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder="Ask AI for help with your workspace..."
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              className="min-h-24"
            />
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsAIDialogOpen(false)}>
                Cancel
              </Button>
              <Button>
                <Send className="h-4 w-4 mr-2" />
                Send
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={isNodeDialogOpen} onOpenChange={setIsNodeDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Create Node
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input placeholder="Node title..." />
            <Textarea placeholder="Node content..." className="min-h-24" />
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Node type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="note">Note</SelectItem>
                <SelectItem value="task">Task</SelectItem>
                <SelectItem value="idea">Idea</SelectItem>
                <SelectItem value="meeting">Meeting</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsNodeDialogOpen(false)}>
                Cancel
              </Button>
              <Button>Create Node</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={isIntegrationsDialogOpen} onOpenChange={setIsIntegrationsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Workflow className="h-5 w-5" />
              Integration Hub
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              {integrationPlatforms.slice(0, 8).map((platform) => (
                <Button
                  key={platform.id}
                  variant="outline"
                  className="h-auto p-4 flex items-center gap-3"
                  onClick={() => {
                    setSelectedIntegration(platform.id as Integration['platform']);
                    executeIntegration(platform.id as Integration['platform'], platform.actions[0], {});
                  }}
                >
                  <div className={`p-2 rounded text-white ${platform.color}`}>
                    {platform.icon}
                  </div>
                  <div className="text-left">
                    <div className="font-medium text-sm">{platform.name}</div>
                    <div className="text-xs text-muted-foreground">Connect & automate</div>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}