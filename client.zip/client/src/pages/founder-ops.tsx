import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Plus, 
  DollarSign, 
  Users, 
  TrendingUp, 
  FileText, 
  Download, 
  Send, 
  Calendar,
  Clock,
  CheckCircle,
  AlertCircle,
  Building,
  Mail,
  PieChart,
  BarChart3,
  Presentation,
  Receipt,
  CreditCard,
  Calculator,
  UserCheck,
  Globe,
  Settings,
  Search,
  Filter,
  Edit,
  Trash2,
  Eye,
  Copy
} from "lucide-react";

// Types for the founder operations
interface Invoice {
  id: number;
  invoiceNumber: string;
  clientName: string;
  clientEmail?: string;
  service: string;
  hours?: number;
  rate?: number;
  totalAmount: number;
  status: 'paid' | 'unpaid' | 'overdue';
  isRecurring: boolean;
  dueDate?: Date;
  paidDate?: Date;
  createdAt: Date;
}

interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  employeeType: 'employee' | 'contractor';
  hourlyRate?: number;
  paymentCycle: 'weekly' | 'biweekly' | 'monthly';
  isActive: boolean;
  startDate?: Date;
  createdAt: Date;
}

interface PitchDeck {
  id: number;
  title: string;
  description?: string;
  templateId?: number;
  slides: any[];
  status: 'draft' | 'completed' | 'shared';
  viewCount: number;
  createdAt: Date;
  updatedAt: Date;
}

interface InvestorUpdate {
  id: number;
  title: string;
  content: string;
  updateType: 'milestones' | 'financials' | 'burn_rate' | 'hiring';
  status: 'draft' | 'sent';
  sentDate?: Date;
  createdAt: Date;
}

interface Template {
  id: number;
  name: string;
  category: 'fundraising' | 'legal' | 'hr' | 'ops' | 'product';
  templateType: 'invoice' | 'pitch_deck' | 'investor_update' | 'document';
  usageCount: number;
  isPublic: boolean;
  createdAt: Date;
}

export default function FounderOps() {
  const [activeModule, setActiveModule] = useState<'invoicing' | 'payroll' | 'investor' | 'templates'>('invoicing');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [isCreateInvoiceOpen, setIsCreateInvoiceOpen] = useState(false);
  const [isCreateEmployeeOpen, setIsCreateEmployeeOpen] = useState(false);
  const [isCreatePitchDeckOpen, setIsCreatePitchDeckOpen] = useState(false);
  const [isCreateUpdateOpen, setIsCreateUpdateOpen] = useState(false);
  const [isTemplatePreviewOpen, setIsTemplatePreviewOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [isPayrollDocumentOpen, setIsPayrollDocumentOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const { toast } = useToast();

  // Queries for data fetching
  const { data: invoices = [], isLoading: invoicesLoading } = useQuery<Invoice[]>({
    queryKey: ['/api/founder-ops/invoices'],
    queryFn: async () => {
      // Demo data for now
      return [
        {
          id: 1,
          invoiceNumber: 'INV-001',
          clientName: 'Acme Corp',
          clientEmail: 'billing@acme.com',
          service: 'Consulting Services',
          hours: 40,
          rate: 15000, // $150 in cents
          totalAmount: 600000, // $6000 in cents
          status: 'unpaid' as const,
          isRecurring: false,
          dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          createdAt: new Date(),
        },
        {
          id: 2,
          invoiceNumber: 'INV-002',
          clientName: 'TechStart Inc',
          clientEmail: 'finance@techstart.io',
          service: 'Product Development',
          hours: 80,
          rate: 17500,
          totalAmount: 1400000,
          status: 'paid' as const,
          isRecurring: true,
          paidDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
          createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
        }
      ];
    }
  });

  const { data: employees = [], isLoading: employeesLoading } = useQuery<Employee[]>({
    queryKey: ['/api/founder-ops/employees'],
    queryFn: async () => {
      return [
        {
          id: 1,
          firstName: 'John',
          lastName: 'Smith',
          email: 'john@company.com',
          employeeType: 'employee' as const,
          hourlyRate: 7500, // $75/hr in cents
          paymentCycle: 'biweekly' as const,
          isActive: true,
          startDate: new Date('2024-01-15'),
          createdAt: new Date('2024-01-15'),
        },
        {
          id: 2,
          firstName: 'Sarah',
          lastName: 'Johnson',
          email: 'sarah@freelance.com',
          employeeType: 'contractor' as const,
          hourlyRate: 10000,
          paymentCycle: 'monthly' as const,
          isActive: true,
          startDate: new Date('2024-03-01'),
          createdAt: new Date('2024-03-01'),
        }
      ];
    }
  });

  const { data: pitchDecks = [], isLoading: pitchDecksLoading } = useQuery<PitchDeck[]>({
    queryKey: ['/api/founder-ops/pitch-decks'],
    queryFn: async () => {
      return [
        {
          id: 1,
          title: 'Series A Pitch Deck',
          description: 'Fundraising presentation for Series A round',
          slides: [],
          status: 'draft' as const,
          viewCount: 0,
          createdAt: new Date(),
          updatedAt: new Date(),
        }
      ];
    }
  });

  const { data: investorUpdates = [], isLoading: investorUpdatesLoading } = useQuery<InvestorUpdate[]>({
    queryKey: ['/api/founder-ops/investor-updates'],
    queryFn: async () => {
      return [
        {
          id: 1,
          title: 'Q4 2024 Update',
          content: 'Monthly investor update with key metrics and milestones',
          updateType: 'milestones' as const,
          status: 'draft' as const,
          createdAt: new Date(),
        }
      ];
    }
  });

  const { data: templates = [], isLoading: templatesLoading } = useQuery<Template[]>({
    queryKey: ['/api/founder-ops/templates'],
    queryFn: async () => {
      return [
        {
          id: 1,
          name: 'Standard Invoice Template',
          category: 'ops' as const,
          templateType: 'invoice' as const,
          usageCount: 15,
          isPublic: true,
          createdAt: new Date(),
          content: {
            title: 'Professional Invoice Template',
            sections: [
              { type: 'header', content: 'INVOICE' },
              { type: 'company_info', content: '{{company_name}}\n{{company_address}}\n{{company_email}}' },
              { type: 'client_info', content: 'Bill To:\n{{client_name}}\n{{client_address}}' },
              { type: 'invoice_details', content: 'Invoice #: {{invoice_number}}\nDate: {{date}}\nDue Date: {{due_date}}' },
              { type: 'line_items', content: 'Description | Quantity | Rate | Amount' },
              { type: 'totals', content: 'Subtotal: {{subtotal}}\nTax: {{tax}}\nTotal: {{total}}' },
              { type: 'footer', content: 'Payment Terms: {{payment_terms}}\nThank you for your business!' }
            ]
          },
          variables: ['company_name', 'company_address', 'company_email', 'client_name', 'client_address', 'invoice_number', 'date', 'due_date', 'subtotal', 'tax', 'total', 'payment_terms']
        },
        {
          id: 2,
          name: 'Series A Pitch Template',
          category: 'fundraising' as const,
          templateType: 'pitch_deck' as const,
          usageCount: 8,
          isPublic: true,
          createdAt: new Date(),
          content: {
            title: 'Series A Fundraising Deck',
            slides: [
              { title: 'Company Overview', content: '{{company_name}} - {{tagline}}' },
              { title: 'Problem', content: 'The problem we solve: {{problem_statement}}' },
              { title: 'Solution', content: 'Our solution: {{solution_description}}' },
              { title: 'Market Opportunity', content: 'Total Addressable Market: {{tam}}' },
              { title: 'Business Model', content: 'Revenue Model: {{revenue_model}}' },
              { title: 'Traction', content: 'Key Metrics: {{key_metrics}}' },
              { title: 'Competition', content: 'Competitive Landscape: {{competition_analysis}}' },
              { title: 'Team', content: 'Founding Team: {{team_bios}}' },
              { title: 'Financials', content: 'Revenue Projections: {{financial_projections}}' },
              { title: 'Funding Ask', content: 'Seeking: {{funding_amount}} for {{use_of_funds}}' }
            ]
          },
          variables: ['company_name', 'tagline', 'problem_statement', 'solution_description', 'tam', 'revenue_model', 'key_metrics', 'competition_analysis', 'team_bios', 'financial_projections', 'funding_amount', 'use_of_funds']
        },
        {
          id: 3,
          name: 'Employee W-2 Form',
          category: 'hr' as const,
          templateType: 'document' as const,
          usageCount: 23,
          isPublic: true,
          createdAt: new Date(),
          content: {
            title: 'Form W-2 Wage and Tax Statement',
            sections: [
              { type: 'header', content: 'Form W-2 - Wage and Tax Statement' },
              { type: 'employer_info', content: 'Employer: {{company_name}}\nEIN: {{ein}}\nAddress: {{company_address}}' },
              { type: 'employee_info', content: 'Employee: {{employee_name}}\nSSN: {{ssn}}\nAddress: {{employee_address}}' },
              { type: 'wages', content: 'Wages, tips, compensation: ${{total_wages}}' },
              { type: 'taxes', content: 'Federal income tax withheld: ${{federal_tax}}\nSocial security wages: ${{ss_wages}}\nSocial security tax withheld: ${{ss_tax}}\nMedicare wages: ${{medicare_wages}}\nMedicare tax withheld: ${{medicare_tax}}' }
            ]
          },
          variables: ['company_name', 'ein', 'company_address', 'employee_name', 'ssn', 'employee_address', 'total_wages', 'federal_tax', 'ss_wages', 'ss_tax', 'medicare_wages', 'medicare_tax']
        },
        {
          id: 4,
          name: 'Monthly Investor Update',
          category: 'fundraising' as const,
          templateType: 'investor_update' as const,
          usageCount: 12,
          isPublic: true,
          createdAt: new Date(),
          content: {
            title: 'Monthly Investor Update - {{month}} {{year}}',
            sections: [
              { type: 'summary', content: 'Executive Summary:\n{{executive_summary}}' },
              { type: 'metrics', content: 'Key Metrics:\n• Revenue: {{revenue}}\n• Users: {{user_count}}\n• MRR: {{mrr}}\n• Burn Rate: {{burn_rate}}' },
              { type: 'highlights', content: 'This Month\'s Highlights:\n{{highlights}}' },
              { type: 'challenges', content: 'Challenges & Learnings:\n{{challenges}}' },
              { type: 'team', content: 'Team Updates:\n{{team_updates}}' },
              { type: 'financials', content: 'Financial Update:\n• Cash on Hand: {{cash_balance}}\n• Runway: {{runway_months}} months' },
              { type: 'asks', content: 'How You Can Help:\n{{investor_asks}}' }
            ]
          },
          variables: ['month', 'year', 'executive_summary', 'revenue', 'user_count', 'mrr', 'burn_rate', 'highlights', 'challenges', 'team_updates', 'cash_balance', 'runway_months', 'investor_asks']
        },
        {
          id: 5,
          name: 'Contractor 1099 Form',
          category: 'hr' as const,
          templateType: 'document' as const,
          usageCount: 18,
          isPublic: true,
          createdAt: new Date(),
          content: {
            title: 'Form 1099-NEC Nonemployee Compensation',
            sections: [
              { type: 'header', content: 'Form 1099-NEC - Nonemployee Compensation' },
              { type: 'payer_info', content: 'Payer: {{company_name}}\nEIN: {{ein}}\nAddress: {{company_address}}' },
              { type: 'recipient_info', content: 'Recipient: {{contractor_name}}\nTIN: {{tin}}\nAddress: {{contractor_address}}' },
              { type: 'compensation', content: 'Nonemployee compensation: ${{total_compensation}}' },
              { type: 'backup_withholding', content: 'Federal income tax withheld: ${{backup_withholding}}' }
            ]
          },
          variables: ['company_name', 'ein', 'company_address', 'contractor_name', 'tin', 'contractor_address', 'total_compensation', 'backup_withholding']
        }
      ];
    }
  });

  // Calculate totals for dashboard overview
  const totalRevenue = invoices.reduce((sum, inv) => sum + (inv.status === 'paid' ? inv.totalAmount : 0), 0);
  const pendingRevenue = invoices.reduce((sum, inv) => sum + (inv.status === 'unpaid' ? inv.totalAmount : 0), 0);
  const overdueRevenue = invoices.reduce((sum, inv) => sum + (inv.status === 'overdue' ? inv.totalAmount : 0), 0);

  const formatCurrency = (cents: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(cents / 100);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-green-100 text-green-800 border-green-200';
      case 'unpaid': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'overdue': return 'bg-red-100 text-red-800 border-red-200';
      case 'draft': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'completed': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'sent': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="flex h-full bg-gray-50/50">
      {/* Left Sidebar Navigation */}
      <div className="w-64 bg-white border-r border-gray-200 p-4">
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-1">Founder Operations</h2>
          <p className="text-sm text-gray-500">Business management hub</p>
        </div>

        <nav className="space-y-2">
          <Button
            variant={activeModule === 'invoicing' ? 'default' : 'ghost'}
            className="w-full justify-start h-10"
            onClick={() => setActiveModule('invoicing')}
          >
            <DollarSign className="h-4 w-4 mr-3" />
            Invoicing & Payments
          </Button>
          <Button
            variant={activeModule === 'payroll' ? 'default' : 'ghost'}
            className="w-full justify-start h-10"
            onClick={() => setActiveModule('payroll')}
          >
            <Users className="h-4 w-4 mr-3" />
            Payroll & Compliance
          </Button>
          <Button
            variant={activeModule === 'investor' ? 'default' : 'ghost'}
            className="w-full justify-start h-10"
            onClick={() => setActiveModule('investor')}
          >
            <TrendingUp className="h-4 w-4 mr-3" />
            Investor Relations
          </Button>
          <Button
            variant={activeModule === 'templates' ? 'default' : 'ghost'}
            className="w-full justify-start h-10"
            onClick={() => setActiveModule('templates')}
          >
            <FileText className="h-4 w-4 mr-3" />
            Template Library
          </Button>
        </nav>

        {/* Quick Stats */}
        <div className="mt-8 space-y-4">
          <div className="bg-gray-50 rounded-lg p-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Total Revenue</span>
              <span className="text-sm font-bold text-green-600">{formatCurrency(totalRevenue)}</span>
            </div>
          </div>
          <div className="bg-gray-50 rounded-lg p-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Pending</span>
              <span className="text-sm font-bold text-yellow-600">{formatCurrency(pendingRevenue)}</span>
            </div>
          </div>
          <div className="bg-gray-50 rounded-lg p-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Active Employees</span>
              <span className="text-sm font-bold text-blue-600">{employees.filter(e => e.isActive).length}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-auto">
        {/* Invoicing & Payments Module */}
        {activeModule === 'invoicing' && (
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Invoicing & Payments</h1>
                <p className="text-gray-600">Manage client invoices and track payments</p>
              </div>
              <Button onClick={() => setIsCreateInvoiceOpen(true)} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                Create Invoice
              </Button>
            </div>

            {/* Revenue Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card className="bg-gradient-to-r from-green-50 to-green-100 border-green-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-green-600">Paid This Month</p>
                      <p className="text-2xl font-bold text-green-700">{formatCurrency(totalRevenue)}</p>
                    </div>
                    <CheckCircle className="h-8 w-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-yellow-600">Pending Payment</p>
                      <p className="text-2xl font-bold text-yellow-700">{formatCurrency(pendingRevenue)}</p>
                    </div>
                    <Clock className="h-8 w-8 text-yellow-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-red-50 to-red-100 border-red-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-red-600">Overdue</p>
                      <p className="text-2xl font-bold text-red-700">{formatCurrency(overdueRevenue)}</p>
                    </div>
                    <AlertCircle className="h-8 w-8 text-red-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-blue-600">Total Invoices</p>
                      <p className="text-2xl font-bold text-blue-700">{invoices.length}</p>
                    </div>
                    <Receipt className="h-8 w-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Invoices Table */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Invoices</CardTitle>
                <CardDescription>Manage and track your client invoices</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {invoices.map((invoice) => (
                    <div key={invoice.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <Receipt className="h-4 w-4 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{invoice.invoiceNumber}</p>
                          <p className="text-sm text-gray-500">{invoice.clientName} • {invoice.service}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <Badge className={getStatusColor(invoice.status)}>
                          {invoice.status}
                        </Badge>
                        <div className="text-right">
                          <p className="font-medium text-gray-900">{formatCurrency(invoice.totalAmount)}</p>
                          <p className="text-sm text-gray-500">
                            {invoice.hours ? `${invoice.hours}h × ${formatCurrency(invoice.rate || 0)}` : 'Fixed price'}
                          </p>
                        </div>
                        <div className="flex space-x-1">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Download className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Send className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Payroll & Compliance Module */}
        {activeModule === 'payroll' && (
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Payroll & Compliance</h1>
                <p className="text-gray-600">Manage employees and generate payroll documents</p>
              </div>
              <Button onClick={() => setIsCreateEmployeeOpen(true)} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                Add Employee
              </Button>
            </div>

            {/* Employee Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Active Employees</p>
                      <p className="text-2xl font-bold text-gray-900">{employees.filter(e => e.employeeType === 'employee' && e.isActive).length}</p>
                    </div>
                    <UserCheck className="h-8 w-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Contractors</p>
                      <p className="text-2xl font-bold text-gray-900">{employees.filter(e => e.employeeType === 'contractor' && e.isActive).length}</p>
                    </div>
                    <Users className="h-8 w-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Monthly Payroll</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {formatCurrency(employees.reduce((sum, emp) => sum + (emp.hourlyRate || 0) * 160, 0))}
                      </p>
                    </div>
                    <Calculator className="h-8 w-8 text-purple-600" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Employees List */}
            <Card>
              <CardHeader>
                <CardTitle>Team Members</CardTitle>
                <CardDescription>Manage employee information and payroll</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {employees.map((employee) => (
                    <div key={employee.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className={`p-2 rounded-lg ${employee.employeeType === 'employee' ? 'bg-blue-100' : 'bg-green-100'}`}>
                          <Users className={`h-4 w-4 ${employee.employeeType === 'employee' ? 'text-blue-600' : 'text-green-600'}`} />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{employee.firstName} {employee.lastName}</p>
                          <p className="text-sm text-gray-500">{employee.email} • {employee.employeeType}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <Badge className={employee.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                          {employee.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                        <div className="text-right">
                          <p className="font-medium text-gray-900">{formatCurrency(employee.hourlyRate || 0)}/hr</p>
                          <p className="text-sm text-gray-500">{employee.paymentCycle}</p>
                        </div>
                        <div className="flex space-x-1">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => {
                              setSelectedEmployee(employee);
                              setIsPayrollDocumentOpen(true);
                            }}
                          >
                            <FileText className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Investor Relations Module */}
        {activeModule === 'investor' && (
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Investor Relations</h1>
                <p className="text-gray-600">Manage pitch decks and investor communications</p>
              </div>
              <div className="flex space-x-2">
                <Button onClick={() => setIsCreatePitchDeckOpen(true)} variant="outline">
                  <Presentation className="h-4 w-4 mr-2" />
                  New Pitch Deck
                </Button>
                <Button onClick={() => setIsCreateUpdateOpen(true)} className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Investor Update
                </Button>
              </div>
            </div>

            <Tabs defaultValue="pitch-decks" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="pitch-decks">Pitch Decks</TabsTrigger>
                <TabsTrigger value="investor-updates">Investor Updates</TabsTrigger>
              </TabsList>

              <TabsContent value="pitch-decks" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Pitch Decks</CardTitle>
                    <CardDescription>Create and manage fundraising presentations</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {pitchDecks.map((deck) => (
                        <div key={deck.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                          <div className="flex items-center space-x-4">
                            <div className="p-2 bg-purple-100 rounded-lg">
                              <Presentation className="h-4 w-4 text-purple-600" />
                            </div>
                            <div>
                              <p className="font-medium text-gray-900">{deck.title}</p>
                              <p className="text-sm text-gray-500">{deck.description}</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-4">
                            <Badge className={getStatusColor(deck.status)}>
                              {deck.status}
                            </Badge>
                            <div className="text-right">
                              <p className="font-medium text-gray-900">{deck.viewCount} views</p>
                              <p className="text-sm text-gray-500">{deck.slides.length} slides</p>
                            </div>
                            <div className="flex space-x-1">
                              <Button variant="ghost" size="sm">
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Download className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="investor-updates" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Investor Updates</CardTitle>
                    <CardDescription>Regular communications with your investors</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {investorUpdates.map((update) => (
                        <div key={update.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                          <div className="flex items-center space-x-4">
                            <div className="p-2 bg-orange-100 rounded-lg">
                              <Mail className="h-4 w-4 text-orange-600" />
                            </div>
                            <div>
                              <p className="font-medium text-gray-900">{update.title}</p>
                              <p className="text-sm text-gray-500">{update.updateType} • {update.content.slice(0, 60)}...</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-4">
                            <Badge className={getStatusColor(update.status)}>
                              {update.status}
                            </Badge>
                            <div className="text-right">
                              <p className="font-medium text-gray-900">
                                {update.sentDate ? update.sentDate.toLocaleDateString() : 'Not sent'}
                              </p>
                              <p className="text-sm text-gray-500">{update.updateType}</p>
                            </div>
                            <div className="flex space-x-1">
                              <Button variant="ghost" size="sm">
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Send className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        )}

        {/* Template Library Module */}
        {activeModule === 'templates' && (
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Template Library</h1>
                <p className="text-gray-600">Pre-built templates for common business documents</p>
              </div>
              <div className="flex space-x-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input placeholder="Search templates..." className="pl-10 w-64" />
                </div>
                <Button variant="outline">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
              </div>
            </div>

            {/* Template Categories */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
              {['fundraising', 'legal', 'hr', 'ops', 'product'].map((category) => (
                <Card key={category} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-4 text-center">
                    <div className="p-2 bg-blue-100 rounded-lg w-fit mx-auto mb-2">
                      <FileText className="h-6 w-6 text-blue-600" />
                    </div>
                    <p className="font-medium text-gray-900 capitalize">{category}</p>
                    <p className="text-sm text-gray-500">
                      {templates.filter(t => t.category === category).length} templates
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Templates Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {templates.map((template) => (
                <Card key={template.id} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="p-2 bg-gray-100 rounded-lg">
                        <FileText className="h-4 w-4 text-gray-600" />
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {template.category}
                      </Badge>
                    </div>
                    <h3 className="font-medium text-gray-900 mb-2">{template.name}</h3>
                    <p className="text-sm text-gray-500 mb-3">
                      Used {template.usageCount} times • {template.templateType}
                    </p>
                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1"
                        onClick={() => {
                          setSelectedTemplate(template);
                          setIsTemplatePreviewOpen(true);
                        }}
                      >
                        <Eye className="h-3 w-3 mr-1" />
                        Preview
                      </Button>
                      <Button size="sm" className="flex-1">
                        <Copy className="h-3 w-3 mr-1" />
                        Use Template
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Template Preview Modal */}
      <Dialog open={isTemplatePreviewOpen} onOpenChange={setIsTemplatePreviewOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              {selectedTemplate?.name}
            </DialogTitle>
            <DialogDescription>
              Template preview with customizable variables
            </DialogDescription>
          </DialogHeader>
          
          {selectedTemplate && (
            <div className="space-y-6">
              {/* Template Info */}
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{selectedTemplate.name}</p>
                  <p className="text-sm text-gray-500">
                    {selectedTemplate.category} • {selectedTemplate.templateType} • Used {selectedTemplate.usageCount} times
                  </p>
                </div>
                <Badge variant={selectedTemplate.isPublic ? "default" : "secondary"}>
                  {selectedTemplate.isPublic ? "Public" : "Private"}
                </Badge>
              </div>

              {/* Template Content */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Variables Panel */}
                <div className="space-y-4">
                  <h3 className="font-medium text-gray-900">Template Variables</h3>
                  <div className="space-y-3">
                    {selectedTemplate.variables?.map((variable, index) => (
                      <div key={index} className="flex flex-col space-y-1">
                        <label className="text-sm font-medium text-gray-700">
                          {variable.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </label>
                        <input
                          type="text"
                          placeholder={`Enter ${variable.replace(/_/g, ' ')}`}
                          className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Preview Panel */}
                <div className="space-y-4">
                  <h3 className="font-medium text-gray-900">Preview</h3>
                  <div className="border border-gray-200 rounded-lg p-4 bg-white min-h-[400px]">
                    {selectedTemplate.content?.title && (
                      <h2 className="text-xl font-bold mb-4">{selectedTemplate.content.title}</h2>
                    )}
                    
                    {selectedTemplate.content?.sections && (
                      <div className="space-y-4">
                        {selectedTemplate.content.sections.map((section: any, index: number) => (
                          <div key={index} className="border-b border-gray-100 pb-3">
                            <div className="text-sm text-gray-600 mb-1 uppercase tracking-wide">
                              {section.type.replace(/_/g, ' ')}
                            </div>
                            <div className="whitespace-pre-line text-gray-900">
                              {section.content}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {selectedTemplate.content?.slides && (
                      <div className="space-y-4">
                        {selectedTemplate.content.slides.map((slide: any, index: number) => (
                          <div key={index} className="border border-gray-200 rounded p-3">
                            <h4 className="font-medium text-gray-900 mb-2">
                              Slide {index + 1}: {slide.title}
                            </h4>
                            <p className="text-sm text-gray-600">{slide.content}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex justify-end space-x-3 pt-4 border-t">
                <Button variant="outline" onClick={() => setIsTemplatePreviewOpen(false)}>
                  Close
                </Button>
                <Button>
                  <Copy className="h-4 w-4 mr-2" />
                  Use This Template
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Payroll Document Generation Modal */}
      <Dialog open={isPayrollDocumentOpen} onOpenChange={setIsPayrollDocumentOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Generate Payroll Document
            </DialogTitle>
            <DialogDescription>
              {selectedEmployee ? `Generate documents for ${selectedEmployee.firstName} ${selectedEmployee.lastName}` : 'Select document type to generate'}
            </DialogDescription>
          </DialogHeader>
          
          {selectedEmployee && (
            <div className="space-y-6">
              {/* Employee Info */}
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-gray-900">
                      {selectedEmployee.firstName} {selectedEmployee.lastName}
                    </h3>
                    <p className="text-sm text-gray-500">{selectedEmployee.email}</p>
                  </div>
                  <Badge variant={selectedEmployee.employeeType === 'employee' ? 'default' : 'secondary'}>
                    {selectedEmployee.employeeType}
                  </Badge>
                </div>
                <div className="mt-2 grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">Rate:</span> {formatCurrency(selectedEmployee.hourlyRate || 0)}/hr
                  </div>
                  <div>
                    <span className="text-gray-500">Cycle:</span> {selectedEmployee.paymentCycle}
                  </div>
                </div>
              </div>

              {/* Document Type Selection */}
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Select Document Type</h4>
                <div className="grid grid-cols-1 gap-3">
                  {selectedEmployee.employeeType === 'employee' ? (
                    <>
                      <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                        <div className="flex items-center space-x-3">
                          <FileText className="h-5 w-5 text-blue-500" />
                          <div>
                            <p className="font-medium text-gray-900">W-2 Form</p>
                            <p className="text-sm text-gray-500">Annual wage and tax statement</p>
                          </div>
                        </div>
                        <Button size="sm">Generate</Button>
                      </div>
                      
                      <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                        <div className="flex items-center space-x-3">
                          <FileText className="h-5 w-5 text-green-500" />
                          <div>
                            <p className="font-medium text-gray-900">Paystub</p>
                            <p className="text-sm text-gray-500">Pay period statement</p>
                          </div>
                        </div>
                        <Button size="sm">Generate</Button>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                        <div className="flex items-center space-x-3">
                          <FileText className="h-5 w-5 text-purple-500" />
                          <div>
                            <p className="font-medium text-gray-900">1099-NEC Form</p>
                            <p className="text-sm text-gray-500">Nonemployee compensation</p>
                          </div>
                        </div>
                        <Button size="sm">Generate</Button>
                      </div>
                      
                      <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                        <div className="flex items-center space-x-3">
                          <FileText className="h-5 w-5 text-orange-500" />
                          <div>
                            <p className="font-medium text-gray-900">Invoice</p>
                            <p className="text-sm text-gray-500">Contractor payment request</p>
                          </div>
                        </div>
                        <Button size="sm">Generate</Button>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* Recent Documents */}
              <div className="space-y-3">
                <h4 className="font-medium text-gray-900">Recent Documents</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <FileText className="h-4 w-4 text-gray-400" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {selectedEmployee.employeeType === 'employee' ? 'W-2 Form 2024' : '1099-NEC 2024'}
                        </p>
                        <p className="text-xs text-gray-500">Generated Dec 15, 2024</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex justify-end space-x-3 pt-4 border-t">
                <Button variant="outline" onClick={() => setIsPayrollDocumentOpen(false)}>
                  Close
                </Button>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Generate New Document
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}