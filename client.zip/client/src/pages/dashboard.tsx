import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Calendar } from "@/components/ui/calendar";
import { useLocation } from "wouter";
import {
  CheckCircle2,
  Clock,
  Users,
  MessageSquare,
  FileText,
  Lightbulb,
  GitBranch,
  FolderOpen,
  TrendingUp,
  Plus,
  ExternalLink,
  Target,
  BarChart3,
  Archive,
  AlertTriangle,
  Circle,
  Layers,
  Star,
  Activity,
  Book,
  LayoutDashboard,
  ArrowRight,
  Play,
  Pause,
  Eye,
  Focus,
  CalendarDays,
  Search,
  Map,
} from "lucide-react";
import { Node, NodeLink } from "@shared/schema";
import RichTextJournal from "@/components/rich-text-journal";

/* ── Types ──────────────────────────────────────────── */
interface DashboardTask {
  id: number;
  title: string;
  priority: "high" | "medium" | "low" | "neutral";
  status: "todo" | "in_progress" | "done";
  dueDate?: Date;
  assignedTo?: string;
  nodeId: number;
}

interface MentionItem {
  id: number;
  nodeTitle: string;
  content: string;
  timestamp: Date;
  nodeId: number;
  type: "comment" | "mention" | "update";
}

/* ── Helper functions ────────────────────────────────── */
function getPriorityFromTags(tags: string[] | null): "high" | "medium" | "low" | "neutral" {
  if (!tags) return "neutral";
  if (tags.includes("high") || tags.includes("urgent")) return "high";
  if (tags.includes("medium")) return "medium";
  if (tags.includes("low")) return "low";
  return "neutral";
}

function getStatusFromContent(content: string | null): "todo" | "in_progress" | "done" {
  if (!content) return "todo";
  const lower = content.toLowerCase();
  if (lower.includes("done") || lower.includes("completed")) return "done";
  if (lower.includes("in progress") || lower.includes("working")) return "in_progress";
  return "todo";
}

function getDueDateFromContent(content: string | null): Date | undefined {
  if (!content) return undefined;
  const m = content.match(/due:?\s*(\d{4}-\d{2}-\d{2})/i);
  return m ? new Date(m[1]) : undefined;
}

function getAssignedFromContent(content: string | null): string | undefined {
  if (!content) return undefined;
  const m = content.match(/assigned:?\s*(\w+)/i);
  return m ? m[1] : undefined;
}

function generateMentions(nodes: Node[]): MentionItem[] {
  return nodes.slice(0, 10).map((node, i) => ({
    id: i + 1,
    nodeTitle: node.title,
    content: `You were mentioned in "${node.title}"`,
    timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
    nodeId: node.id,
    type: (["comment", "mention", "update"] as const)[Math.floor(Math.random() * 3)],
  }));
}

function formatRelativeTime(date: Date): string {
  const diff = Date.now() - date.getTime();
  const m = Math.floor(diff / 60000);
  const h = Math.floor(diff / 3600000);
  const d = Math.floor(diff / 86400000);
  if (m < 60) return `${m}m ago`;
  if (h < 24) return `${h}h ago`;
  return `${d}d ago`;
}

function isSameDay(a: Date, b: Date) {
  return a.toDateString() === b.toDateString();
}

/* ── Node icon map ───────────────────────────────────── */
const NODE_ICONS: Record<string, React.ElementType> = {
  task: CheckCircle2,
  note: FileText,
  meeting: Users,
  journal: Book,
  file: FolderOpen,
  chat: MessageSquare,
  idea: Lightbulb,
  link: GitBranch,
};

const NODE_COLORS: Record<string, string> = {
  task:    "#818cf8",
  note:    "#34d399",
  meeting: "#fb923c",
  journal: "#38bdf8",
  file:    "#f472b6",
  chat:    "#a78bfa",
  idea:    "#c084fc",
  link:    "#fbbf24",
};

function NodeIcon({ type, size = 14 }: { type: string; size?: number }) {
  const Icon = NODE_ICONS[type] || Layers;
  const color = NODE_COLORS[type] || "#666";
  return <Icon size={size} style={{ color }} />;
}

/* ── Priority indicator ──────────────────────────────── */
function PriorityDot({ priority }: { priority: string }) {
  const colors: Record<string, string> = {
    high: "#f87171",
    medium: "#fb923c",
    low: "#4ade80",
    neutral: "#52525b",
  };
  return (
    <div
      className="w-2 h-2 rounded-full flex-shrink-0"
      style={{ background: colors[priority] || colors.neutral }}
    />
  );
}

/* ── Status badge ────────────────────────────────────── */
function StatusPill({ status }: { status: string }) {
  const config: Record<string, { label: string; color: string; bg: string }> = {
    todo:        { label: "To do",       color: "#9ca3af", bg: "rgba(156,163,175,0.1)" },
    in_progress: { label: "In progress", color: "#818cf8", bg: "rgba(129,140,248,0.1)" },
    done:        { label: "Done",        color: "#4ade80", bg: "rgba(74,222,128,0.1)"  },
  };
  const c = config[status] || config.todo;
  return (
    <span
      className="inline-flex items-center text-[10px] font-semibold px-2 py-0.5 rounded-full"
      style={{ color: c.color, background: c.bg }}
    >
      {c.label}
    </span>
  );
}

/* ── Stat card ───────────────────────────────────────── */
function StatCard({ icon: Icon, label, value, sub, color }: {
  icon: React.ElementType; label: string; value: string | number; sub?: string; color: string;
}) {
  return (
    <div className="rounded-xl p-4 border border-border bg-card flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground font-medium">{label}</span>
        <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${color}18` }}>
          <Icon size={14} style={{ color }} />
        </div>
      </div>
      <div>
        <div className="text-2xl font-bold text-foreground tracking-tight">{value}</div>
        {sub && <div className="text-[11px] text-muted-foreground mt-0.5">{sub}</div>}
      </div>
    </div>
  );
}

/* ── Section header ──────────────────────────────────── */
function SectionHeader({ icon: Icon, title, action }: {
  icon: React.ElementType; title: string; action?: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between mb-3">
      <div className="flex items-center gap-2">
        <Icon size={14} className="text-muted-foreground" />
        <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">{title}</span>
      </div>
      {action}
    </div>
  );
}

/* ── Section card ────────────────────────────────────── */
function Section({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={`rounded-xl border border-border bg-card p-4 ${className}`}
    >
      {children}
    </div>
  );
}

/* ── Task row ────────────────────────────────────────── */
function TaskRow({ task }: { task: DashboardTask }) {
  return (
    <div
      className="flex items-center gap-3 px-3 py-2.5 rounded-lg border border-border/60 bg-background/40 transition-colors cursor-pointer hover:border-border hover:bg-accent/30"
    >
      <PriorityDot priority={task.priority} />
      <div className="flex-1 min-w-0">
        <p className="text-sm text-foreground truncate font-medium">{task.title}</p>
        {task.dueDate && (
          <p className="text-[11px] text-muted-foreground flex items-center gap-1 mt-0.5">
            <Clock size={10} /> {task.dueDate.toLocaleDateString()}
          </p>
        )}
      </div>
      <StatusPill status={task.status} />
    </div>
  );
}

/* ── Node row ────────────────────────────────────────── */
function NodeRow({ node, onClick }: { node: Node; onClick: () => void }) {
  return (
    <div
      className="flex items-center gap-3 px-3 py-2.5 rounded-lg border border-border/60 bg-background/40 transition-colors cursor-pointer hover:border-border hover:bg-accent/30"
      onClick={onClick}
    >
      <NodeIcon type={node.nodeType} />
      <span className="flex-1 text-sm text-foreground truncate font-medium">{node.title}</span>
      <span className="text-[10px] text-muted-foreground capitalize">{node.nodeType}</span>
    </div>
  );
}

/* ── Focus mode ──────────────────────────────────────── */
function FocusMode({ tasks, onExit }: { tasks: DashboardTask[]; onExit: () => void }) {
  const [timer, setTimer] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const active = tasks.filter(t => t.status === "in_progress");
  const mins = String(Math.floor(timer / 60)).padStart(2, "0");
  const secs = String(timer % 60).padStart(2, "0");

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background">
      <div className="w-full max-w-lg space-y-6 px-6">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold text-foreground">Focus Mode</h1>
          <button
            onClick={onExit}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground border border-border px-3 py-1.5 rounded-lg transition-colors"
          >
            <Eye size={14} /> Exit
          </button>
        </div>

        <div className="rounded-2xl border border-border bg-card p-8 text-center">
          <div className="text-6xl font-mono font-bold text-foreground mb-6">{mins}:{secs}</div>
          <div className="flex justify-center gap-3">
            <button
              onClick={() => setRunning(!running)}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors"
            >
              {running ? <Pause size={14} /> : <Play size={14} />}
              {running ? "Pause" : "Start"}
            </button>
            <button
              onClick={() => setTimer(25 * 60)}
              className="text-sm text-muted-foreground hover:text-foreground border border-border px-4 py-2 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>

        {active.length > 0 && (
          <Section>
            <SectionHeader icon={Target} title="Active tasks" />
            <div className="space-y-2">
              {active.map(t => <TaskRow key={t.id} task={t} />)}
            </div>
          </Section>
        )}
      </div>
    </div>
  );
}

/* ── Main Dashboard ──────────────────────────────────── */
export default function Dashboard() {
  const [focusMode, setFocusMode] = useState(false);
  const [taskFilter, setTaskFilter] = useState<"all" | "today" | "overdue">("all");
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [recentRooms, setRecentRooms] = useState<{ id: string; name: string; description?: string; template?: string }[]>([]);
  const [, navigate] = useLocation();

  useEffect(() => {
    try {
      const stored = localStorage.getItem("planning-rooms");
      if (stored) setRecentRooms(JSON.parse(stored).slice(0, 4));
    } catch { /* ignore */ }
  }, []);

  const { data: nodes = [] } = useQuery<Node[]>({ queryKey: ["/api/nodes"] });
  const { data: nodeLinks = [] } = useQuery<NodeLink[]>({ queryKey: ["/api/node-links"] });

  const dashboardTasks: DashboardTask[] = nodes
    .filter(n => n.nodeType === "task")
    .map(n => ({
      id: n.id,
      title: n.title,
      priority: getPriorityFromTags(n.tags),
      status: getStatusFromContent(n.content),
      dueDate: getDueDateFromContent(n.content),
      assignedTo: getAssignedFromContent(n.content),
      nodeId: n.id,
    }));

  const mentionsData: MentionItem[] = generateMentions(nodes);

  const dormantNodes = nodes
    .filter(n => {
      const days = Math.floor((Date.now() - new Date(n.updatedAt).getTime()) / 86400000);
      return days > 7;
    })
    .slice(0, 6);

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(today.getTime() - 86400000);
  const weekStart = new Date(today.getTime() - today.getDay() * 86400000);

  const todayNodes = nodes.filter(n => new Date(n.createdAt) >= today).slice(0, 5);
  const recentNodes = nodes
    .slice()
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 8);

  const taskStats = {
    total: dashboardTasks.length,
    done: dashboardTasks.filter(t => t.status === "done").length,
    inProgress: dashboardTasks.filter(t => t.status === "in_progress").length,
    overdue: dashboardTasks.filter(t => t.dueDate && t.dueDate < now && t.status !== "done").length,
  };
  const completion = taskStats.total > 0 ? Math.round((taskStats.done / taskStats.total) * 100) : 0;

  const filteredTasks = dashboardTasks
    .filter(t => {
      if (taskFilter === "today") return t.dueDate && isSameDay(t.dueDate, now);
      if (taskFilter === "overdue") return t.dueDate && t.dueDate < now && t.status !== "done";
      return true;
    })
    .slice(0, 10);

  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  // Calendar events: meetings with scheduledFor + tasks with due dates
  const calendarEvents = [
    ...nodes
      .filter(n => n.nodeType === "meeting" && n.scheduledFor)
      .map(n => ({ date: new Date(n.scheduledFor!), title: n.title, type: "meeting" as const })),
    ...dashboardTasks
      .filter(t => t.dueDate)
      .map(t => ({ date: t.dueDate!, title: t.title, type: "task" as const })),
  ];

  // Events on the selected date
  const eventsOnSelected = selectedDate
    ? calendarEvents.filter(e => isSameDay(e.date, selectedDate))
    : [];

  // Dates with events (for dot indicators)
  const datesWithEvents = new Set(calendarEvents.map(e => e.date.toDateString()));

  const updateNodeCoreMutation = useMutation({
    mutationFn: async ({ nodeId, isCore }: { nodeId: number; isCore: boolean }) =>
      apiRequest(`/api/nodes/${nodeId}`, { method: "PATCH", body: JSON.stringify({ isCore }) }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/nodes"] }),
  });

  const navigateToNode = (node: Node) => {
    setSelectedNode(null);
    navigate(node.nodeType === "file" ? "/workspace" : node.nodeType === "chat" ? "/chat" : `/graph?focus=${node.id}`);
  };

  const hour = now.getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";

  if (focusMode) {
    return <FocusMode tasks={dashboardTasks} onExit={() => setFocusMode(false)} />;
  }

  return (
    <div className="min-h-screen p-5 sm:p-6 bg-background">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* ── Header ─────────────────────────────────────── */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-foreground tracking-tight">{greeting}</h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              {now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFocusMode(true)}
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground border border-border hover:border-border/70 px-3.5 py-2 rounded-lg transition-colors"
            >
              <Focus size={14} /> Focus Mode
            </button>
            <button
              onClick={() => navigate("/graph")}
              className="flex items-center gap-2 text-sm font-medium bg-indigo-600 hover:bg-indigo-500 text-white px-3.5 py-2 rounded-lg transition-colors"
            >
              <GitBranch size={14} /> Open Graph
            </button>
          </div>
        </div>

        {/* ── Stats row ──────────────────────────────────── */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <StatCard icon={Layers}      label="Total Nodes"   value={nodes.length}         sub={`${todayNodes.length} added today`} color="#818cf8" />
          <StatCard icon={CheckCircle2} label="Tasks"         value={taskStats.total}      sub={`${taskStats.inProgress} in progress`} color="#34d399" />
          <StatCard icon={TrendingUp}  label="Completion"    value={`${completion}%`}     sub={`${taskStats.done} of ${taskStats.total} done`} color="#fb923c" />
          <StatCard icon={Activity}    label="Connections"   value={nodeLinks.length}     sub="node links" color="#38bdf8" />
        </div>

        {/* ── Tabs ───────────────────────────────────────── */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList
            className="mb-6 h-9 p-1 rounded-lg bg-card border border-border"
          >
            <TabsTrigger
              value="overview"
              className="text-xs font-medium data-[state=active]:bg-accent data-[state=active]:text-foreground text-muted-foreground rounded-md px-4 h-7 flex items-center gap-1.5"
            >
              <LayoutDashboard size={12} /> Overview
            </TabsTrigger>
            <TabsTrigger
              value="journal"
              className="text-xs font-medium data-[state=active]:bg-accent data-[state=active]:text-foreground text-muted-foreground rounded-md px-4 h-7 flex items-center gap-1.5"
            >
              <Book size={12} /> Journal
            </TabsTrigger>
          </TabsList>

          {/* ── Overview tab ─────────────────────────────── */}
          <TabsContent value="overview" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

              {/* Left column — 2/3 */}
              <div className="lg:col-span-2 space-y-4">

                {/* Task Overview */}
                <Section>
                  <SectionHeader
                    icon={CheckCircle2}
                    title="Tasks"
                    action={
                      <button
                        onClick={() => navigate("/tasks")}
                        className="text-[10px] text-muted-foreground hover:text-indigo-400 flex items-center gap-1 transition-colors"
                      >
                        View all <ArrowRight size={10} />
                      </button>
                    }
                  />

                  {/* Completion bar */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1.5">
                      <span>{taskStats.done} completed</span>
                      <span>{completion}%</span>
                    </div>
                    <div className="h-1.5 rounded-full overflow-hidden bg-border">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{ width: `${completion}%`, background: "linear-gradient(90deg, #6366f1, #818cf8)" }}
                      />
                    </div>
                  </div>

                  {/* Filters */}
                  <div className="flex gap-1.5 mb-3">
                    {(["all", "today", "overdue"] as const).map(f => (
                      <button
                        key={f}
                        onClick={() => setTaskFilter(f)}
                        className={`text-[11px] font-medium px-2.5 py-1 rounded-md transition-colors capitalize ${
                          taskFilter === f
                            ? "bg-indigo-600/20 text-indigo-400 border border-indigo-500/30"
                            : "text-muted-foreground hover:text-foreground border border-border hover:border-border/70"
                        }`}
                      >
                        {f === "overdue" && taskStats.overdue > 0 ? `Overdue (${taskStats.overdue})` : f.charAt(0).toUpperCase() + f.slice(1)}
                      </button>
                    ))}
                  </div>

                  {/* Task list */}
                  <div className="space-y-1.5">
                    {filteredTasks.length > 0
                      ? filteredTasks.map(t => <TaskRow key={t.id} task={t} />)
                      : <p className="text-sm text-muted-foreground/60 text-center py-6">No tasks for this filter</p>
                    }
                  </div>
                </Section>

                {/* Recent Activity / Mentions */}
                <Section>
                  <SectionHeader
                    icon={MessageSquare}
                    title="Recent Activity"
                    action={
                      <button
                        onClick={() => navigate("/chat")}
                        className="text-[10px] text-muted-foreground hover:text-indigo-400 flex items-center gap-1 transition-colors"
                      >
                        Go to chat <ArrowRight size={10} />
                      </button>
                    }
                  />
                  <div className="space-y-2">
                    {mentionsData.slice(0, 5).map(m => (
                      <div
                        key={m.id}
                        onClick={() => navigate("/chat")}
                        className="flex items-start gap-3 px-3 py-2.5 rounded-lg border border-border/60 bg-background/40 cursor-pointer transition-colors hover:border-border hover:bg-accent/30"
                      >
                        <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-sm font-medium text-foreground truncate">{m.nodeTitle}</span>
                            <span className="text-[10px] text-muted-foreground flex-shrink-0">{formatRelativeTime(m.timestamp)}</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5 truncate">{m.content}</p>
                        </div>
                        <span
                          className="text-[9px] font-semibold px-1.5 py-0.5 rounded-full flex-shrink-0 mt-0.5 capitalize"
                          style={{
                            color: m.type === "mention" ? "#818cf8" : m.type === "comment" ? "#34d399" : "#fb923c",
                            background: m.type === "mention" ? "rgba(129,140,248,0.1)" : m.type === "comment" ? "rgba(52,211,153,0.1)" : "rgba(251,146,60,0.1)",
                          }}
                        >
                          {m.type}
                        </span>
                      </div>
                    ))}
                  </div>
                </Section>

                {/* Today's Highlights */}
                <Section>
                  <SectionHeader icon={TrendingUp} title="Highlights" />
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="rounded-lg p-3.5" style={{ background: "rgba(52,211,153,0.07)", border: "1px solid rgba(52,211,153,0.15)" }}>
                      <Activity size={14} style={{ color: "#34d399" }} className="mb-2" />
                      <div className="text-xs font-semibold text-foreground/70 mb-1">Most Active</div>
                      <div className="text-[11px] text-muted-foreground">Daily Journal · 5 updates today</div>
                    </div>
                    <div className="rounded-lg p-3.5" style={{ background: "rgba(251,191,36,0.07)", border: "1px solid rgba(251,191,36,0.15)" }}>
                      <Target size={14} style={{ color: "#fbbf24" }} className="mb-2" />
                      <div className="text-xs font-semibold text-foreground/70 mb-1">Suggested</div>
                      <div className="text-[11px] text-muted-foreground">Pick up where you left off</div>
                    </div>
                    <div className="rounded-lg p-3.5" style={{ background: "rgba(168,85,247,0.07)", border: "1px solid rgba(168,85,247,0.15)" }}>
                      <Users size={14} style={{ color: "#c084fc" }} className="mb-2" />
                      <div className="text-xs font-semibold text-foreground/70 mb-1">Team Updates</div>
                      <div className="text-[11px] text-muted-foreground">3 new comments from teammates</div>
                    </div>
                  </div>
                </Section>
              </div>

              {/* Right column — 1/3 */}
              <div className="space-y-4">

                {/* Quick actions */}
                <Section>
                  <SectionHeader icon={Plus} title="Quick Actions" />
                  <div className="space-y-1.5">
                    {/* Search shortcut */}
                    <button
                      onClick={() => document.dispatchEvent(new KeyboardEvent("keydown", { key: "k", ctrlKey: true, bubbles: true }))}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border border-indigo-500/20 bg-indigo-500/5 text-left transition-colors hover:bg-indigo-500/10 hover:border-indigo-500/30"
                    >
                      <div className="w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0 bg-indigo-500/15">
                        <Search size={12} style={{ color: "#818cf8" }} />
                      </div>
                      <span className="text-sm text-foreground/70 font-medium flex-1">Search everything</span>
                      <span className="flex items-center gap-0.5 text-[10px] text-muted-foreground/40 font-mono">
                        <span className="border border-border/40 rounded px-1">⌘</span>
                        <span className="border border-border/40 rounded px-1">K</span>
                      </span>
                    </button>
                    {[
                      { label: "Knowledge Graph", icon: GitBranch,   href: "/graph",    color: "#818cf8" },
                      { label: "All Tasks",        icon: CheckCircle2, href: "/tasks",   color: "#34d399" },
                      { label: "Planning Room",    icon: CalendarDays, href: "/planning", color: "#fb923c" },
                      { label: "Team Chat",        icon: MessageSquare, href: "/chat",   color: "#38bdf8" },
                    ].map((a, i) => {
                      const Icon = a.icon;
                      return (
                        <button
                          key={i}
                          onClick={() => navigate(a.href)}
                          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border border-border/60 bg-background/40 text-left transition-colors hover:border-border hover:bg-accent/30"
                        >
                          <div className="w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0" style={{ background: `${a.color}18` }}>
                            <Icon size={12} style={{ color: a.color }} />
                          </div>
                          <span className="text-sm text-foreground/70 font-medium">{a.label}</span>
                          <ArrowRight size={11} className="ml-auto text-muted-foreground" />
                        </button>
                      );
                    })}
                  </div>
                </Section>

                {/* Recent Planning Rooms */}
                {recentRooms.length > 0 && (
                  <Section>
                    <SectionHeader
                      icon={Layers}
                      title="Planning Rooms"
                      action={
                        <button
                          onClick={() => navigate("/planning")}
                          className="text-[10px] text-muted-foreground hover:text-indigo-400 flex items-center gap-1 transition-colors"
                        >
                          All rooms <ArrowRight size={10} />
                        </button>
                      }
                    />
                    <div className="space-y-1.5">
                      {recentRooms.map(room => {
                        const emojiMap: Record<string, string> = {
                          project_kickoff: "🚀", sprint_planning: "⚡", product_launch: "🎯",
                          client_onboarding: "🤝", resource_planning: "📊", blank: "✨",
                        };
                        const emoji = emojiMap[room.template || "blank"] || "✨";
                        return (
                          <button
                            key={room.id}
                            onClick={() => navigate("/planning")}
                            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border border-border/60 bg-background/40 text-left transition-colors hover:border-border hover:bg-accent/30"
                          >
                            <span className="text-base leading-none w-6 flex-shrink-0 text-center">{emoji}</span>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-foreground/80 truncate">{room.name}</p>
                              {room.description && (
                                <p className="text-[10px] text-muted-foreground truncate">{room.description}</p>
                              )}
                            </div>
                            <ArrowRight size={11} className="text-muted-foreground flex-shrink-0" />
                          </button>
                        );
                      })}
                    </div>
                  </Section>
                )}

                {/* Calendar */}
                <Section>
                  <SectionHeader
                    icon={CalendarDays}
                    title="Calendar"
                    action={
                      <button
                        onClick={() => navigate("/calendar")}
                        className="text-[10px] text-muted-foreground hover:text-indigo-400 flex items-center gap-1 transition-colors"
                      >
                        Full view <ArrowRight size={10} />
                      </button>
                    }
                  />

                  {/* shadcn calendar — dark-styled via CSS vars */}
                  <div className="flex justify-center">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      className="rounded-lg p-0 w-full"
                      classNames={{
                        months: "w-full",
                        month: "w-full space-y-2",
                        caption: "flex justify-between items-center px-1 mb-1",
                        caption_label: "text-xs font-semibold text-foreground/60",
                        nav: "flex items-center gap-1",
                        nav_button: "h-6 w-6 rounded-md flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-colors",
                        nav_button_previous: "",
                        nav_button_next: "",
                        table: "w-full border-collapse",
                        head_row: "flex w-full",
                        head_cell: "flex-1 text-center text-[10px] font-medium text-muted-foreground py-1",
                        row: "flex w-full mt-0.5",
                        cell: "flex-1 text-center p-0 relative",
                        day: "w-full h-7 text-[11px] rounded-md font-medium transition-colors text-foreground/50 hover:text-foreground hover:bg-accent/50 flex items-center justify-center",
                        day_selected: "bg-indigo-600 text-white hover:bg-indigo-500",
                        day_today: "text-indigo-500 font-bold",
                        day_outside: "text-muted-foreground/30",
                        day_disabled: "text-muted-foreground/20",
                      }}
                      modifiers={{
                        hasEvent: (date) => datesWithEvents.has(date.toDateString()),
                      }}
                      modifiersClassNames={{
                        hasEvent: "after:absolute after:bottom-0.5 after:left-1/2 after:-translate-x-1/2 after:w-1 after:h-1 after:rounded-full after:bg-indigo-500",
                      }}
                    />
                  </div>

                  {/* Events on selected date */}
                  {selectedDate && (
                    <div className="mt-3 pt-3 border-t border-border">
                      <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest mb-2">
                        {selectedDate.toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                      </p>
                      {eventsOnSelected.length > 0 ? (
                        <div className="space-y-1.5">
                          {eventsOnSelected.map((ev, i) => (
                            <div
                              key={i}
                              className="flex items-center gap-2 px-2.5 py-2 rounded-lg"
                              style={{
                                background: ev.type === "meeting" ? "rgba(251,146,60,0.08)" : "rgba(129,140,248,0.08)",
                                border: `1px solid ${ev.type === "meeting" ? "rgba(251,146,60,0.15)" : "rgba(129,140,248,0.15)"}`,
                              }}
                            >
                              <div
                                className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                                style={{ background: ev.type === "meeting" ? "#fb923c" : "#818cf8" }}
                              />
                              <span className="text-xs text-foreground/70 truncate">{ev.title}</span>
                              <span
                                className="ml-auto text-[9px] font-semibold capitalize flex-shrink-0"
                                style={{ color: ev.type === "meeting" ? "#fb923c" : "#818cf8" }}
                              >
                                {ev.type}
                              </span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-muted-foreground/60 text-center py-2">No events</p>
                      )}
                    </div>
                  )}

                  {/* Legend */}
                  <div className="flex items-center gap-4 mt-3 pt-3 border-t border-border">
                    <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#fb923c]" /> Meetings
                    </div>
                    <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#818cf8]" /> Tasks
                    </div>
                  </div>
                </Section>

                {/* Recent nodes */}
                <Section>
                  <SectionHeader
                    icon={Layers}
                    title="Recent Nodes"
                    action={
                      <button
                        onClick={() => navigate("/graph")}
                        className="text-[10px] text-muted-foreground hover:text-indigo-400 flex items-center gap-1 transition-colors"
                      >
                        Graph <ArrowRight size={10} />
                      </button>
                    }
                  />
                  <div className="space-y-1.5">
                    {recentNodes.slice(0, 6).map(n => (
                      <NodeRow key={n.id} node={n} onClick={() => setSelectedNode(n)} />
                    ))}
                    {nodes.length === 0 && (
                      <p className="text-xs text-muted-foreground/60 text-center py-4">No nodes yet</p>
                    )}
                  </div>
                </Section>

                {/* Dormant nodes */}
                {dormantNodes.length > 0 && (
                  <Section>
                    <SectionHeader icon={AlertTriangle} title="Needs Attention" />
                    <p className="text-[11px] text-muted-foreground mb-3">Nodes not updated in over 7 days</p>
                    <div className="space-y-1.5">
                      {dormantNodes.map(n => (
                        <NodeRow key={n.id} node={n} onClick={() => setSelectedNode(n)} />
                      ))}
                    </div>
                  </Section>
                )}
              </div>
            </div>
          </TabsContent>

          {/* ── Journal tab ──────────────────────────────── */}
          <TabsContent value="journal" className="mt-0">
            <div
              className="rounded-xl border border-border bg-card p-6"
            >
              <RichTextJournal />
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* ── Node detail dialog ─────────────────────────── */}
      <Dialog open={!!selectedNode} onOpenChange={() => setSelectedNode(null)}>
        <DialogContent className="sm:max-w-lg bg-card border border-border">
          {selectedNode && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2.5 text-foreground">
                  <NodeIcon type={selectedNode.nodeType} size={16} />
                  {selectedNode.title}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <span
                    className="text-[11px] font-semibold px-2.5 py-1 rounded-full capitalize"
                    style={{
                      color: NODE_COLORS[selectedNode.nodeType] || "#666",
                      background: `${NODE_COLORS[selectedNode.nodeType] || "#666"}18`,
                    }}
                  >
                    {selectedNode.nodeType}
                  </span>
                  {selectedNode.status && (
                    <StatusPill status={selectedNode.status.replace(" ", "_")} />
                  )}
                  {selectedNode.priority && (
                    <span className="text-[11px] text-muted-foreground capitalize">{selectedNode.priority} priority</span>
                  )}
                </div>

                {selectedNode.content && (
                  <p className="text-sm text-muted-foreground leading-relaxed border-l-2 border-border pl-3">
                    {selectedNode.content.slice(0, 300)}{selectedNode.content.length > 300 ? "…" : ""}
                  </p>
                )}

                {selectedNode.tags && selectedNode.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {selectedNode.tags.map((tag, i) => (
                      <span
                        key={i}
                        className="text-[10px] px-2 py-0.5 rounded-full bg-accent text-muted-foreground border border-border"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <div className="flex justify-between pt-4 border-t border-border">
                <button
                  onClick={() => setSelectedNode(null)}
                  className="text-sm text-muted-foreground hover:text-foreground border border-border hover:border-border/80 px-4 py-2 rounded-lg transition-colors"
                >
                  Close
                </button>
                <button
                  onClick={() => navigateToNode(selectedNode)}
                  className="flex items-center gap-2 text-sm font-medium bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg transition-colors"
                >
                  <ExternalLink size={13} />
                  Open in {selectedNode.nodeType === "file" ? "Files" : selectedNode.nodeType === "chat" ? "Chat" : "Graph"}
                </button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
