import { useState, useEffect, useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import NodeGraph from "@/components/node-graph";
import SimpleJournal from "@/components/simple-journal";
import { Node, NodeWithLinks } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  HistoryIcon, 
  MoreHorizontalIcon, 
  FileText,
  Link as LinkIcon,
  Maximize2,
  Wifi,
  WifiOff,
  Users,
  MessageSquare
} from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";

// Helper to get node type color
const getNodeTypeColor = (type: string) => {
  switch (type) {
    case 'journal': return '#10b981';
    case 'task': return '#f59e0b';
    case 'note': return '#3b82f6';
    case 'meeting': return '#8b5cf6';
    default: return '#6b7280';
  }
};

// Helper function to safely truncate content
const safeContentTruncate = (content: string | null | undefined, maxLength: number = 50): string => {
  if (!content || typeof content !== 'string') return '';
  return content.length > maxLength ? content.substring(0, maxLength) + '...' : content;
};

export default function Journal() {
  const [activeTab, setActiveTab] = useState("daily-journal");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Query for the daily journal node
  const { data: journalNode, isLoading, refetch: refetchJournalNode } = useQuery<NodeWithLinks>({
    queryKey: ['/api/nodes/1'],
  });
  
  // Query for all nodes to display in the right panel
  const { data: allNodes, refetch: refetchAllNodes } = useQuery<Node[]>({
    queryKey: ['/api/nodes'],
    enabled: true,
  });
  
  // Setup WebSocket connection for real-time updates
  const { connected, lastMessage, sendUpdate } = useWebSocket(journalNode?.id);
  
  // Handle real-time updates from other users
  useEffect(() => {
    if (lastMessage && lastMessage.type === 'node_updated') {
      console.log('Received node update:', lastMessage.data);
      
      // Refresh node data when updates come in
      if (lastMessage.nodeId === journalNode?.id) {
        refetchJournalNode();
      }
      
      // Always refresh the list of nodes to show new nodes created by others
      refetchAllNodes();
      
      // Show a toast notification about the update
      toast({
        title: "Content updated",
        description: "Another user has made changes to this content.",
        duration: 3000,
      });
    }
  }, [lastMessage, journalNode?.id, refetchJournalNode, refetchAllNodes, toast]);
  
  // Generate graph data for visualization
  const graphData = useMemo(() => {
    if (!allNodes || allNodes.length === 0) {
      return { nodes: [], links: [] };
    }

    const nodes = allNodes.map(node => ({
      id: node.id,
      label: node.title,
      nodeType: node.nodeType,
      radius: 20,
      color: getNodeTypeColor(node.nodeType)
    }));

    // For demo purposes, create some sample links between nodes
    const links = allNodes.length > 1 ? [
      { source: allNodes[0].id, target: allNodes[1].id, value: 1 }
    ] : [];

    return { nodes, links };
  }, [allNodes]);

  const today = new Date();
  const formattedDate = format(today, "EEEE, MMMM d, yyyy");
  
  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-primary rounded-full border-t-transparent"></div>
      </div>
    );
  }
  
  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex flex-col space-y-3 md:space-y-0 md:flex-row md:items-center md:justify-between p-3 md:p-6 border-b border-border">
        <div className="flex items-center space-x-2 md:space-x-3">
          <FileText className="h-5 w-5 md:h-6 md:w-6 text-primary" />
          <h1 className="text-lg md:text-2xl font-bold">Daily Journal</h1>
          <Badge variant="outline" className="ml-1 md:ml-2">
            {connected ? (
              <><Wifi className="h-3 w-3 mr-1" />Online</>
            ) : (
              <><WifiOff className="h-3 w-3 mr-1" />Offline</>
            )}
          </Badge>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" onClick={() => refetchJournalNode()}>
            <HistoryIcon className="h-4 w-4 mr-1" />
            <span className="hidden sm:inline">Refresh</span>
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 px-2 md:px-4">
        <Tabs defaultValue="daily-journal" className="w-full" value={activeTab} onValueChange={setActiveTab}>
          <div className="flex flex-col space-y-2 md:space-y-0 md:flex-row md:justify-between md:items-center">
            <TabsList className="w-full md:w-auto grid grid-cols-3 md:flex">
              <TabsTrigger value="daily-journal" className="text-xs md:text-sm px-2 md:px-4">Journal</TabsTrigger>
              <TabsTrigger value="team-chat" className="text-xs md:text-sm px-2 md:px-4">Chat</TabsTrigger>
              <TabsTrigger value="graph-view" className="text-xs md:text-sm px-2 md:px-4">Graph</TabsTrigger>
            </TabsList>
            
            <div className="hidden md:flex items-center space-x-2">
              <Button variant="ghost" size="icon">
                <HistoryIcon className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon">
                <MoreHorizontalIcon className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <TabsContent value="daily-journal" className="p-0 m-0 h-[calc(100vh-8rem)]">
            {journalNode && (
              <SimpleJournal nodeId={journalNode.id} />
            )}
          </TabsContent>

          <TabsContent value="team-chat" className="p-0 m-0 h-[calc(100vh-8rem)]">
            <div className="h-full p-4">
              <h2 className="text-lg font-semibold mb-4">Real-time Team Chat</h2>
              <div className="h-full bg-muted/30 rounded-lg p-4 flex items-center justify-center">
                <div className="text-center">
                  <MessageSquare className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">Real-time messaging with WebSocket support</p>
                  <p className="text-sm text-muted-foreground mt-2">Connect with your team instantly</p>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="graph-view" className="p-0 m-0 h-[calc(100vh-8rem)]">
            <div className="h-full p-4">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-lg font-semibold">Interactive Node Graph</h2>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">
                    <Users className="h-3 w-3 mr-1" />
                    Interactive Linking
                  </Badge>
                  <Button variant="outline" size="sm">
                    <LinkIcon className="h-4 w-4 mr-1" />
                    Connect Nodes
                  </Button>
                </div>
              </div>
              
              {journalNode ? (
                <div className="h-[calc(100%-6rem)] bg-muted/30 rounded-lg">
                  <NodeGraph 
                    data={graphData}
                    zoom={0.8}
                    allowLinking={true}
                    onNodeSelect={(nodeId) => {
                      console.log('Selected node:', nodeId);
                    }}
                    onNodeLink={(sourceId, targetId) => {
                      console.log('Linking nodes:', sourceId, targetId);
                    }}
                  />
                </div>
              ) : (
                <div className="h-full bg-muted/30 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <Maximize2 className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">No data for graph visualization</p>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}