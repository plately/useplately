// Simple working integrations page to test mobile responsiveness
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Github, 
  Slack, 
  Mail, 
  Zap,
  CheckCircle,
  XCircle,
  Activity
} from "lucide-react";

export default function Integrations() {
  const mockIntegrations = [
    { id: 1, name: "GitHub", category: "Development", connected: true, icon: Github, color: "#000000" },
    { id: 2, name: "Slack", category: "Communication", connected: false, icon: Slack, color: "#4A154B" },
    { id: 3, name: "Gmail", category: "Email", connected: true, icon: Mail, color: "#EA4335" },
  ];

  return (
    <div className="h-screen flex flex-col">
      {/* Mobile-friendly Header */}
      <div className="px-3 sm:px-6 py-3 sm:py-4 border-b">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold">Integrations</h1>
            <p className="text-muted-foreground mt-1 text-sm sm:text-base">Connect NodeOS with your favorite apps</p>
          </div>
          <div className="flex items-center space-x-2 flex-wrap gap-1">
            <Badge variant="secondary" className="flex items-center space-x-1 text-xs">
              <Activity className="w-3 h-3" />
              <span className="hidden sm:inline">2 Connected</span>
              <span className="sm:hidden">2</span>
            </Badge>
            <Badge variant="outline" className="flex items-center space-x-1 text-xs">
              <Zap className="w-3 h-3" />
              <span className="hidden sm:inline">3 Available</span>
              <span className="sm:hidden">3</span>
            </Badge>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Mobile-responsive Sidebar */}
        <div className="w-full lg:w-64 p-3 sm:p-4 border-b lg:border-b-0 lg:border-r">
          <div className="space-y-2">
            <h3 className="text-sm font-medium mb-3">Categories</h3>
            <div className="flex lg:flex-col gap-2 overflow-x-auto lg:overflow-x-visible">
              {["All", "Development", "Communication", "Email"].map(category => (
                <button
                  key={category}
                  className="flex-shrink-0 lg:w-full text-left px-3 py-2 text-sm rounded-md transition-all whitespace-nowrap hover:bg-accent"
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Mobile-responsive Main Content */}
        <div className="flex-1 overflow-auto">
          <div className="p-3 sm:p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {mockIntegrations.map(integration => {
                const IconComponent = integration.icon;
                return (
                  <Card key={integration.id} className="group hover:shadow-lg transition-all duration-200">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-accent">
                            <IconComponent 
                              className="w-5 h-5" 
                              style={{ color: integration.color }}
                            />
                          </div>
                          <div>
                            <CardTitle className="text-lg">{integration.name}</CardTitle>
                            <Badge variant="secondary" className="text-xs">
                              {integration.category}
                            </Badge>
                          </div>
                        </div>
                        
                        {integration.connected ? (
                          <Badge variant="default" className="text-xs">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Connected
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-xs">
                            <XCircle className="w-3 h-3 mr-1" />
                            Not Connected
                          </Badge>
                        )}
                      </div>
                    </CardHeader>
                    
                    <CardContent className="pt-0">
                      <CardDescription className="mb-4 text-sm">
                        Connect {integration.name} to sync your data with NodeOS.
                      </CardDescription>
                      
                      <div className="flex space-x-2">
                        {integration.connected ? (
                          <Button size="sm" variant="outline" className="flex-1">
                            Sync
                          </Button>
                        ) : (
                          <Button size="sm" className="w-full">
                            Connect
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}