import { useState, useRef, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format, startOfDay, addHours } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Node, InsertNode } from "@shared/schema";
import {
  Calendar,
  Clock,
  CheckCircle2,
  Circle,
  Plus,
  Upload,
  Mic,
  Video,
  Link,
  Hash,
  Brain,
  Target,
  BarChart3,
  Paperclip,
  Zap,
  Sun,
  CloudDrizzle,
  Moon,
  Coffee,
  Lightbulb,
  FileText,
  Image,
  File,
  Play,
  Pause,
  Square,
  ChevronDown,
  ChevronRight,
  Users,
  Tag,
  MessageSquare,
  Archive,
  Trash2,
  ExternalLink,
  Maximize2,
  PlusCircle,
  Timer,
  MapPin,
  AlertCircle,
  CheckCheck,
  ArrowRight,
  Eye,
  EyeOff,
  Share2,
  Download,
  Copy,
  Settings,
  Filter,
  Search,
  Webhook,
  Database,
  Globe,
  Send,
  Rocket,
  GitBranch,
  Mail,
  FolderOpen,
  Smartphone,
  Monitor,
  Cloud,
  Workflow
} from "lucide-react";

interface WorkspaceEntry {
  id: string;
  type: 'note' | 'task' | 'checkin' | 'file' | 'voice' | 'meeting' | 'idea';
  content: string;
  timestamp: Date;
  completed?: boolean;
  tags: string[];
  mood?: 'great' | 'good' | 'neutral' | 'stressed' | 'blocked';
  assignedTo?: string;
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  linkedNodes?: number[];
  files?: WorkspaceFile[];
  metadata?: Record<string, any>;
}

interface WorkspaceFile {
  id: string;
  name: string;
  type: string;
  size: number;
  url: string;
  preview?: string;
  visibility: 'private' | 'public';
  linkedTo?: string[];
  tags: string[];
}

interface TimeBlock {
  id: string;
  title: string;
  timeRange: string;
  icon: React.ReactNode;
  color: string;
  entries: WorkspaceEntry[];
  isCollapsed: boolean;
}

interface Task {
  id: string;
  title: string;
  description?: string;
  status: 'todo' | 'doing' | 'done';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assignedTo?: string;
  dueDate?: Date;
  tags: string[];
  subtasks: Task[];
  linkedNodes: number[];
  createdAt: Date;
  integrations?: Integration[];
}

interface Integration {
  id: string;
  platform: 'google' | 'github' | 'zapier' | 'drive' | 'outlook' | 'excel' | 'slack' | 'notion' | 'trello' | 'asana' | 'jira' | 'teams' | 'calendar' | 'sheets';
  action: string;
  config: Record<string, any>;
  status: 'pending' | 'success' | 'failed';
  lastSync?: Date;
}

interface AutomationRule {
  id: string;
  name: string;
  trigger: {
    type: 'task_complete' | 'entry_added' | 'file_uploaded' | 'time_based';
    conditions: Record<string, any>;
  };
  actions: Array<{
    platform: Integration['platform'];
    action: string;
    config: Record<string, any>;
  }>;
  enabled: boolean;
}

const moodIcons = {
  great: { emoji: '😊', color: 'text-green-600' },
  good: { emoji: '🙂', color: 'text-blue-600' },
  neutral: { emoji: '😐', color: 'text-gray-600' },
  stressed: { emoji: '😰', color: 'text-orange-600' },
  blocked: { emoji: '😤', color: 'text-red-600' }
};

const priorityColors = {
  low: 'bg-gray-100 text-gray-800',
  medium: 'bg-blue-100 text-blue-800',
  high: 'bg-orange-100 text-orange-800',
  urgent: 'bg-red-100 text-red-800'
};

const initialTimeBlocks: TimeBlock[] = [
  {
    id: 'morning',
    title: 'Morning Focus',
    timeRange: '6:00 - 12:00',
    icon: <Sun className="h-4 w-4" />,
    color: 'bg-yellow-50 border-yellow-200',
    entries: [],
    isCollapsed: false
  },
  {
    id: 'midday',
    title: 'Midday Flow',
    timeRange: '12:00 - 17:00',
    icon: <CloudDrizzle className="h-4 w-4" />,
    color: 'bg-blue-50 border-blue-200',
    entries: [],
    isCollapsed: false
  },
  {
    id: 'evening',
    title: 'Evening Wrap',
    timeRange: '17:00 - 23:00',
    icon: <Moon className="h-4 w-4" />,
    color: 'bg-purple-50 border-purple-200',
    entries: [],
    isCollapsed: false
  }
];

export default function Workspace() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [timeBlocks, setTimeBlocks] = useState<TimeBlock[]>(initialTimeBlocks);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [files, setFiles] = useState<WorkspaceFile[]>([]);
  
  // Form states
  const [newEntry, setNewEntry] = useState('');
  const [entryType, setEntryType] = useState<WorkspaceEntry['type']>('note');
  const [isAddingEntry, setIsAddingEntry] = useState(false);
  const [activeBlock, setActiveBlock] = useState('morning');
  const [selectedMood, setSelectedMood] = useState<WorkspaceEntry['mood']>('neutral');
  const [entryTags, setEntryTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');
  const [selectedPriority, setSelectedPriority] = useState<Task['priority']>('medium');
  
  // Dialog states
  const [isAIDialogOpen, setIsAIDialogOpen] = useState(false);
  const [isNodeDialogOpen, setIsNodeDialogOpen] = useState(false);
  const [isFileDialogOpen, setIsFileDialogOpen] = useState(false);
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);
  const [isIntegrationsDialogOpen, setIsIntegrationsDialogOpen] = useState(false);
  const [isAutomationDialogOpen, setIsAutomationDialogOpen] = useState(false);
  
  // Other states
  const [aiPrompt, setAiPrompt] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'freeform' | 'structured'>('freeform');
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [draggedTask, setDraggedTask] = useState<Task | null>(null);
  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [automationRules, setAutomationRules] = useState<AutomationRule[]>([]);
  const [selectedIntegration, setSelectedIntegration] = useState<Integration['platform'] | ''>('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Query for nodes
  const { data: nodes = [] } = useQuery<Node[]>({
    queryKey: ['/api/nodes'],
  });

  // Create node mutation
  const createNodeMutation = useMutation({
    mutationFn: (nodeData: InsertNode) => apiRequest('/api/nodes', {
      method: 'POST',
      body: JSON.stringify(nodeData),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/nodes'] });
      toast({
        title: "Node created",
        description: "Your idea has been turned into a node",
      });
    },
  });

  const addWorkspaceEntry = useCallback((blockId: string) => {
    if (!newEntry.trim()) return;

    const entry: WorkspaceEntry = {
      id: Date.now().toString(),
      type: entryType,
      content: newEntry,
      timestamp: new Date(),
      tags: entryTags,
      mood: entryType === 'checkin' ? selectedMood : undefined,
      completed: entryType === 'task' ? false : undefined,
      priority: entryType === 'task' ? selectedPriority : undefined,
    };

    setTimeBlocks(prev => prev.map(block => 
      block.id === blockId 
        ? { ...block, entries: [...block.entries, entry] }
        : block
    ));

    // Auto-suggest converting to node for ideas
    if (entryType === 'idea' || newEntry.toLowerCase().includes('idea') || newEntry.toLowerCase().includes('concept')) {
      setTimeout(() => {
        if (window.confirm('Would you like to turn this into a node?')) {
          createNodeFromEntry(entry);
        }
      }, 500);
    }

    resetForm();
    
    toast({
      title: "Entry added",
      description: `${entryType} added to ${blockId} block`,
    });
  }, [newEntry, entryType, entryTags, selectedMood, selectedPriority]);

  const resetForm = () => {
    setNewEntry('');
    setEntryTags([]);
    setIsAddingEntry(false);
  };

  const addTag = () => {
    if (newTag.trim() && !entryTags.includes(newTag.trim())) {
      setEntryTags([...entryTags, newTag.trim()]);
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setEntryTags(entryTags.filter(tag => tag !== tagToRemove));
  };

  const createNodeFromEntry = (entry: WorkspaceEntry) => {
    createNodeMutation.mutate({
      title: entry.content.substring(0, 50) + (entry.content.length > 50 ? '...' : ''),
      content: entry.content,
      nodeType: entry.type === 'task' ? 'task' : entry.type === 'idea' ? 'idea' : 'note',
      tags: entry.tags,
      createdBy: 1,
    });
  };

  const toggleTaskCompletion = (blockId: string, entryId: string) => {
    setTimeBlocks(prev => prev.map(block => 
      block.id === blockId 
        ? {
            ...block,
            entries: block.entries.map(entry => 
              entry.id === entryId 
                ? { ...entry, completed: !entry.completed }
                : entry
            )
          }
        : block
    ));
  };

  const toggleBlockCollapse = (blockId: string) => {
    setTimeBlocks(prev => prev.map(block => 
      block.id === blockId 
        ? { ...block, isCollapsed: !block.isCollapsed }
        : block
    ));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = Array.from(event.target.files || []);
    
    uploadedFiles.forEach(file => {
      const workspaceFile: WorkspaceFile = {
        id: Date.now().toString() + Math.random(),
        name: file.name,
        type: file.type,
        size: file.size,
        url: URL.createObjectURL(file),
        visibility: 'private',
        linkedTo: [],
        tags: []
      };
      
      setFiles(prev => [...prev, workspaceFile]);
    });

    toast({
      title: "Files uploaded",
      description: `${uploadedFiles.length} file(s) added to workspace`,
    });
  };

  const addTask = (status: Task['status'] = 'todo') => {
    if (!newEntry.trim()) return;

    const task: Task = {
      id: Date.now().toString(),
      title: newEntry,
      status,
      priority: selectedPriority,
      tags: entryTags,
      subtasks: [],
      linkedNodes: [],
      createdAt: new Date()
    };

    setTasks(prev => [...prev, task]);
    resetForm();
    
    toast({
      title: "Task created",
      description: "New task added to board",
    });
  };

  const updateTaskStatus = (taskId: string, newStatus: Task['status']) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, status: newStatus } : task
    ));
  };

  const getDailyStats = () => {
    const allEntries = timeBlocks.flatMap(block => block.entries);
    const completedTasks = tasks.filter(task => task.status === 'done').length;
    const totalTasks = tasks.length;
    const todayFiles = files.filter(file => 
      new Date(file.id).toDateString() === selectedDate.toDateString()
    ).length;
    
    return {
      totalEntries: allEntries.length,
      tasksCompleted: completedTasks,
      totalTasks,
      filesUploaded: todayFiles,
      nodesLinked: allEntries.reduce((acc, entry) => acc + (entry.linkedNodes?.length || 0), 0)
    };
  };

  const getProgressPercentage = () => {
    const stats = getDailyStats();
    return stats.totalTasks > 0 ? (stats.tasksCompleted / stats.totalTasks) * 100 : 0;
  };

  const stats = getDailyStats();

  // Integration platform configurations
  const integrationPlatforms = [
    {
      id: 'google',
      name: 'Google Workspace',
      icon: <Globe className="h-4 w-4" />,
      color: 'bg-blue-500',
      actions: ['Create Doc', 'Add to Calendar', 'Send Email', 'Create Sheet']
    },
    {
      id: 'github',
      name: 'GitHub',
      icon: <GitBranch className="h-4 w-4" />,
      color: 'bg-gray-900',
      actions: ['Create Issue', 'Create PR', 'Add to Project', 'Commit Code']
    },
    {
      id: 'zapier',
      name: 'Zapier',
      icon: <Workflow className="h-4 w-4" />,
      color: 'bg-orange-500',
      actions: ['Trigger Zap', 'Create Automation', 'Send Webhook']
    },
    {
      id: 'drive',
      name: 'Google Drive',
      icon: <Cloud className="h-4 w-4" />,
      color: 'bg-yellow-500',
      actions: ['Upload File', 'Create Folder', 'Share Document']
    },
    {
      id: 'outlook',
      name: 'Microsoft Outlook',
      icon: <Mail className="h-4 w-4" />,
      color: 'bg-blue-600',
      actions: ['Send Email', 'Create Meeting', 'Add to Calendar']
    },
    {
      id: 'excel',
      name: 'Microsoft Excel',
      icon: <Database className="h-4 w-4" />,
      color: 'bg-green-600',
      actions: ['Create Workbook', 'Add Row', 'Update Cell', 'Generate Chart']
    },
    {
      id: 'slack',
      name: 'Slack',
      icon: <MessageSquare className="h-4 w-4" />,
      color: 'bg-purple-500',
      actions: ['Send Message', 'Create Channel', 'Post Update']
    },
    {
      id: 'notion',
      name: 'Notion',
      icon: <FileText className="h-4 w-4" />,
      color: 'bg-gray-800',
      actions: ['Create Page', 'Add to Database', 'Update Property']
    },
    {
      id: 'trello',
      name: 'Trello',
      icon: <Target className="h-4 w-4" />,
      color: 'bg-blue-400',
      actions: ['Create Card', 'Move Card', 'Add Checklist']
    },
    {
      id: 'asana',
      name: 'Asana',
      icon: <CheckCircle2 className="h-4 w-4" />,
      color: 'bg-red-500',
      actions: ['Create Task', 'Add to Project', 'Set Due Date']
    }
  ];

  // Quick action functions for integrations
  const executeIntegration = async (platform: Integration['platform'], action: string, data: any) => {
    const integration: Integration = {
      id: Date.now().toString(),
      platform,
      action,
      config: data,
      status: 'pending'
    };

    setIntegrations(prev => [...prev, integration]);

    // Simulate API call with realistic delay
    setTimeout(() => {
      setIntegrations(prev => prev.map(int => 
        int.id === integration.id 
          ? { ...int, status: 'success', lastSync: new Date() }
          : int
      ));
      
      toast({
        title: "Integration successful",
        description: `${action} executed in ${integrationPlatforms.find(p => p.id === platform)?.name}`,
      });
    }, 1500);

    toast({
      title: "Integration started",
      description: `Executing ${action} in ${integrationPlatforms.find(p => p.id === platform)?.name}...`,
    });
  };

  const pushToMultipleApps = async (entry: WorkspaceEntry) => {
    const platforms = ['google', 'github', 'slack', 'notion'] as Integration['platform'][];
    
    for (const platform of platforms) {
      let action = '';
      let config = {};
      
      switch (platform) {
        case 'google':
          action = entry.type === 'task' ? 'Add to Calendar' : 'Create Doc';
          config = { title: entry.content, type: entry.type };
          break;
        case 'github':
          action = 'Create Issue';
          config = { title: entry.content, labels: entry.tags };
          break;
        case 'slack':
          action = 'Send Message';
          config = { message: `New ${entry.type}: ${entry.content}`, tags: entry.tags };
          break;
        case 'notion':
          action = 'Create Page';
          config = { title: entry.content, properties: { type: entry.type, tags: entry.tags } };
          break;
      }
      
      await executeIntegration(platform, action, config);
    }
  };

  const TaskBoard = () => (
    <div className="grid grid-cols-3 gap-4">
      {(['todo', 'doing', 'done'] as const).map(status => (
        <div key={status} className="space-y-2">
          <div className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
            <h3 className="font-medium capitalize">{status === 'todo' ? 'To Do' : status === 'doing' ? 'Doing' : 'Done'}</h3>
            <Badge variant="secondary">{tasks.filter(t => t.status === status).length}</Badge>
          </div>
          
          <div 
            className="min-h-[200px] p-2 border-2 border-dashed border-gray-200 rounded-lg space-y-2"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              if (draggedTask) {
                updateTaskStatus(draggedTask.id, status);
                setDraggedTask(null);
              }
            }}
          >
            {tasks.filter(task => task.status === status).map(task => (
              <Card 
                key={task.id} 
                className="cursor-move hover:shadow-md transition-shadow"
                draggable
                onDragStart={() => setDraggedTask(task)}
                onDragEnd={() => setDraggedTask(null)}
              >
                <CardContent className="p-3">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-medium text-sm">{task.title}</h4>
                    <Badge className={priorityColors[task.priority]} variant="secondary">
                      {task.priority}
                    </Badge>
                  </div>
                  
                  {task.description && (
                    <p className="text-xs text-muted-foreground mb-2">{task.description}</p>
                  )}
                  
                  {task.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-2">
                      {task.tags.map(tag => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{format(task.createdAt, 'MMM d')}</span>
                    {task.linkedNodes.length > 0 && (
                      <div className="flex items-center space-x-1">
                        <Link className="h-3 w-3" />
                        <span>{task.linkedNodes.length}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {status === 'todo' && (
              <Button
                variant="ghost"
                className="w-full border-dashed border-2"
                onClick={() => {
                  setIsAddingEntry(true);
                  setEntryType('task');
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Task
              </Button>
            )}
          </div>
        </div>
      ))}
    </div>
  );

  const FileManager = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-medium">Today's Assets</h3>
        <Button
          onClick={() => fileInputRef.current?.click()}
          size="sm"
          className="flex items-center space-x-1"
        >
          <Upload className="h-4 w-4" />
          <span>Upload</span>
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={handleFileUpload}
        />
      </div>
      
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {files.map(file => (
          <Card key={file.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-3">
              <div className="flex items-center space-x-2 mb-2">
                {file.type.startsWith('image/') ? (
                  <Image className="h-4 w-4" />
                ) : file.type.startsWith('video/') ? (
                  <Video className="h-4 w-4" />
                ) : (
                  <File className="h-4 w-4" />
                )}
                <span className="text-sm font-medium truncate">{file.name}</span>
              </div>
              
              <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                <span>{(file.size / 1024).toFixed(1)} KB</span>
                <Badge variant={file.visibility === 'public' ? 'default' : 'secondary'}>
                  {file.visibility === 'public' ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                </Badge>
              </div>
              
              {file.tags.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {file.tags.map(tag => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      #{tag}
                    </Badge>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  return (
    <div className="p-6 space-y-6 max-w-full overflow-x-hidden">
      {/* Header */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between space-y-4 lg:space-y-0">
        <div>
          <h1 className="text-3xl font-bold">Workspace</h1>
          <p className="text-muted-foreground">
            {format(selectedDate, 'EEEE, MMMM d, yyyy')} • Your complete work environment
          </p>
        </div>
        
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="outline" className="flex items-center space-x-1">
            <Target className="h-3 w-3" />
            <span>{Math.round(getProgressPercentage())}% Complete</span>
          </Badge>
          
          <Select value={viewMode} onValueChange={(value: 'freeform' | 'structured') => setViewMode(value)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="freeform">Freeform</SelectItem>
              <SelectItem value="structured">Structured</SelectItem>
            </SelectContent>
          </Select>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsTemplateDialogOpen(true)}
            className="flex items-center space-x-1"
          >
            <FileText className="h-4 w-4" />
            <span>Templates</span>
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsAIDialogOpen(true)}
            className="flex items-center space-x-1"
          >
            <Brain className="h-4 w-4" />
            <span>AI Assistant</span>
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="timeline" className="w-full">
        <TabsList className="grid w-full grid-cols-7">
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="automations">Automations</TabsTrigger>
          <TabsTrigger value="files">Files</TabsTrigger>
          <TabsTrigger value="nodes">Nodes</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="timeline" className="space-y-6">
          <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
            {/* Daily Work Zone */}
            <div className="xl:col-span-3 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Clock className="h-5 w-5" />
                    <span>Daily Work Timeline</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {timeBlocks.map((block) => (
                      <Card key={block.id} className={`${block.color} border-2`}>
                        <Collapsible open={!block.isCollapsed} onOpenChange={() => toggleBlockCollapse(block.id)}>
                          <CollapsibleTrigger asChild>
                            <CardHeader className="cursor-pointer hover:bg-white/50 transition-colors">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-3">
                                  {block.icon}
                                  <div>
                                    <CardTitle className="text-lg">{block.title}</CardTitle>
                                    <p className="text-sm text-muted-foreground">{block.timeRange}</p>
                                  </div>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <Badge variant="secondary">
                                    {block.entries.length} entries
                                  </Badge>
                                  {block.isCollapsed ? (
                                    <ChevronRight className="h-4 w-4" />
                                  ) : (
                                    <ChevronDown className="h-4 w-4" />
                                  )}
                                </div>
                              </div>
                            </CardHeader>
                          </CollapsibleTrigger>

                          <CollapsibleContent>
                            <CardContent className="space-y-3">
                              {/* Existing entries */}
                              {block.entries.map((entry) => (
                                <div key={entry.id} className="p-3 bg-white rounded-lg border">
                                  <div className="flex items-start justify-between">
                                    <div className="flex-1">
                                      <div className="flex items-center space-x-2 mb-2">
                                        {entry.type === 'task' && (
                                          <Button
                                            variant="ghost"
                                            size="sm"
                                            onClick={() => toggleTaskCompletion(block.id, entry.id)}
                                            className="h-6 w-6 p-0"
                                          >
                                            {entry.completed ? (
                                              <CheckCircle2 className="h-4 w-4 text-green-600" />
                                            ) : (
                                              <Circle className="h-4 w-4" />
                                            )}
                                          </Button>
                                        )}
                                        <Badge variant="outline" className="text-xs">
                                          {entry.type}
                                        </Badge>
                                        {entry.priority && (
                                          <Badge className={priorityColors[entry.priority]} variant="secondary">
                                            {entry.priority}
                                          </Badge>
                                        )}
                                        {entry.mood && (
                                          <span className={`text-sm ${moodIcons[entry.mood].color}`}>
                                            {moodIcons[entry.mood].emoji}
                                          </span>
                                        )}
                                        <span className="text-xs text-muted-foreground">
                                          {format(entry.timestamp, 'HH:mm')}
                                        </span>
                                      </div>
                                      <p className={`text-sm ${entry.completed ? 'line-through text-muted-foreground' : ''}`}>
                                        {entry.content}
                                      </p>
                                      {entry.tags.length > 0 && (
                                        <div className="flex flex-wrap gap-1 mt-2">
                                          {entry.tags.map((tag) => (
                                            <Badge key={tag} variant="secondary" className="text-xs">
                                              #{tag}
                                            </Badge>
                                          ))}
                                        </div>
                                      )}
                                      {entry.linkedNodes && entry.linkedNodes.length > 0 && (
                                        <div className="flex items-center space-x-1 mt-2 text-xs text-blue-600">
                                          <Link className="h-3 w-3" />
                                          <span>{entry.linkedNodes.length} linked nodes</span>
                                        </div>
                                      )}
                                    </div>
                                    <div className="flex items-center space-x-1">
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => createNodeFromEntry(entry)}
                                        className="h-8 w-8 p-0"
                                        title="Turn into node"
                                      >
                                        <Lightbulb className="h-3 w-3" />
                                      </Button>
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        className="h-8 w-8 p-0"
                                        title="Link to node"
                                      >
                                        <Link className="h-3 w-3" />
                                      </Button>
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => pushToMultipleApps(entry)}
                                        className="h-8 w-8 p-0"
                                        title="Push to all apps"
                                      >
                                        <Rocket className="h-3 w-3" />
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              ))}

                              {/* Add new entry */}
                              {isAddingEntry && activeBlock === block.id ? (
                                <div className="p-3 bg-white rounded-lg border-2 border-dashed border-primary">
                                  <div className="space-y-3">
                                    <div className="flex flex-wrap items-center gap-2">
                                      {['note', 'task', 'checkin', 'idea', 'meeting', 'voice'].map(type => (
                                        <Button
                                          key={type}
                                          variant={entryType === type ? 'default' : 'outline'}
                                          size="sm"
                                          onClick={() => setEntryType(type as WorkspaceEntry['type'])}
                                        >
                                          {type === 'note' && <FileText className="h-3 w-3 mr-1" />}
                                          {type === 'task' && <CheckCircle2 className="h-3 w-3 mr-1" />}
                                          {type === 'checkin' && <MessageSquare className="h-3 w-3 mr-1" />}
                                          {type === 'idea' && <Lightbulb className="h-3 w-3 mr-1" />}
                                          {type === 'meeting' && <Users className="h-3 w-3 mr-1" />}
                                          {type === 'voice' && <Mic className="h-3 w-3 mr-1" />}
                                          {type.charAt(0).toUpperCase() + type.slice(1)}
                                        </Button>
                                      ))}
                                    </div>

                                    <Textarea
                                      placeholder={`Add a ${entryType}...`}
                                      value={newEntry}
                                      onChange={(e) => setNewEntry(e.target.value)}
                                      className="min-h-[80px]"
                                    />

                                    {entryType === 'checkin' && (
                                      <div className="flex items-center space-x-2">
                                        <span className="text-sm">Mood:</span>
                                        {Object.entries(moodIcons).map(([mood, { emoji, color }]) => (
                                          <Button
                                            key={mood}
                                            variant={selectedMood === mood ? "default" : "ghost"}
                                            size="sm"
                                            onClick={() => setSelectedMood(mood as WorkspaceEntry['mood'])}
                                            className="h-8 w-8 p-0"
                                          >
                                            {emoji}
                                          </Button>
                                        ))}
                                      </div>
                                    )}

                                    {entryType === 'task' && (
                                      <Select value={selectedPriority} onValueChange={(value: Task['priority']) => setSelectedPriority(value)}>
                                        <SelectTrigger className="w-32">
                                          <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="low">Low</SelectItem>
                                          <SelectItem value="medium">Medium</SelectItem>
                                          <SelectItem value="high">High</SelectItem>
                                          <SelectItem value="urgent">Urgent</SelectItem>
                                        </SelectContent>
                                      </Select>
                                    )}

                                    <div className="flex items-center space-x-2">
                                      <Input
                                        placeholder="Add tags..."
                                        value={newTag}
                                        onChange={(e) => setNewTag(e.target.value)}
                                        onKeyPress={(e) => e.key === 'Enter' && addTag()}
                                        className="flex-1"
                                      />
                                      <Button onClick={addTag} size="sm">
                                        <Hash className="h-4 w-4" />
                                      </Button>
                                    </div>

                                    {entryTags.length > 0 && (
                                      <div className="flex flex-wrap gap-1">
                                        {entryTags.map((tag) => (
                                          <Badge
                                            key={tag}
                                            variant="secondary"
                                            className="cursor-pointer"
                                            onClick={() => removeTag(tag)}
                                          >
                                            #{tag} ×
                                          </Badge>
                                        ))}
                                      </div>
                                    )}

                                    <div className="flex items-center justify-end space-x-2">
                                      <Button
                                        variant="ghost"
                                        onClick={() => setIsAddingEntry(false)}
                                      >
                                        Cancel
                                      </Button>
                                      <Button onClick={() => addWorkspaceEntry(block.id)}>
                                        Add {entryType}
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              ) : (
                                <Button
                                  variant="outline"
                                  className="w-full border-dashed"
                                  onClick={() => {
                                    setActiveBlock(block.id);
                                    setIsAddingEntry(true);
                                  }}
                                >
                                  <Plus className="h-4 w-4 mr-2" />
                                  Add to {block.title}
                                </Button>
                              )}
                            </CardContent>
                          </CollapsibleContent>
                        </Collapsible>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-4">
              {/* Daily Progress */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="h-5 w-5" />
                    <span>Today's Progress</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Tasks Complete</span>
                      <span>{stats.tasksCompleted}/{stats.totalTasks}</span>
                    </div>
                    <Progress value={getProgressPercentage()} className="h-2" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="text-center">
                      <div className="font-medium">{stats.totalEntries}</div>
                      <div className="text-muted-foreground">Entries</div>
                    </div>
                    <div className="text-center">
                      <div className="font-medium">{stats.filesUploaded}</div>
                      <div className="text-muted-foreground">Files</div>
                    </div>
                    <div className="text-center">
                      <div className="font-medium">{stats.nodesLinked}</div>
                      <div className="text-muted-foreground">Nodes</div>
                    </div>
                    <div className="text-center">
                      <div className="font-medium">{nodes.length}</div>
                      <div className="text-muted-foreground">Total</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Zap className="h-5 w-5" />
                    <span>Quick Actions</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Upload File
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => setIsNodeDialogOpen(true)}
                  >
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Create Node
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => {
                      setIsAddingEntry(true);
                      setEntryType('task');
                      setActiveBlock('morning');
                    }}
                  >
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Add Task
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => setIsAIDialogOpen(true)}
                  >
                    <Brain className="h-4 w-4 mr-2" />
                    Ask AI
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => executeIntegration('google', 'Create Doc', { title: 'Daily Notes', content: 'Workspace export' })}
                  >
                    <Globe className="h-4 w-4 mr-2" />
                    Push to Google
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => executeIntegration('github', 'Create Issue', { title: 'New feature', labels: ['enhancement'] })}
                  >
                    <GitBranch className="h-4 w-4 mr-2" />
                    Create GitHub Issue
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => executeIntegration('slack', 'Send Message', { message: `Progress update: ${stats.tasksCompleted}/${stats.totalTasks} tasks completed` })}
                  >
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Send Slack Update
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => {
                      // Push all incomplete tasks to multiple apps
                      const incompleteTasks = timeBlocks.flatMap(block => 
                        block.entries.filter(entry => entry.type === 'task' && !entry.completed)
                      );
                      incompleteTasks.forEach(task => pushToMultipleApps(task));
                    }}
                  >
                    <Rocket className="h-4 w-4 mr-2" />
                    Sync All Tasks
                  </Button>
                </CardContent>
              </Card>

              {/* Node Links */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Link className="h-5 w-5" />
                    <span>Linked Nodes</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {nodes.slice(0, 4).map((node) => (
                      <div key={node.id} className="flex items-center space-x-2 p-2 rounded-lg border hover:bg-gray-50 cursor-pointer">
                        <div className="w-2 h-2 rounded-full bg-blue-500" />
                        <span className="text-sm truncate flex-1">{node.title}</span>
                        <ExternalLink className="h-3 w-3 text-muted-foreground" />
                      </div>
                    ))}
                    <Button variant="ghost" size="sm" className="w-full">
                      <Link className="h-4 w-4 mr-2" />
                      Link More Nodes
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="tasks">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="h-5 w-5" />
                <span>Smart Task Capsule</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <TaskBoard />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <Rocket className="h-5 w-5" />
                    <span>App Integrations</span>
                  </CardTitle>
                  <Button
                    onClick={() => setIsIntegrationsDialogOpen(true)}
                    className="flex items-center space-x-1"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Connect App</span>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {integrationPlatforms.map((platform) => (
                    <Card key={platform.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            <div className={`p-2 rounded-lg ${platform.color} text-white`}>
                              {platform.icon}
                            </div>
                            <div>
                              <h3 className="font-medium">{platform.name}</h3>
                              <p className="text-xs text-muted-foreground">
                                {integrations.filter(i => i.platform === platform.id).length} active
                              </p>
                            </div>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedIntegration(platform.id as Integration['platform'])}
                          >
                            <Send className="h-3 w-3" />
                          </Button>
                        </div>
                        
                        <div className="space-y-2">
                          <p className="text-xs font-medium text-muted-foreground">Quick Actions:</p>
                          <div className="flex flex-wrap gap-1">
                            {platform.actions.slice(0, 3).map((action) => (
                              <Button
                                key={action}
                                variant="ghost"
                                size="sm"
                                className="h-6 text-xs"
                                onClick={() => executeIntegration(platform.id as Integration['platform'], action, {})}
                              >
                                {action}
                              </Button>
                            ))}
                          </div>
                        </div>
                        
                        {integrations.filter(i => i.platform === platform.id).length > 0 && (
                          <div className="mt-3 pt-3 border-t">
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-green-600">Connected</span>
                              <span className="text-muted-foreground">
                                Last sync: {integrations.find(i => i.platform === platform.id && i.lastSync)?.lastSync ? 
                                  format(integrations.find(i => i.platform === platform.id && i.lastSync)!.lastSync!, 'HH:mm') : 'Never'}
                              </span>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Integrations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Workflow className="h-5 w-5" />
                  <span>Recent Activity</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {integrations.slice(-5).reverse().map((integration) => {
                    const platform = integrationPlatforms.find(p => p.id === integration.platform);
                    return (
                      <div key={integration.id} className="flex items-center justify-between p-3 rounded-lg border">
                        <div className="flex items-center space-x-3">
                          <div className={`p-1 rounded ${platform?.color} text-white`}>
                            {platform?.icon}
                          </div>
                          <div>
                            <p className="text-sm font-medium">{integration.action}</p>
                            <p className="text-xs text-muted-foreground">{platform?.name}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge 
                            variant={integration.status === 'success' ? 'default' : 
                                   integration.status === 'pending' ? 'secondary' : 'destructive'}
                          >
                            {integration.status}
                          </Badge>
                          {integration.lastSync && (
                            <span className="text-xs text-muted-foreground">
                              {format(integration.lastSync, 'HH:mm')}
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                  {integrations.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      <Workflow className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No integrations yet</p>
                      <p className="text-sm">Connect apps to start automating your workflow</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="automations">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <Zap className="h-5 w-5" />
                    <span>Automation Rules</span>
                  </CardTitle>
                  <Button
                    onClick={() => setIsAutomationDialogOpen(true)}
                    className="flex items-center space-x-1"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Create Rule</span>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {/* Pre-built automation templates */}
                  {[
                    {
                      name: 'Auto-sync to Google Calendar',
                      description: 'When task is created, add to Google Calendar',
                      trigger: 'Task Created',
                      actions: ['Google Calendar'],
                      enabled: true
                    },
                    {
                      name: 'GitHub Issue Creation',
                      description: 'When idea is added, create GitHub issue',
                      trigger: 'Idea Added',
                      actions: ['GitHub Issue'],
                      enabled: false
                    },
                    {
                      name: 'Slack Notifications',
                      description: 'Send daily summary to Slack channel',
                      trigger: 'End of Day',
                      actions: ['Slack Message'],
                      enabled: true
                    },
                    {
                      name: 'Excel Data Export',
                      description: 'Export completed tasks to Excel daily',
                      trigger: 'Daily 6PM',
                      actions: ['Excel Row'],
                      enabled: false
                    }
                  ].map((rule, index) => (
                    <Card key={index} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <h3 className="font-medium">{rule.name}</h3>
                            <p className="text-sm text-muted-foreground mt-1">{rule.description}</p>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-12"
                          >
                            {rule.enabled ? (
                              <div className="w-6 h-3 bg-green-500 rounded-full" />
                            ) : (
                              <div className="w-6 h-3 bg-gray-300 rounded-full" />
                            )}
                          </Button>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2 text-sm">
                            <span className="text-muted-foreground">Trigger:</span>
                            <Badge variant="outline">{rule.trigger}</Badge>
                          </div>
                          <div className="flex items-center space-x-2 text-sm">
                            <span className="text-muted-foreground">Actions:</span>
                            <div className="flex flex-wrap gap-1">
                              {rule.actions.map((action, i) => (
                                <Badge key={i} variant="secondary" className="text-xs">
                                  {action}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between mt-4 pt-3 border-t">
                          <span className="text-xs text-muted-foreground">
                            {rule.enabled ? 'Active' : 'Inactive'}
                          </span>
                          <div className="flex items-center space-x-1">
                            <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                              <Settings className="h-3 w-3" />
                            </Button>
                            <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                              <Copy className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Bulk Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Send className="h-5 w-5" />
                  <span>Bulk Actions</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Button
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center space-y-2"
                    onClick={() => {
                      // Push all today's tasks to multiple apps
                      timeBlocks.forEach(block => {
                        block.entries.forEach(entry => {
                          if (entry.type === 'task') {
                            pushToMultipleApps(entry);
                          }
                        });
                      });
                    }}
                  >
                    <Rocket className="h-6 w-6" />
                    <span className="text-xs text-center">Push All Tasks</span>
                  </Button>
                  
                  <Button
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center space-y-2"
                    onClick={() => executeIntegration('google', 'Create Sheet', { name: 'Daily Report', data: stats })}
                  >
                    <Database className="h-6 w-6" />
                    <span className="text-xs text-center">Export to Excel</span>
                  </Button>
                  
                  <Button
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center space-y-2"
                    onClick={() => executeIntegration('slack', 'Send Message', { message: `Daily update: ${stats.tasksCompleted}/${stats.totalTasks} tasks completed` })}
                  >
                    <MessageSquare className="h-6 w-6" />
                    <span className="text-xs text-center">Send Update</span>
                  </Button>
                  
                  <Button
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center space-y-2"
                    onClick={() => {
                      // Backup all data to Drive
                      executeIntegration('drive', 'Upload File', { 
                        name: `Workspace_Backup_${format(new Date(), 'yyyy-MM-dd')}`, 
                        data: { timeBlocks, tasks, files } 
                      });
                    }}
                  >
                    <Cloud className="h-6 w-6" />
                    <span className="text-xs text-center">Backup Data</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="files">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Paperclip className="h-5 w-5" />
                <span>File & Asset Manager</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <FileManager />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="nodes">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="h-5 w-5" />
                <span>Node Integration Panel</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {nodes.map((node) => (
                  <Card key={node.id} className="hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-medium text-sm">{node.title}</h3>
                        <Badge variant="secondary">{node.nodeType}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                        {node.content?.substring(0, 100)}...
                      </p>
                      {node.tags && node.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {node.tags.slice(0, 3).map((tag) => (
                            <Badge key={tag} variant="outline" className="text-xs">
                              #{tag}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Daily Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Productivity Score</span>
                    <span className="font-bold text-green-600">{Math.round(getProgressPercentage())}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Focus Time</span>
                    <span className="font-medium">4.2 hours</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Interruptions</span>
                    <span className="font-medium">7</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Energy Level</span>
                    <span className="font-medium">High</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Content Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Top Theme</span>
                    <span className="font-medium">Planning</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sentiment</span>
                    <span className="font-medium text-green-600">Positive</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Keywords</span>
                    <span className="font-medium">Innovation, Focus</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Connections Made</span>
                    <span className="font-medium">{stats.nodesLinked}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Weekly Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Avg. Daily Tasks</span>
                    <span className="font-medium">12</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Best Day</span>
                    <span className="font-medium">Tuesday</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Growth Rate</span>
                    <span className="font-medium text-green-600">+15%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Streak</span>
                    <span className="font-medium">5 days</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* AI Assistant Dialog */}
      <Dialog open={isAIDialogOpen} onOpenChange={setIsAIDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Brain className="h-5 w-5" />
              <span>AI Assistant Companion</span>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder="Ask about your day, get suggestions, or request analysis..."
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              className="min-h-[120px]"
            />
            <div className="flex flex-wrap gap-2">
              {[
                "What are today's major unfinished thoughts?",
                "Summarize my week's progress",
                "What's a good next step from these ideas?",
                "Generate daily report",
                "Analyze my productivity patterns",
                "Suggest task priorities"
              ].map((suggestion) => (
                <Button
                  key={suggestion}
                  variant="outline"
                  size="sm"
                  onClick={() => setAiPrompt(suggestion)}
                >
                  {suggestion}
                </Button>
              ))}
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="ghost" onClick={() => setIsAIDialogOpen(false)}>
                Cancel
              </Button>
              <Button>
                <Zap className="h-4 w-4 mr-2" />
                Ask AI
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={handleFileUpload}
      />
    </div>
  );
}