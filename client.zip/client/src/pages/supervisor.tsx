import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertTriangle, Users, CheckCircle, Clock, Flag, Shield, Activity, Eye, Edit3, UserX, UserCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { queryClient, apiRequest } from '@/lib/queryClient';
import type { User, Node, AuditLog, UserActivity, TagValidationIssue, SupervisorAlert } from '@shared/schema';

interface UserWithActivity extends User {
  nodeCount: number;
  taskCount: number;
  completedTasks: number;
  isOnline: boolean;
  lastSeen: Date;
}

export default function SupervisorDashboard() {
  const { toast } = useToast();
  const [selectedTab, setSelectedTab] = useState('overview');
  const [filterRole, setFilterRole] = useState<'all' | 'user' | 'supervisor'>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Data queries
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ['/api/users']
  });

  const { data: nodes = [] } = useQuery<Node[]>({
    queryKey: ['/api/nodes']
  });

  const { data: auditLogs = [] } = useQuery<AuditLog[]>({
    queryKey: ['/api/audit-logs']
  });

  const { data: userActivities = [] } = useQuery<UserActivity[]>({
    queryKey: ['/api/user-activities']
  });

  const { data: tagIssues = [] } = useQuery<TagValidationIssue[]>({
    queryKey: ['/api/tag-validation-issues']
  });

  const { data: alerts = [] } = useQuery<SupervisorAlert[]>({
    queryKey: ['/api/supervisor-alerts']
  });

  // Mutations
  const updateUserRole = useMutation({
    mutationFn: async ({ userId, role }: { userId: number; role: string }) => {
      return apiRequest('PATCH', `/api/users/${userId}/role`, { role });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Role Updated",
        description: "User role has been successfully updated.",
      });
    },
  });

  const toggleUserStatus = useMutation({
    mutationFn: async ({ userId, isActive }: { userId: number; isActive: boolean }) => {
      return apiRequest('PATCH', `/api/users/${userId}/status`, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "User Status Updated",
        description: "User status has been successfully updated.",
      });
    },
  });

  const resolveAlert = useMutation({
    mutationFn: async (alertId: number) => {
      return apiRequest('PATCH', `/api/supervisor-alerts/${alertId}/resolve`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/supervisor-alerts'] });
      toast({
        title: "Alert Resolved",
        description: "Alert has been marked as resolved.",
      });
    },
  });

  // Process users with activity data
  const usersWithActivity: UserWithActivity[] = users.map(user => {
    const userNodes = nodes.filter(node => node.createdBy === user.id);
    const userTasks = userNodes.filter(node => node.nodeType === 'task');
    const completedTasks = userTasks.filter(task => 
      task.properties && typeof task.properties === 'object' && 
      'status' in task.properties && task.properties.status === 'done'
    );
    
    const recentActivity = userActivities.find(activity => 
      activity.userId === user.id && 
      activity.timestamp > new Date(Date.now() - 15 * 60 * 1000) // 15 minutes
    );

    return {
      ...user,
      nodeCount: userNodes.length,
      taskCount: userTasks.length,
      completedTasks: completedTasks.length,
      isOnline: !!recentActivity,
      lastSeen: user.lastActivity || user.createdAt
    };
  });

  // Filter users based on search and filters
  const filteredUsers = usersWithActivity.filter(user => {
    const matchesSearch = user.displayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === 'all' || user.role === filterRole;
    const matchesStatus = filterStatus === 'all' || 
                         (filterStatus === 'active' && user.isActive) ||
                         (filterStatus === 'inactive' && !user.isActive);
    
    return matchesSearch && matchesRole && matchesStatus;
  });

  // Statistics
  const stats = {
    totalUsers: users.length,
    activeUsers: users.filter(u => u.isActive).length,
    supervisors: users.filter(u => u.role === 'supervisor').length,
    admins: users.filter(u => u.role === 'admin').length,
    totalNodes: nodes.length,
    untaggedNodes: nodes.filter(n => !n.tags || n.tags.length === 0).length,
    overdueALerts: alerts.filter(a => a.severity === 'high' && a.status === 'active').length,
    tagIssues: tagIssues.filter(i => i.status === 'open').length,
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'supervisor': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'user': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Shield className="w-8 h-8 text-blue-600" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Supervisor Dashboard</h1>
              <p className="text-gray-600">Manage users, monitor activity, and maintain system health</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="text-sm">
              {stats.overdueALerts} Critical Alerts
            </Badge>
            <Badge variant="outline" className="text-sm">
              {stats.tagIssues} Tag Issues
            </Badge>
          </div>
        </div>

        {/* Statistics Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalUsers}</div>
              <div className="text-sm text-gray-500">{stats.activeUsers} active</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Supervisors</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.supervisors}</div>
              <div className="text-sm text-gray-500">{stats.admins} admins</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Nodes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalNodes}</div>
              <div className="text-sm text-gray-500">{stats.untaggedNodes} untagged</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Active Issues</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.overdueALerts + stats.tagIssues}</div>
              <div className="text-sm text-gray-500">Need attention</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="alerts">Alerts</TabsTrigger>
            <TabsTrigger value="tags">Tag Issues</TabsTrigger>
            <TabsTrigger value="audit">Audit Logs</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Activity className="w-5 h-5" />
                    <span>Recent Activity</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-3">
                      {userActivities.slice(0, 10).map((activity) => {
                        const user = users.find(u => u.id === activity.userId);
                        return (
                          <div key={activity.id} className="flex items-center space-x-3 p-2 rounded-lg bg-gray-50">
                            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                              <span className="text-sm font-medium">{user?.displayName?.[0]}</span>
                            </div>
                            <div className="flex-1">
                              <div className="text-sm font-medium">{user?.displayName}</div>
                              <div className="text-xs text-gray-500">
                                {activity.activityType.replace('_', ' ')} • {activity.timestamp.toLocaleString()}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* System Health */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5" />
                    <span>System Health</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Node Tagging</span>
                      <Badge variant={stats.untaggedNodes > 10 ? "destructive" : "secondary"}>
                        {stats.untaggedNodes > 10 ? "Needs Attention" : "Good"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">User Activity</span>
                      <Badge variant={stats.activeUsers < stats.totalUsers * 0.8 ? "destructive" : "secondary"}>
                        {stats.activeUsers < stats.totalUsers * 0.8 ? "Low Activity" : "Active"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Critical Alerts</span>
                      <Badge variant={stats.overdueALerts > 0 ? "destructive" : "secondary"}>
                        {stats.overdueALerts > 0 ? `${stats.overdueALerts} Active` : "None"}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users" className="space-y-4">
            {/* User Filters */}
            <Card>
              <CardHeader>
                <CardTitle>Employee Management</CardTitle>
                <CardDescription>Manage user roles, status, and monitor activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-4 mb-4">
                  <Input
                    placeholder="Search users..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="max-w-sm"
                  />
                  <Select value={filterRole} onValueChange={(value: any) => setFilterRole(value)}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Roles</SelectItem>
                      <SelectItem value="user">User</SelectItem>
                      <SelectItem value="supervisor">Supervisor</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterStatus} onValueChange={(value: any) => setFilterStatus(value)}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {filteredUsers.map((user) => (
                      <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                            <span className="text-sm font-medium">{user.displayName[0]}</span>
                          </div>
                          <div>
                            <div className="flex items-center space-x-2">
                              <span className="font-medium">{user.displayName}</span>
                              <Badge className={getRoleColor(user.role)}>
                                {user.role}
                              </Badge>
                              {user.isOnline && (
                                <Badge variant="outline" className="bg-green-50 text-green-700">
                                  Online
                                </Badge>
                              )}
                            </div>
                            <div className="text-sm text-gray-500">{user.email}</div>
                            <div className="text-xs text-gray-400">
                              {user.nodeCount} nodes • {user.taskCount} tasks • {user.completedTasks} completed
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Select
                            value={user.role}
                            onValueChange={(role) => updateUserRole.mutate({ userId: user.id, role })}
                          >
                            <SelectTrigger className="w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="user">User</SelectItem>
                              <SelectItem value="supervisor">Supervisor</SelectItem>
                              <SelectItem value="admin">Admin</SelectItem>
                            </SelectContent>
                          </Select>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => toggleUserStatus.mutate({ userId: user.id, isActive: !user.isActive })}
                          >
                            {user.isActive ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="alerts" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5" />
                  <span>System Alerts</span>
                </CardTitle>
                <CardDescription>Monitor and resolve system issues</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {alerts.map((alert) => (
                      <div key={alert.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                            <AlertTriangle className="w-5 h-5 text-orange-600" />
                          </div>
                          <div>
                            <div className="flex items-center space-x-2">
                              <span className="font-medium">{alert.message}</span>
                              <Badge className={getSeverityColor(alert.severity)}>
                                {alert.severity}
                              </Badge>
                            </div>
                            <div className="text-sm text-gray-500">
                              {alert.alertType} • {alert.createdAt.toLocaleString()}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {alert.status === 'active' && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => resolveAlert.mutate(alert.id)}
                            >
                              Resolve
                            </Button>
                          )}
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tags" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Flag className="w-5 h-5" />
                  <span>Tag Validation Issues</span>
                </CardTitle>
                <CardDescription>Review and fix node tagging issues</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {tagIssues.map((issue) => {
                      const node = nodes.find(n => n.id === issue.nodeId);
                      return (
                        <div key={issue.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
                              <Flag className="w-5 h-5 text-yellow-600" />
                            </div>
                            <div>
                              <div className="flex items-center space-x-2">
                                <span className="font-medium">{node?.title || 'Unknown Node'}</span>
                                <Badge className={getSeverityColor(issue.severity)}>
                                  {issue.severity}
                                </Badge>
                              </div>
                              <div className="text-sm text-gray-500">
                                {issue.issueType.replace('_', ' ')} • {issue.createdAt.toLocaleString()}
                              </div>
                              {issue.suggestedTags && issue.suggestedTags.length > 0 && (
                                <div className="text-xs text-gray-400">
                                  Suggested: {issue.suggestedTags.join(', ')}
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button variant="outline" size="sm">
                              <Edit3 className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Eye className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="audit" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Clock className="w-5 h-5" />
                  <span>Audit Log</span>
                </CardTitle>
                <CardDescription>Track all supervisor and admin actions</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {auditLogs.map((log) => {
                      const user = users.find(u => u.id === log.userId);
                      return (
                        <div key={log.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                              <span className="text-sm font-medium">{user?.displayName?.[0]}</span>
                            </div>
                            <div>
                              <div className="font-medium">{log.description || log.action}</div>
                              <div className="text-sm text-gray-500">
                                {user?.displayName} • {log.createdAt.toLocaleString()}
                              </div>
                              <div className="text-xs text-gray-400">
                                {log.targetType} #{log.targetId}
                              </div>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}