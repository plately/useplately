import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import desqLogoSrc from "@assets/desq-logo.png";
import { Button } from "@/components/ui/button";
import {
  ArrowRight,
  CheckCircle,
  Users,
  BarChart3,
  MessageSquare,
  Calendar,
  GitBranch,
  Shield,
  Globe,
  Menu,
  X,
  FolderOpen,
  Layout,
  Zap,
  ChevronRight,
  ChevronDown,
  Plus,
  FileText,
  Lightbulb,
  Clock,
  Tag,
  Link2,
} from "lucide-react";

/* ─── Node type tab data ─────────────────────────────── */
const NODE_TYPES = [
  {
    label: "Task",
    color: "#818cf8",
    bg: "bg-indigo-500/10",
    border: "border-indigo-500/30",
    accent: "text-indigo-400",
    icon: CheckCircle,
    title: "Implement JWT Authentication",
    meta: [
      { icon: Clock, text: "Due: Next Week" },
      { icon: Tag, text: "Priority: High" },
      { icon: Users, text: "Assigned: Alex" },
    ],
    desc: "Create any message, idea, or requirement into a tracked task — with due dates, assignees, and priorities.",
  },
  {
    label: "Note",
    color: "#34d399",
    bg: "bg-emerald-500/10",
    border: "border-emerald-500/30",
    accent: "text-emerald-400",
    icon: FileText,
    title: "API Design Decisions",
    meta: [
      { icon: Tag, text: "Tag: backend" },
      { icon: Link2, text: "Linked: 3 nodes" },
      { icon: Users, text: "By: Sarah" },
    ],
    desc: "Capture meeting minutes, research findings, or documentation as richly linked notes in the graph.",
  },
  {
    label: "Meeting",
    color: "#fb923c",
    bg: "bg-orange-500/10",
    border: "border-orange-500/30",
    accent: "text-orange-400",
    icon: Users,
    title: "Q3 Planning Kickoff",
    meta: [
      { icon: Calendar, text: "Sep 12 — 10:00 AM" },
      { icon: Users, text: "5 attendees" },
      { icon: CheckCircle, text: "2 action items" },
    ],
    desc: "Turn calendar events into meeting nodes that auto-link attendees, agenda items, and follow-up tasks.",
  },
  {
    label: "Chat Message",
    color: "#38bdf8",
    bg: "bg-sky-500/10",
    border: "border-sky-500/30",
    accent: "text-sky-400",
    icon: MessageSquare,
    title: "We should add rate limiting",
    meta: [
      { icon: MessageSquare, text: "#engineering channel" },
      { icon: Users, text: "From: Michael" },
      { icon: Link2, text: "Node created" },
    ],
    desc: "Any chat message can become a node with one click — preserving full context from the conversation.",
  },
  {
    label: "Idea",
    color: "#c084fc",
    bg: "bg-purple-500/10",
    border: "border-purple-500/30",
    accent: "text-purple-400",
    icon: Lightbulb,
    title: "Offline-first sync architecture",
    meta: [
      { icon: Tag, text: "Status: Exploring" },
      { icon: Users, text: "Champion: Alex" },
      { icon: Link2, text: "Linked: 5 nodes" },
    ],
    desc: "Capture sparks of inspiration before they disappear — ideas connect to tasks, notes, and discussions.",
  },
  {
    label: "File",
    color: "#f472b6",
    bg: "bg-pink-500/10",
    border: "border-pink-500/30",
    accent: "text-pink-400",
    icon: FolderOpen,
    title: "Brand_Guidelines_v3.pdf",
    meta: [
      { icon: FolderOpen, text: "Design folder" },
      { icon: Users, text: "Uploaded: Sarah" },
      { icon: Link2, text: "Linked: 2 nodes" },
    ],
    desc: "Every uploaded file becomes a node — linked to projects, tasks, and the people who need it.",
  },
];

/* ─── FAQ items ──────────────────────────────────────── */
const FAQ = [
  {
    q: "What is a node?",
    a: "A node is any piece of information in Desq — a task, note, meeting, chat message, file, or idea. Every node can be linked to others, forming a living knowledge graph of your team's work.",
  },
  {
    q: "How does chat-to-node work?",
    a: "In any Desq chat channel, hover over a message and click the node icon. Choose the type (task, note, idea, meeting) and it's instantly captured as a linked node — with the full conversation context preserved.",
  },
  {
    q: "Is the graph interactive?",
    a: "Yes — you can drag nodes, zoom, pan, create new links by selecting two nodes, filter by type, and open any node for full editing. The graph updates in real time as your team works.",
  },
  {
    q: "How does Discord sync work?",
    a: "Connect your Discord server and map channels to Desq categories. Task updates, journal entries, and graph changes automatically post to your Discord — and Discord messages can be promoted to nodes directly from Desq.",
  },
  {
    q: "What is the Planning Room?",
    a: "The Planning Room is an infinite canvas where you drag and drop blocks (tasks, ideas, files, timelines) and draw connections between them. You can schedule emails, launch plans, and export the result — all without leaving Desq.",
  },
  {
    q: "Does Desq work offline?",
    a: "Desq is built offline-first. Changes made without a connection are queued and synced when you reconnect, with automatic conflict resolution for simultaneous edits.",
  },
  {
    q: "Can I invite my team for free?",
    a: "Yes — the Starter plan is free for up to 5 users with 500 nodes. Invite your team with a single link, no credit card required.",
  },
];

/* ─── Main component ─────────────────────────────────── */
export function WelcomePage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeNode, setActiveNode] = useState(0);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0.5, y: 0.45 });

  const NodeType = NODE_TYPES[activeNode];
  const NodeIcon = NodeType.icon;

  const handleHeroMouseMove = (e: React.MouseEvent<HTMLElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({
      x: (e.clientX - rect.left) / rect.width,
      y: (e.clientY - rect.top) / rect.height,
    });
  };

  return (
    <div className="min-h-screen font-sans antialiased" style={{ background: "#0a0a0a", color: "#fff" }}>

      {/* ── Nav ─────────────────────────────────────────── */}
      <header className="fixed top-0 inset-x-0 z-50 border-b border-white/[0.06]" style={{ background: "rgba(10,10,10,0.08)", backdropFilter: "blur(16px)" }}>
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between h-14">
          <Link href="/"><img src={desqLogoSrc} alt="desq" className="h-7 object-contain" style={{ filter: "invert(1)" }} /></Link>

          <nav className="hidden md:flex items-center gap-7 text-sm text-white/50">
            <a href="#node" className="hover:text-white transition-colors">Features</a>
            <a href="#graph" className="hover:text-white transition-colors">Graph</a>
            <a href="#planning" className="hover:text-white transition-colors">Planning</a>
            <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
            <a href="#faq" className="hover:text-white transition-colors">FAQ</a>
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <Link href="/auth/login" className="text-sm text-white/50 hover:text-white px-3 py-1.5 transition-colors">Sign in</Link>
            <Link href="/auth/register">
              <button className="text-sm font-medium bg-white text-black px-4 py-1.5 rounded-md hover:bg-white/90 transition-colors">Get started</button>
            </Link>
          </div>

          <button className="md:hidden p-2 text-white/50 hover:text-white" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {menuOpen && (
          <div className="md:hidden border-t border-white/[0.06] bg-[#0a0a0a] px-6 py-4 space-y-3">
            {["#node","#graph","#planning","#pricing","#faq"].map((href, i) => (
              <a key={i} href={href} className="block text-sm text-white/60 py-1 capitalize" onClick={() => setMenuOpen(false)}>{href.slice(1)}</a>
            ))}
            <div className="pt-2 flex flex-col gap-2">
              <Link href="/auth/login"><button className="w-full text-sm border border-white/20 text-white px-4 py-2 rounded-md">Sign in</button></Link>
              <Link href="/auth/register"><button className="w-full text-sm bg-white text-black px-4 py-2 rounded-md font-medium">Get started</button></Link>
            </div>
          </div>
        )}
      </header>

      {/* ── Hero ────────────────────────────────────────── */}
      <section
        className="relative pt-36 pb-24 flex flex-col items-center text-center px-6 overflow-hidden"
        onMouseMove={handleHeroMouseMove}
      >
        {/* Original top-center indigo bloom */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[500px] pointer-events-none"
          style={{ background: "radial-gradient(ellipse at center top, rgba(99,102,241,0.18) 0%, transparent 70%)" }} />

        {/* Ambient purple orb — bottom-left, slow drift */}
        <div
          className="hero-orb-left absolute pointer-events-none"
          style={{
            left: "-10%",
            top: "30%",
            width: 640,
            height: 640,
            background: "radial-gradient(circle, rgba(139,92,246,0.14) 0%, rgba(168,85,247,0.07) 45%, transparent 72%)",
            borderRadius: "50%",
            filter: "blur(2px)",
          }}
        />

        {/* Ambient electric-blue orb — right side, slow drift */}
        <div
          className="hero-orb-right absolute pointer-events-none"
          style={{
            right: "-8%",
            top: "10%",
            width: 560,
            height: 560,
            background: "radial-gradient(circle, rgba(59,130,246,0.13) 0%, rgba(96,165,250,0.06) 50%, transparent 72%)",
            borderRadius: "50%",
            filter: "blur(2px)",
          }}
        />

        {/* Mouse-following spotlight — purple → electric blue mix */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: `radial-gradient(700px circle at ${mousePos.x * 100}% ${mousePos.y * 100}%,
              rgba(139,92,246,0.09) 0%,
              rgba(59,130,246,0.06) 35%,
              transparent 68%)`,
            transition: "background 0.25s ease-out",
          }}
        />

        <div className="inline-flex items-center gap-2 border border-white/10 rounded-full px-3.5 py-1 text-xs text-white/50 mb-8 font-medium">
          <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
          Now in early access — free to start
          <ChevronRight className="w-3 h-3" />
        </div>

        <h1 className="text-5xl sm:text-6xl lg:text-[80px] font-bold text-white leading-[1.04] tracking-[-0.03em] max-w-4xl mb-6">
          You've got a new Desq
          <span className="text-white/25"> where your work actually connects.</span>
        </h1>

        <p className="text-lg text-white/40 max-w-xl leading-relaxed mb-10">
          Desq links your tasks, notes, meetings, files, and conversations into one living knowledge graph — so your team always has context.
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <Link href="/auth/register">
            <button className="inline-flex items-center gap-2 bg-white text-black font-semibold px-6 py-3 rounded-lg text-sm hover:bg-white/90 transition-colors shadow-lg">
              Start for free <ArrowRight className="w-4 h-4" />
            </button>
          </Link>
          <Link href="/auth/login">
            <button className="inline-flex items-center gap-2 border border-white/10 text-white/70 hover:text-white hover:border-white/20 px-6 py-3 rounded-lg text-sm transition-colors">
              Sign in
            </button>
          </Link>
        </div>

        <p className="mt-5 text-white/20 text-xs">No credit card required</p>

        {/* Hero app preview */}
        <div className="relative mt-20 w-full max-w-5xl mx-auto">
          <HeroAppPreview />
          <div className="absolute inset-x-0 bottom-0 h-28 pointer-events-none"
            style={{ background: "linear-gradient(to top, #0a0a0a 0%, transparent 100%)" }} />
        </div>
      </section>

      {/* ── Turn anything into a node ───────────────────── */}
      <section id="node" className="py-28 px-6 border-t border-white/[0.06]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-xs font-medium tracking-widest text-indigo-400 uppercase mb-4">The Node System</p>
            <h2 className="text-3xl sm:text-5xl font-bold text-white tracking-tight leading-tight">
              Everything becomes a node.
              <br /><span className="text-white/30">Nothing gets lost.</span>
            </h2>
            <p className="text-white/40 mt-4 max-w-xl mx-auto text-sm leading-relaxed">
              Every task, note, meeting, chat message, file, and idea is stored as a connected node — searchable, linkable, and visible in your team's knowledge graph.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
            {/* Left: type selector */}
            <div className="space-y-3">
              <p className="text-xs text-white/30 uppercase tracking-widest mb-5 font-medium">Select a node type</p>
              {NODE_TYPES.map((type, i) => {
                const Icon = type.icon;
                const active = activeNode === i;
                return (
                  <button
                    key={i}
                    onClick={() => setActiveNode(i)}
                    className={`w-full text-left flex items-center gap-4 px-5 py-4 rounded-xl border transition-all duration-150 ${
                      active
                        ? `${type.bg} ${type.border} border`
                        : "border-white/[0.06] hover:border-white/15 hover:bg-white/[0.02]"
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${active ? type.bg : "bg-white/[0.05]"}`}>
                      <Icon className={`w-4 h-4 ${active ? type.accent : "text-white/40"}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className={`text-sm font-semibold ${active ? "text-white" : "text-white/60"}`}>{type.label}</div>
                      {active && <div className="text-xs text-white/40 mt-0.5 leading-relaxed">{type.desc}</div>}
                    </div>
                    {active && <ChevronRight className={`w-4 h-4 flex-shrink-0 ${type.accent}`} />}
                  </button>
                );
              })}
            </div>

            {/* Right: node preview card */}
            <div className="lg:sticky lg:top-24">
              <div className="rounded-2xl border border-white/[0.08] overflow-hidden" style={{ background: "#111" }}>
                {/* Card header */}
                <div className="px-5 py-4 border-b border-white/[0.06] flex items-center justify-between" style={{ background: "#0d0d0d" }}>
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
                    <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
                    <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
                  </div>
                  <span className="text-xs text-white/20 font-medium">desq — Node View</span>
                  <div className="w-16" />
                </div>

                <div className="p-6">
                  {/* Node type badge */}
                  <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold mb-4 ${NodeType.bg} ${NodeType.accent}`}>
                    <NodeIcon className="w-3 h-3" />
                    {NodeType.label}
                  </div>

                  {/* Title */}
                  <h3 className="text-white font-semibold text-lg mb-5 leading-snug">{NodeType.title}</h3>

                  {/* Meta fields */}
                  <div className="space-y-3 mb-6">
                    {NodeType.meta.map((m, i) => {
                      const MetaIcon = m.icon;
                      return (
                        <div key={i} className="flex items-center gap-3">
                          <div className="w-7 h-7 rounded-md bg-white/[0.05] flex items-center justify-center flex-shrink-0">
                            <MetaIcon className="w-3.5 h-3.5 text-white/40" />
                          </div>
                          <span className="text-sm text-white/50">{m.text}</span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Graph link indicator */}
                  <div className="border-t border-white/[0.06] pt-4 mt-4">
                    <div className="flex items-center gap-2 text-xs text-white/30">
                      <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: NodeType.color }} />
                      Visible in knowledge graph · linked to {Math.floor(Math.random() * 4) + 1} other nodes
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 mt-4">
                    <button className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-md ${NodeType.bg} ${NodeType.accent} transition-opacity hover:opacity-80`}>
                      <Link2 className="w-3 h-3" /> Link node
                    </button>
                    <button className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-md bg-white/[0.05] text-white/50 hover:bg-white/[0.08] transition-colors">
                      <Plus className="w-3 h-3" /> Add to graph
                    </button>
                  </div>
                </div>
              </div>

              <p className="text-center text-xs text-white/20 mt-4">Click any type on the left to preview →</p>
            </div>
          </div>
        </div>
      </section>

      {/* ── Chat to Node ────────────────────────────────── */}
      <section className="py-24 px-6 border-t border-white/[0.06]">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left: chat mockup */}
          <div className="rounded-2xl overflow-hidden border border-white/[0.08]" style={{ background: "#111" }}>
            {/* Channel header */}
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/[0.06]" style={{ background: "#0d0d0d" }}>
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center text-xs font-bold text-white">#</div>
                <div>
                  <div className="text-sm font-semibold text-white">development</div>
                  <div className="text-[10px] text-white/30">3 members online</div>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span className="text-xs text-white/40">Live</span>
              </div>
            </div>

            {/* Messages */}
            <div className="p-5 space-y-5">
              {/* Alex message */}
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-xs font-bold text-white flex-shrink-0">A</div>
                <div className="flex-1">
                  <div className="flex items-baseline gap-2 mb-1.5">
                    <span className="text-sm font-semibold text-white">Alex</span>
                    <span className="text-[10px] text-white/25">10:30 AM</span>
                  </div>
                  <div className="text-sm text-white/70 leading-relaxed mb-3">
                    We need to implement JWT authentication before the demo next week. Should take about 3 days to complete properly.
                  </div>

                  {/* Converted task card */}
                  <div className="rounded-xl border border-indigo-500/30 p-3.5" style={{ background: "rgba(99,102,241,0.08)" }}>
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="w-3.5 h-3.5 text-indigo-400" />
                      <span className="text-xs font-semibold text-indigo-400">Task Created</span>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-white/70"><span className="text-white/40">Title:</span> Implement JWT Authentication</p>
                      <p className="text-xs text-white/70"><span className="text-white/40">Due:</span> Next Week</p>
                      <p className="text-xs text-white/70"><span className="text-white/40">Context:</span> From #development chat</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Sarah message */}
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center text-xs font-bold text-white flex-shrink-0">S</div>
                <div className="flex-1">
                  <div className="flex items-baseline gap-2 mb-1.5">
                    <span className="text-sm font-semibold text-white">Sarah</span>
                    <span className="text-[10px] text-white/25">10:32 AM</span>
                  </div>
                  <p className="text-sm text-white/70 leading-relaxed">
                    Great idea! I found a really helpful tutorial on JWT. Let me schedule a quick review session.
                  </p>
                </div>
              </div>
            </div>

            {/* Input */}
            <div className="px-5 pb-5">
              <div className="flex items-center gap-3 rounded-xl border border-white/[0.08] px-4 py-2.5" style={{ background: "#0d0d0d" }}>
                <span className="text-sm text-white/20 flex-1">Type your message…</span>
                <button className="text-xs font-semibold bg-indigo-600 text-white px-3 py-1.5 rounded-lg">Send</button>
              </div>
            </div>
          </div>

          {/* Right: description */}
          <div>
            <p className="text-xs font-medium tracking-widest text-indigo-400 uppercase mb-4">Chat → Node</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight leading-tight mb-4">
              Context-Aware
              <br /><span className="text-white/30">Conversations</span>
            </h2>
            <p className="text-white/50 leading-relaxed mb-8 text-sm">
              Transform everyday team conversations into structured knowledge. Every message becomes a potential building block for your team's collective intelligence.
            </p>

            <div className="space-y-5">
              {[
                { color: "bg-indigo-500", title: "One-Click Node Creation", desc: "Instantly convert messages into tasks, notes, ideas, or meetings without breaking the conversation flow." },
                { color: "bg-emerald-500", title: "Automatic Context Linking", desc: "Messages automatically reference related nodes, preserving the full context of decisions and discussions." },
                { color: "bg-purple-500", title: "Seamless Integration", desc: "Chat nodes appear instantly in your knowledge graph, connected to all relevant context and team members." },
              ].map((item, i) => (
                <div key={i} className="flex gap-4">
                  <div className={`w-8 h-8 rounded-lg ${item.color} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                    <CheckCircle className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-white mb-1">{item.title}</div>
                    <div className="text-sm text-white/40 leading-relaxed">{item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Planning Room ───────────────────────────────── */}
      <section id="planning" className="py-24 px-6 border-t border-white/[0.06]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-xs font-medium tracking-widest text-pink-400 uppercase mb-4">Planning Room</p>
            <h2 className="text-3xl sm:text-5xl font-bold text-white tracking-tight leading-tight">
              Visual Workflows
              <br /><span className="text-white/30">That Actually Work</span>
            </h2>
            <p className="text-white/40 mt-4 max-w-2xl mx-auto text-sm leading-relaxed">
              Design complex workflows with drag-and-drop blocks. Each block can send emails, create tasks, schedule events, make announcements, and reference documents — all from one infinite canvas.
            </p>
          </div>

          {/* Planning room mockup */}
          <div className="rounded-2xl border border-white/[0.08] overflow-hidden" style={{ background: "#0d0d0d" }}>
            {/* Titlebar */}
            <div className="flex items-center justify-between px-5 py-3 border-b border-white/[0.06]">
              <div className="flex items-center gap-3">
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
                  <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
                  <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
                </div>
                <span className="text-sm font-semibold text-white/70">Desq MVP Development</span>
                <span className="text-[10px] border border-white/15 text-white/30 px-2 py-0.5 rounded-full">software</span>
              </div>
              <div className="flex items-center gap-2">
                <button className="text-xs border border-white/10 text-white/50 px-3 py-1.5 rounded-md">Save Draft</button>
                <button className="text-xs bg-indigo-600 text-white px-3 py-1.5 rounded-md font-medium flex items-center gap-1">
                  <Zap className="w-3 h-3" /> Launch Plan
                </button>
              </div>
            </div>

            <div className="flex" style={{ height: 380 }}>
              {/* Sidebar blocks */}
              <div className="w-20 border-r border-white/[0.06] p-3 flex flex-col gap-3 flex-shrink-0">
                <p className="text-[9px] text-white/20 uppercase tracking-widest font-medium text-center">Blocks</p>
                {[
                  { color: "bg-indigo-500", label: "Idea" },
                  { color: "bg-emerald-500", label: "Task" },
                  { color: "bg-white/20", label: "File" },
                  { color: "bg-purple-500", label: "Node" },
                  { color: "bg-orange-500", label: "Timeline" },
                  { color: "bg-pink-500", label: "Email" },
                ].map((b, i) => (
                  <div key={i} className="flex flex-col items-center gap-1">
                    <div className={`w-9 h-9 ${b.color} rounded-lg flex items-center justify-center cursor-pointer hover:opacity-80 transition-opacity`}>
                      <Plus className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-[9px] text-white/30">{b.label}</span>
                  </div>
                ))}
              </div>

              {/* Canvas */}
              <div className="flex-1 relative p-6" style={{ background: "radial-gradient(circle at 50% 50%, rgba(255,255,255,0.01) 0%, transparent 70%)", backgroundImage: "radial-gradient(rgba(255,255,255,0.04) 1px, transparent 1px)", backgroundSize: "28px 28px" }}>
                {/* Block 1 — Core Architecture */}
                <div className="absolute" style={{ left: 40, top: 30, width: 200 }}>
                  <div className="rounded-xl p-4 border border-indigo-500/40" style={{ background: "rgba(99,102,241,0.15)" }}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-indigo-300">Core Architecture</span>
                      <div className="w-5 h-5 rounded-full bg-orange-500 flex items-center justify-center text-[9px] text-white font-bold">!</div>
                    </div>
                    <p className="text-[10px] text-indigo-200/60 leading-relaxed">Define the foundational architecture for the Desq system</p>
                  </div>
                </div>

                {/* Arrow 1 */}
                <svg className="absolute" style={{ left: 245, top: 62, width: 80, height: 20 }} viewBox="0 0 80 20">
                  <defs><marker id="ah" markerWidth="6" markerHeight="6" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 z" fill="rgba(255,255,255,0.2)" /></marker></defs>
                  <line x1="0" y1="10" x2="70" y2="10" stroke="rgba(255,255,255,0.15)" strokeWidth="1.5" strokeDasharray="4,3" markerEnd="url(#ah)" />
                  <text x="35" y="7" textAnchor="middle" className="text-[8px]" fill="rgba(255,255,255,0.2)" fontSize="8">enables</text>
                </svg>

                {/* Block 2 — Backend API */}
                <div className="absolute" style={{ right: 30, top: 30, width: 190 }}>
                  <div className="rounded-xl p-4 border border-emerald-500/40" style={{ background: "rgba(52,211,153,0.12)" }}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-emerald-300">Backend API</span>
                      <CheckCircle className="w-4 h-4 text-emerald-400" />
                    </div>
                    <p className="text-[10px] text-emerald-200/60 leading-relaxed">Implement REST API endpoints for nodes and connections</p>
                  </div>
                </div>

                {/* Arrow 2 */}
                <svg className="absolute" style={{ right: 125, top: 120, width: 20, height: 80 }} viewBox="0 0 20 80">
                  <defs><marker id="av" markerWidth="6" markerHeight="6" refX="3" refY="6" orient="auto"><path d="M0,0 L3,6 L6,0 z" fill="rgba(255,255,255,0.2)" /></marker></defs>
                  <line x1="10" y1="0" x2="10" y2="70" stroke="rgba(255,255,255,0.15)" strokeWidth="1.5" strokeDasharray="4,3" markerEnd="url(#av)" />
                  <text x="13" y="40" className="text-[8px]" fill="rgba(255,255,255,0.2)" fontSize="8">↓</text>
                </svg>

                {/* Schedule Email panel */}
                <div className="absolute" style={{ left: 40, top: 160, width: 180 }}>
                  <div className="rounded-xl border border-white/[0.12] p-4" style={{ background: "#1a1a1a" }}>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-semibold text-white/70">Schedule Email</span>
                      <X className="w-3 h-3 text-white/30 cursor-pointer" />
                    </div>
                    <div className="space-y-2">
                      {["team@company.com", "Q1 Milestone Update"].map((ph, i) => (
                        <div key={i} className="rounded-md border border-white/[0.08] px-2.5 py-1.5 text-[10px] text-white/20" style={{ background: "#111" }}>{ph}</div>
                      ))}
                      <div className="rounded-md border border-white/[0.08] px-2.5 py-1.5 text-[10px] text-white/20 flex items-center justify-between" style={{ background: "#111" }}>
                        When milestone completes <ChevronDown className="w-3 h-3" />
                      </div>
                    </div>
                    <div className="flex gap-2 mt-3">
                      <button className="flex-1 text-[10px] border border-white/10 text-white/40 py-1.5 rounded-md">Cancel</button>
                      <button className="flex-1 text-[10px] bg-indigo-600 text-white py-1.5 rounded-md font-medium">Schedule</button>
                    </div>
                  </div>
                </div>

                {/* Block 3 — Q1 Milestone */}
                <div className="absolute" style={{ right: 30, bottom: 30, width: 190 }}>
                  <div className="rounded-xl p-4 border border-orange-500/40" style={{ background: "rgba(251,146,60,0.12)" }}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-orange-300">Q1 2025 Milestone</span>
                      <div className="w-5 h-5 rounded-full bg-orange-500/30 flex items-center justify-center text-[9px] text-orange-300 font-bold">17</div>
                    </div>
                    <p className="text-[10px] text-orange-200/60">Launch beta version with core features</p>
                  </div>
                </div>

                {/* Mini map */}
                <div className="absolute top-3 right-3 rounded-lg border border-white/[0.08] p-2" style={{ background: "#1a1a1a" }}>
                  <p className="text-[8px] text-white/20 mb-1.5">Mini Map</p>
                  <div className="relative w-14 h-9">
                    <div className="absolute w-3 h-2 rounded-sm bg-indigo-500/60" style={{ left: 0, top: 0 }} />
                    <div className="absolute w-3 h-2 rounded-sm bg-emerald-500/60" style={{ right: 0, top: 0 }} />
                    <div className="absolute w-3 h-2 rounded-sm bg-orange-500/60" style={{ right: 0, bottom: 0 }} />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Planning features below */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 mt-8">
            {[
              { icon: Layout, title: "7 block types", desc: "Idea, Task, File, Node, Timeline, Comment, Email — each block is fully configurable." },
              { icon: Zap, title: "Launch plans", desc: "Schedule or trigger blocks immediately. Automated emails, task creation, and announcements." },
              { icon: GitBranch, title: "Connects to graph", desc: "Every planning room block creates or links to nodes — your plan lives in the knowledge graph." },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <div key={i} className="rounded-xl border border-white/[0.08] p-5" style={{ background: "#111" }}>
                  <Icon className="w-5 h-5 text-pink-400 mb-3" />
                  <div className="text-sm font-semibold text-white mb-1">{item.title}</div>
                  <div className="text-xs text-white/40 leading-relaxed">{item.desc}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── Knowledge Graph ─────────────────────────────── */}
      <section id="graph" className="py-24 px-6 border-t border-white/[0.06]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-xs font-medium tracking-widest text-violet-400 uppercase mb-4">Knowledge Graph</p>
            <h2 className="text-3xl sm:text-5xl font-bold text-white tracking-tight leading-tight">
              The Graph That
              <br /><span className="text-white/30">Powers Everything</span>
            </h2>
            <p className="text-white/40 mt-4 max-w-2xl mx-auto text-sm leading-relaxed">
              Every piece of information in Desq becomes a node — whether it's a task, meeting, note, or idea. The graph automatically identifies connections between nodes, creating a living map of your team's knowledge.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Left */}
            <div>
              <h3 className="text-xl font-bold text-white mb-4">How It Works</h3>
              <p className="text-white/40 text-sm leading-relaxed mb-8">
                Every piece of information in Desq becomes a node — task, meeting note, document, or idea. Links between nodes are created manually or suggested automatically by the system.
              </p>
              <div className="space-y-5">
                {[
                  { icon: Zap, color: "text-violet-400 bg-violet-500/10", title: "Automatic Connections", desc: "Desq analyzes content, @mentions, tags, and relationships to automatically link related information." },
                  { icon: GitBranch, color: "text-indigo-400 bg-indigo-500/10", title: "Smart Discovery", desc: "Find relevant information through visual exploration and intelligent search. The graph surfaces what you need before you ask." },
                  { icon: Globe, color: "text-pink-400 bg-pink-500/10", title: "Visual Context", desc: "See the big picture with an interactive visualization that reveals hidden patterns and insights across your team's work." },
                ].map((item, i) => {
                  const Icon = item.icon;
                  return (
                    <div key={i} className="flex gap-4">
                      <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${item.color}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-white mb-1">{item.title}</div>
                        <div className="text-sm text-white/40 leading-relaxed">{item.desc}</div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-8 grid grid-cols-3 gap-4">
                {[
                  { val: "12+", label: "Node types" },
                  { val: "∞", label: "Connections" },
                  { val: "Live", label: "Real-time" },
                ].map((s, i) => (
                  <div key={i} className="rounded-xl border border-white/[0.08] p-4 text-center" style={{ background: "#111" }}>
                    <div className="text-2xl font-bold text-white">{s.val}</div>
                    <div className="text-xs text-white/30 mt-1">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: animated graph */}
            <div className="relative rounded-2xl overflow-hidden border border-white/10" style={{ height: 420, background: "#0d0d0d" }}>
              <GraphCanvasPreview />
              {/* Overlay labels */}
              <div className="absolute top-4 left-4">
                <div className="text-xs text-white/30 font-medium bg-black/40 px-2.5 py-1 rounded-full backdrop-blur-sm">Sample Knowledge Graph</div>
              </div>
              <div className="absolute bottom-4 left-4 flex gap-2 flex-wrap">
                {[
                  { color: "#818cf8", label: "Task" },
                  { color: "#34d399", label: "Note" },
                  { color: "#fb923c", label: "Meeting" },
                  { color: "#c084fc", label: "Idea" },
                  { color: "#38bdf8", label: "Journal" },
                ].map((t, i) => (
                  <div key={i} className="flex items-center gap-1 text-[10px] text-white/40 bg-black/40 px-2 py-0.5 rounded-full backdrop-blur-sm">
                    <div className="w-1.5 h-1.5 rounded-full" style={{ background: t.color }} />
                    {t.label}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── How it works ────────────────────────────────── */}
      <section className="py-24 px-6 border-t border-white/[0.06]">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-xs font-medium tracking-widest text-indigo-400 uppercase mb-4">How it works</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">Up and running in minutes</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { n: "1", title: "Create your workspace", desc: "Sign up, invite your team with a link, and set up spaces for each project in under 5 minutes." },
              { n: "2", title: "Capture and connect", desc: "Add tasks, notes, meetings, and ideas. Link them as you discover relationships — or let Desq suggest them." },
              { n: "3", title: "Work in sync", desc: "Collaborate in real time, chat in context, and keep everyone aligned — in one tab, without switching tools." },
            ].map((s, i) => (
              <div key={i} className="relative pl-12">
                <div className="absolute left-0 top-0 w-7 h-7 rounded-full border border-white/10 flex items-center justify-center text-xs font-bold text-white/30">
                  {s.n}
                </div>
                <h3 className="text-base font-semibold text-white mb-2">{s.title}</h3>
                <p className="text-white/40 text-sm leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Pricing ─────────────────────────────────────── */}
      <section id="pricing" className="py-24 px-6 border-t border-white/[0.06]">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-xs font-medium tracking-widest text-indigo-400 uppercase mb-4">Pricing</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">Simple, transparent pricing</h2>
            <p className="text-white/40 mt-3 text-sm">Start free. Scale when you're ready.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              {
                name: "Starter", price: "Free", per: "", desc: "For individuals and small teams.",
                features: ["Up to 5 users", "500 nodes", "3 spaces", "Basic integrations", "Community support"],
                cta: "Get started free", highlight: false,
              },
              {
                name: "Team", price: "$12", per: "/user/mo", desc: "Everything teams need at scale.",
                features: ["Unlimited users", "Unlimited nodes", "Unlimited spaces", "Discord sync", "Admin dashboard", "Priority support"],
                cta: "Start free trial", highlight: true,
              },
              {
                name: "Enterprise", price: "Custom", per: "", desc: "For large organizations.",
                features: ["Custom roles", "SSO / SAML", "Audit logs", "SLA guarantee", "Dedicated support", "On-premise option"],
                cta: "Contact sales", highlight: false,
              },
            ].map((plan, i) => (
              <div key={i} className={`rounded-2xl p-7 flex flex-col ${plan.highlight ? "bg-indigo-600 ring-1 ring-indigo-500" : "border border-white/[0.08]"}`} style={plan.highlight ? {} : { background: "#111" }}>
                <div className="mb-6">
                  <div className={`text-xs font-semibold tracking-widest uppercase mb-3 ${plan.highlight ? "text-indigo-200" : "text-white/30"}`}>{plan.name}</div>
                  <div className="flex items-end gap-1 mb-1">
                    <span className="text-3xl font-bold text-white">{plan.price}</span>
                    {plan.per && <span className={`text-xs mb-1.5 ${plan.highlight ? "text-indigo-200" : "text-white/30"}`}>{plan.per}</span>}
                  </div>
                  <p className={`text-xs mt-2 ${plan.highlight ? "text-indigo-200" : "text-white/40"}`}>{plan.desc}</p>
                </div>
                <ul className="space-y-2.5 mb-8 flex-1">
                  {plan.features.map((feat, j) => (
                    <li key={j} className="flex items-center gap-3 text-sm">
                      <CheckCircle className={`w-3.5 h-3.5 flex-shrink-0 ${plan.highlight ? "text-indigo-200" : "text-white/30"}`} />
                      <span className={plan.highlight ? "text-indigo-100" : "text-white/50"}>{feat}</span>
                    </li>
                  ))}
                </ul>
                <Link href="/auth/register">
                  <button className={`w-full py-2.5 rounded-lg text-sm font-semibold transition-colors ${plan.highlight ? "bg-white text-indigo-700 hover:bg-indigo-50" : "border border-white/10 text-white hover:bg-white/[0.05]"}`}>
                    {plan.cta}
                  </button>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FAQ ─────────────────────────────────────────── */}
      <section id="faq" className="py-24 px-6 border-t border-white/[0.06]">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-xs font-medium tracking-widest text-indigo-400 uppercase mb-4">FAQ</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">Common questions</h2>
          </div>

          <div className="space-y-2">
            {FAQ.map((item, i) => (
              <div key={i} className="rounded-xl border border-white/[0.08] overflow-hidden" style={{ background: "#111" }}>
                <button
                  className="w-full flex items-center justify-between px-6 py-4 text-left hover:bg-white/[0.02] transition-colors"
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                >
                  <span className="text-sm font-semibold text-white pr-4">{item.q}</span>
                  <ChevronDown className={`w-4 h-4 text-white/30 flex-shrink-0 transition-transform duration-200 ${openFaq === i ? "rotate-180" : ""}`} />
                </button>
                {openFaq === i && (
                  <div className="px-6 pb-5 border-t border-white/[0.06]">
                    <p className="text-sm text-white/50 leading-relaxed pt-4">{item.a}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Final CTA ───────────────────────────────────── */}
      <section className="py-24 px-6 border-t border-white/[0.06]">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl sm:text-5xl font-bold text-white tracking-tight leading-tight mb-5">
            Bring your team to
            <span className="text-white/30"> the same page.</span>
          </h2>
          <p className="text-white/40 mb-10 text-sm">Get started for free. No credit card needed.</p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/auth/register">
              <button className="inline-flex items-center gap-2 bg-white text-black font-semibold px-7 py-3 rounded-lg text-sm hover:bg-white/90 transition-colors">
                Create your workspace <ArrowRight className="w-4 h-4" />
              </button>
            </Link>
            <Link href="/auth/login">
              <button className="inline-flex items-center gap-2 border border-white/10 text-white/60 hover:text-white hover:border-white/20 px-7 py-3 rounded-lg text-sm transition-colors">
                Sign in
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* ── Footer ──────────────────────────────────────── */}
      <footer className="border-t border-white/[0.06] py-8 px-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <img src={desqLogoSrc} alt="desq" className="h-5 object-contain opacity-30" style={{ filter: "invert(1)" }} />
          <p className="text-xs text-white/20">© {new Date().getFullYear()} Desq. All rights reserved.</p>
          <div className="flex gap-6 text-xs text-white/20">
            <a href="#" className="hover:text-white/50 transition-colors">Privacy</a>
            <a href="#" className="hover:text-white/50 transition-colors">Terms</a>
            <Link href="/auth/login" className="hover:text-white/50 transition-colors">Sign in</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

/* ── Hero App Preview Panel ─────────────────────────── */
function HeroAppPreview() {
  return (
    <div className="rounded-2xl overflow-hidden border border-white/[0.08] shadow-2xl shadow-black/80" style={{ background: "#111" }}>
      <div className="flex items-center gap-2 px-4 py-3 border-b border-white/[0.06]" style={{ background: "#0d0d0d" }}>
        <div className="flex gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
          <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
          <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
        </div>
        <div className="mx-auto text-xs text-white/20 font-medium">desq — Knowledge Graph</div>
      </div>

      <div className="flex" style={{ height: 400 }}>
        {/* Sidebar */}
        <div className="w-44 border-r border-white/[0.06] p-3 flex flex-col gap-1 flex-shrink-0" style={{ background: "#0d0d0d" }}>
          {[
            { icon: "◉", label: "Dashboard" },
            { icon: "⬡", label: "Graph", active: true },
            { icon: "✓", label: "Tasks" },
            { icon: "◷", label: "Calendar" },
            { icon: "💬", label: "Chat" },
            { icon: "📁", label: "Files" },
            { icon: "🗺", label: "Planning" },
          ].map((item, i) => (
            <div key={i} className={`flex items-center gap-2.5 px-3 py-1.5 rounded-lg text-xs ${item.active ? "bg-indigo-600/20 text-indigo-400 font-medium" : "text-white/30"}`}>
              <span className="text-[10px]">{item.icon}</span>
              {item.label}
            </div>
          ))}
        </div>

        {/* Graph area */}
        <div className="flex-1 relative" style={{ background: "#0f0f0f" }}>
          <GraphCanvasPreview />
          <div className="absolute top-3 right-3 flex flex-col gap-1.5">
            {["+", "−", "⊡"].map((c, i) => (
              <div key={i} className="w-7 h-7 rounded-md border border-white/[0.08] flex items-center justify-center text-xs text-white/40" style={{ background: "#1a1a1a" }}>{c}</div>
            ))}
          </div>
          <div className="absolute bottom-3 left-3 flex gap-2">
            {[{ c: "#818cf8", l: "Task" }, { c: "#34d399", l: "Note" }, { c: "#fb923c", l: "Meeting" }, { c: "#c084fc", l: "Idea" }].map((t, i) => (
              <div key={i} className="flex items-center gap-1 text-[10px] text-white/30">
                <div className="w-2 h-2 rounded-full" style={{ background: t.c }} />
                {t.l}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Animated Graph Canvas ──────────────────────────── */
function GraphCanvasPreview() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const setSize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    setSize();
    window.addEventListener("resize", setSize);

    const COLORS = ["#818cf8","#34d399","#fb923c","#c084fc","#38bdf8","#f472b6","#fbbf24","#4ade80"];
    type N = { x: number; y: number; vx: number; vy: number; r: number; color: string; phase: number };
    let nodes: N[] = [];

    const init = () => {
      if (!canvas.width || !canvas.height) return;
      nodes = Array.from({ length: 20 }, (_, i) => ({
        x: canvas.width * 0.1 + Math.random() * canvas.width * 0.8,
        y: canvas.height * 0.1 + Math.random() * canvas.height * 0.8,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        r: 5 + Math.random() * 7,
        color: COLORS[i % COLORS.length],
        phase: Math.random() * Math.PI * 2,
      }));
    };

    const draw = () => {
      if (!canvas.width || !canvas.height) {
        if (!nodes.length) init();
        animRef.current = requestAnimationFrame(draw);
        return;
      }
      if (!nodes.length) init();

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      nodes.forEach(n => {
        n.x += n.vx; n.y += n.vy;
        if (n.x < n.r) { n.x = n.r; n.vx = Math.abs(n.vx); }
        if (n.x > canvas.width - n.r) { n.x = canvas.width - n.r; n.vx = -Math.abs(n.vx); }
        if (n.y < n.r) { n.y = n.r; n.vy = Math.abs(n.vy); }
        if (n.y > canvas.height - n.r) { n.y = canvas.height - n.r; n.vy = -Math.abs(n.vy); }
        n.phase += 0.025;
      });

      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x, dy = nodes[i].y - nodes[j].y;
          const d = Math.sqrt(dx * dx + dy * dy);
          if (d < 130) {
            ctx.beginPath();
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.strokeStyle = nodes[i].color + Math.round(0.18 * (1 - d / 130) * 255).toString(16).padStart(2, "0");
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }
      }

      nodes.forEach(n => {
        const p = 1 + Math.sin(n.phase) * 0.1;
        const g = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.r * 2.8);
        g.addColorStop(0, n.color + "40"); g.addColorStop(1, n.color + "00");
        ctx.beginPath(); ctx.arc(n.x, n.y, n.r * 2.8, 0, Math.PI * 2);
        ctx.fillStyle = g; ctx.fill();
        ctx.beginPath(); ctx.arc(n.x, n.y, n.r * p, 0, Math.PI * 2);
        ctx.fillStyle = n.color; ctx.fill();
        ctx.beginPath(); ctx.arc(n.x, n.y, n.r * 0.35, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(255,255,255,0.55)"; ctx.fill();
      });

      animRef.current = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      window.removeEventListener("resize", setSize);
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, []);

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />;
}
