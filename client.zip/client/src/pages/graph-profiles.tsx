import { useState, useRef, useEffect, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { consumeDeepLink } from "@/lib/deep-link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import InteractiveNodeGraph, { InteractiveNodeGraphRef } from "@/components/interactive-node-graph";
import NodePreviewModal from "@/components/node-preview-modal";
import NodeEditorModal from "@/components/node-editor-modal";
import UniversalNodeCreator from "@/components/universal-node-creator";
import { 
  LucideIcon,
  Search, Plus, ZoomIn, ZoomOut, RefreshCw, Filter, Layers, Settings, 
  Globe, User, Users, Folder, Palette, Edit2, Trash2, MoreVertical,
  Check, X, Eye, EyeOff, Link, AlertTriangle,
  Network, LayoutGrid, BookOpen, CheckSquare, StickyNote, 
  Calendar, MessageSquare, Lightbulb, FileText, ExternalLink, Clock
} from "lucide-react";
import { Node, NodeLink, GraphProfile } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

const profileIcons = {
  globe: Globe,
  user: User,
  users: Users,
  folder: Folder,
  palette: Palette
};

const profileColors = [
  "#3b82f6", "#10b981", "#f59e0b", "#8b5cf6", "#ef4444", 
  "#06b6d4", "#84cc16", "#f97316", "#ec4899", "#6366f1"
];

const nodeTypeConfig: Record<string, { label: string; icon: LucideIcon; color: string; bg: string }> = {
  journal:  { label: "Journal",   icon: BookOpen,      color: "text-amber-600",   bg: "bg-amber-50 dark:bg-amber-950/30" },
  task:     { label: "Tasks",     icon: CheckSquare,   color: "text-blue-600",    bg: "bg-blue-50 dark:bg-blue-950/30" },
  note:     { label: "Notes",     icon: StickyNote,    color: "text-yellow-600",  bg: "bg-yellow-50 dark:bg-yellow-950/30" },
  meeting:  { label: "Meetings",  icon: Calendar,      color: "text-purple-600",  bg: "bg-purple-50 dark:bg-purple-950/30" },
  chat:     { label: "Chats",     icon: MessageSquare, color: "text-green-600",   bg: "bg-green-50 dark:bg-green-950/30" },
  idea:     { label: "Ideas",     icon: Lightbulb,     color: "text-orange-600",  bg: "bg-orange-50 dark:bg-orange-950/30" },
  file:     { label: "Files",     icon: FileText,      color: "text-red-600",     bg: "bg-red-50 dark:bg-red-950/30" },
  link:     { label: "Links",     icon: ExternalLink,  color: "text-cyan-600",    bg: "bg-cyan-50 dark:bg-cyan-950/30" },
};

const statusStyles: Record<string, string> = {
  active:      "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400",
  todo:        "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400",
  "in-progress": "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400",
  done:        "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400",
  completed:   "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400",
  pending:     "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-400",
};

function NodeBoardView({ 
  nodes, 
  links, 
  onNodeClick 
}: { 
  nodes: Node[]; 
  links: NodeLink[]; 
  onNodeClick: (nodeId: number) => void 
}) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [boardSearch, setBoardSearch] = useState("");
  const [sortBy, setSortBy] = useState<"title" | "date" | "connections">("date");
  const [density, setDensity] = useState<"comfortable" | "compact">("comfortable");
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const [activeType, setActiveType] = useState<string>("");

  const getConnectionCount = (nodeId: number) => 
    links.filter(l => l.sourceId === nodeId || l.targetId === nodeId).length;

  const displayNodes = nodes.filter(n =>
    boardSearch
      ? n.title.toLowerCase().includes(boardSearch.toLowerCase()) ||
        n.content?.toLowerCase().includes(boardSearch.toLowerCase())
      : true
  );

  const sorted = [...displayNodes].sort((a, b) => {
    if (sortBy === "title") return a.title.localeCompare(b.title);
    if (sortBy === "connections") return getConnectionCount(b.id) - getConnectionCount(a.id);
    return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
  });

  const types = Array.from(new Set(nodes.map(n => n.nodeType))).filter(Boolean);
  const grouped = types.reduce((acc, type) => {
    acc[type] = sorted.filter(n => n.nodeType === type);
    return acc;
  }, {} as Record<string, Node[]>);

  const visibleTypes = types.filter(t => (grouped[t] || []).length > 0);

  const formatDate = (date: Date | string | null | undefined) => {
    if (!date) return "";
    const d = new Date(date);
    const now = new Date();
    const diff = Math.floor((now.getTime() - d.getTime()) / 86400000);
    if (diff === 0) return "Today";
    if (diff === 1) return "Yesterday";
    if (diff < 7) return `${diff}d ago`;
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  };

  const toggleCollapse = (type: string) => {
    setCollapsed(prev => ({ ...prev, [type]: !prev[type] }));
  };

  const scrollToType = (type: string) => {
    setActiveType(type);
    const el = document.getElementById(`board-section-${type}`);
    if (el && scrollRef.current) {
      const container = scrollRef.current;
      const elTop = el.offsetTop - 120;
      container.scrollTo({ top: elTop, behavior: "smooth" });
    }
  };

  return (
    <div ref={scrollRef} className="h-full overflow-auto">
      {/* Sticky Controls Bar */}
      <div className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b">
        {/* Top Row: Search + Sort + Density */}
        <div className="px-3 sm:px-4 py-2.5 flex flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-[120px] max-w-sm">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              placeholder="Search nodes..."
              className="pl-8 h-8 text-sm"
              value={boardSearch}
              onChange={e => setBoardSearch(e.target.value)}
            />
          </div>

          <Select value={sortBy} onValueChange={(v) => setSortBy(v as any)}>
            <SelectTrigger className="w-28 sm:w-40 h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="date">Newest first</SelectItem>
              <SelectItem value="title">A → Z</SelectItem>
              <SelectItem value="connections">Most connected</SelectItem>
            </SelectContent>
          </Select>

          {/* Density Toggle */}
          <div className="flex items-center border rounded-md overflow-hidden">
            <button
              onClick={() => setDensity("comfortable")}
              className={`h-8 px-2.5 flex items-center gap-1 text-xs transition-colors ${density === "comfortable" ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}
            >
              <LayoutGrid className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => setDensity("compact")}
              className={`h-8 px-2.5 flex items-center gap-1 text-xs transition-colors ${density === "compact" ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}
            >
              <Layers className="h-3.5 w-3.5" />
            </button>
          </div>

          <span className="text-xs text-muted-foreground whitespace-nowrap ml-1">
            {displayNodes.length} <span className="hidden sm:inline">nodes</span>
          </span>
        </div>

        {/* Type Navigation Pills */}
        <div className="px-4 pb-2 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          <button
            onClick={() => { setActiveType(""); scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" }); }}
            className={`flex-shrink-0 h-7 px-3 rounded-full text-xs font-medium transition-colors ${activeType === "" ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80 text-muted-foreground"}`}
          >
            All
          </button>
          {visibleTypes.map(type => {
            const config = nodeTypeConfig[type] || { label: type, icon: Layers, color: "text-muted-foreground", bg: "bg-muted/30" };
            const TypeIcon = config.icon;
            const count = (grouped[type] || []).length;
            return (
              <button
                key={type}
                onClick={() => scrollToType(type)}
                className={`flex-shrink-0 h-7 px-3 rounded-full text-xs font-medium transition-colors flex items-center gap-1.5 ${
                  activeType === type ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80 text-muted-foreground"
                }`}
              >
                <TypeIcon className="h-3 w-3" />
                {config.label}
                <span className={`ml-0.5 ${activeType === type ? "opacity-80" : "opacity-60"}`}>·{count}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="p-5 space-y-6">
        {visibleTypes.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <Search className="h-10 w-10 text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground font-medium">No nodes match your search</p>
            <p className="text-xs text-muted-foreground mt-1">Try different keywords</p>
          </div>
        ) : (
          visibleTypes.map(type => {
            const config = nodeTypeConfig[type] || { label: type, icon: Layers, color: "text-muted-foreground", bg: "bg-muted/30" };
            const TypeIcon = config.icon;
            const groupNodes = grouped[type] || [];
            const isCollapsed = collapsed[type];

            return (
              <div key={type} id={`board-section-${type}`} className="scroll-mt-28">
                {/* Section Header */}
                <button
                  onClick={() => toggleCollapse(type)}
                  className="w-full flex items-center gap-2 mb-3 group"
                >
                  <div className={`p-1.5 rounded-lg ${config.bg} flex-shrink-0`}>
                    <TypeIcon className={`h-4 w-4 ${config.color}`} />
                  </div>
                  <span className="font-semibold text-sm">{config.label}</span>
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${config.bg} ${config.color}`}>
                    {groupNodes.length}
                  </span>
                  <div className="flex-1 h-px bg-border" />
                  <div className={`text-muted-foreground transition-transform duration-200 ${isCollapsed ? "-rotate-90" : ""}`}>
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                      <path d="M2 4l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                </button>

                {/* Cards / Rows */}
                {!isCollapsed && (
                  density === "comfortable" ? (
                    /* Comfortable: Card Grid */
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                      {groupNodes.map(node => {
                        const connections = getConnectionCount(node.id);
                        const statusStyle = node.status ? statusStyles[node.status] || "bg-muted text-muted-foreground" : "";
                        return (
                          <button
                            key={node.id}
                            onClick={() => onNodeClick(node.id)}
                            className="text-left group relative bg-card border rounded-xl overflow-hidden hover:shadow-lg hover:border-primary/40 transition-all duration-200 hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                          >
                            {/* Color accent bar */}
                            <div className={`absolute left-0 top-0 bottom-0 w-1 ${config.bg.replace("bg-", "bg-").replace("/30", "")}`}
                              style={{ background: `var(--accent, #3b82f6)` }} />
                            
                            <div className="pl-4 pr-3 pt-3 pb-3">
                              {/* Header row */}
                              <div className="flex items-center justify-between gap-2 mb-2">
                                <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${config.bg} ${config.color}`}>
                                  <TypeIcon className="h-3 w-3" />
                                  {config.label}
                                </div>
                                {connections > 0 && (
                                  <div className="flex items-center gap-0.5 text-xs text-muted-foreground">
                                    <Link className="h-3 w-3" />
                                    <span>{connections}</span>
                                  </div>
                                )}
                              </div>

                              {/* Title */}
                              <h4 className="font-semibold text-sm line-clamp-2 group-hover:text-primary transition-colors leading-snug mb-1.5">
                                {node.title || "Untitled"}
                              </h4>

                              {/* Content preview */}
                              {node.content && (
                                <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed mb-2">
                                  {node.content.replace(/#+\s/g, "").replace(/\*\*/g, "")}
                                </p>
                              )}

                              {/* Footer */}
                              <div className="flex items-center justify-between gap-2 pt-2 border-t border-border/50">
                                <span className="text-xs text-muted-foreground">{formatDate(node.createdAt)}</span>
                                {node.status && (
                                  <span className={`text-xs px-1.5 py-0.5 rounded-full font-medium capitalize ${statusStyle}`}>
                                    {node.status.replace("-", " ")}
                                  </span>
                                )}
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  ) : (
                    /* Compact: List Rows */
                    <div className="border rounded-xl overflow-hidden divide-y">
                      {groupNodes.map(node => {
                        const connections = getConnectionCount(node.id);
                        const statusStyle = node.status ? statusStyles[node.status] || "bg-muted text-muted-foreground" : "";
                        return (
                          <button
                            key={node.id}
                            onClick={() => onNodeClick(node.id)}
                            className="w-full flex items-center gap-3 px-4 py-2.5 text-left hover:bg-muted/50 transition-colors group"
                          >
                            <div className={`p-1 rounded-md flex-shrink-0 ${config.bg}`}>
                              <TypeIcon className={`h-3 w-3 ${config.color}`} />
                            </div>
                            <span className="flex-1 text-sm font-medium truncate group-hover:text-primary transition-colors">
                              {node.title || "Untitled"}
                            </span>
                            {node.status && (
                              <span className={`hidden sm:inline text-xs px-1.5 py-0.5 rounded-full font-medium capitalize flex-shrink-0 ${statusStyle}`}>
                                {node.status.replace("-", " ")}
                              </span>
                            )}
                            {connections > 0 && (
                              <div className="hidden md:flex items-center gap-0.5 text-xs text-muted-foreground flex-shrink-0">
                                <Link className="h-3 w-3" />
                                <span>{connections}</span>
                              </div>
                            )}
                            <span className="text-xs text-muted-foreground flex-shrink-0">{formatDate(node.createdAt)}</span>
                          </button>
                        );
                      })}
                    </div>
                  )
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

export default function GraphProfiles() {
  const queryClient = useQueryClient();
  const [location] = useLocation();
  const graphRef = useRef<InteractiveNodeGraphRef>(null);

  // State
  const [activeProfileId, setActiveProfileId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [nodeTypeFilter, setNodeTypeFilter] = useState<string>("all");
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
  const [isEditorModalOpen, setIsEditorModalOpen] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const [showProfileManager, setShowProfileManager] = useState(false);
  const [focusNodeId, setFocusNodeId] = useState<number | null>(null);
  const [isLinkingMode, setIsLinkingMode] = useState(false);

  // Profile creation state
  const [isCreateProfileOpen, setIsCreateProfileOpen] = useState(false);
  const [newProfileName, setNewProfileName] = useState("");
  const [newProfileDescription, setNewProfileDescription] = useState("");
  const [newProfileColor, setNewProfileColor] = useState(profileColors[0]);
  const [newProfileIcon, setNewProfileIcon] = useState("palette");
  const [newProfileType, setNewProfileType] = useState("custom");

  // View mode state
  const [viewMode, setViewMode] = useState<"graph" | "board">("graph");

  // Profile deletion state
  const [profileToDelete, setProfileToDelete] = useState<GraphProfile | null>(null);
  const [deleteAction, setDeleteAction] = useState<"keep-nodes" | "delete-all">("keep-nodes");

  // Query for graph profiles
  const { data: graphProfiles, isLoading: loadingProfiles } = useQuery<GraphProfile[]>({
    queryKey: ['/api/graph-profiles'],
  });

  // Set default profile when profiles load
  useEffect(() => {
    if (graphProfiles && graphProfiles.length > 0 && !activeProfileId) {
      const defaultProfile = graphProfiles.find(p => p.isDefault) || graphProfiles[0];
      setActiveProfileId(defaultProfile.id);
    }
  }, [graphProfiles, activeProfileId]);

  // Get active profile
  const activeProfile = graphProfiles?.find(p => p.id === activeProfileId);

  // Query for all nodes - profiles will filter them client-side
  // MUST be declared before the deep-link useEffect that references allNodes
  const { data: allNodes, isLoading: loadingNodes } = useQuery<Node[]>({
    queryKey: ['/api/nodes'],
  });

  // Deep-link on mount / when data loads (navigating FROM another page)
  useEffect(() => {
    if (!allNodes) return;
    const link = consumeDeepLink();
    if (!link || link.type !== "node") return;
    const t = setTimeout(() => handleNodeSelect(link.id), 600);
    return () => clearTimeout(t);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allNodes]);

  // Deep-link via event (already on this page when search fires)
  useEffect(() => {
    const handler = (e: Event) => {
      const link = (e as CustomEvent).detail;
      if (!link || link.type !== "node") return;
      consumeDeepLink(); // clear the store
      const t = setTimeout(() => handleNodeSelect(link.id), 300);
      return () => clearTimeout(t);
    };
    window.addEventListener("desq:deeplink", handler);
    return () => window.removeEventListener("desq:deeplink", handler);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Filter nodes based on active profile — memoized so the array reference is
  // stable between modal open/close cycles (prevents the graph from rebuilding)
  const nodes = useMemo(() => allNodes?.filter(node => {
    if (!activeProfile) return true;
    if (activeProfile.type === 'custom') {
      return node.graphProfiles?.includes(activeProfile.id) || false;
    }
    switch (activeProfile.type) {
      case 'all':       return true;
      case 'personal':  return ['journal', 'note', 'idea'].includes(node.nodeType);
      case 'team':      return ['task', 'meeting', 'chat'].includes(node.nodeType);
      case 'project':   return ['task', 'note', 'file'].includes(node.nodeType);
      default:          return false;
    }
  }) || [], [allNodes, activeProfile]);

  // Query for node links
  const { data: nodeLinks, isLoading: loadingLinks } = useQuery<NodeLink[]>({
    queryKey: ['/api/node-links'],
    enabled: !!nodes && nodes.length > 0
  });

  // Create profile mutation
  const createProfileMutation = useMutation({
    mutationFn: async (profileData: any) => {
      return apiRequest('/api/graph-profiles', {
        method: 'POST',
        body: JSON.stringify(profileData)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/graph-profiles'] });
      setIsCreateProfileOpen(false);
      setNewProfileName("");
      setNewProfileDescription("");
      setNewProfileColor(profileColors[0]);
      setNewProfileIcon("palette");
      setNewProfileType("custom");
      toast({
        title: "Profile created",
        description: "New graph profile has been created successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Failed to create profile",
        description: "There was an error creating the profile. Please try again.",
      });
    }
  });

  // Delete profile mutation
  const deleteProfileMutation = useMutation({
    mutationFn: async ({ profileId, action }: { profileId: number; action: "keep-nodes" | "delete-all" }) => {
      return apiRequest(`/api/graph-profiles/${profileId}`, {
        method: 'DELETE',
        body: JSON.stringify({ action })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/graph-profiles'] });
      queryClient.invalidateQueries({ queryKey: ['/api/nodes'] });
      if (activeProfileId === profileToDelete?.id) {
        setActiveProfileId(1); // Switch to "Everything" profile
      }
      setProfileToDelete(null);
      setDeleteAction("keep-nodes");
      toast({
        title: "Profile deleted",
        description: deleteAction === "keep-nodes" 
          ? "Graph profile deleted. All nodes are now in 'Everything' profile."
          : "Graph profile and all its nodes have been deleted.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Failed to delete profile",
        description: "There was an error deleting the profile. Please try again.",
      });
      setProfileToDelete(null);
    }
  });

  // Memoized search+type filtering — stable reference avoids graph rebuilds on modal state changes
  const filteredNodes = useMemo(() => nodes?.filter(node => {
    const matchesSearch = searchQuery
      ? node.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        node.content?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        node.nodeType.toLowerCase().includes(searchQuery.toLowerCase())
      : true;
    const matchesType = nodeTypeFilter !== "all" ? node.nodeType === nodeTypeFilter : true;
    return matchesSearch && matchesType;
  }) || [], [nodes, searchQuery, nodeTypeFilter]);

  const filteredLinks = useMemo(() => {
    const nodeIds = new Set(filteredNodes.map(n => n.id));
    return nodeLinks?.filter(l => nodeIds.has(l.sourceId) && nodeIds.has(l.targetId)) || [];
  }, [nodeLinks, filteredNodes]);

  // Handle node selection
  const handleNodeSelect = (nodeId: number) => {
    const node = nodes?.find(n => n.id === nodeId) || null;
    setSelectedNode(node);
    setIsPreviewModalOpen(true);
    
    // Zoom to the selected node and lock the graph
    graphRef.current?.zoomToNode(nodeId);
    setTimeout(() => {
      graphRef.current?.lockZoom();
    }, 850); // Lock after zoom animation completes
  };

  // Handle zoom controls
  const handleZoomIn = () => graphRef.current?.zoomIn();
  const handleZoomOut = () => graphRef.current?.zoomOut();
  const handleResetZoom = () => graphRef.current?.resetZoom();

  // Handle creating a new profile
  const handleCreateProfile = () => {
    if (!newProfileName.trim()) {
      toast({
        variant: "destructive",
        title: "Name required",
        description: "Please provide a name for the new profile.",
      });
      return;
    }

    const profileData = {
      name: newProfileName,
      description: newProfileDescription,
      type: newProfileType,
      color: newProfileColor,
      icon: newProfileIcon,
      isDefault: false,
      isPublic: true,
      nodeTypes: ['journal', 'task', 'note', 'meeting', 'chat', 'idea', 'file', 'link']
    };

    createProfileMutation.mutate(profileData);
  };

  // Get unique node types for filter
  const nodeTypes = nodes ? Array.from(new Set(nodes.map(node => node.nodeType).filter(type => type))) : [];

  // Get icon component
  const getIconComponent = (iconName: string) => {
    const IconComponent = profileIcons[iconName as keyof typeof profileIcons] || Palette;
    return IconComponent;
  };

  const handleProfileNodeCreate = () => {
    // Refresh the nodes for the active profile after creation
    queryClient.invalidateQueries({ queryKey: ['/api/nodes'] });
  };

  // Handle node editing
  const handleNodeEdit = (node: Node) => {
    setSelectedNode(node);
    setIsPreviewModalOpen(false);
    setIsEditorModalOpen(true);
    // Keep zoom locked when transitioning from preview to editor
  };

  // Handle node linking
  const handleNodeLink = (node: Node) => {
    setSelectedNode(node);
    setIsPreviewModalOpen(false);
    // Unlock zoom when entering link mode
    graphRef.current?.unlockZoom();
    // Enable linking mode in the graph by calling the graph's toggle function
    if (graphRef.current) {
      graphRef.current.toggleLinkingMode();
    }
    setIsLinkingMode(true);
    toast({
      title: "Link mode enabled",
      description: "Click on another node to create a connection.",
    });
  };

  // Toggle linking mode
  const toggleLinkingMode = () => {
    if (graphRef.current) {
      graphRef.current.toggleLinkingMode();
    }
    setIsLinkingMode(!isLinkingMode);
    if (!isLinkingMode) {
      toast({
        title: "Link mode enabled",
        description: "Click on two nodes to create a connection.",
      });
    } else {
      toast({
        title: "Link mode disabled",
        description: "Returned to normal navigation mode.",
      });
    }
  };

  // Handle node editor close
  const handleEditorClose = () => {
    setIsEditorModalOpen(false);
    setSelectedNode(null);
    // Unlock zoom when closing the editor
    graphRef.current?.unlockZoom();
  };

  // Handle node saved
  const handleNodeSaved = (updatedNode: Node) => {
    // Close editor and show preview of updated node
    setIsEditorModalOpen(false);
    setSelectedNode(updatedNode);
    setIsPreviewModalOpen(true);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden h-full">
      {/* Top Controls Panel */}
      <div className="bg-background border-b p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between shadow-sm z-30 min-h-[64px] flex-shrink-0 gap-3">
        <div className="flex items-center gap-3 flex-1 min-w-0 w-full sm:w-auto">
          <h1 className="text-base font-semibold whitespace-nowrap">Graph Profiles</h1>
          
          {/* Profile Selector */}
          <Select value={activeProfileId?.toString() || ""} onValueChange={(value) => setActiveProfileId(parseInt(value))}>
            <SelectTrigger className="w-full sm:w-56">
              <div className="flex items-center gap-2">
                {activeProfile && (
                  <>
                    {(() => {
                      const IconComponent = getIconComponent(activeProfile.icon || "palette");
                      return <IconComponent className="h-4 w-4" style={{ color: activeProfile.color || '#3b82f6' }} />;
                    })()}
                    <span className="truncate">{activeProfile.name}</span>
                  </>
                )}
              </div>
            </SelectTrigger>
            <SelectContent>
              {graphProfiles?.map(profile => {
                const IconComponent = getIconComponent(profile.icon || "palette");
                return (
                  <SelectItem key={profile.id} value={profile.id.toString()}>
                    <div className="flex items-center gap-2">
                      <IconComponent className="h-4 w-4" style={{ color: profile.color || '#3b82f6' }} />
                      <span>{profile.name}</span>
                      {profile.isDefault && <Badge variant="secondary" className="text-xs">Default</Badge>}
                    </div>
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>

          {/* Search - Hidden on mobile, shown below */}
          <div className="relative flex-1 max-w-sm hidden sm:block">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search nodes..."
              className="pl-10 text-sm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          {/* Filter - Responsive width */}
          <Select value={nodeTypeFilter} onValueChange={setNodeTypeFilter}>
            <SelectTrigger className="w-20 sm:w-32">
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {nodeTypes.map(type => (
                <SelectItem key={type} value={type}>
                  {type ? type.charAt(0).toUpperCase() + type.slice(1) : 'Unknown'}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex items-center gap-2 ml-0 sm:ml-4 flex-wrap">
          {/* Graph Controls */}
          <div className="flex items-center gap-1">
            {/* Zoom Controls */}
            <div className="flex items-center gap-1 border rounded-md p-1">
              <Button variant="ghost" size="sm" onClick={handleZoomOut} className="h-8 w-8 p-0">
                <ZoomOut className="h-3 w-3" />
              </Button>
              <Button variant="ghost" size="sm" onClick={handleResetZoom} className="h-8 w-8 p-0">
                <RefreshCw className="h-3 w-3" />
              </Button>
              <Button variant="ghost" size="sm" onClick={handleZoomIn} className="h-8 w-8 p-0">
                <ZoomIn className="h-3 w-3" />
              </Button>
            </div>
            
            {/* Link Mode Button */}
            <Button
              variant={isLinkingMode ? "default" : "outline"}
              size="sm"
              onClick={toggleLinkingMode}
              className="h-8"
            >
              <Link className="h-3 w-3 mr-1" />
              <span className="hidden sm:inline">{isLinkingMode ? "Exit Link" : "Link"}</span>
            </Button>
          </div>
          
          {/* Stats - Hidden on small screens */}
          <div className="hidden md:flex items-center gap-1 text-xs text-muted-foreground bg-muted/50 rounded-md px-2 py-1">
            <span className="font-medium">{filteredNodes.length}</span>
            <span>nodes</span>
            <span>•</span>
            <span className="font-medium">{filteredLinks.length}</span>
            <span>links</span>
          </div>
          
          {/* View Mode Toggle */}
          <div className="flex items-center border rounded-md overflow-hidden">
            <Button
              variant={viewMode === "graph" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("graph")}
              className="h-8 rounded-none gap-1 px-3"
            >
              <Network className="h-3 w-3" />
              <span className="hidden sm:inline text-xs">Graph</span>
            </Button>
            <Button
              variant={viewMode === "board" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("board")}
              className="h-8 rounded-none gap-1 px-3"
            >
              <LayoutGrid className="h-3 w-3" />
              <span className="hidden sm:inline text-xs">Board</span>
            </Button>
          </div>

          {/* Profile Management */}
          <Popover open={showProfileManager} onOpenChange={setShowProfileManager}>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-1" />
                Manage
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80" align="end">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">Profile Management</h3>
                  <Dialog open={isCreateProfileOpen} onOpenChange={setIsCreateProfileOpen}>
                    <DialogTrigger asChild>
                      <Button size="sm">
                        <Plus className="h-4 w-4 mr-1" />
                        New
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-md">
                      <DialogHeader>
                        <DialogTitle>Create Graph Profile</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="name">Profile Name</Label>
                          <Input
                            id="name"
                            value={newProfileName}
                            onChange={(e) => setNewProfileName(e.target.value)}
                            placeholder="My Custom Graph"
                          />
                        </div>
                        <div>
                          <Label htmlFor="description">Description</Label>
                          <Textarea
                            id="description"
                            value={newProfileDescription}
                            onChange={(e) => setNewProfileDescription(e.target.value)}
                            placeholder="Describe what this graph profile is for..."
                            rows={3}
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Color</Label>
                            <div className="grid grid-cols-5 gap-2 mt-2">
                              {profileColors.map(color => (
                                <button
                                  key={color}
                                  className={`w-8 h-8 rounded-full border-2 ${
                                    newProfileColor === color ? 'border-primary' : 'border-transparent'
                                  }`}
                                  style={{ backgroundColor: color }}
                                  onClick={() => setNewProfileColor(color)}
                                />
                              ))}
                            </div>
                          </div>
                          <div>
                            <Label>Icon</Label>
                            <Select value={newProfileIcon} onValueChange={setNewProfileIcon}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {Object.entries(profileIcons).map(([key, IconComponent]) => (
                                  <SelectItem key={key} value={key}>
                                    <div className="flex items-center gap-2">
                                      <IconComponent className="h-4 w-4" />
                                      <span className="capitalize">{key}</span>
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div className="flex justify-end gap-2">
                          <Button variant="outline" onClick={() => setIsCreateProfileOpen(false)}>
                            Cancel
                          </Button>
                          <Button onClick={handleCreateProfile} disabled={createProfileMutation.isPending}>
                            Create Profile
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
                
                <Separator />
                
                <div className="space-y-2 max-h-64 overflow-auto">
                  {graphProfiles?.map(profile => {
                    const IconComponent = getIconComponent(profile.icon || "palette");
                    return (
                      <div key={profile.id} className="flex items-center gap-2 p-2 rounded border">
                        <IconComponent className="h-4 w-4" style={{ color: profile.color || '#3b82f6' }} />
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm truncate">{profile.name}</div>
                          <div className="text-xs text-muted-foreground truncate">{profile.description}</div>
                        </div>
                        <div className="flex items-center gap-1">
                          {profile.isDefault && (
                            <Badge variant="secondary" className="text-xs">Default</Badge>
                          )}
                          {profile.type !== 'all' && !profile.isDefault && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0"
                              onClick={() => setProfileToDelete(profile)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </PopoverContent>
          </Popover>

          {/* Create Node */}
          <UniversalNodeCreator 
            onSuccess={handleProfileNodeCreate}
            trigger={
              <Button>
                <Plus className="h-4 w-4 mr-1" />
                <span className="hidden sm:inline">New Node</span>
                <span className="sm:hidden">New</span>
              </Button>
            }
          />
        </div>
        
        {/* Mobile Search - Only visible on small screens */}
        <div className="sm:hidden w-full">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search nodes..."
              className="pl-10 text-sm w-full"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>
      
      {/* Profile Description Bar */}
      {activeProfile && (
        <div className="bg-muted/30 border-b px-4 py-2 text-sm text-muted-foreground">
          {activeProfile.description || `Viewing ${activeProfile.name} graph profile`}
        </div>
      )}

      {/* Main Content Area — dark background in graph view to match the canvas,
          semantic background in board view so it follows the theme */}
      <div className={`flex-1 relative overflow-hidden ${viewMode === 'graph' ? 'bg-[#060b14]' : 'bg-background'}`}>
        {loadingNodes || loadingProfiles ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-2 text-muted-foreground" />
              <p className="text-muted-foreground">Loading...</p>
            </div>
          </div>
        ) : filteredNodes.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center max-w-md">
              <div className="mx-auto mb-4 w-16 h-16 bg-muted rounded-full flex items-center justify-center">
                <Globe className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">No nodes in this profile</h3>
              <p className="text-muted-foreground mb-4">
                This graph profile doesn't have any nodes yet. Create your first node to get started.
              </p>
              <UniversalNodeCreator 
                onSuccess={handleProfileNodeCreate}
                trigger={
                  <Button>
                    <Plus className="h-4 w-4 mr-1" />
                    Create First Node
                  </Button>
                }
              />
            </div>
          </div>
        ) : viewMode === "graph" ? (
          <InteractiveNodeGraph
            ref={graphRef}
            nodes={filteredNodes}
            links={filteredLinks}
            onNodeClick={handleNodeSelect}
            focusNodeId={focusNodeId}
          />
        ) : (
          <NodeBoardView
            nodes={filteredNodes}
            links={filteredLinks}
            onNodeClick={handleNodeSelect}
          />
        )}
      </div>

      {/* Node Preview Modal */}
      <NodePreviewModal
        node={selectedNode}
        isOpen={isPreviewModalOpen}
        onClose={() => {
          setIsPreviewModalOpen(false);
          setSelectedNode(null);
          // Unlock zoom when closing the preview
          graphRef.current?.unlockZoom();
        }}
        onEdit={handleNodeEdit}
        onLink={handleNodeLink}
      />

      {/* Node Editor Modal */}
      <NodeEditorModal
        node={selectedNode}
        isOpen={isEditorModalOpen}
        onClose={handleEditorClose}
        onSaved={handleNodeSaved}
      />

      {/* Delete Profile Confirmation Dialog */}
      <AlertDialog open={!!profileToDelete} onOpenChange={(open) => !open && setProfileToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
              Delete Graph Profile
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-3">
              <p>
                You are about to delete the graph profile <strong>"{profileToDelete?.name}"</strong>.
              </p>
              
              {/* Show node count for the profile */}
              <div className="bg-muted p-3 rounded-lg">
                <p className="text-sm">
                  This profile contains <strong>{nodes?.filter(node => 
                    node.graphProfiles?.includes(profileToDelete?.id || 0)
                  ).length || 0} nodes</strong>.
                </p>
              </div>
              
              <p className="font-medium">What would you like to do with the nodes in this profile?</p>
              
              <div className="space-y-2">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="radio"
                    name="delete-action"
                    value="keep-nodes"
                    checked={deleteAction === "keep-nodes"}
                    onChange={(e) => setDeleteAction(e.target.value as "keep-nodes" | "delete-all")}
                    className="w-4 h-4"
                  />
                  <div>
                    <div className="text-sm font-medium">Keep nodes in "Everything"</div>
                    <div className="text-xs text-muted-foreground">
                      Nodes will remain accessible in the main "Everything" graph
                    </div>
                  </div>
                </label>
                
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="radio"
                    name="delete-action"
                    value="delete-all"
                    checked={deleteAction === "delete-all"}
                    onChange={(e) => setDeleteAction(e.target.value as "keep-nodes" | "delete-all")}
                    className="w-4 h-4"
                  />
                  <div>
                    <div className="text-sm font-medium text-red-600">Delete all nodes</div>
                    <div className="text-xs text-muted-foreground">
                      Permanently delete all nodes in this profile (cannot be undone)
                    </div>
                  </div>
                </label>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
              setProfileToDelete(null);
              setDeleteAction("keep-nodes");
            }}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (profileToDelete) {
                  deleteProfileMutation.mutate({ 
                    profileId: profileToDelete.id, 
                    action: deleteAction 
                  });
                }
              }}
              className={deleteAction === "delete-all" ? "bg-red-600 hover:bg-red-700" : ""}
            >
              {deleteAction === "keep-nodes" ? "Delete Profile Only" : "Delete Profile & All Nodes"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}