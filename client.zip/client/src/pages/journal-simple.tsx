import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Node, InsertNode } from "@shared/schema";
import {
  Calendar,
  Clock,
  CheckCircle2,
  Circle,
  Plus,
  Upload,
  Mic,
  Video,
  Link,
  Hash,
  Brain,
  Target,
  BarChart3,
  Paperclip,
  Zap,
  Sun,
  CloudDrizzle,
  Moon,
  Coffee,
  Lightbulb
} from "lucide-react";

interface TimeBlock {
  id: string;
  title: string;
  timeRange: string;
  icon: React.ReactNode;
  color: string;
  entries: WorkEntry[];
}

interface WorkEntry {
  id: string;
  type: 'note' | 'task' | 'checkin' | 'file';
  content: string;
  timestamp: Date;
  completed?: boolean;
  tags: string[];
  mood?: 'great' | 'good' | 'neutral' | 'stressed' | 'blocked';
}

const timeBlocks: TimeBlock[] = [
  {
    id: 'morning',
    title: 'Morning Focus',
    timeRange: '6:00 - 12:00',
    icon: <Sun className="h-4 w-4" />,
    color: 'bg-yellow-50 border-yellow-200',
    entries: []
  },
  {
    id: 'midday',
    title: 'Midday Flow',
    timeRange: '12:00 - 17:00',
    icon: <CloudDrizzle className="h-4 w-4" />,
    color: 'bg-blue-50 border-blue-200',
    entries: []
  },
  {
    id: 'evening',
    title: 'Evening Wrap',
    timeRange: '17:00 - 23:00',
    icon: <Moon className="h-4 w-4" />,
    color: 'bg-purple-50 border-purple-200',
    entries: []
  }
];

const moodIcons = {
  great: '😊',
  good: '🙂',
  neutral: '😐',
  stressed: '😰',
  blocked: '😤'
};

export default function JournalWorkHub() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [workBlocks, setWorkBlocks] = useState<TimeBlock[]>(timeBlocks);
  const [newEntry, setNewEntry] = useState('');
  const [entryType, setEntryType] = useState<WorkEntry['type']>('note');
  const [isAddingEntry, setIsAddingEntry] = useState(false);
  const [activeBlock, setActiveBlock] = useState('morning');
  const [selectedMood, setSelectedMood] = useState<WorkEntry['mood']>('neutral');
  const [entryTags, setEntryTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');
  const [isAIDialogOpen, setIsAIDialogOpen] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Query for nodes
  const { data: nodes = [] } = useQuery<Node[]>({
    queryKey: ['/api/nodes'],
  });

  // Create node mutation
  const createNodeMutation = useMutation({
    mutationFn: (nodeData: InsertNode) => apiRequest('/api/nodes', {
      method: 'POST',
      body: JSON.stringify(nodeData),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/nodes'] });
      toast({
        title: "Node created",
        description: "Your idea has been turned into a node",
      });
    },
  });

  const addWorkEntry = (blockId: string) => {
    if (!newEntry.trim()) return;

    const entry: WorkEntry = {
      id: Date.now().toString(),
      type: entryType,
      content: newEntry,
      timestamp: new Date(),
      tags: entryTags,
      mood: entryType === 'checkin' ? selectedMood : undefined,
      completed: entryType === 'task' ? false : undefined,
    };

    setWorkBlocks(prev => prev.map(block => 
      block.id === blockId 
        ? { ...block, entries: [...block.entries, entry] }
        : block
    ));

    setNewEntry('');
    setEntryTags([]);
    setIsAddingEntry(false);
    
    toast({
      title: "Entry added",
      description: `${entryType} added to ${blockId} block`,
    });
  };

  const addTag = () => {
    if (newTag.trim() && !entryTags.includes(newTag.trim())) {
      setEntryTags([...entryTags, newTag.trim()]);
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setEntryTags(entryTags.filter(tag => tag !== tagToRemove));
  };

  const createNodeFromEntry = (entry: WorkEntry) => {
    createNodeMutation.mutate({
      title: entry.content.substring(0, 50) + (entry.content.length > 50 ? '...' : ''),
      content: entry.content,
      nodeType: entry.type === 'task' ? 'task' : 'note',
      tags: entry.tags,
      createdBy: 1,
    });
  };

  const toggleTaskCompletion = (blockId: string, entryId: string) => {
    setWorkBlocks(prev => prev.map(block => 
      block.id === blockId 
        ? {
            ...block,
            entries: block.entries.map(entry => 
              entry.id === entryId 
                ? { ...entry, completed: !entry.completed }
                : entry
            )
          }
        : block
    ));
  };

  const getTodayProgress = () => {
    const allEntries = workBlocks.flatMap(block => block.entries);
    const completedTasks = allEntries.filter(entry => entry.type === 'task' && entry.completed).length;
    const totalTasks = allEntries.filter(entry => entry.type === 'task').length;
    return totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
  };

  const getDailyStats = () => {
    const allEntries = workBlocks.flatMap(block => block.entries);
    return {
      totalEntries: allEntries.length,
      tasksCompleted: allEntries.filter(entry => entry.type === 'task' && entry.completed).length,
      totalTasks: allEntries.filter(entry => entry.type === 'task').length,
      filesUploaded: allEntries.filter(entry => entry.type === 'file').length,
    };
  };

  const stats = getDailyStats();

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Work Hub</h1>
          <p className="text-muted-foreground">
            {format(selectedDate, 'EEEE, MMMM d, yyyy')}
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="flex items-center space-x-1">
            <Target className="h-3 w-3" />
            <span>{Math.round(getTodayProgress())}% Complete</span>
          </Badge>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsAIDialogOpen(true)}
            className="flex items-center space-x-1"
          >
            <Brain className="h-4 w-4" />
            <span>AI Assistant</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Timeline */}
        <div className="lg:col-span-3 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="h-5 w-5" />
                <span>Daily Work Timeline</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {workBlocks.map((block) => (
                  <Card key={block.id} className={`${block.color} border-2`}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          {block.icon}
                          <div>
                            <CardTitle className="text-lg">{block.title}</CardTitle>
                            <p className="text-sm text-muted-foreground">{block.timeRange}</p>
                          </div>
                        </div>
                        <Badge variant="secondary">
                          {block.entries.length} entries
                        </Badge>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-3">
                      {/* Existing entries */}
                      {block.entries.map((entry) => (
                        <div key={entry.id} className="p-3 bg-white rounded-lg border">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                {entry.type === 'task' && (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => toggleTaskCompletion(block.id, entry.id)}
                                    className="h-6 w-6 p-0"
                                  >
                                    {entry.completed ? (
                                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                                    ) : (
                                      <Circle className="h-4 w-4" />
                                    )}
                                  </Button>
                                )}
                                <Badge variant="outline" className="text-xs">
                                  {entry.type}
                                </Badge>
                                {entry.mood && (
                                  <span className="text-sm">
                                    {moodIcons[entry.mood]}
                                  </span>
                                )}
                                <span className="text-xs text-muted-foreground">
                                  {format(entry.timestamp, 'HH:mm')}
                                </span>
                              </div>
                              <p className={`text-sm ${entry.completed ? 'line-through text-muted-foreground' : ''}`}>
                                {entry.content}
                              </p>
                              {entry.tags.length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-2">
                                  {entry.tags.map((tag) => (
                                    <Badge key={tag} variant="secondary" className="text-xs">
                                      #{tag}
                                    </Badge>
                                  ))}
                                </div>
                              )}
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => createNodeFromEntry(entry)}
                              className="h-8 w-8 p-0"
                              title="Turn into node"
                            >
                              <Lightbulb className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      ))}

                      {/* Add new entry */}
                      {isAddingEntry && activeBlock === block.id ? (
                        <div className="p-3 bg-white rounded-lg border-2 border-dashed border-primary">
                          <div className="space-y-3">
                            <div className="flex items-center space-x-2">
                              <Button
                                variant={entryType === 'note' ? 'default' : 'outline'}
                                size="sm"
                                onClick={() => setEntryType('note')}
                              >
                                Note
                              </Button>
                              <Button
                                variant={entryType === 'task' ? 'default' : 'outline'}
                                size="sm"
                                onClick={() => setEntryType('task')}
                              >
                                Task
                              </Button>
                              <Button
                                variant={entryType === 'checkin' ? 'default' : 'outline'}
                                size="sm"
                                onClick={() => setEntryType('checkin')}
                              >
                                Check-in
                              </Button>
                            </div>

                            <Textarea
                              placeholder={`Add a ${entryType}...`}
                              value={newEntry}
                              onChange={(e) => setNewEntry(e.target.value)}
                              className="min-h-[80px]"
                            />

                            {entryType === 'checkin' && (
                              <div className="flex items-center space-x-2">
                                <span className="text-sm">Mood:</span>
                                {Object.entries(moodIcons).map(([mood, icon]) => (
                                  <Button
                                    key={mood}
                                    variant={selectedMood === mood ? "default" : "ghost"}
                                    size="sm"
                                    onClick={() => setSelectedMood(mood as WorkEntry['mood'])}
                                    className="h-8 w-8 p-0"
                                  >
                                    {icon}
                                  </Button>
                                ))}
                              </div>
                            )}

                            <div className="flex items-center space-x-2">
                              <Input
                                placeholder="Add tags..."
                                value={newTag}
                                onChange={(e) => setNewTag(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && addTag()}
                                className="flex-1"
                              />
                              <Button onClick={addTag} size="sm">
                                <Hash className="h-4 w-4" />
                              </Button>
                            </div>

                            {entryTags.length > 0 && (
                              <div className="flex flex-wrap gap-1">
                                {entryTags.map((tag) => (
                                  <Badge
                                    key={tag}
                                    variant="secondary"
                                    className="cursor-pointer"
                                    onClick={() => removeTag(tag)}
                                  >
                                    #{tag} ×
                                  </Badge>
                                ))}
                              </div>
                            )}

                            <div className="flex items-center justify-end space-x-2">
                              <Button
                                variant="ghost"
                                onClick={() => setIsAddingEntry(false)}
                              >
                                Cancel
                              </Button>
                              <Button onClick={() => addWorkEntry(block.id)}>
                                Add {entryType}
                              </Button>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <Button
                          variant="outline"
                          className="w-full border-dashed"
                          onClick={() => {
                            setActiveBlock(block.id);
                            setIsAddingEntry(true);
                          }}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add to {block.title}
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Sidebar */}
        <div className="space-y-4">
          {/* Daily Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="h-5 w-5" />
                <span>Today's Progress</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Tasks Complete</span>
                  <span>{stats.tasksCompleted}/{stats.totalTasks}</span>
                </div>
                <Progress value={getTodayProgress()} className="h-2" />
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="text-center">
                  <div className="font-medium">{stats.totalEntries}</div>
                  <div className="text-muted-foreground">Entries</div>
                </div>
                <div className="text-center">
                  <div className="font-medium">{stats.filesUploaded}</div>
                  <div className="text-muted-foreground">Files</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Node Links */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="h-5 w-5" />
                <span>Node Links</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {nodes.slice(0, 3).map((node) => (
                  <div key={node.id} className="flex items-center space-x-2 p-2 rounded-lg border">
                    <div className="w-2 h-2 rounded-full bg-blue-500" />
                    <span className="text-sm truncate">{node.title}</span>
                  </div>
                ))}
                <Button variant="ghost" size="sm" className="w-full">
                  <Link className="h-4 w-4 mr-2" />
                  Link Node
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* AI Assistant Dialog */}
      <Dialog open={isAIDialogOpen} onOpenChange={setIsAIDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Brain className="h-5 w-5" />
              <span>AI Assistant</span>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder="Ask about your day, get suggestions, or request analysis..."
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              className="min-h-[120px]"
            />
            <div className="flex justify-end space-x-2">
              <Button variant="ghost" onClick={() => setIsAIDialogOpen(false)}>
                Cancel
              </Button>
              <Button>
                <Zap className="h-4 w-4 mr-2" />
                Ask AI
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}