import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { LucideIcon, Users, Code, ShoppingCart, Network, Laptop, Headphones, Plus, Trash2, Edit, Eye } from 'lucide-react';

// Interface types
interface Interface {
  id: number;
  name: string;
  type: string;
  description: string | null;
  icon: string | null;
  config: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

interface User {
  id: number;
  username: string;
  displayName: string;
  email: string;
  avatar: string | null;
}

// Icon mapping for interface types
const getInterfaceIcon = (type: string): LucideIcon => {
  switch (type.toLowerCase()) {
    case 'marketing':
      return Users;
    case 'swe':
      return Code;
    case 'ecommerce':
      return ShoppingCart;
    case 'network':
      return Network;
    case 'it':
      return Laptop;
    case 'support':
      return Headphones;
    default:
      return Users;
  }
};

// Interface card component
const InterfaceCard = ({ 
  interface: interfaceItem, 
  onEdit, 
  onDelete, 
  onAssign,
  onPreview
}: { 
  interface: Interface; 
  onEdit: (id: number) => void; 
  onDelete: (id: number) => void;
  onAssign: (id: number) => void;
  onPreview: (id: number) => void;
}) => {
  const Icon = getInterfaceIcon(interfaceItem.type);
  
  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">{interfaceItem.name}</CardTitle>
          <Badge variant="outline">{interfaceItem.type}</Badge>
        </div>
        <CardDescription className="flex items-center gap-2">
          <Icon className="h-4 w-4" />
          <span>{interfaceItem.type.charAt(0).toUpperCase() + interfaceItem.type.slice(1)} Interface</span>
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-sm text-muted-foreground">
          {interfaceItem.description || 'No description provided.'}
        </p>
      </CardContent>
      <CardFooter className="flex flex-col space-y-3 w-full">
        <Button 
          variant="default" 
          size="sm" 
          className="w-full"
          onClick={() => onPreview(interfaceItem.id)}
        >
          <Eye className="h-4 w-4 mr-1" />
          Preview Interface
        </Button>
        <div className="flex justify-between w-full">
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => onEdit(interfaceItem.id)}
            >
              <Edit className="h-4 w-4 mr-1" />
              Edit
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="text-destructive hover:text-destructive"
              onClick={() => onDelete(interfaceItem.id)}
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Delete
            </Button>
          </div>
          <Button 
            size="sm"
            onClick={() => onAssign(interfaceItem.id)}
          >
            <Users className="h-4 w-4 mr-1" />
            Assign
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

// Simple interface preview modal
const InterfacePreviewModal = ({
  open,
  onClose,
  interfaceId
}: {
  open: boolean;
  onClose: () => void;
  interfaceId: number | null;
}) => {
  const { data: interfaceItem, isLoading } = useQuery({
    queryKey: ['/api/interfaces', interfaceId],
    enabled: !!interfaceId && open,
  });

  if (!open) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Interface Preview</DialogTitle>
          <DialogDescription>
            Preview of the {interfaceItem?.name} interface
          </DialogDescription>
        </DialogHeader>
        <div className="p-6">
          {isLoading ? (
            <div className="text-center">Loading preview...</div>
          ) : interfaceItem ? (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">{interfaceItem.name}</h3>
              <p className="text-muted-foreground">{interfaceItem.description}</p>
              <div className="bg-muted p-4 rounded-md">
                <p className="text-sm">Interface Type: {interfaceItem.type}</p>
                <p className="text-sm">This is a preview of how the {interfaceItem.type} interface would appear to users.</p>
              </div>
            </div>
          ) : (
            <div className="text-center">Interface not found</div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

// New Interface form
const NewInterfaceForm = ({ 
  onSubmit, 
  onCancel, 
  initialData = null 
}: { 
  onSubmit: (data: any) => void; 
  onCancel: () => void;
  initialData?: Interface | null;
}) => {
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    type: initialData?.type || '',
    description: initialData?.description || '',
    icon: initialData?.icon || '',
    config: initialData?.config || {}
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleTypeChange = (value: string) => {
    setFormData(prev => ({ ...prev, type: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Name</Label>
        <Input 
          id="name" 
          name="name" 
          value={formData.name} 
          onChange={handleChange} 
          required 
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="type">Type</Label>
        <Select 
          value={formData.type} 
          onValueChange={handleTypeChange}
          required
        >
          <SelectTrigger>
            <SelectValue placeholder="Select interface type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="marketing">Marketing</SelectItem>
            <SelectItem value="swe">Software Engineering</SelectItem>
            <SelectItem value="ecommerce">E-commerce</SelectItem>
            <SelectItem value="network">Network</SelectItem>
            <SelectItem value="it">IT</SelectItem>
            <SelectItem value="support">Support Ticket Handler</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea 
          id="description" 
          name="description" 
          value={formData.description} 
          onChange={handleChange} 
          rows={3}
        />
      </div>
      
      <div className="flex justify-end space-x-2 pt-4">
        <Button variant="outline" type="button" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {initialData ? 'Update Interface' : 'Create Interface'}
        </Button>
      </div>
    </form>
  );
};

// Assign Interface Dialog
const AssignInterfaceDialog = ({ 
  open, 
  onClose, 
  interfaceId, 
  onAssign 
}: { 
  open: boolean; 
  onClose: () => void; 
  interfaceId: number | null;
  onAssign: (userId: number, interfaceId: number) => void;
}) => {
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  
  const { data: users = [], isLoading: isLoadingUsers } = useQuery({
    queryKey: ['/api/users'],
    enabled: open,
  });
  
  const { data: interfaceItem } = useQuery({
    queryKey: ['/api/interfaces', interfaceId],
    enabled: !!interfaceId,
  });
  
  const handleAssign = () => {
    if (selectedUserId && interfaceId) {
      onAssign(parseInt(selectedUserId), interfaceId);
      onClose();
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Assign Interface to User</DialogTitle>
          <DialogDescription>
            Select a user to assign the {interfaceItem?.name} interface to.
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <Label htmlFor="user-select">Select User</Label>
          <Select 
            value={selectedUserId}
            onValueChange={setSelectedUserId}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select a user" />
            </SelectTrigger>
            <SelectContent>
              {isLoadingUsers ? (
                <SelectItem value="loading" disabled>Loading users...</SelectItem>
              ) : (
                users.map((user: User) => (
                  <SelectItem key={user.id} value={user.id.toString()}>
                    {user.displayName} ({user.username})
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleAssign} disabled={!selectedUserId}>
            Assign Interface
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

// Main Interfaces page component
export default function InterfacesPage() {
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editingInterfaceId, setEditingInterfaceId] = useState<number | null>(null);
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false);
  const [assigningInterfaceId, setAssigningInterfaceId] = useState<number | null>(null);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
  const [previewInterfaceId, setPreviewInterfaceId] = useState<number | null>(null);
  
  // Queries
  const { data: interfaces = [], isLoading } = useQuery({
    queryKey: ['/api/interfaces'],
  });
  
  const { data: editingInterface } = useQuery({
    queryKey: ['/api/interfaces', editingInterfaceId],
    enabled: !!editingInterfaceId,
  });
  
  // Mutations
  const createInterfaceMutation = useMutation({
    mutationFn: (data: any) => apiRequest('/api/interfaces', { method: 'POST', body: data }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/interfaces'] });
      handleCloseDialog();
    },
  });
  
  const updateInterfaceMutation = useMutation({
    mutationFn: ({ id, data }: { id: number, data: any }) => 
      apiRequest(`/api/interfaces/${id}`, { method: 'PATCH', body: data }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/interfaces'] });
      handleCloseDialog();
    },
  });
  
  const deleteInterfaceMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/interfaces/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/interfaces'] });
    },
  });
  
  const assignInterfaceMutation = useMutation({
    mutationFn: ({ userId, interfaceId }: { userId: number, interfaceId: number }) => 
      apiRequest('/api/user-interfaces', { 
        method: 'POST', 
        body: { userId, interfaceId } 
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user-interfaces'] });
    },
  });
  
  // Handlers
  const handleCreateInterface = (data: any) => {
    if (isEditMode && editingInterfaceId) {
      updateInterfaceMutation.mutate({ id: editingInterfaceId, data });
    } else {
      createInterfaceMutation.mutate(data);
    }
  };
  
  const handleEditInterface = (id: number) => {
    setEditingInterfaceId(id);
    setIsEditMode(true);
    setIsDialogOpen(true);
  };
  
  const handleDeleteInterface = (id: number) => {
    if (confirm('Are you sure you want to delete this interface? This action cannot be undone.')) {
      deleteInterfaceMutation.mutate(id);
    }
  };
  
  const handleAssignInterface = (id: number) => {
    setAssigningInterfaceId(id);
    setIsAssignDialogOpen(true);
  };
  
  const handleAssignUserToInterface = (userId: number, interfaceId: number) => {
    assignInterfaceMutation.mutate({ userId, interfaceId });
  };
  
  const handlePreviewInterface = (id: number) => {
    setPreviewInterfaceId(id);
    setIsPreviewModalOpen(true);
  };
  
  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setIsEditMode(false);
    setEditingInterfaceId(null);
  };
  
  return (
    <div className="container mx-auto py-3 md:py-6 px-3 md:px-6">
      <div className="flex flex-col space-y-3 md:space-y-0 md:flex-row md:justify-between md:items-center mb-4 md:mb-6">
        <div>
          <h1 className="text-xl md:text-3xl font-bold">Role-Based Interfaces</h1>
          <p className="text-sm md:text-base text-muted-foreground mt-1">
            Manage and assign specialized interfaces to users based on their roles.
          </p>
        </div>
        <Button onClick={() => setIsDialogOpen(true)} size="sm" className="w-fit">
          <Plus className="mr-1 md:mr-2 h-4 w-4" />
          <span className="text-sm">New Interface</span>
        </Button>
      </div>
      
      <Tabs defaultValue="interfaces" className="w-full">
        <TabsList className="mb-4 w-full md:w-auto">
          <TabsTrigger value="interfaces" className="flex-1 md:flex-none">Interfaces</TabsTrigger>
        </TabsList>
        
        <TabsContent value="interfaces">
          {isLoading ? (
            <div className="text-center py-8 md:py-12">Loading interfaces...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-6">
              {interfaces.length === 0 ? (
                <div className="col-span-full text-center py-12 text-muted-foreground">
                  No interfaces found. Create a new interface to get started.
                </div>
              ) : (
                interfaces.map((interfaceItem: Interface) => (
                  <InterfaceCard 
                    key={interfaceItem.id}
                    interface={interfaceItem}
                    onEdit={handleEditInterface}
                    onDelete={handleDeleteInterface}
                    onAssign={handleAssignInterface}
                    onPreview={handlePreviewInterface}
                  />
                ))
              )}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Interface Preview Modal */}
      <InterfacePreviewModal
        open={isPreviewModalOpen}
        onClose={() => setIsPreviewModalOpen(false)}
        interfaceId={previewInterfaceId}
      />
      
      {/* Create/Edit Interface Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{isEditMode ? 'Edit Interface' : 'Create New Interface'}</DialogTitle>
            <DialogDescription>
              {isEditMode 
                ? 'Update the details of this interface.' 
                : 'Add a new interface to assign to users.'}
            </DialogDescription>
          </DialogHeader>
          <NewInterfaceForm 
            onSubmit={handleCreateInterface} 
            onCancel={handleCloseDialog}
            initialData={isEditMode ? editingInterface : null}
          />
        </DialogContent>
      </Dialog>
      
      {/* Assign Interface Dialog */}
      <AssignInterfaceDialog 
        open={isAssignDialogOpen} 
        onClose={() => setIsAssignDialogOpen(false)}
        interfaceId={assigningInterfaceId}
        onAssign={handleAssignUserToInterface}
      />
    </div>
  );
}