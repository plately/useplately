import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Channel, User, NodeWithLinks, MessageWithSender, Message, Node } from "@shared/schema";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import UniversalNodeCreator from "@/components/universal-node-creator";
import { useWebSocket } from "@/hooks/use-websocket";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile.tsx";
import { 
  ChevronDown, 
  Hash, 
  Lock, 
  MessageSquare, 
  Users, 
  PlusCircle, 
  Send, 
  PaperclipIcon,
  SmileIcon,
  Menu,
  X,
  MoreHorizontal,
  Reply,
  Star,
  Bookmark,
  Copy,
  Edit,
  Trash2,
  Search,
  Filter,
  Archive,
  Pin,
  Link2,
  FileText,
  Image,
  Video,
  Mic,
  Settings,
  UserPlus,
  Bell,
  MessageCircle,
  GitBranch,
  Eye,
  Clock,
  Calendar,
  Tag,
  Share2,
  Plus,
  Check,
  Bot,
  Wifi,
  WifiOff,
} from "lucide-react";

export default function Chat() {
  const [selectedSpace, setSelectedSpace] = useState<any>(null);
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null);
  const [messageInput, setMessageInput] = useState("");
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [showSidebar, setShowSidebar] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [replyingTo, setReplyingTo] = useState<MessageWithSender | null>(null);
  const [editingMessage, setEditingMessage] = useState<MessageWithSender | null>(null);
  const [selectedMessages, setSelectedMessages] = useState<number[]>([]);
  const nodeCreatorTriggerRef = useRef<HTMLButtonElement>(null);
  const [convertedMessages, setConvertedMessages] = useState<{
    [messageId: number]: Array<{
      nodeId: number;
      title: string;
      type: string;
      createdAt: string;
      tags?: string[];
      dueDate?: string;
      meetingDate?: string;
      context?: string;
    }>
  }>({});

  // Discord state
  const [showDiscordSettings, setShowDiscordSettings] = useState(false);
  const [discordChannelInput, setDiscordChannelInput] = useState("");
  const [discordSyncedMessages, setDiscordSyncedMessages] = useState<Set<number>>(new Set());

  // Discord config query
  const { data: discordConfig, refetch: refetchDiscordConfig } = useQuery<{
    connected: boolean;
    botTag: string | null;
    clientId: string | null;
    inviteUrl: string | null;
    guilds: { id: string; name: string }[];
    mappings: { nodeosChannelId: number; discordChannelId: string }[];
  }>({
    queryKey: ['/api/discord/config'],
    refetchInterval: 30000,
  });

  // Derived: Discord channel ID for the currently viewed NodeOS channel
  const currentChannelDiscordId = selectedChannel
    ? discordConfig?.mappings?.find(m => m.nodeosChannelId === selectedChannel.id)?.discordChannelId ?? null
    : null;

  // Discord: save mapping for current channel
  const saveDiscordChannelMutation = useMutation({
    mutationFn: async ({ nodeosChannelId, discordChannelId }: { nodeosChannelId: number; discordChannelId: string }) =>
      apiRequest('/api/discord/config', { method: 'POST', body: JSON.stringify({ nodeosChannelId, discordChannelId }) }),
    onSuccess: () => {
      refetchDiscordConfig();
      setShowDiscordSettings(false);
      toast({ title: "Discord channel linked", description: "Messages from that Discord channel will now appear here." });
    },
    onError: () => toast({ variant: "destructive", title: "Failed to link Discord channel" }),
  });

  // Discord: remove mapping for current channel
  const removeDiscordChannelMutation = useMutation({
    mutationFn: async (nodeosChannelId: number) =>
      apiRequest('/api/discord/config', { method: 'POST', body: JSON.stringify({ nodeosChannelId, remove: true }) }),
    onSuccess: () => {
      refetchDiscordConfig();
      setShowDiscordSettings(false);
      toast({ title: "Discord channel unlinked" });
    },
  });

  // Discord: push message to Discord
  const sendToDiscordMutation = useMutation({
    mutationFn: async ({ content, senderName, messageId, nodeosChannelId }: { content: string; senderName: string; messageId: number; nodeosChannelId: number }) => {
      const res = await apiRequest('/api/discord/send', { method: 'POST', body: JSON.stringify({ content, senderName, nodeosChannelId }) });
      return { res, messageId };
    },
    onSuccess: ({ messageId }) => {
      setDiscordSyncedMessages(prev => new Set(prev).add(messageId));
      toast({ title: "Sent to Discord", description: "Your message appeared in the Discord channel." });
    },
    onError: () => toast({ variant: "destructive", title: "Couldn't send to Discord", description: "Check that this channel is linked to a Discord channel." }),
  });

  // Discord: notify node created
  const notifyDiscordNodeMutation = useMutation({
    mutationFn: async (payload: { originalContent: string; nodeType: string; nodeTitle: string; senderName: string; nodeosChannelId: number }) =>
      apiRequest('/api/discord/notify-node', { method: 'POST', body: JSON.stringify(payload) }),
  });

  // Component for displaying node conversion indicator
  const NodeConversionIndicator = ({ messageId }: { messageId: number }) => {
    const conversions = convertedMessages[messageId];
    if (!conversions || conversions.length === 0) return null;

    const getTypeIcon = (type: string) => {
      switch (type) {
        case 'task': return <Check className="h-4 w-4" />;
        case 'meeting': return <Calendar className="h-4 w-4" />;
        case 'idea': return <span className="text-base">💡</span>;
        case 'reference': return <FileText className="h-4 w-4" />;
        default: return <GitBranch className="h-4 w-4" />;
      }
    };

    const getTypeTitle = (type: string) => {
      switch (type) {
        case 'task': return 'Task Created';
        case 'meeting': return 'Meeting Created';
        case 'idea': return 'Idea Created';
        case 'reference': return 'Reference Created';
        case 'chat': return 'Discussion Saved';
        default: return 'Node Created';
      }
    };

    const handleClick = (conversion: any) => {
      if (conversion.type === 'task') {
        // Navigate to tasks section
        window.location.hash = '#/tasks';
      } else if (conversion.type === 'meeting') {
        // Navigate to calendar
        window.location.hash = '#/calendar';
      } else if (conversion.type === 'idea') {
        // Navigate to planning room or ideas
        window.location.hash = '#/planning';
      } else {
        // Navigate to knowledge graph or specific node
        window.location.hash = '#/graph';
      }
    };

    return (
      <div className="mt-2 ml-8 sm:ml-11 mr-2 space-y-2" data-testid={`node-indicator-${messageId}`}>
        {conversions.map((conversion, index) => (
          <div 
            key={`${messageId}-${conversion.nodeId}-${index}`}
            className="p-3 bg-blue-50/80 dark:bg-blue-950/20 border border-blue-200/50 dark:border-blue-800/30 rounded-lg backdrop-blur-sm cursor-pointer hover:bg-blue-100/80 dark:hover:bg-blue-950/30 transition-colors"
            onClick={() => handleClick(conversion)}
          >
            <div className="flex items-center gap-2 text-blue-700 dark:text-blue-300">
              {getTypeIcon(conversion.type)}
              <span className="font-medium text-sm">{getTypeTitle(conversion.type)}</span>
            </div>
            
            <div className="mt-1 space-y-1">
              <div className="text-sm text-blue-900 dark:text-blue-100">
                <span className="font-medium">Title:</span> {conversion.title}
              </div>
              
              {conversion.type === 'task' && conversion.dueDate && (
                <div className="text-sm text-blue-900 dark:text-blue-100">
                  <span className="font-medium">Due:</span> {conversion.dueDate}
                </div>
              )}
              
              {conversion.type === 'meeting' && conversion.meetingDate && (
                <div className="text-sm text-blue-900 dark:text-blue-100">
                  <span className="font-medium">Date:</span> {conversion.meetingDate}
                </div>
              )}
              
              <div className="text-xs text-blue-600 dark:text-blue-400">
                {conversion.context}
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };
  const [showChannelSettings, setShowChannelSettings] = useState(false);
  const [pinnedMessages, setPinnedMessages] = useState<number[]>([]);
  const [showThreads, setShowThreads] = useState(false);
  const [activeThread, setActiveThread] = useState<number | null>(null);
  const [showCreateSpaceDialog, setShowCreateSpaceDialog] = useState(false);
  const [showCreateChannelDialog, setShowCreateChannelDialog] = useState(false);
  const [showSpaceSelector, setShowSpaceSelector] = useState(false);
  const [newSpaceName, setNewSpaceName] = useState("");
  const [newSpaceDescription, setNewSpaceDescription] = useState("");
  const [newChannelName, setNewChannelName] = useState("");
  const [newChannelDescription, setNewChannelDescription] = useState("");
  const [isChannelPrivate, setIsChannelPrivate] = useState(false);
  const [selectedMembers, setSelectedMembers] = useState<number[]>([]);
  const [showRenameChannelDialog, setShowRenameChannelDialog] = useState(false);
  const [showDeleteChannelDialog, setShowDeleteChannelDialog] = useState(false);
  const [renameChannelValue, setRenameChannelValue] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const isMobile = useIsMobile();
  
  // When on mobile, hide sidebar by default
  useEffect(() => {
    if (isMobile) {
      setShowSidebar(false);
    } else {
      setShowSidebar(true);
    }
  }, [isMobile]);
  
  // On mobile, selecting a channel should hide the sidebar
  const handleSelectChannel = (channel: Channel) => {
    setSelectedChannel(channel);
    if (isMobile) {
      setShowSidebar(false);
    }
  };
  
  // WebSocket connection
  const { connected, sendChatMessage, lastMessage } = useWebSocket();

  // Handle message to node conversion
  const handleConvertToNode = (message: MessageWithSender) => {
    console.log('handleConvertToNode called with message:', message.id);
    
    if (selectedMessages.length === 0) {
      setSelectedMessages([message.id]);
    }
    
    console.log('Clicking nodeCreatorTriggerRef');
    nodeCreatorTriggerRef.current?.click();
  };
  
  // Query for the current user
  const { data: userData } = useQuery<User>({
    queryKey: ['/api/users/me'],
    enabled: true
  });

  // Set current user when data loads
  useEffect(() => {
    if (userData) {
      setCurrentUser(userData);
    }
  }, [userData]);
  
  // Query for channels in selected space
  const { data: channels, isLoading: loadingChannels } = useQuery<Channel[]>({
    queryKey: [`/api/spaces/${selectedSpace?.id}/channels`],
    enabled: !!selectedSpace
  });
  
  // Query for direct messages
  const { data: directMessages, isLoading: loadingDms } = useQuery<User[]>({
    queryKey: ['/api/users'],
    enabled: true
  });

  // These queries are not needed for the simplified approach
  // They were used by the complex dialog that we've removed

  // Query for spaces
  const { data: spaces } = useQuery<any[]>({
    queryKey: ['/api/spaces'],
    enabled: true
  });

  // Set default space when spaces load
  useEffect(() => {
    if (spaces && Array.isArray(spaces) && spaces.length > 0 && !selectedSpace) {
      setSelectedSpace(spaces[0]);
    }
  }, [spaces, selectedSpace]);

  // Mutation for creating new space
  const createSpaceMutation = useMutation({
    mutationFn: async (data: { name: string; description: string }) => {
      console.log('Creating space with data:', data);
      const response = await apiRequest('/api/spaces', {
        method: 'POST',
        body: JSON.stringify({
          name: data.name,
          description: data.description
        })
      });
      console.log('Space creation response:', response);
      return response;
    },
    onSuccess: (data) => {
      console.log('Space created successfully:', data);
      queryClient.invalidateQueries({ queryKey: ['/api/spaces'] });
      setShowCreateSpaceDialog(false);
      setNewSpaceName("");
      setNewSpaceDescription("");
      toast({
        title: "Space created successfully",
        description: "Your new workspace is ready to use.",
      });
    },
    onError: (error) => {
      console.error('Failed to create space:', error);
      toast({
        title: "Failed to create space",
        description: error.message || "Could not create the new workspace. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Mutation for creating new channel
  const createChannelMutation = useMutation({
    mutationFn: async (data: { name: string, description: string, isPrivate: boolean, members: number[] }) => {
      return apiRequest('/api/channels', {
        method: 'POST',
        body: JSON.stringify({
          name: data.name,
          description: data.description,
          spaceId: selectedSpace?.id || 1,
          isPrivate: data.isPrivate,
          members: data.members
        })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/spaces/${selectedSpace?.id}/channels`] });
      setShowCreateChannelDialog(false);
      setNewChannelName("");
      setNewChannelDescription("");
      setIsChannelPrivate(false);
      setSelectedMembers([]);
      toast({
        title: "Channel created successfully",
        description: "Your new channel is ready for conversations.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to create channel",
        description: "Could not create the new channel. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  // Query for messages in selected channel
  const { data: messages, isLoading: loadingMessages } = useQuery<MessageWithSender[]>({
    queryKey: [`/api/channels/${selectedChannel?.id}/messages`],
    enabled: !!selectedChannel
  });

  // Query for chat discussion nodes related to this channel
  const { data: chatNodes } = useQuery<Node[]>({
    queryKey: ['/api/nodes', 'chat', selectedChannel?.id],
    queryFn: async () => {
      if (!selectedChannel) return [];
      const allNodes = await apiRequest('/api/nodes');
      // Filter for chat nodes that mention this channel
      return Array.isArray(allNodes) ? allNodes.filter((node: Node) => 
        node.nodeType === 'chat' && 
        (node.title.toLowerCase().includes(selectedChannel.name.toLowerCase()) ||
         (node.content && node.content.toLowerCase().includes(selectedChannel.name.toLowerCase())))
      ) : [];
    },
    enabled: !!selectedChannel
  });

  // Set current user from demo data if API fails
  useEffect(() => {
    if (!currentUser && !userData) {
      setCurrentUser({
        id: 1,
        username: 'demo-user',
        password: '',
        displayName: 'Demo User',
        email: 'demo@example.com',
        avatar: null,
        role: 'user',
        isActive: true,
        lastActivity: new Date(),
        createdAt: new Date()
      });
    }
  }, [currentUser, userData]);
  
  // Mutation for sending messages
  const sendMessageMutation = useMutation({
    mutationFn: async (message: { channelId: number, content: string, replyTo?: number }) => {
      return apiRequest('/api/messages', {
        method: 'POST',
        body: JSON.stringify({
          channelId: message.channelId,
          content: message.content,
          userId: currentUser?.id || 1
        })
      });
    },
    onSuccess: () => {
      // Invalidate messages query to trigger a refetch
      queryClient.invalidateQueries({ queryKey: [`/api/channels/${selectedChannel?.id}/messages`] });
    },
    onError: (error) => {
      toast({
        title: "Error sending message",
        description: "Your message couldn't be sent. Please try again.",
        variant: "destructive"
      });
      console.error("Error sending message:", error);
    }
  });

  // Simplified node creation tracking - we'll use the UniversalNodeCreator
  // and just track which messages were converted for visual feedback

  // Mutation for pinning messages
  const pinMessageMutation = useMutation({
    mutationFn: async (messageId: number) => {
      // In a real app, this would update the backend
      setPinnedMessages(prev => 
        prev.includes(messageId) 
          ? prev.filter(id => id !== messageId)
          : [...prev, messageId]
      );
      return Promise.resolve();
    },
    onSuccess: () => {
      toast({
        title: "Message pinned",
        description: "Message has been pinned to this channel.",
      });
    }
  });

  // Mutation for renaming channel
  const renameChannelMutation = useMutation({
    mutationFn: async (data: { channelId: number; name: string }) => {
      return apiRequest(`/api/channels/${data.channelId}`, {
        method: 'PATCH',
        body: JSON.stringify({ name: data.name })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/spaces/${selectedSpace?.id}/channels`] });
      setShowRenameChannelDialog(false);
      setRenameChannelValue("");
      toast({
        title: "Channel renamed",
        description: "The channel name has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to rename channel",
        description: "Could not rename the channel. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Mutation for deleting channel
  const deleteChannelMutation = useMutation({
    mutationFn: async (channelId: number) => {
      return apiRequest(`/api/channels/${channelId}`, {
        method: 'DELETE'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/spaces/${selectedSpace?.id}/channels`] });
      setSelectedChannel(null);
      setShowDeleteChannelDialog(false);
      toast({
        title: "Channel deleted",
        description: "The channel has been deleted successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to delete channel",
        description: "Could not delete the channel. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  // Scroll to bottom when new messages arrive
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);
  
  // Process incoming WebSocket messages
  useEffect(() => {
    if (!lastMessage || !selectedChannel) return;

    if (lastMessage.type === 'chat_message') {
      // NodeOS user sent a message — refresh if it's for this channel
      if (lastMessage.data.channelId === selectedChannel.id) {
        queryClient.invalidateQueries({ queryKey: [`/api/channels/${selectedChannel.id}/messages`] });
      }
    } else if (lastMessage.type === 'new_message') {
      // new_message can come from Discord (shape: {message:{channelId}})
      // or from channel broadcasts (shape: {data:{channelId}})
      const raw = lastMessage as any;
      const msgChannelId = raw.message?.channelId ?? raw.data?.channelId ?? 1;
      if (msgChannelId === selectedChannel.id) {
        queryClient.invalidateQueries({ queryKey: [`/api/channels/${selectedChannel.id}/messages`] });
      }
    }
  }, [lastMessage, queryClient, selectedChannel]);
  
  const handleSendMessage = () => {
    if (!messageInput.trim() || !selectedChannel || !currentUser) return;
    
    // Send through API
    sendMessageMutation.mutate({
      channelId: selectedChannel.id,
      content: messageInput,
      replyTo: replyingTo?.id
    });
    
    // Also send through WebSocket for real-time updates
    if (connected && currentUser) {
      sendChatMessage(selectedChannel.id, messageInput, currentUser.id);
    }
    
    // Clear input and reset reply
    setMessageInput("");
    setReplyingTo(null);
  };

  const handleMessageSelect = (messageId: number) => {
    setSelectedMessages(prev => 
      prev.includes(messageId) 
        ? prev.filter(id => id !== messageId)
        : [...prev, messageId]
    );
  };

  const handleCreateNode = () => {
    if (selectedMessages.length === 0) {
      toast({
        title: "No messages selected",
        description: "Select one or more messages to create a node.",
        variant: "destructive",
      });
      return;
    }
    nodeCreatorTriggerRef.current?.click();
  };


  const filteredMessages = messages?.filter(message => 
    !searchQuery || 
    message.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
    message.sender.displayName.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  return (
    <div className="h-screen flex overflow-hidden">
      {/* Semi-transparent backdrop for mobile when sidebar is open */}
      {isMobile && showSidebar && (
        <div 
          className="fixed inset-0 bg-black/40 z-20"
          onClick={() => setShowSidebar(false)}
        />
      )}
      
      {/* Channels sidebar - conditionally shown based on showSidebar */}
      {(showSidebar || !isMobile) && (
        <div className={`${isMobile ? 'absolute inset-y-0 left-0 z-30 w-64 sm:w-72' : 'w-60'} glass-sidebar flex flex-col`}>
          <div className="py-3 px-3 sm:p-4 border-b border-border flex justify-between items-center">
            <DropdownMenu open={showSpaceSelector} onOpenChange={setShowSpaceSelector}>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="flex items-center gap-2 p-0 h-auto font-semibold text-base sm:text-lg truncate hover:bg-accent/50"
                >
                  <span className="truncate">{selectedSpace?.name || 'Select Space'}</span>
                  <ChevronDown className="h-4 w-4 flex-shrink-0" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                {spaces?.map((space: any) => (
                  <DropdownMenuItem
                    key={space.id}
                    onClick={() => {
                      setSelectedSpace(space);
                      setSelectedChannel(null);
                      setShowSpaceSelector(false);
                    }}
                    className={selectedSpace?.id === space.id ? 'bg-accent' : ''}
                  >
                    <div className="flex items-center gap-2">
                      <Hash className="h-4 w-4" />
                      <span>{space.name}</span>
                    </div>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setShowCreateSpaceDialog(true)}>
                  <div className="flex items-center gap-2">
                    <Plus className="h-4 w-4" />
                    <span>Create New Space</span>
                  </div>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            {isMobile && (
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-7 w-7 sm:h-8 sm:w-8 flex-shrink-0 ml-1" 
                onClick={() => setShowSidebar(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
          
          <ScrollArea className="flex-1">
            <div className="p-2">
              <div className="mt-2">
                <h3 className="px-3 text-xs font-semibold text-muted-foreground flex items-center justify-between">
                  <span>CHANNELS</span>
                  <PlusCircle 
                    className="h-4 w-4 cursor-pointer hover:text-foreground transition-colors" 
                    onClick={() => setShowCreateChannelDialog(true)}
                  />
                </h3>
                
                <div className="mt-1 space-y-[2px]">
                  {loadingChannels ? (
                    <div className="px-3 py-1.5 text-sm text-muted-foreground">Loading...</div>
                  ) : (
                    channels?.map(channel => (
                      <button 
                        key={channel.id}
                        className={`px-2 py-1.5 text-sm w-full text-left rounded flex items-center ${
                          selectedChannel?.id === channel.id 
                            ? 'bg-accent text-accent-foreground' 
                            : 'text-foreground hover:bg-accent/50'
                        }`}
                        onClick={() => handleSelectChannel(channel)}
                      >
                        {channel.isPrivate ? (
                          <Lock className="h-4 w-4 mr-1.5 text-muted-foreground" />
                        ) : (
                          <Hash className="h-4 w-4 mr-1.5 text-muted-foreground" />
                        )}
                        {channel.name}
                      </button>
                    ))
                  )}
                </div>
              </div>
              
              <div className="mt-6">
                <h3 className="px-3 text-xs font-semibold text-muted-foreground flex items-center justify-between">
                  <span>DIRECT MESSAGES</span>
                  <PlusCircle 
                    className="h-4 w-4 cursor-pointer hover:text-foreground transition-colors" 
                    onClick={() => setShowCreateChannelDialog(true)}
                  />
                </h3>
                
                <div className="mt-1 space-y-[2px]">
                  {loadingDms ? (
                    <div className="px-3 py-1.5 text-sm text-muted-foreground">Loading...</div>
                  ) : (
                    directMessages?.map(user => (
                      <button 
                        key={user.id}
                        className="px-2 py-1.5 text-sm w-full text-left rounded flex items-center text-foreground hover:bg-accent/50"
                      >
                        <div className="relative mr-2">
                          <Avatar className="h-5 w-5">
                            <AvatarImage src={user.avatar || undefined} alt={user.displayName} />
                            <AvatarFallback>{user.displayName.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-green-500 border border-background"></div>
                        </div>
                        {user.displayName}
                      </button>
                    ))
                  )}
                </div>
              </div>
            </div>
          </ScrollArea>
        </div>
      )}
      
      {/* Main chat area */}
      <div className="flex-1 flex flex-col h-full">
        {selectedChannel ? (
          <>
            {/* Channel header with mobile menu button */}
            <div className="h-14 border-b border-border flex items-center px-4 justify-between flex-shrink-0">
              <div className="flex items-center overflow-hidden">
                {isMobile && !showSidebar && (
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 mr-2 flex-shrink-0" 
                    onClick={() => setShowSidebar(true)}
                  >
                    <Menu className="h-4 w-4" />
                  </Button>
                )}
                <div className="flex items-center overflow-hidden">
                  {selectedChannel.isPrivate ? (
                    <Lock className="h-4 w-4 mr-2 text-muted-foreground flex-shrink-0" />
                  ) : (
                    <Hash className="h-4 w-4 mr-2 text-muted-foreground flex-shrink-0" />
                  )}
                  <h2 className="font-medium text-base truncate">{selectedChannel.name}</h2>
                </div>
                
                {!isMobile && selectedChannel.description && (
                  <>
                    <Separator orientation="vertical" className="mx-3 h-4 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground truncate">{selectedChannel.description}</span>
                  </>
                )}
              </div>
              
              <div className="flex items-center gap-2">
                {selectedMessages.length > 0 && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleCreateNode}
                    className="h-8 text-xs bg-gradient-to-r from-green-500 via-blue-500 to-purple-500 hover:from-green-600 hover:via-blue-600 hover:to-purple-600 text-white border-none"
                  >
                    <GitBranch className="h-3 w-3 mr-1" />
                    Create Node ({selectedMessages.length})
                  </Button>
                )}
                
                <UniversalNodeCreator 
                  defaultType="chat"
                  size="sm"
                  className="h-8"
                  channelContext={{
                    channelId: selectedChannel.id,
                    channelName: selectedChannel.name,
                    spaceId: selectedSpace?.id || 1,
                    spaceName: selectedSpace?.name || 'Default Space'
                  }}
                  trigger={
                    <Button variant="outline" size="sm" className="h-8 text-xs">
                      <Plus className="h-3 w-3 mr-1" />
                      New Discussion
                    </Button>
                  }
                />
                
                {/* Discord Status + Settings */}
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className={`h-8 w-8 p-0 relative ${currentChannelDiscordId ? 'text-[#5865F2]' : 'text-muted-foreground'}`}
                        onClick={() => {
                          setDiscordChannelInput(currentChannelDiscordId || "");
                          setShowDiscordSettings(true);
                        }}
                      >
                        <Bot className="h-4 w-4" />
                        <span className={`absolute bottom-1 right-1 w-2 h-2 rounded-full ring-1 ring-background ${currentChannelDiscordId ? 'bg-green-500' : discordConfig?.connected ? 'bg-yellow-400' : 'bg-gray-400'}`} />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      {currentChannelDiscordId
                        ? `Syncing with Discord channel ${currentChannelDiscordId}`
                        : discordConfig?.connected
                          ? 'Bot connected — click to link a Discord channel'
                          : 'Discord – click to configure'}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <Button variant="ghost" size="sm" className="h-8">
                  <Users className="h-4 w-4" />
                </Button>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-8">
                      <Settings className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => {
                      setRenameChannelValue(selectedChannel.name);
                      setShowRenameChannelDialog(true);
                    }}>
                      <Edit className="h-4 w-4 mr-2" />
                      Rename Channel
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      onClick={() => setShowDeleteChannelDialog(true)}
                      className="text-destructive focus:text-destructive"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete Channel
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4">
              {/* Chat Discussion Nodes */}
              {chatNodes && chatNodes.length > 0 && (
                <div className="mb-6 space-y-3">
                  <div className="flex items-center gap-2 mb-3">
                    <MessageSquare className="h-4 w-4 text-primary" />
                    <h3 className="text-sm font-semibold text-foreground">Active Discussions</h3>
                    <Badge variant="secondary" className="text-xs">
                      {chatNodes.length}
                    </Badge>
                  </div>
                  
                  {chatNodes.map(node => (
                    <div 
                      key={node.id}
                      className="glass-chat-bubble rounded-lg p-4 border border-border/50 bg-gradient-to-r from-primary/5 to-secondary/5 hover:bg-gradient-to-r hover:from-primary/10 hover:to-secondary/10 transition-all duration-200 cursor-pointer"
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-2 h-2 rounded-full bg-primary mt-2"></div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h4 className="font-medium text-sm text-foreground">{node.title}</h4>
                            <Badge variant="outline" className="text-xs">
                              Discussion
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {format(new Date(node.createdAt), 'MMM d, h:mm a')}
                            </span>
                          </div>
                          
                          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                            {node.content ? node.content.slice(0, 150) + '...' : 'No content'}
                          </p>
                          
                          {node.metadata?.channelContext && (
                            <div className="flex items-center gap-2 text-xs">
                              <Hash className="h-3 w-3" />
                              <span className="text-muted-foreground">
                                Related to #{node.metadata.channelContext.channelName}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  <Separator className="my-4" />
                </div>
              )}

              {loadingMessages ? (
                <div className="flex items-center justify-center h-full">
                  <div className="animate-spin h-5 w-5 border-2 border-primary rounded-full border-t-transparent"></div>
                </div>
              ) : filteredMessages.length > 0 ? (
                <div className="space-y-3">
                  {filteredMessages.map(message => (
                    <div 
                      key={message.id} 
                      className={`group flex gap-3 p-3 rounded-lg glass-chat-bubble cursor-pointer ${
                        selectedMessages.includes(message.id) ? 'bg-accent/30' : ''
                      }`}
                      onClick={() => {
                        if (selectedMessages.includes(message.id)) {
                          setSelectedMessages(selectedMessages.filter(id => id !== message.id));
                        } else {
                          setSelectedMessages([...selectedMessages, message.id]);
                        }
                      }}
                    >
                      <div className="relative flex-shrink-0">
                        <Avatar className="h-8 w-8">
                          <AvatarImage
                            src={(message as any).discordAvatar || message.sender?.avatar || undefined}
                            alt={(message as any).discordUsername || message.sender?.displayName || 'User'}
                          />
                          <AvatarFallback className="text-xs">
                            {(message as any).discordUsername
                              ? (message as any).discordUsername.charAt(0).toUpperCase()
                              : (message.sender?.displayName || 'U').charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        {/* Discord source indicator badge */}
                        {(message as any).source === 'discord' && (
                          <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#5865F2] rounded-full flex items-center justify-center ring-1 ring-background">
                            <Bot className="h-2.5 w-2.5 text-white" />
                          </div>
                        )}
                        {selectedMessages.includes(message.id) && (
                          <div className="absolute -top-1 -right-1 w-4 h-4 bg-primary rounded-full flex items-center justify-center">
                            <Check className="h-2.5 w-2.5 text-primary-foreground" />
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className="font-medium text-sm">
                            {(message as any).discordUsername || message.sender?.displayName || 'Unknown User'}
                          </span>
                          {(message as any).source === 'discord' && (
                            <Badge
                              variant="outline"
                              className="h-4 px-1.5 text-[10px] font-semibold border-[#5865F2]/40 text-[#5865F2] bg-[#5865F2]/10 gap-1"
                            >
                              <Bot className="h-2.5 w-2.5" />
                              Discord
                            </Badge>
                          )}
                          <span className="text-xs text-muted-foreground">
                            {format(new Date(message.createdAt), 'h:mm a')}
                          </span>
                          {discordSyncedMessages.has(message.id) && (
                            <Badge variant="secondary" className="h-4 px-1.5 text-[10px] gap-1">
                              <Check className="h-2.5 w-2.5" /> Synced to Discord
                            </Badge>
                          )}
                        </div>
                        
                        <div className="text-sm text-foreground leading-relaxed">
                          {message.content}
                        </div>
                        
                        {/* Node Conversion Indicator */}
                        <NodeConversionIndicator messageId={message.id} />
                      </div>

                      <div className="flex items-start gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setReplyingTo(message);
                                }}
                                className="h-6 w-6 p-0 hover:bg-blue-500/20"
                              >
                                <Reply className="h-3 w-3" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Reply to this message</TooltipContent>
                          </Tooltip>
                        </TooltipProvider>

                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleConvertToNode(message);
                                }}
                                className="h-6 w-6 p-0 hover:bg-green-500/20"
                              >
                                <GitBranch className="h-3 w-3" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Convert message to node</TooltipContent>
                          </Tooltip>
                        </TooltipProvider>

                        {/* Discord sync button - only for NodeOS messages, not Discord ones */}
                        {(message as any).source !== 'discord' && (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    sendToDiscordMutation.mutate({
                                      content: message.content,
                                      senderName: message.sender?.displayName || 'NodeOS User',
                                      messageId: message.id,
                                      nodeosChannelId: selectedChannel?.id ?? 1,
                                    });
                                  }}
                                  disabled={sendToDiscordMutation.isPending || discordSyncedMessages.has(message.id)}
                                  className={`h-6 w-6 p-0 hover:bg-[#5865F2]/20 ${discordSyncedMessages.has(message.id) ? 'text-[#5865F2]' : ''}`}
                                >
                                  <Bot className="h-3 w-3" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                {discordSyncedMessages.has(message.id) ? 'Already synced to Discord' : 'Send to Discord'}
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">No messages yet</h3>
                    <p className="text-muted-foreground">Start the conversation by sending a message below.</p>
                  </div>
                </div>
              )}
            </div>
            
            {/* Message Input */}
            <div className="p-4 border-t border-border bg-background flex-shrink-0">
              {replyingTo && (
                <div className="mb-3 p-2 bg-accent/30 rounded-md border-l-2 border-primary">
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-muted-foreground">
                      Replying to <span className="font-medium">{replyingTo.sender.displayName}</span>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setReplyingTo(null)}
                      className="h-5 w-5 p-0"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                  <div className="text-xs mt-1 truncate">{replyingTo.content}</div>
                </div>
              )}

              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm" className="h-10 w-10 p-0">
                  <PlusCircle className="h-5 w-5" />
                </Button>
                
                <div className="flex-1">
                  <Input
                    placeholder={`Message #${selectedChannel.name}`}
                    className="h-10"
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                  />
                </div>
                
                <Button variant="ghost" size="sm" className="h-10 w-10 p-0">
                  <SmileIcon className="h-5 w-5" />
                </Button>
                
                <Button 
                  onClick={handleSendMessage}
                  disabled={!messageInput.trim() || sendMessageMutation.isPending}
                  className="h-10 px-4"
                >
                  {sendMessageMutation.isPending ? (
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  ) : (
                    <Send className="h-5 w-5" />
                  )}
                </Button>
              </div>

              <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
                <span>Press Enter to send</span>
                <div className="flex items-center gap-1">
                  {connected ? (
                    <>
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>Connected</span>
                    </>
                  ) : (
                    <>
                      <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                      <span>Connecting...</span>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Removed complex node creation dialog - using simple UniversalNodeCreator instead */}

            {/* Universal Node Creator with Hidden Trigger */}
            <UniversalNodeCreator
              defaultType="chat"
              trigger={
                <button 
                  ref={nodeCreatorTriggerRef}
                  className="hidden"
                  aria-hidden="true"
                >
                  Hidden Trigger
                </button>
              }
              onSuccess={(createdNode) => {
                // Add visual feedback for converted messages with context-specific information
                if (createdNode) {
                  // Generate context message based on node type
                  let contextMessage = `From ${selectedChannel?.name} chat`;
                  let dueDate: string | undefined;
                  let meetingDate: string | undefined;
                  
                  if (createdNode.nodeType === 'task') {
                    if (createdNode.scheduledFor) {
                      dueDate = format(new Date(createdNode.scheduledFor), 'MMM d');
                    }
                    contextMessage = `From ${selectedChannel?.name} chat`;
                  } else if (createdNode.nodeType === 'meeting') {
                    // Extract meeting date and time from scheduledFor or properties
                    if (createdNode.scheduledFor) {
                      const meetingDateTime = new Date(createdNode.scheduledFor);
                      const startTime = createdNode.properties?.startTime || '09:00';
                      meetingDate = `${format(meetingDateTime, 'MMM d')} at ${startTime}`;
                    }
                    contextMessage = `From ${selectedChannel?.name} chat`;
                  } else if (createdNode.nodeType === 'idea') {
                    contextMessage = `From ${selectedChannel?.name} discussion`;
                  } else if (createdNode.nodeType === 'reference') {
                    contextMessage = `From ${selectedChannel?.name} chat`;
                  } else if (createdNode.nodeType === 'note') {
                    contextMessage = `From ${selectedChannel?.name} chat`;
                  } else {
                    contextMessage = `From ${selectedChannel?.name} chat`;
                  }
                  
                  const nodeData = {
                    nodeId: createdNode.id,
                    title: createdNode.title,
                    type: createdNode.nodeType,
                    createdAt: new Date().toISOString(),
                    context: contextMessage,
                    dueDate: dueDate,
                    meetingDate: meetingDate,
                    tags: createdNode.tags
                  };
                  
                  // Append to the array for each selected message instead of replacing
                  setConvertedMessages(prev => {
                    const updated = { ...prev };
                    selectedMessages.forEach(messageId => {
                      if (!updated[messageId]) {
                        updated[messageId] = [];
                      }
                      updated[messageId] = [...updated[messageId], nodeData];
                    });
                    return updated;
                  });
                  
                  setSelectedMessages([]);

                  // Notify Discord that a node was created from this conversation
                  if (discordConfig?.connected && selectedMessages.length > 0) {
                    const firstMsgId = selectedMessages[0];
                    const srcMsg = (messages as any[])?.find((m: any) => m.id === firstMsgId);
                    if (srcMsg) {
                      notifyDiscordNodeMutation.mutate({
                        originalContent: srcMsg.content,
                        nodeType: createdNode.nodeType,
                        nodeTitle: createdNode.title,
                        senderName: srcMsg.discordUsername || srcMsg.sender?.displayName || 'NodeOS User',
                        nodeosChannelId: selectedChannel?.id ?? 1,
                      });
                    }
                  }
                  
                  toast({
                    title: `${createdNode.nodeType.charAt(0).toUpperCase() + createdNode.nodeType.slice(1)} created`,
                    description: "Your message has been converted to a node.",
                  });
                } else {
                  setSelectedMessages([]);
                }
              }}
              channelContext={selectedChannel && selectedSpace ? {
                channelId: selectedChannel.id,
                channelName: selectedChannel.name,
                spaceId: selectedSpace.id,
                spaceName: selectedSpace.name
              } : undefined}
            />

            {/* Discord Settings Dialog */}
            <Dialog open={showDiscordSettings} onOpenChange={setShowDiscordSettings}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Bot className="h-5 w-5 text-[#5865F2]" />
                    Discord Sync — #{selectedChannel?.name}
                  </DialogTitle>
                  <DialogDescription>
                    Link a Discord channel to this NodeOS channel for two-way message sync.
                  </DialogDescription>
                </DialogHeader>

                {/* Connection status */}
                <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm ${discordConfig?.connected ? 'bg-green-50 text-green-700 dark:bg-green-950/30 dark:text-green-400' : 'bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400'}`}>
                  {discordConfig?.connected ? (
                    <><Wifi className="h-4 w-4 flex-shrink-0" /><span>Bot online as <strong>{discordConfig.botTag}</strong></span></>
                  ) : (
                    <><WifiOff className="h-4 w-4 flex-shrink-0" /><span>Bot offline — check that DISCORD_BOT_TOKEN is set correctly</span></>
                  )}
                </div>

                {/* Current mapping for this channel */}
                {currentChannelDiscordId && (
                  <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-[#5865F2]/10 border border-[#5865F2]/20 text-sm">
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-[#5865F2]" />
                      <span className="text-[#5865F2] font-medium">Linked to Discord channel</span>
                      <code className="bg-[#5865F2]/10 px-1.5 py-0.5 rounded text-xs">{currentChannelDiscordId}</code>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-2 text-xs text-destructive hover:text-destructive"
                      onClick={() => selectedChannel && removeDiscordChannelMutation.mutate(selectedChannel.id)}
                    >
                      Unlink
                    </Button>
                  </div>
                )}

                <div className="space-y-4">

                  {/* Bot invite step — collapsed if bot is already connected */}
                  {!discordConfig?.connected && (
                    <div className="border rounded-lg p-3 space-y-2">
                      <p className="text-sm font-medium flex items-center gap-1.5">
                        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#5865F2] text-white text-[10px] font-bold flex-shrink-0">1</span>
                        Add the bot to your Discord server first
                      </p>
                      {discordConfig?.inviteUrl ? (
                        <a
                          href={discordConfig.inviteUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 w-full justify-center px-3 py-2 rounded-md text-sm font-medium bg-[#5865F2] hover:bg-[#4752c4] text-white transition-colors"
                        >
                          <Bot className="h-4 w-4" />
                          Invite NodeOS Bot to Server
                        </a>
                      ) : (
                        <p className="text-xs text-muted-foreground">Bot invite URL unavailable.</p>
                      )}
                    </div>
                  )}

                  {/* Bot invite link when connected (compact) */}
                  {discordConfig?.connected && discordConfig.guilds && discordConfig.guilds.length > 0 && (
                    <div className="rounded-md bg-green-50 dark:bg-green-950/30 px-3 py-2 text-xs text-green-700 dark:text-green-400">
                      <span className="font-medium">Bot in:</span>{" "}
                      {discordConfig.guilds.map(g => g.name).join(", ")}
                    </div>
                  )}

                  {/* Link this channel to a Discord channel */}
                  <div className="border rounded-lg p-3 space-y-2">
                    <p className="text-sm font-medium">
                      Link <strong>#{selectedChannel?.name}</strong> to a Discord channel
                    </p>
                    <p className="text-xs text-muted-foreground">
                      In Discord: User Settings → Advanced → enable <strong>Developer Mode</strong>, then right-click any channel → <strong>Copy Channel ID</strong>
                    </p>
                    <Input
                      id="discord-channel-id"
                      placeholder="Paste Discord channel ID, e.g. 1412951447473094748"
                      value={discordChannelInput}
                      onChange={e => setDiscordChannelInput(e.target.value)}
                    />

                    {/* Warn if this Discord channel ID is already used by another NodeOS channel */}
                    {(() => {
                      const trimmed = discordChannelInput.trim();
                      if (!trimmed) return null;
                      const existingMapping = discordConfig?.mappings?.find(
                        m => m.discordChannelId === trimmed && m.nodeosChannelId !== selectedChannel?.id
                      );
                      if (existingMapping) {
                        return (
                          <p className="text-xs text-amber-600 dark:text-amber-400 flex items-center gap-1">
                            ⚠ This Discord channel is currently linked to another NodeOS channel (ID {existingMapping.nodeosChannelId}). Saving will move the link here.
                          </p>
                        );
                      }
                      if (trimmed === currentChannelDiscordId) {
                        return (
                          <p className="text-xs text-green-600 dark:text-green-400 flex items-center gap-1">
                            <Check className="h-3 w-3" /> Already linked to this channel.
                          </p>
                        );
                      }
                      return null;
                    })()}
                  </div>

                  {/* All current mappings — so the user can see what's linked where */}
                  {discordConfig?.mappings && discordConfig.mappings.length > 0 && (
                    <div className="border rounded-lg p-3 space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">All linked channels</p>
                      {discordConfig.mappings.map(m => (
                        <div key={m.nodeosChannelId} className={`flex items-center justify-between text-xs rounded px-2 py-1 ${m.nodeosChannelId === selectedChannel?.id ? 'bg-[#5865F2]/10 border border-[#5865F2]/25' : 'bg-muted/50'}`}>
                          <span>
                            NodeOS channel <strong>{m.nodeosChannelId}</strong>
                            {m.nodeosChannelId === selectedChannel?.id && <span className="text-[#5865F2] ml-1">(this channel)</span>}
                          </span>
                          <code className="bg-background border px-1.5 py-0.5 rounded">{m.discordChannelId}</code>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="bg-muted/50 rounded-lg p-2.5 text-xs text-muted-foreground space-y-0.5">
                    <p>• Discord → NodeOS: messages from the linked Discord channel appear here in real-time</p>
                    <p>• NodeOS → Discord: hover any message and click the <Bot className="inline h-3 w-3" /> button to push it</p>
                    <p>• Each NodeOS channel links to its own Discord channel independently</p>
                  </div>

                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setShowDiscordSettings(false)}>
                      Cancel
                    </Button>
                    <Button
                      onClick={() => {
                        if (!selectedChannel) return;
                        saveDiscordChannelMutation.mutate({
                          nodeosChannelId: selectedChannel.id,
                          discordChannelId: discordChannelInput.trim(),
                        });
                      }}
                      disabled={!discordChannelInput.trim() || discordChannelInput.trim() === currentChannelDiscordId || saveDiscordChannelMutation.isPending}
                      className="bg-[#5865F2] hover:bg-[#4752c4] text-white"
                    >
                      {saveDiscordChannelMutation.isPending ? 'Saving…' : currentChannelDiscordId ? 'Update Link' : 'Link Channel'}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            {/* Create Space Dialog */}
            <Dialog open={showCreateSpaceDialog} onOpenChange={setShowCreateSpaceDialog}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Create New Space</DialogTitle>
                  <DialogDescription>
                    Create a new workspace for your team to collaborate.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Space Name</label>
                    <Input 
                      placeholder="e.g., Marketing Team, Project Alpha"
                      value={newSpaceName}
                      onChange={(e) => setNewSpaceName(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">Description (Optional)</label>
                    <Textarea 
                      placeholder="Brief description of what this space is for..."
                      value={newSpaceDescription}
                      onChange={(e) => setNewSpaceDescription(e.target.value)}
                      className="mt-1"
                      rows={3}
                    />
                  </div>
                  
                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={() => setShowCreateSpaceDialog(false)}>
                      Cancel
                    </Button>
                    <Button 
                      onClick={() => {
                        console.log('Create space button clicked');
                        console.log('Space name:', newSpaceName);
                        console.log('Space description:', newSpaceDescription);
                        
                        if (!newSpaceName.trim()) {
                          console.log('Space name is empty');
                          toast({
                            title: "Space name required",
                            description: "Please enter a name for the space.",
                            variant: "destructive",
                          });
                          return;
                        }
                        
                        console.log('Calling createSpaceMutation...');
                        createSpaceMutation.mutate({ 
                          name: newSpaceName, 
                          description: newSpaceDescription || `${newSpaceName} workspace` 
                        });
                      }}
                      disabled={!newSpaceName.trim() || createSpaceMutation.isPending}
                    >
                      {createSpaceMutation.isPending ? (
                        <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent" />
                      ) : null}
                      Create Space
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            {/* Create Channel Dialog */}
            <Dialog open={showCreateChannelDialog} onOpenChange={setShowCreateChannelDialog}>
              <DialogContent className="sm:max-w-lg max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Create New Channel</DialogTitle>
                  <DialogDescription>
                    Add a new channel to organize team conversations.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Channel Name</label>
                    <Input 
                      placeholder="e.g., general, announcements, random"
                      value={newChannelName}
                      onChange={(e) => setNewChannelName(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">Description (Optional)</label>
                    <Input 
                      placeholder="What's this channel about?"
                      value={newChannelDescription}
                      onChange={(e) => setNewChannelDescription(e.target.value)}
                      className="mt-1"
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="private-channel"
                      checked={isChannelPrivate}
                      onCheckedChange={(checked) => setIsChannelPrivate(checked as boolean)}
                    />
                    <Label htmlFor="private-channel" className="text-sm">
                      Make this channel private
                    </Label>
                  </div>

                  {isChannelPrivate && (
                    <div className="bg-accent/10 p-3 rounded-md">
                      <div className="text-sm font-medium mb-3">Add Members</div>
                      <div className="space-y-2 max-h-48 overflow-y-auto">
                        {Array.isArray(userData) ? userData.map((user: any) => (
                          <div key={user.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={`user-${user.id}`}
                              checked={selectedMembers.includes(user.id)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setSelectedMembers([...selectedMembers, user.id]);
                                } else {
                                  setSelectedMembers(selectedMembers.filter(id => id !== user.id));
                                }
                              }}
                            />
                            <Label 
                              htmlFor={`user-${user.id}`} 
                              className="text-sm cursor-pointer flex-1 flex items-center gap-2"
                            >
                              <Avatar className="h-6 w-6">
                                <AvatarImage src={user.avatar || undefined} alt={user.displayName} />
                                <AvatarFallback>{user.displayName?.charAt(0) || 'U'}</AvatarFallback>
                              </Avatar>
                              <span>{user.displayName}</span>
                            </Label>
                          </div>
                        )) : []}
                      </div>
                      {selectedMembers.length > 0 && (
                        <div className="mt-2 text-xs text-muted-foreground">
                          {selectedMembers.length} member{selectedMembers.length !== 1 ? 's' : ''} selected
                        </div>
                      )}
                    </div>
                  )}
                  
                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={() => setShowCreateChannelDialog(false)}>
                      Cancel
                    </Button>
                    <Button 
                      onClick={() => {
                        if (!newChannelName.trim()) {
                          toast({
                            title: "Channel name required",
                            description: "Please enter a name for the channel.",
                            variant: "destructive",
                          });
                          return;
                        }
                        createChannelMutation.mutate({
                          name: newChannelName,
                          description: newChannelDescription,
                          isPrivate: isChannelPrivate,
                          members: selectedMembers
                        });
                      }}
                      disabled={!newChannelName.trim() || createChannelMutation.isPending}
                    >
                      {createChannelMutation.isPending ? (
                        <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent" />
                      ) : null}
                      Create Channel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            {/* Rename Channel Dialog */}
            <Dialog open={showRenameChannelDialog} onOpenChange={setShowRenameChannelDialog}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Rename Channel</DialogTitle>
                  <DialogDescription>
                    Change the name of #{selectedChannel?.name}
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">New Channel Name</label>
                    <Input 
                      placeholder="Enter new channel name"
                      value={renameChannelValue}
                      onChange={(e) => setRenameChannelValue(e.target.value)}
                      className="mt-1"
                      data-testid="input-rename-channel"
                    />
                  </div>
                  
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setShowRenameChannelDialog(false)}>
                      Cancel
                    </Button>
                    <Button 
                      onClick={() => {
                        if (!renameChannelValue.trim()) {
                          toast({
                            title: "Channel name required",
                            description: "Please enter a new name for the channel.",
                            variant: "destructive",
                          });
                          return;
                        }
                        if (selectedChannel) {
                          renameChannelMutation.mutate({
                            channelId: selectedChannel.id,
                            name: renameChannelValue
                          });
                        }
                      }}
                      disabled={!renameChannelValue.trim() || renameChannelMutation.isPending}
                      data-testid="button-confirm-rename"
                    >
                      {renameChannelMutation.isPending ? (
                        <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent" />
                      ) : null}
                      Rename
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            {/* Delete Channel Confirmation Dialog */}
            <Dialog open={showDeleteChannelDialog} onOpenChange={setShowDeleteChannelDialog}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Delete Channel</DialogTitle>
                  <DialogDescription>
                    Are you sure you want to delete #{selectedChannel?.name}? This action cannot be undone.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="flex justify-end gap-2 pt-4">
                  <Button variant="outline" onClick={() => setShowDeleteChannelDialog(false)}>
                    Cancel
                  </Button>
                  <Button 
                    variant="destructive"
                    onClick={() => {
                      if (selectedChannel) {
                        deleteChannelMutation.mutate(selectedChannel.id);
                      }
                    }}
                    disabled={deleteChannelMutation.isPending}
                    data-testid="button-confirm-delete"
                  >
                    {deleteChannelMutation.isPending ? (
                      <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    ) : null}
                    Delete Channel
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center flex-col p-4">
            {/* Mobile menu toggle button */}
            {isMobile && !showSidebar && (
              <div className="absolute top-4 left-4">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-10 w-10" 
                  onClick={() => setShowSidebar(true)}
                >
                  <Menu className="h-5 w-5" />
                </Button>
              </div>
            )}
            <MessageSquare className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-medium mb-2">Welcome to Team Chat</h3>
            <p className="text-center text-muted-foreground max-w-md mb-4">
              {isMobile && !showSidebar 
                ? "Tap the menu button to see your channels or start a new conversation."
                : "Select a channel or direct message on the left to start chatting. All chats are connected to nodes for easy reference."
              }
            </p>
            <Button onClick={() => channels?.[0] && handleSelectChannel(channels[0])}>
              Join #general
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
