import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { LucideIcon, Users, Code, ShoppingCart, Network, Laptop, Headphones, Plus, Trash2, Edit, Eye, ChevronDown, BookOpen, BarChart, Settings, FileText, Inbox, Calendar, PieChart, UserCog, Layers, Database, Clock, CheckCircle, X } from 'lucide-react';

// Interface types
interface Interface {
  id: number;
  name: string;
  type: string;
  description: string | null;
  icon: string | null;
  config: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

interface User {
  id: number;
  username: string;
  displayName: string;
  email: string;
  avatar: string | null;
}

interface UserInterface {
  id: number;
  userId: number;
  interfaceId: number;
  assignedAt: string;
  assignedBy: number | null;
}

// Icon mapping for interface types
const getInterfaceIcon = (type: string): LucideIcon => {
  switch (type.toLowerCase()) {
    case 'marketing':
      return Users;
    case 'swe':
      return Code;
    case 'ecommerce':
      return ShoppingCart;
    case 'network':
      return Network;
    case 'it':
      return Laptop;
    case 'support':
      return Headphones;
    default:
      return Users;
  }
};

// Interface card component
const InterfaceCard = ({ 
  interface: interfaceItem, 
  onEdit, 
  onDelete, 
  onAssign,
  onPreview
}: { 
  interface: Interface; 
  onEdit: (id: number) => void; 
  onDelete: (id: number) => void;
  onAssign: (id: number) => void;
  onPreview: (id: number) => void;
}) => {
  const Icon = getInterfaceIcon(interfaceItem.type);
  
  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">{interfaceItem.name}</CardTitle>
          <Badge variant="outline">{interfaceItem.type}</Badge>
        </div>
        <CardDescription className="flex items-center gap-2">
          <Icon className="h-4 w-4" />
          <span>{interfaceItem.type.charAt(0).toUpperCase() + interfaceItem.type.slice(1)} Interface</span>
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-sm text-muted-foreground">
          {interfaceItem.description || 'No description provided.'}
        </p>
      </CardContent>
      <CardFooter className="flex flex-col space-y-3 w-full">
        <Button 
          variant="default" 
          size="sm" 
          className="w-full"
          onClick={() => onPreview(interfaceItem.id)}
        >
          <Eye className="h-4 w-4 mr-1" />
          Preview Interface
        </Button>
        <div className="flex justify-between w-full">
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => onEdit(interfaceItem.id)}
            >
              <Edit className="h-4 w-4 mr-1" />
              Edit
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="text-destructive hover:text-destructive"
              onClick={() => onDelete(interfaceItem.id)}
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Delete
            </Button>
          </div>
          <Button 
            size="sm"
            onClick={() => onAssign(interfaceItem.id)}
          >
            <Users className="h-4 w-4 mr-1" />
            Assign
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

// New Interface form
const NewInterfaceForm = ({ 
  onSubmit, 
  onCancel, 
  initialData = null 
}: { 
  onSubmit: (data: any) => void; 
  onCancel: () => void;
  initialData?: Interface | null;
}) => {
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    type: initialData?.type || '',
    description: initialData?.description || '',
    icon: initialData?.icon || '',
    config: initialData?.config || {}
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleTypeChange = (value: string) => {
    setFormData(prev => ({ ...prev, type: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Name</Label>
        <Input 
          id="name" 
          name="name" 
          value={formData.name} 
          onChange={handleChange} 
          required 
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="type">Type</Label>
        <Select 
          value={formData.type} 
          onValueChange={handleTypeChange}
          required
        >
          <SelectTrigger>
            <SelectValue placeholder="Select interface type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="marketing">Marketing</SelectItem>
            <SelectItem value="swe">Software Engineering</SelectItem>
            <SelectItem value="ecommerce">E-commerce</SelectItem>
            <SelectItem value="network">Network</SelectItem>
            <SelectItem value="it">IT</SelectItem>
            <SelectItem value="support">Support Ticket Handler</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea 
          id="description" 
          name="description" 
          value={formData.description} 
          onChange={handleChange} 
          rows={3}
        />
      </div>
      
      <div className="flex justify-end space-x-2 pt-4">
        <Button variant="outline" type="button" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {initialData ? 'Update Interface' : 'Create Interface'}
        </Button>
      </div>
    </form>
  );
};

// Assign Interface Dialog
const AssignInterfaceDialog = ({ 
  open, 
  onClose, 
  interfaceId, 
  onAssign 
}: { 
  open: boolean; 
  onClose: () => void; 
  interfaceId: number | null;
  onAssign: (userId: number, interfaceId: number) => void;
}) => {
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  
  const { data: users = [], isLoading: isLoadingUsers } = useQuery({
    queryKey: ['/api/users'],
    enabled: open,
  });
  
  const { data: interfaceItem } = useQuery({
    queryKey: ['/api/interfaces', interfaceId],
    enabled: !!interfaceId,
  });
  
  const handleAssign = () => {
    if (selectedUserId && interfaceId) {
      onAssign(parseInt(selectedUserId), interfaceId);
      onClose();
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Assign Interface to User</DialogTitle>
          <DialogDescription>
            Select a user to assign the {interfaceItem?.name} interface to.
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <Label htmlFor="user-select">Select User</Label>
          <Select 
            value={selectedUserId}
            onValueChange={setSelectedUserId}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select a user" />
            </SelectTrigger>
            <SelectContent>
              {isLoadingUsers ? (
                <SelectItem value="loading" disabled>Loading users...</SelectItem>
              ) : (
                users.map((user: User) => (
                  <SelectItem key={user.id} value={user.id.toString()}>
                    {user.displayName} ({user.username})
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleAssign} disabled={!selectedUserId}>
            Assign Interface
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

// Interface Preview Modal
const InterfacePreviewModal = ({
  open,
  onClose,
  interfaceId
}: {
  open: boolean;
  onClose: () => void;
  interfaceId: number | null;
}) => {
  const { data: interfaceItem, isLoading } = useQuery({
    queryKey: ['/api/interfaces', interfaceId],
    enabled: !!interfaceId && open,
  });
  
  if (!open) return null;
  
  // Rendering the appropriate preview based on interface type
  const renderPreviewContent = () => {
    if (isLoading) {
      return (
        <div className="flex justify-center p-8">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      );
    }
    
    if (!interfaceItem) {
      return (
        <div className="p-6 text-center">
          <p className="text-muted-foreground">Interface not found or failed to load.</p>
        </div>
      );
    }
    
    // Render different UI based on interface type
    switch (interfaceItem.type) {
      case 'marketing':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Performance</CardTitle>
                <CardDescription>Metrics for active marketing campaigns</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-md">
                    <div className="flex items-center justify-between mb-4">
                      <div className="font-medium">Summer Product Launch</div>
                      <Badge variant="secondary">Active</Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <div className="text-muted-foreground">Impressions</div>
                        <div className="font-medium text-lg">124.5K</div>
                        <div className="text-green-500 text-xs">↑ 12.5%</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Click Rate</div>
                        <div className="font-medium text-lg">3.2%</div>
                        <div className="text-green-500 text-xs">↑ 0.8%</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Conversion</div>
                        <div className="font-medium text-lg">1.8%</div>
                        <div className="text-red-500 text-xs">↓ 0.3%</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Revenue</div>
                        <div className="font-medium text-lg">$12,450</div>
                        <div className="text-green-500 text-xs">↑ 18.2%</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Audience Demographics</CardTitle>
                <CardDescription>Breakdown of customer segments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-60 bg-muted/40 rounded-md flex items-center justify-center">
                  <PieChart className="h-8 w-8 text-muted-foreground" />
                </div>
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                    <div className="text-sm">18-24 (24%)</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <div className="text-sm">25-34 (38%)</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <div className="text-sm">35-44 (22%)</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                    <div className="text-sm">45+ (16%)</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'developer':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Code Repositories</CardTitle>
                <CardDescription>Recent activity across repositories</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center p-2 bg-muted/40 rounded-md">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <div className="text-sm">node-os-api</div>
                  </div>
                  <div className="flex items-center p-2 bg-muted/40 rounded-md">
                    <div className="w-2 h-2 bg-yellow-500 rounded-full mr-2"></div>
                    <div className="text-sm">frontend-dashboard</div>
                  </div>
                  <div className="flex items-center p-2 bg-muted/40 rounded-md">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
                    <div className="text-sm">data-processor</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Build Status</CardTitle>
                <CardDescription>Latest CI/CD pipeline status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center p-2 bg-green-100 dark:bg-green-900/20 rounded-md">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <div className="text-sm flex-grow">main (Node OS API)</div>
                    <Badge variant="outline" className="text-green-600 dark:text-green-400">Passing</Badge>
                  </div>
                  <div className="flex items-center p-2 bg-green-100 dark:bg-green-900/20 rounded-md">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <div className="text-sm flex-grow">develop (Frontend)</div>
                    <Badge variant="outline" className="text-green-600 dark:text-green-400">Passing</Badge>
                  </div>
                  <div className="flex items-center p-2 bg-red-100 dark:bg-red-900/20 rounded-md">
                    <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
                    <div className="text-sm flex-grow">feature/graph-engine</div>
                    <Badge variant="outline" className="text-red-600 dark:text-red-400">Failed</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );
        
      case 'ecommerce':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Sales Overview</CardTitle>
                <CardDescription>Today's sales performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 border rounded-md">
                    <div className="text-muted-foreground text-sm">Revenue</div>
                    <div className="text-2xl font-bold">$8,431</div>
                    <div className="text-green-500 text-xs">↑ 12% vs yesterday</div>
                  </div>
                  <div className="p-4 border rounded-md">
                    <div className="text-muted-foreground text-sm">Orders</div>
                    <div className="text-2xl font-bold">94</div>
                    <div className="text-green-500 text-xs">↑ 8% vs yesterday</div>
                  </div>
                  <div className="p-4 border rounded-md">
                    <div className="text-muted-foreground text-sm">Conversion</div>
                    <div className="text-2xl font-bold">3.2%</div>
                    <div className="text-red-500 text-xs">↓ 0.5% vs yesterday</div>
                  </div>
                  <div className="p-4 border rounded-md">
                    <div className="text-muted-foreground text-sm">Avg. Order</div>
                    <div className="text-2xl font-bold">$89.69</div>
                    <div className="text-green-500 text-xs">↑ 4% vs yesterday</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Inventory Status</CardTitle>
                <CardDescription>Product stock levels</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-2 border-b">
                    <div className="font-medium">Premium Headphones</div>
                    <Badge variant="outline" className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">In Stock (24)</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 border-b">
                    <div className="font-medium">Wireless Keyboard</div>
                    <Badge variant="outline" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400">Low Stock (3)</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 border-b">
                    <div className="font-medium">Ultra HD Monitor</div>
                    <Badge variant="outline" className="bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400">Out of Stock</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 border-b">
                    <div className="font-medium">Ergonomic Mouse</div>
                    <Badge variant="outline" className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">In Stock (47)</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'network':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Network Status</CardTitle>
                <CardDescription>Current service health</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-2 border-b">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                      <div>Primary Gateway</div>
                    </div>
                    <div className="text-sm text-muted-foreground">Latency: 4ms</div>
                  </div>
                  <div className="flex items-center justify-between p-2 border-b">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                      <div>Database Cluster</div>
                    </div>
                    <div className="text-sm text-muted-foreground">Load: 28%</div>
                  </div>
                  <div className="flex items-center justify-between p-2 border-b">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full mr-2"></div>
                      <div>CDN Edge Nodes</div>
                    </div>
                    <div className="text-sm text-muted-foreground">Cache: 92%</div>
                  </div>
                  <div className="flex items-center justify-between p-2 border-b">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
                      <div>Backup Server</div>
                    </div>
                    <div className="text-sm text-muted-foreground">Offline</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Traffic Overview</CardTitle>
                <CardDescription>Bandwidth consumption by service</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-60 bg-muted/40 rounded-md flex items-center justify-center">
                  <BarChart className="h-8 w-8 text-muted-foreground" />
                </div>
                <div className="space-y-2 mt-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                      <div className="text-sm">Web Traffic</div>
                    </div>
                    <div className="text-sm">345 Mbps</div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                      <div className="text-sm">API Services</div>
                    </div>
                    <div className="text-sm">128 Mbps</div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                      <div className="text-sm">Database</div>
                    </div>
                    <div className="text-sm">87 Mbps</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'support':
        return (
          <div className="grid grid-cols-1 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Support Tickets</CardTitle>
                <CardDescription>
                  Manage and respond to customer support requests
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="open">
                  <TabsList className="mb-4">
                    <TabsTrigger value="open">Open Tickets</TabsTrigger>
                    <TabsTrigger value="assigned">Assigned to Me</TabsTrigger>
                    <TabsTrigger value="all">All Tickets</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="open">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Ticket ID</TableHead>
                          <TableHead>Customer</TableHead>
                          <TableHead>Subject</TableHead>
                          <TableHead>Priority</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Created</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">#T-5942</TableCell>
                          <TableCell>Sarah Johnson</TableCell>
                          <TableCell>Unable to access account</TableCell>
                          <TableCell>
                            <Badge className="bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400">High</Badge>
                          </TableCell>
                          <TableCell><Badge>New</Badge></TableCell>
                          <TableCell>10 min ago</TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">Assign</Button>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">#T-5941</TableCell>
                          <TableCell>Michael Chen</TableCell>
                          <TableCell>Payment failed on checkout</TableCell>
                          <TableCell>
                            <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400">Medium</Badge>
                          </TableCell>
                          <TableCell><Badge>New</Badge></TableCell>
                          <TableCell>25 min ago</TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">Assign</Button>
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'it':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>System Status</CardTitle>
                <CardDescription>Server health monitoring</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-2 border-b">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                      <div>Production Server</div>
                    </div>
                    <div className="text-sm">
                      <Badge variant="outline" className="text-green-600 dark:text-green-400">Online</Badge>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-2 border-b">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                      <div>Staging Environment</div>
                    </div>
                    <div className="text-sm">
                      <Badge variant="outline" className="text-green-600 dark:text-green-400">Online</Badge>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-2 border-b">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full mr-2"></div>
                      <div>Database Server</div>
                    </div>
                    <div className="text-sm">
                      <Badge variant="outline" className="text-yellow-600 dark:text-yellow-400">Maintenance</Badge>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-2 border-b">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
                      <div>Backup System</div>
                    </div>
                    <div className="text-sm">
                      <Badge variant="outline" className="text-red-600 dark:text-red-400">Alert</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Resource Usage</CardTitle>
                <CardDescription>Server resource monitoring</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <div className="text-sm font-medium">CPU</div>
                      <div className="text-sm text-muted-foreground">68%</div>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: '68%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <div className="text-sm font-medium">Memory</div>
                      <div className="text-sm text-muted-foreground">42%</div>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 rounded-full" style={{ width: '42%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <div className="text-sm font-medium">Disk</div>
                      <div className="text-sm text-muted-foreground">87%</div>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-red-500 rounded-full" style={{ width: '87%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <div className="text-sm font-medium">Network</div>
                      <div className="text-sm text-muted-foreground">35%</div>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 rounded-full" style={{ width: '35%' }}></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      
      default:
        return (
          <div className="p-6 text-center">
            <p className="text-muted-foreground">No preview available for this interface type.</p>
          </div>
        );
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={() => onClose()}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {isLoading ? "Loading..." : interfaceItem ? 
              `${interfaceItem.name} Interface Preview` : 
              "Interface Preview"}
          </DialogTitle>
          <DialogDescription>
            {isLoading ? 
              "Loading interface details..." : 
              interfaceItem ? 
                `View how the ${interfaceItem.type} interface appears to users` :
                "Interface details not found"}
          </DialogDescription>
        </DialogHeader>
        
        {renderPreviewContent()}
        
        <DialogFooter className="mt-6">
          <Button onClick={onClose}>Close Preview</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );

  // This function is no longer needed as we've implemented renderPreviewContent above
  /* const renderInterfacePreview = () => {
    switch (interfaceItem?.type) {
      case 'marketing':
        return <MarketingInterfacePreview />;
      case 'swe':
        return <DeveloperInterfacePreview />;
      case 'ecommerce':
        return <EcommerceInterfacePreview />;
      case 'network':
        return <NetworkInterfacePreview />;
      case 'it':
        return <ITInterfacePreview />;
      case 'support':
        return <SupportInterfacePreview />;
      default:
        return <div className="text-center p-8">No preview available for this interface type.</div>;
    }
  };

  const Icon = getInterfaceIcon(interfaceItem.type);

  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-5xl w-full h-[85vh] max-h-[800px] p-0 overflow-hidden">
        <div className="h-full flex flex-col">
          <DialogHeader className="px-6 pt-6 pb-2 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Icon className="h-5 w-5" />
                <DialogTitle>{interfaceItem.name}</DialogTitle>
              </div>
              <Badge variant="outline">{interfaceItem.type.charAt(0).toUpperCase() + interfaceItem.type.slice(1)}</Badge>
            </div>
            <DialogDescription className="mt-1">
              {interfaceItem.description}
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="flex-grow">
            <div className="p-6">
              {renderInterfacePreview()}
            </div>
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
};

// Marketing Interface Preview
const MarketingInterfacePreview = () => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <BarChart className="h-4 w-4 mr-2" />
              Campaign Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-36 bg-muted/40 rounded-md flex items-center justify-center">
              <div className="space-y-2">
                <div className="h-4 w-32 bg-primary/20 rounded-full mx-auto"></div>
                <div className="h-4 w-24 bg-primary/30 rounded-full mx-auto"></div>
                <div className="h-4 w-40 bg-primary/40 rounded-full mx-auto"></div>
                <div className="h-4 w-20 bg-primary/50 rounded-full mx-auto"></div>
              </div>
            </div>
            <div className="flex justify-between items-center mt-4 text-sm text-muted-foreground">
              <div>Impressions: 45.2K</div>
              <div>Conversions: 1.8K</div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <PieChart className="h-4 w-4 mr-2" />
              Audience Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-36 bg-muted/40 rounded-md flex items-center justify-center">
              <div className="flex space-x-3">
                <div className="h-24 w-24 rounded-full border-8 border-primary/60"></div>
                <div className="space-y-2">
                  <div className="h-4 w-20 bg-primary/20 rounded-full"></div>
                  <div className="h-4 w-24 bg-primary/30 rounded-full"></div>
                  <div className="h-4 w-16 bg-primary/40 rounded-full"></div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-4 text-sm text-muted-foreground">
              <div>Female: 58%</div>
              <div>Male: 42%</div>
              <div>Age 18-34: 65%</div>
              <div>Mobile: 72%</div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Calendar className="h-4 w-4 mr-2" />
              Content Calendar
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center p-2 bg-muted/40 rounded-md">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                <div className="text-sm">Product Launch - May 25</div>
              </div>
              <div className="flex items-center p-2 bg-muted/40 rounded-md">
                <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
                <div className="text-sm">Social Campaign - May 27</div>
              </div>
              <div className="flex items-center p-2 bg-muted/40 rounded-md">
                <div className="w-2 h-2 bg-purple-500 rounded-full mr-2"></div>
                <div className="text-sm">Email Newsletter - May 30</div>
              </div>
              <div className="flex items-center p-2 bg-muted/40 rounded-md">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mr-2"></div>
                <div className="text-sm">Webinar - June 2</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart className="h-5 w-5 mr-2" />
            Marketing Campaign Analytics
          </CardTitle>
          <CardDescription>Track performance metrics across all running campaigns</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 border rounded-md">
              <div className="flex items-center justify-between mb-4">
                <div className="font-medium">Summer Product Launch</div>
                <Badge variant="secondary">Active</Badge>
              </div>
              <div className="grid grid-cols-4 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Impressions</div>
                  <div className="font-medium text-lg">124.5K</div>
                  <div className="text-green-500 text-xs">↑ 12.5%</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Click Rate</div>
                  <div className="font-medium text-lg">3.2%</div>
                  <div className="text-green-500 text-xs">↑ 0.8%</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Conversion</div>
                  <div className="font-medium text-lg">1.8%</div>
                  <div className="text-red-500 text-xs">↓ 0.3%</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Revenue</div>
                  <div className="font-medium text-lg">$12,450</div>
                  <div className="text-green-500 text-xs">↑ 18.2%</div>
                </div>
              </div>
              <div className="mt-4 h-12 bg-muted/40 rounded-md"></div>
            </div>

            <div className="p-4 border rounded-md">
              <div className="flex items-center justify-between mb-4">
                <div className="font-medium">Email Retention Campaign</div>
                <Badge variant="secondary">Active</Badge>
              </div>
              <div className="grid grid-cols-4 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Open Rate</div>
                  <div className="font-medium text-lg">28.4%</div>
                  <div className="text-green-500 text-xs">↑ 3.2%</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Click Rate</div>
                  <div className="font-medium text-lg">4.5%</div>
                  <div className="text-green-500 text-xs">↑ 1.2%</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Unsubscribe</div>
                  <div className="font-medium text-lg">0.8%</div>
                  <div className="text-green-500 text-xs">↓ 0.3%</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Revenue</div>
                  <div className="font-medium text-lg">$8,320</div>
                  <div className="text-green-500 text-xs">↑ 7.5%</div>
                </div>
              </div>
              <div className="mt-4 h-12 bg-muted/40 rounded-md"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Developer Interface Preview
const DeveloperInterfacePreview = () => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Code className="h-4 w-4 mr-2" />
              Code Repositories
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center p-2 bg-muted/40 rounded-md">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                <div className="text-sm">node-os-api</div>
              </div>
              <div className="flex items-center p-2 bg-muted/40 rounded-md">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mr-2"></div>
                <div className="text-sm">frontend-dashboard</div>
              </div>
              <div className="flex items-center p-2 bg-muted/40 rounded-md">
                <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
                <div className="text-sm">data-processor</div>
              </div>
              <div className="flex items-center p-2 bg-muted/40 rounded-md">
                <div className="w-2 h-2 bg-purple-500 rounded-full mr-2"></div>
                <div className="text-sm">analytics-module</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Layers className="h-4 w-4 mr-2" />
              Current Sprint
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="text-sm font-medium">Sprint 24 - Node Graph Enhancement</div>
              <div className="flex justify-between text-xs text-muted-foreground">
                <div>Days Remaining: 8</div>
                <div>Progress: 65%</div>
              </div>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-primary rounded-full" style={{ width: '65%' }}></div>
              </div>
              <div className="mt-3 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div>Tasks Completed:</div>
                  <div>15/23</div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div>Bugs Fixed:</div>
                  <div>7/12</div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div>Story Points:</div>
                  <div>34/52</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Settings className="h-4 w-4 mr-2" />
              Build Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center p-2 bg-green-100 dark:bg-green-900/20 rounded-md">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                <div className="text-sm flex-grow">main (Node OS API)</div>
                <Badge variant="outline" className="text-green-600 dark:text-green-400">Passing</Badge>
              </div>
              <div className="flex items-center p-2 bg-green-100 dark:bg-green-900/20 rounded-md">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                <div className="text-sm flex-grow">main (Frontend)</div>
                <Badge variant="outline" className="text-green-600 dark:text-green-400">Passing</Badge>
              </div>
              <div className="flex items-center p-2 bg-red-100 dark:bg-red-900/20 rounded-md">
                <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
                <div className="text-sm flex-grow">feature/graph-links</div>
                <Badge variant="outline" className="text-red-600 dark:text-red-400">Failing</Badge>
              </div>
              <div className="flex items-center p-2 bg-green-100 dark:bg-green-900/20 rounded-md">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                <div className="text-sm flex-grow">feature/auth</div>
                <Badge variant="outline" className="text-green-600 dark:text-green-400">Passing</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Database className="h-5 w-5 mr-2" />
              Node Query Explorer
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="border rounded-md p-3 bg-muted/30 font-mono text-sm overflow-hidden">
              <div className="text-blue-600 dark:text-blue-400">// Find all nodes connected to current node</div>
              <div className="text-green-600 dark:text-green-400">const getConnectedNodes = async (nodeId) =&gt; {"{"}</div>
              <div className="ml-4">const links = await db.nodeLinks.findMany({"{"}</div>
              <div className="ml-8">where: {"{"} sourceId: nodeId {"}"}</div>
              <div className="ml-4">{"}"});</div>
              <div className="ml-4">return Promise.all(</div>
              <div className="ml-8">links.map(link =&gt; db.nodes.findOne(link.targetId))</div>
              <div className="ml-4">);</div>
              <div className="text-green-600 dark:text-green-400">{"}"}</div>
            </div>
            <div className="mt-4">
              <div className="text-sm font-medium mb-2">Node Relationships</div>
              <div className="h-48 bg-muted/40 rounded-md flex items-center justify-center">
                <div className="relative">
                  <div className="h-12 w-12 rounded-full bg-primary/20 absolute" style={{top: '0px', left: '60px'}}></div>
                  <div className="h-12 w-12 rounded-full bg-primary/40 absolute" style={{top: '40px', left: '20px'}}></div>
                  <div className="h-12 w-12 rounded-full bg-primary/60 absolute" style={{top: '40px', left: '100px'}}></div>
                  <div className="h-12 w-12 rounded-full bg-primary/80 absolute" style={{top: '80px', left: '60px'}}></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Inbox className="h-5 w-5 mr-2" />
              Pull Requests
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-3 border rounded-md">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Fix graph visualization bug</div>
                  <Badge>Review Needed</Badge>
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  PR #145 by Alex Chen • Updated 2h ago
                </div>
                <div className="flex items-center mt-2 space-x-2">
                  <div className="h-6 w-6 rounded-full bg-purple-500/20"></div>
                  <div className="h-6 w-6 rounded-full bg-blue-500/20"></div>
                </div>
              </div>
              
              <div className="p-3 border rounded-md">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Implement role-based interfaces</div>
                  <Badge variant="outline">Changes Requested</Badge>
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  PR #142 by Jamie Wong • Updated 5h ago
                </div>
                <div className="flex items-center mt-2 space-x-2">
                  <div className="h-6 w-6 rounded-full bg-green-500/20"></div>
                  <div className="h-6 w-6 rounded-full bg-yellow-500/20"></div>
                </div>
              </div>
              
              <div className="p-3 border rounded-md">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Add database migration tool</div>
                  <Badge variant="secondary">Approved</Badge>
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  PR #139 by Sarah Johnson • Updated 1d ago
                </div>
                <div className="flex items-center mt-2 space-x-2">
                  <div className="h-6 w-6 rounded-full bg-blue-500/20"></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// E-commerce Interface Preview
const EcommerceInterfacePreview = () => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <ShoppingCart className="h-4 w-4 mr-2" />
              Orders Today
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">42</div>
            <div className="flex items-center text-sm mt-1">
              <span className="text-green-500 mr-1">↑ 12%</span>
              <span className="text-muted-foreground">from yesterday</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Users className="h-4 w-4 mr-2" />
              New Customers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">18</div>
            <div className="flex items-center text-sm mt-1">
              <span className="text-green-500 mr-1">↑ 5%</span>
              <span className="text-muted-foreground">from yesterday</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <PieChart className="h-4 w-4 mr-2" />
              Revenue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">$2,845</div>
            <div className="flex items-center text-sm mt-1">
              <span className="text-green-500 mr-1">↑ 8%</span>
              <span className="text-muted-foreground">from yesterday</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <BarChart className="h-4 w-4 mr-2" />
              Avg. Order Value
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">$67.50</div>
            <div className="flex items-center text-sm mt-1">
              <span className="text-red-500 mr-1">↓ 3%</span>
              <span className="text-muted-foreground">from yesterday</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Recent Orders</CardTitle>
          <CardDescription>
            View and manage the most recent customer orders
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order ID</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Products</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">#ORD-5492</TableCell>
                <TableCell>Sarah Johnson</TableCell>
                <TableCell>3 items</TableCell>
                <TableCell>$128.50</TableCell>
                <TableCell><Badge>Processing</Badge></TableCell>
                <TableCell>May 22, 2025</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">View</Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">#ORD-5491</TableCell>
                <TableCell>Michael Chen</TableCell>
                <TableCell>1 item</TableCell>
                <TableCell>$79.99</TableCell>
                <TableCell><Badge variant="outline">Shipped</Badge></TableCell>
                <TableCell>May 22, 2025</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">View</Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">#ORD-5490</TableCell>
                <TableCell>Alex Rodriguez</TableCell>
                <TableCell>2 items</TableCell>
                <TableCell>$56.75</TableCell>
                <TableCell><Badge variant="secondary">Delivered</Badge></TableCell>
                <TableCell>May 21, 2025</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">View</Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">#ORD-5489</TableCell>
                <TableCell>Emma Wilson</TableCell>
                <TableCell>5 items</TableCell>
                <TableCell>$215.30</TableCell>
                <TableCell><Badge variant="outline">Shipped</Badge></TableCell>
                <TableCell>May 21, 2025</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">View</Button>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Inventory Alerts</CardTitle>
            <CardDescription>Products that need attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="p-3 bg-red-100 dark:bg-red-900/20 rounded-md flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
                  <div>
                    <div className="font-medium">Wireless Headphones</div>
                    <div className="text-sm text-muted-foreground">Out of stock</div>
                  </div>
                </div>
                <Button size="sm">Restock</Button>
              </div>
              
              <div className="p-3 bg-yellow-100 dark:bg-yellow-900/20 rounded-md flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full mr-2"></div>
                  <div>
                    <div className="font-medium">Smart Watch</div>
                    <div className="text-sm text-muted-foreground">Low stock (3 left)</div>
                  </div>
                </div>
                <Button size="sm">Restock</Button>
              </div>
              
              <div className="p-3 bg-yellow-100 dark:bg-yellow-900/20 rounded-md flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full mr-2"></div>
                  <div>
                    <div className="font-medium">Bluetooth Speaker</div>
                    <div className="text-sm text-muted-foreground">Low stock (5 left)</div>
                  </div>
                </div>
                <Button size="sm">Restock</Button>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Popular Products</CardTitle>
            <CardDescription>Best selling items this week</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-2 border-b">
                <div className="flex items-center">
                  <div className="h-10 w-10 bg-muted rounded-md mr-3"></div>
                  <div>
                    <div className="font-medium">Wireless Earbuds Pro</div>
                    <div className="text-sm text-muted-foreground">$129.99</div>
                  </div>
                </div>
                <div className="text-sm">82 sold</div>
              </div>
              
              <div className="flex items-center justify-between p-2 border-b">
                <div className="flex items-center">
                  <div className="h-10 w-10 bg-muted rounded-md mr-3"></div>
                  <div>
                    <div className="font-medium">Smart Home Hub</div>
                    <div className="text-sm text-muted-foreground">$89.95</div>
                  </div>
                </div>
                <div className="text-sm">65 sold</div>
              </div>
              
              <div className="flex items-center justify-between p-2 border-b">
                <div className="flex items-center">
                  <div className="h-10 w-10 bg-muted rounded-md mr-3"></div>
                  <div>
                    <div className="font-medium">Ultra HD Action Camera</div>
                    <div className="text-sm text-muted-foreground">$249.99</div>
                  </div>
                </div>
                <div className="text-sm">41 sold</div>
              </div>
              
              <div className="flex items-center justify-between p-2">
                <div className="flex items-center">
                  <div className="h-10 w-10 bg-muted rounded-md mr-3"></div>
                  <div>
                    <div className="font-medium">Fitness Tracker</div>
                    <div className="text-sm text-muted-foreground">$79.50</div>
                  </div>
                </div>
                <div className="text-sm">38 sold</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// Network Interface Preview
const NetworkInterfacePreview = () => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Network className="h-4 w-4 mr-2" />
              Network Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="text-sm">Uptime</div>
                <div className="font-medium">99.98%</div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm">Bandwidth Usage</div>
                <div className="font-medium">76.4 GB / 100 GB</div>
              </div>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-primary rounded-full" style={{ width: '76.4%' }}></div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm">Active Connections</div>
                <div className="font-medium">534</div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm">Response Time</div>
                <div className="font-medium">28ms</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Laptop className="h-4 w-4 mr-2" />
              Devices
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center p-2 bg-green-100 dark:bg-green-900/20 rounded-md justify-between">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                  <div className="text-sm">Router 1 (main)</div>
                </div>
                <Badge variant="outline" className="text-green-600 dark:text-green-400">Online</Badge>
              </div>
              <div className="flex items-center p-2 bg-green-100 dark:bg-green-900/20 rounded-md justify-between">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                  <div className="text-sm">Switch 1 (floor 1)</div>
                </div>
                <Badge variant="outline" className="text-green-600 dark:text-green-400">Online</Badge>
              </div>
              <div className="flex items-center p-2 bg-red-100 dark:bg-red-900/20 rounded-md justify-between">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
                  <div className="text-sm">Access Point 3</div>
                </div>
                <Badge variant="outline" className="text-red-600 dark:text-red-400">Offline</Badge>
              </div>
              <div className="flex items-center p-2 bg-green-100 dark:bg-green-900/20 rounded-md justify-between">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                  <div className="text-sm">Firewall</div>
                </div>
                <Badge variant="outline" className="text-green-600 dark:text-green-400">Online</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <FileText className="h-4 w-4 mr-2" />
              Recent Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="p-2 bg-red-100 dark:bg-red-900/20 rounded-md">
                <div className="text-sm font-medium">High CPU Usage</div>
                <div className="text-xs text-muted-foreground">Server-01 • 15 min ago</div>
              </div>
              <div className="p-2 bg-yellow-100 dark:bg-yellow-900/20 rounded-md">
                <div className="text-sm font-medium">Unusual Traffic Pattern</div>
                <div className="text-xs text-muted-foreground">10.0.1.45 • 32 min ago</div>
              </div>
              <div className="p-2 bg-red-100 dark:bg-red-900/20 rounded-md">
                <div className="text-sm font-medium">Device Disconnected</div>
                <div className="text-xs text-muted-foreground">Access Point 3 • 54 min ago</div>
              </div>
              <div className="p-2 bg-green-100 dark:bg-green-900/20 rounded-md">
                <div className="text-sm font-medium">Firmware Update Available</div>
                <div className="text-xs text-muted-foreground">Switch 1 • 2h ago</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Network className="h-5 w-5 mr-2" />
            Network Traffic
          </CardTitle>
          <CardDescription>
            Real-time traffic monitoring across all interfaces
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64 bg-muted/40 rounded-md">
            <div className="h-full w-full p-4 flex items-end gap-1">
              {Array.from({ length: 24 }).map((_, i) => (
                <div 
                  key={i} 
                  className="bg-primary/60 rounded-t w-full" 
                  style={{ 
                    height: `${15 + Math.random() * 70}%`,
                  }}
                ></div>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 mt-6">
            <div>
              <div className="text-sm font-medium mb-2">Top Talkers (IPs)</div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div>10.0.1.45</div>
                  <div>28.4 GB</div>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: '78%' }}></div>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <div>10.0.1.18</div>
                  <div>15.2 GB</div>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: '42%' }}></div>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <div>10.0.1.23</div>
                  <div>8.7 GB</div>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: '24%' }}></div>
                </div>
              </div>
            </div>
            
            <div>
              <div className="text-sm font-medium mb-2">Top Applications</div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div>Web (HTTPS)</div>
                  <div>32.8 GB</div>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: '86%' }}></div>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <div>Database</div>
                  <div>18.5 GB</div>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: '48%' }}></div>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <div>File Transfer</div>
                  <div>12.3 GB</div>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: '32%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// IT Interface Preview
const ITInterfacePreview = () => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Laptop className="h-4 w-4 mr-2" />
              System Health
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <div className="text-sm">CPU Usage</div>
                  <div className="text-sm font-medium">42%</div>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: '42%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-1">
                  <div className="text-sm">Memory Usage</div>
                  <div className="text-sm font-medium">68%</div>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-yellow-500 rounded-full" style={{ width: '68%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-1">
                  <div className="text-sm">Disk Usage</div>
                  <div className="text-sm font-medium">85%</div>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-red-500 rounded-full" style={{ width: '85%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-1">
                  <div className="text-sm">Network</div>
                  <div className="text-sm font-medium">28%</div>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: '28%' }}></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <UserCog className="h-4 w-4 mr-2" />
              Active Directory
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="text-sm font-medium">User Management</div>
              <div className="grid grid-cols-2 gap-y-1 text-sm mt-2">
                <div>Total Users:</div>
                <div className="font-medium">245</div>
                <div>Active Users:</div>
                <div className="font-medium">212</div>
                <div>Locked Accounts:</div>
                <div className="font-medium">3</div>
                <div>Groups:</div>
                <div className="font-medium">18</div>
              </div>
              <div className="flex justify-between mt-3">
                <Button size="sm" variant="outline">
                  <Plus className="h-3 w-3 mr-1" />
                  Add User
                </Button>
                <Button size="sm" variant="outline">
                  Manage Groups
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Settings className="h-4 w-4 mr-2" />
              Pending Updates
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="p-2 bg-yellow-100 dark:bg-yellow-900/20 rounded-md flex justify-between items-center">
                <div>
                  <div className="text-sm font-medium">Security Updates</div>
                  <div className="text-xs text-muted-foreground">12 systems need updates</div>
                </div>
                <Button size="sm" variant="secondary">Deploy</Button>
              </div>
              
              <div className="p-2 bg-green-100 dark:bg-green-900/20 rounded-md flex justify-between items-center">
                <div>
                  <div className="text-sm font-medium">OS Updates</div>
                  <div className="text-xs text-muted-foreground">Windows Server 2022</div>
                </div>
                <Button size="sm" variant="secondary">Deploy</Button>
              </div>
              
              <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-md flex justify-between items-center">
                <div>
                  <div className="text-sm font-medium">Application Updates</div>
                  <div className="text-xs text-muted-foreground">5 applications</div>
                </div>
                <Button size="sm" variant="secondary">Deploy</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Laptop className="h-5 w-5 mr-2" />
              Server Monitoring
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-3 border rounded-md">
                <div className="flex items-center justify-between">
                  <div className="font-medium">APP-SERVER-01</div>
                  <Badge variant="outline" className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">Healthy</Badge>
                </div>
                <div className="grid grid-cols-2 gap-y-1 text-sm mt-2">
                  <div className="text-muted-foreground">CPU:</div>
                  <div>32% (8 cores)</div>
                  <div className="text-muted-foreground">RAM:</div>
                  <div>12.4 GB / 32 GB</div>
                  <div className="text-muted-foreground">Disk:</div>
                  <div>342 GB / 1 TB</div>
                  <div className="text-muted-foreground">Uptime:</div>
                  <div>45 days, 3 hours</div>
                </div>
              </div>
              
              <div className="p-3 border rounded-md">
                <div className="flex items-center justify-between">
                  <div className="font-medium">DB-SERVER-01</div>
                  <Badge variant="outline" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400">Warning</Badge>
                </div>
                <div className="grid grid-cols-2 gap-y-1 text-sm mt-2">
                  <div className="text-muted-foreground">CPU:</div>
                  <div>78% (16 cores)</div>
                  <div className="text-muted-foreground">RAM:</div>
                  <div>58.2 GB / 64 GB</div>
                  <div className="text-muted-foreground">Disk:</div>
                  <div>1.8 TB / 2 TB</div>
                  <div className="text-muted-foreground">Uptime:</div>
                  <div>12 days, 5 hours</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Settings className="h-5 w-5 mr-2" />
              Maintenance Schedule
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="p-3 border rounded-md">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Database Backup</div>
                  <Badge>Today, 11:00 PM</Badge>
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  Full backup of all production databases
                </div>
                <div className="flex items-center text-xs mt-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mr-1"></div>
                  <div>Automatic</div>
                </div>
              </div>
              
              <div className="p-3 border rounded-md">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Server Patching</div>
                  <Badge>May 25, 2:00 AM</Badge>
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  Security updates for all Windows servers
                </div>
                <div className="flex items-center text-xs mt-2">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full mr-1"></div>
                  <div>Requires approval</div>
                </div>
              </div>
              
              <div className="p-3 border rounded-md">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Network Maintenance</div>
                  <Badge>May 28, 1:00 AM</Badge>
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  Router firmware updates and configuration backup
                </div>
                <div className="flex items-center text-xs mt-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mr-1"></div>
                  <div>Service disruption expected</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// Support Interface Preview
const SupportInterfacePreview = () => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Inbox className="h-4 w-4 mr-2" />
              Open Tickets
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">24</div>
            <div className="flex items-center text-sm mt-1">
              <span className="text-red-500 mr-1">↑ 8</span>
              <span className="text-muted-foreground">from yesterday</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Clock className="h-4 w-4 mr-2" />
              Avg. Response Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">1.8h</div>
            <div className="flex items-center text-sm mt-1">
              <span className="text-green-500 mr-1">↓ 0.3h</span>
              <span className="text-muted-foreground">from yesterday</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <CheckCircle className="h-4 w-4 mr-2" />
              Resolved Today
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">18</div>
            <div className="flex items-center text-sm mt-1">
              <span className="text-green-500 mr-1">↑ 5</span>
              <span className="text-muted-foreground">from yesterday</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Users className="h-4 w-4 mr-2" />
              Customer Satisfaction
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">94%</div>
            <div className="flex items-center text-sm mt-1">
              <span className="text-green-500 mr-1">↑ 2%</span>
              <span className="text-muted-foreground">from last week</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Support Tickets</CardTitle>
          <CardDescription>
            Manage and respond to customer support requests
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="open">
            <TabsList className="mb-4">
              <TabsTrigger value="open">Open Tickets</TabsTrigger>
              <TabsTrigger value="assigned">Assigned to Me</TabsTrigger>
              <TabsTrigger value="all">All Tickets</TabsTrigger>
            </TabsList>
            
            <TabsContent value="open">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Ticket ID</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">#T-5942</TableCell>
                    <TableCell>Sarah Johnson</TableCell>
                    <TableCell>Unable to access account</TableCell>
                    <TableCell>
                      <Badge className="bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400">High</Badge>
                    </TableCell>
                    <TableCell><Badge>New</Badge></TableCell>
                    <TableCell>10 min ago</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">Assign</Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">#T-5941</TableCell>
                    <TableCell>Michael Chen</TableCell>
                    <TableCell>Payment failed on checkout</TableCell>
                    <TableCell>
                      <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400">Medium</Badge>
                    </TableCell>
                    <TableCell><Badge>New</Badge></TableCell>
                    <TableCell>25 min ago</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">Assign</Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">#T-5940</TableCell>
                    <TableCell>Emma Wilson</TableCell>
                    <TableCell>Request for refund</TableCell>
                    <TableCell>
                      <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400">Medium</Badge>
                    </TableCell>
                    <TableCell><Badge variant="outline">In Progress</Badge></TableCell>
                    <TableCell>1h ago</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">View</Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">#T-5939</TableCell>
                    <TableCell>Alex Rodriguez</TableCell>
                    <TableCell>Product not as described</TableCell>
                    <TableCell>
                      <Badge className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">Low</Badge>
                    </TableCell>
                    <TableCell><Badge variant="outline">In Progress</Badge></TableCell>
                    <TableCell>2h ago</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">View</Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TabsContent>
            
            <TabsContent value="assigned">
              <div className="text-center py-10 text-muted-foreground">
                You have no tickets assigned to you.
              </div>
            </TabsContent>
            
            <TabsContent value="all">
              <div className="text-center py-10 text-muted-foreground">
                All tickets view
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart className="h-5 w-5 mr-2" />
              Ticket Analytics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-muted/40 rounded-md">
              <div className="h-full w-full p-4 flex items-end gap-1">
                {Array.from({ length: 7 }).map((_, i) => (
                  <div 
                    key={i} 
                    className="bg-primary/60 rounded-t w-full" 
                    style={{ 
                      height: `${20 + Math.random() * 70}%`,
                    }}
                  ></div>
                ))}
              </div>
            </div>
            <div className="mt-4 space-y-4">
              <div>
                <div className="text-sm font-medium mb-2">Top Issue Categories</div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div>Account Access</div>
                    <div>32%</div>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: '32%' }}></div>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <div>Payment Issues</div>
                    <div>28%</div>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: '28%' }}></div>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <div>Product Questions</div>
                    <div>18%</div>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: '18%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BookOpen className="h-5 w-5 mr-2" />
              Knowledge Base
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Input placeholder="Search articles..." className="max-w-sm" />
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-1" />
                  New Article
                </Button>
              </div>
              
              <div className="space-y-3 mt-4">
                <div className="p-3 border rounded-md">
                  <div className="font-medium">How to reset your password</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    Step-by-step guide to reset your account password
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <div className="text-xs text-muted-foreground">
                      Updated 2 days ago
                    </div>
                    <div className="text-xs">Views: 542</div>
                  </div>
                </div>
                
                <div className="p-3 border rounded-md">
                  <div className="font-medium">Troubleshooting payment failures</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    Common payment issues and how to resolve them
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <div className="text-xs text-muted-foreground">
                      Updated 1 week ago
                    </div>
                    <div className="text-xs">Views: 328</div>
                  </div>
                </div>
                
                <div className="p-3 border rounded-md">
                  <div className="font-medium">Product return policy</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    Information about our return and refund processes
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <div className="text-xs text-muted-foreground">
                      Updated 3 weeks ago
                    </div>
                    <div className="text-xs">Views: 894</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// User Interfaces Table
const UserInterfacesTable = () => {
  const { data: userInterfaces = [], isLoading } = useQuery({
    queryKey: ['/api/user-interfaces'],
  });
  
  if (isLoading) {
    return <div className="text-center py-4">Loading user interfaces...</div>;
  }
  
  if (!userInterfaces.length) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        No interface assignments found.
      </div>
    );
  }
  
  return (
    <Table>
      <TableCaption>A list of all user interface assignments.</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead>User</TableHead>
          <TableHead>Interface</TableHead>
          <TableHead>Type</TableHead>
          <TableHead>Assigned On</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {userInterfaces.map((assignment: any) => (
          <TableRow key={assignment.id}>
            <TableCell className="font-medium">{assignment.user.displayName}</TableCell>
            <TableCell>{assignment.interface.name}</TableCell>
            <TableCell>
              <Badge variant="outline">{assignment.interface.type}</Badge>
            </TableCell>
            <TableCell>{new Date(assignment.assignedAt).toLocaleDateString()}</TableCell>
            <TableCell>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                title="Remove assignment"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};

// Main Interfaces page component
export default function InterfacesPage() {
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editingInterfaceId, setEditingInterfaceId] = useState<number | null>(null);
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false);
  const [assigningInterfaceId, setAssigningInterfaceId] = useState<number | null>(null);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
  const [previewInterfaceId, setPreviewInterfaceId] = useState<number | null>(null);
  
  // Queries
  const { data: interfaces = [], isLoading } = useQuery({
    queryKey: ['/api/interfaces'],
  });
  
  const { data: editingInterface } = useQuery({
    queryKey: ['/api/interfaces', editingInterfaceId],
    enabled: !!editingInterfaceId,
  });
  
  // Mutations
  const createInterfaceMutation = useMutation({
    mutationFn: (interfaceData: any) => apiRequest('/api/interfaces', 'POST', interfaceData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/interfaces'] });
      setIsDialogOpen(false);
    }
  });
  
  const updateInterfaceMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => 
      apiRequest(`/api/interfaces/${id}`, 'PATCH', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/interfaces'] });
      setIsDialogOpen(false);
      setEditingInterfaceId(null);
      setIsEditMode(false);
    }
  });
  
  const deleteInterfaceMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/interfaces/${id}`, 'DELETE'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/interfaces'] });
    }
  });
  
  const assignInterfaceMutation = useMutation({
    mutationFn: ({ userId, interfaceId }: { userId: number; interfaceId: number }) => 
      apiRequest(`/api/users/${userId}/interfaces/${interfaceId}`, 'POST'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user-interfaces'] });
      setIsAssignDialogOpen(false);
      setAssigningInterfaceId(null);
    }
  });
  
  // Event handlers
  const handleCreateInterface = (data: any) => {
    if (isEditMode && editingInterfaceId) {
      updateInterfaceMutation.mutate({ id: editingInterfaceId, data });
    } else {
      createInterfaceMutation.mutate(data);
    }
  };
  
  const handleEditInterface = (id: number) => {
    setEditingInterfaceId(id);
    setIsEditMode(true);
    setIsDialogOpen(true);
  };
  
  const handleDeleteInterface = (id: number) => {
    if (confirm('Are you sure you want to delete this interface? This will also remove all user assignments.')) {
      deleteInterfaceMutation.mutate(id);
    }
  };
  
  const handleAssignInterface = (id: number) => {
    setAssigningInterfaceId(id);
    setIsAssignDialogOpen(true);
  };
  
  const handlePreviewInterface = (id: number) => {
    setPreviewInterfaceId(id);
    setIsPreviewModalOpen(true);
  };
  
  const handleAssignUserToInterface = (userId: number, interfaceId: number) => {
    assignInterfaceMutation.mutate({ userId, interfaceId });
  };
  
  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setIsEditMode(false);
    setEditingInterfaceId(null);
  };
  
  return (
    <div className="relative">
      <div className="container mx-auto py-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold">Role-Based Interfaces</h1>
            <p className="text-muted-foreground mt-1">
              Manage and assign specialized interfaces to users based on their roles.
            </p>
          </div>
          <Button onClick={() => setIsDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            New Interface
          </Button>
        </div>
        
        {/* Interface Tabs */}
        <Tabs defaultValue="interfaces" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="interfaces">Interfaces</TabsTrigger>
            <TabsTrigger value="assignments">User Assignments</TabsTrigger>
          </TabsList>
          
          <TabsContent value="interfaces">
            {isLoading ? (
              <div className="text-center py-12">Loading interfaces...</div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {interfaces.length === 0 ? (
                  <div className="col-span-full text-center py-12 text-muted-foreground">
                    No interfaces found. Create a new interface to get started.
                  </div>
                ) : (
                  interfaces.map((interfaceItem: Interface) => (
                    <InterfaceCard 
                      key={interfaceItem.id}
                      interface={interfaceItem}
                      onEdit={handleEditInterface}
                      onDelete={handleDeleteInterface}
                      onAssign={handleAssignInterface}
                      onPreview={handlePreviewInterface}
                    />
                  ))
                )}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="assignments">
            <Card>
              <CardHeader>
                <CardTitle>Interface Assignments</CardTitle>
                <CardDescription>
                  View and manage interface assignments to users.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  <UserInterfacesTable />
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Interface Preview Modal */}
        <InterfacePreviewModal
          open={isPreviewModalOpen}
          onClose={() => setIsPreviewModalOpen(false)}
          interfaceId={previewInterfaceId}
        />
        
        {/* Create/Edit Interface Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{isEditMode ? 'Edit Interface' : 'Create New Interface'}</DialogTitle>
              <DialogDescription>
                {isEditMode 
                  ? 'Update the details of this interface.' 
                  : 'Add a new interface to assign to users.'}
              </DialogDescription>
            </DialogHeader>
            <NewInterfaceForm 
              onSubmit={handleCreateInterface} 
              onCancel={handleCloseDialog}
              initialData={isEditMode ? editingInterface : null}
            />
          </DialogContent>
        </Dialog>
        
        {/* Assign Interface Dialog */}
        <AssignInterfaceDialog 
          open={isAssignDialogOpen} 
          onClose={() => setIsAssignDialogOpen(false)}
          interfaceId={assigningInterfaceId}
          onAssign={handleAssignUserToInterface}
        />
      </div>
    </div>
  );
}