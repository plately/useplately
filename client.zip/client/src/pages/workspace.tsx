import { useState, useRef, useCallback, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format, startOfDay, addHours } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Node, InsertNode } from "@shared/schema";
import {
  CheckCircle2,
  Circle,
  Plus,
  Upload,
  Link,
  Hash,
  Brain,
  Target,
  BarChart3,
  Paperclip,
  Zap,
  FileText,
  Image,
  File,
  Play,
  Pause,
  Check,
  ChevronDown,
  ChevronRight,
  Users,
  Tag,
  MessageSquare,
  ExternalLink,
  Timer,
  AlertCircle,
  CheckCheck,
  ArrowRight,
  Share2,
  Download,
  Copy,
  Settings,
  Search,
  Webhook,
  Database,
  Globe,
  Send,
  Rocket,
  GitBranch,
  Mail,
  FolderOpen,
  Smartphone,
  Monitor,
  Cloud,
  Workflow,
  Calendar as CalendarIcon,
  TrendingUp,
  Activity,
  Briefcase,
  Star,
  Award,
  Layers,
  Grid3X3,
  Layout,
  MoreHorizontal,
  Bell,
  Bookmark,
  Focus,
  Expand,
  Clock,
  MapPin,
  Eye,
  Filter,
  Archive,
  LinkIcon,
  Calendar,
  MessageCircle,
  Folder,
  Video,
  Code,
  Archive as ArchiveIcon,
  History,
  Bot,
  ChevronLeft,
  X,
  Edit3
} from "lucide-react";

// File-native workspace interfaces
interface WorkspaceFile {
  id: string;
  name: string;
  type: string;
  size: number;
  url: string;
  uploadedAt: Date;
  linkedNodes: number[];
  attachedTasks: string[];
  tags: string[];
  source: 'local' | 'drive' | 'dropbox' | 'notion' | 'figma' | 'github';
  preview?: string;
  metadata: {
    lastModified?: Date;
    version?: number;
    annotations?: FileAnnotation[];
  };
}

interface FileAnnotation {
  id: string;
  userId: number;
  content: string;
  position: { x: number; y: number; page?: number };
  createdAt: Date;
  resolved: boolean;
}

interface FileTask {
  id: string;
  title: string;
  description?: string;
  fileId: string;
  nodeId: number;
  status: 'todo' | 'in-progress' | 'done';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assignedTo?: string;
  dueDate?: Date;
  createdAt: Date;
  completedAt?: Date;
  autoComplete?: boolean;
}

interface SmartFolder {
  id: string;
  name: string;
  query: string;
  autoTags: string[];
  files: WorkspaceFile[];
  color: string;
}

interface TimelineEvent {
  id: string;
  type: 'upload' | 'edit' | 'task_complete' | 'annotation' | 'link';
  timestamp: Date;
  fileId?: string;
  taskId?: string;
  nodeId?: number;
  description: string;
  user: string;
}

const integrationPlatforms = [
  {
    id: 'notion',
    name: 'Notion',
    icon: <FileText className="h-4 w-4" />,
    color: 'bg-gray-800',
    actions: ['Import Page', 'Sync Database', 'Create Doc']
  },
  {
    id: 'figma',
    name: 'Figma',
    icon: <Layers className="h-4 w-4" />,
    color: 'bg-pink-500',
    actions: ['Import Design', 'Embed Frame', 'Get Comments']
  },
  {
    id: 'drive',
    name: 'Google Drive',
    icon: <Cloud className="h-4 w-4" />,
    color: 'bg-blue-500',
    actions: ['Import Files', 'Sync Folder', 'Share Doc']
  },
  {
    id: 'github',
    name: 'GitHub',
    icon: <GitBranch className="h-4 w-4" />,
    color: 'bg-gray-900',
    actions: ['Import Repo', 'Sync Issues', 'Pull Files']
  },
  {
    id: 'dropbox',
    name: 'Dropbox',
    icon: <Cloud className="h-4 w-4" />,
    color: 'bg-blue-600',
    actions: ['Import Files', 'Sync Folder', 'Share Link']
  },
  {
    id: 'slack',
    name: 'Slack',
    icon: <MessageSquare className="h-4 w-4" />,
    color: 'bg-purple-500',
    actions: ['Share File', 'Send Update', 'Create Channel']
  }
];

const fileTypeIcons = {
  'application/pdf': <FileText className="h-5 w-5 text-red-500" />,
  'image/': <Image className="h-5 w-5 text-green-500" />,
  'video/': <Video className="h-5 w-5 text-purple-500" />,
  'text/': <FileText className="h-5 w-5 text-blue-500" />,
  'application/vnd.ms-excel': <FileText className="h-5 w-5 text-green-600" />,
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': <FileText className="h-5 w-5 text-green-600" />,
  'application/zip': <ArchiveIcon className="h-5 w-5 text-orange-500" />,
  'default': <File className="h-5 w-5 text-gray-500" />
};

export default function Workspace() {
  const [selectedNodeId, setSelectedNodeId] = useState<number | null>(null);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [files, setFiles] = useState<WorkspaceFile[]>([]);
  const [fileTasks, setFileTasks] = useState<FileTask[]>([]);
  const [timeline, setTimeline] = useState<TimelineEvent[]>([]);
  const [smartFolders, setSmartFolders] = useState<SmartFolder[]>([
    {
      id: 'recent',
      name: 'Recent Files',
      query: 'uploaded:7d',
      autoTags: [],
      files: [],
      color: 'bg-blue-500'
    },
    {
      id: 'documents',
      name: 'Documents',
      query: 'type:pdf,doc,txt',
      autoTags: ['#document'],
      files: [],
      color: 'bg-green-500'
    },
    {
      id: 'designs',
      name: 'Design Files',
      query: 'type:fig,psd,ai,sketch',
      autoTags: ['#design'],
      files: [],
      color: 'bg-pink-500'
    },
    {
      id: 'pending',
      name: 'Pending Tasks',
      query: 'tasks:pending',
      autoTags: [],
      files: [],
      color: 'bg-orange-500'
    }
  ]);
  
  // UI States
  const [activeTab, setActiveTab] = useState<'files' | 'tasks' | 'timeline' | 'integrations'>('files');
  const [selectedFile, setSelectedFile] = useState<WorkspaceFile | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [isTaskDialogOpen, setIsTaskDialogOpen] = useState(false);
  const [isBulkUploadOpen, setIsBulkUploadOpen] = useState(false);
  const [isNodeSelectorOpen, setIsNodeSelectorOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFolder, setSelectedFolder] = useState<string>('recent');
  
  // Form states
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [taskDueDate, setTaskDueDate] = useState('');
  const [taskPriority, setTaskPriority] = useState<FileTask['priority']>('medium');
  const [taskAssignedTo, setTaskAssignedTo] = useState('');
  const [bulkUploadFiles, setBulkUploadFiles] = useState<File[]>([]);
  const [nodeMapping, setNodeMapping] = useState<Record<string, number>>({});
  
  // Enhanced file management states
  const [showDetailedUpload, setShowDetailedUpload] = useState(false);
  const [showFileLinkDialog, setShowFileLinkDialog] = useState(false);
  const [currentFileForLinking, setCurrentFileForLinking] = useState<WorkspaceFile | null>(null);
  const [taskNodeSelection, setTaskNodeSelection] = useState<number | null>(null);
  const [uploadTags, setUploadTags] = useState<string[]>([]);
  const [customTags, setCustomTags] = useState('');
  const [fileDescription, setFileDescription] = useState('');
  const [selectedLinkedNodes, setSelectedLinkedNodes] = useState<number[]>([]);
  const [bulkFileData, setBulkFileData] = useState<Array<{
    file: File;
    tags: string[];
    customTags: string;
    description: string;
    linkedNodes: number[];
    priority: 'low' | 'medium' | 'high' | 'urgent';
  }>>([]);
  const [currentBulkFileIndex, setCurrentBulkFileIndex] = useState(0);
  const [isCreateFolderOpen, setIsCreateFolderOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [newFolderTags, setNewFolderTags] = useState('');
  const [newFolderFileType, setNewFolderFileType] = useState('');
  const [newFolderColor, setNewFolderColor] = useState('bg-blue-500');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const bulkFileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Query for all nodes
  const { data: nodes = [] } = useQuery<Node[]>({
    queryKey: ['/api/nodes'],
  });

  // Auto-select first available node
  useEffect(() => {
    if (nodes.length > 0 && !selectedNodeId) {
      const firstNode = nodes[0];
      setSelectedNodeId(firstNode.id);
      setSelectedNode(firstNode);
    }
  }, [nodes, selectedNodeId]);

  // Filter files based on search and folder
  const filteredFiles = files.filter(file => {
    const matchesSearch = searchQuery 
      ? file.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        file.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      : true;
    
    let matchesFolder = true;
    
    if (selectedFolder === 'recent') {
      // Show files from last 7 days
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      matchesFolder = file.uploadedAt >= sevenDaysAgo;
    } else if (selectedFolder === 'documents') {
      matchesFolder = file.type.includes('pdf') || file.type.includes('doc') || file.type.includes('text');
    } else if (selectedFolder === 'designs') {
      matchesFolder = file.name.includes('.fig') || file.name.includes('.psd') || file.name.includes('.ai') || file.type.includes('image');
    } else if (selectedFolder === 'pending') {
      matchesFolder = file.attachedTasks.some(taskId => fileTasks.find(t => t.id === taskId && t.status !== 'done'));
    } else {
      // Check if it's a custom smart folder
      const customFolder = smartFolders.find(folder => folder.id === selectedFolder);
      if (customFolder) {
        matchesFolder = matchesSmartFolderCriteria(file, customFolder);
      }
    }
    
    const matchesNode = selectedNodeId 
      ? file.linkedNodes.includes(selectedNodeId)
      : true;
    
    return matchesSearch && matchesFolder && matchesNode;
  });

  // Function to check if file matches smart folder criteria
  const matchesSmartFolderCriteria = (file: WorkspaceFile, folder: SmartFolder): boolean => {
    const query = folder.query;
    
    // Handle file type filters
    if (query.includes('type:')) {
      const typeMatch = query.match(/type:([^,\s]+)/);
      if (typeMatch) {
        const types = typeMatch[1].split(',');
        const fileMatchesType = types.some(type => {
          if (type === 'pdf') return file.type.includes('pdf');
          if (type === 'image') return file.type.includes('image');
          if (type === 'video') return file.type.includes('video');
          if (type === 'doc' || type === 'docx') return file.type.includes('document') || file.name.includes('.doc');
          if (type === 'xls' || type === 'xlsx') return file.name.includes('.xls') || file.type.includes('spreadsheet');
          if (type === 'ppt' || type === 'pptx') return file.name.includes('.ppt') || file.type.includes('presentation');
          if (type === 'zip' || type === 'rar') return file.name.includes('.zip') || file.name.includes('.rar');
          return file.type.includes(type) || file.name.toLowerCase().includes(type);
        });
        if (!fileMatchesType) return false;
      }
    }
    
    // Handle tag filters
    if (query.includes('tags:')) {
      const tagMatch = query.match(/tags:([^,\s]+)/);
      if (tagMatch) {
        const requiredTags = tagMatch[1].split(',');
        const fileHasRequiredTags = requiredTags.some(tag => 
          file.tags.some(fileTag => fileTag.toLowerCase().includes(tag.toLowerCase().replace('#', '')))
        );
        if (!fileHasRequiredTags) return false;
      }
    }
    
    return true;
  };

  // Get file tasks for selected file
  const selectedFileTasks = selectedFile 
    ? fileTasks.filter(task => task.fileId === selectedFile.id)
    : [];

  const getFileIcon = (type: string) => {
    for (const [key, icon] of Object.entries(fileTypeIcons)) {
      if (type.startsWith(key)) return icon;
    }
    return fileTypeIcons.default;
  };

  const autoTagFile = (file: File): string[] => {
    const tags: string[] = [];
    const name = file.name.toLowerCase();
    const type = file.type;
    
    // Auto-tag based on file type
    if (type.includes('pdf')) tags.push('#document', '#pdf');
    if (type.includes('image')) tags.push('#image', '#visual');
    if (type.includes('video')) tags.push('#video', '#media');
    if (name.includes('invoice')) tags.push('#invoice', '#finance');
    if (name.includes('design') || name.includes('mockup')) tags.push('#design');
    if (name.includes('contract') || name.includes('legal')) tags.push('#legal');
    if (name.includes('proposal')) tags.push('#proposal');
    if (name.includes('report')) tags.push('#report');
    
    return tags;
  };

  const predefinedTags = [
    { label: 'Picture', value: '#picture', color: 'bg-purple-100 text-purple-800' },
    { label: 'PDF', value: '#pdf', color: 'bg-red-100 text-red-800' },
    { label: 'CSV', value: '#csv', color: 'bg-green-100 text-green-800' },
    { label: 'Invoice', value: '#invoice', color: 'bg-blue-100 text-blue-800' },
    { label: 'Design', value: '#design', color: 'bg-pink-100 text-pink-800' },
    { label: 'Legal', value: '#legal', color: 'bg-gray-100 text-gray-800' },
    { label: 'Contract', value: '#contract', color: 'bg-yellow-100 text-yellow-800' },
    { label: 'Report', value: '#report', color: 'bg-indigo-100 text-indigo-800' },
    { label: 'Presentation', value: '#presentation', color: 'bg-orange-100 text-orange-800' },
    { label: 'Spreadsheet', value: '#spreadsheet', color: 'bg-teal-100 text-teal-800' },
    { label: 'Draft', value: '#draft', color: 'bg-gray-100 text-gray-600' },
    { label: 'Final', value: '#final', color: 'bg-green-100 text-green-700' },
    { label: 'Urgent', value: '#urgent', color: 'bg-red-100 text-red-700' },
    { label: 'Review', value: '#review', color: 'bg-amber-100 text-amber-700' }
  ];

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = Array.from(event.target.files || []);
    
    if (uploadedFiles.length === 1) {
      // Single file - show detailed upload dialog
      const file = uploadedFiles[0];
      setUploadTags(autoTagFile(file));
      setFileDescription('');
      setCustomTags('');
      setSelectedLinkedNodes(selectedNodeId ? [selectedNodeId] : []);
      setBulkUploadFiles([file]);
      setShowDetailedUpload(true);
    } else {
      // Multiple files - bulk upload with auto-tagging
      processBulkUpload(uploadedFiles);
    }

    if (event.target) {
      event.target.value = '';
    }
  };

  const processBulkUpload = (uploadedFiles: File[]) => {
    uploadedFiles.forEach(file => {
      const workspaceFile: WorkspaceFile = {
        id: Date.now().toString() + Math.random(),
        name: file.name,
        type: file.type,
        size: file.size,
        url: URL.createObjectURL(file),
        uploadedAt: new Date(),
        linkedNodes: selectedNodeId ? [selectedNodeId] : [],
        attachedTasks: [],
        tags: autoTagFile(file),
        source: 'local',
        metadata: {
          version: 1,
          annotations: []
        }
      };
      
      setFiles(prev => [...prev, workspaceFile]);
      
      // Add timeline event
      const timelineEvent: TimelineEvent = {
        id: Date.now().toString(),
        type: 'upload',
        timestamp: new Date(),
        fileId: workspaceFile.id,
        nodeId: selectedNodeId || undefined,
        description: `Uploaded ${file.name}`,
        user: 'You'
      };
      setTimeline(prev => [timelineEvent, ...prev]);
    });

    toast({
      title: "Files uploaded",
      description: `${uploadedFiles.length} file(s) uploaded and auto-tagged`,
    });
  };

  const handleDetailedUpload = () => {
    const file = bulkUploadFiles[0];
    if (!file) return;

    const customTagsArray = customTags
      .split(',')
      .map(tag => tag.trim())
      .filter(tag => tag.length > 0)
      .map(tag => tag.startsWith('#') ? tag : `#${tag}`);

    const workspaceFile: WorkspaceFile = {
      id: Date.now().toString() + Math.random(),
      name: file.name,
      type: file.type,
      size: file.size,
      url: URL.createObjectURL(file),
      uploadedAt: new Date(),
      linkedNodes: selectedLinkedNodes,
      attachedTasks: [],
      tags: [...uploadTags, ...customTagsArray],
      source: 'local',
      metadata: {
        version: 1,
        annotations: []
      }
    };
    
    setFiles(prev => [...prev, workspaceFile]);
    
    // Add timeline event
    const timelineEvent: TimelineEvent = {
      id: Date.now().toString(),
      type: 'upload',
      timestamp: new Date(),
      fileId: workspaceFile.id,
      nodeId: selectedLinkedNodes[0] || undefined,
      description: `Uploaded ${file.name} with ${workspaceFile.tags.length} tags`,
      user: 'You'
    };
    setTimeline(prev => [timelineEvent, ...prev]);

    setShowDetailedUpload(false);
    setBulkUploadFiles([]);
    setUploadTags([]);
    setCustomTags('');
    setFileDescription('');
    setSelectedLinkedNodes([]);

    toast({
      title: "File uploaded with detailed tagging",
      description: `${file.name} uploaded with ${workspaceFile.tags.length} tags and linked to ${selectedLinkedNodes.length} nodes`,
    });
  };

  const openFileLinkDialog = (file: WorkspaceFile) => {
    setCurrentFileForLinking(file);
    setShowFileLinkDialog(true);
  };

  const handleBulkUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setBulkUploadFiles(files);
    
    // Initialize detailed file data for each uploaded file
    const initialFileData = files.map(file => ({
      file,
      tags: autoTagFile(file),
      customTags: '',
      description: '',
      linkedNodes: selectedNodeId ? [selectedNodeId] : [],
      priority: 'medium' as const
    }));
    
    setBulkFileData(initialFileData);
    setCurrentBulkFileIndex(0);
    setIsBulkUploadOpen(true);
    
    if (event.target) {
      event.target.value = '';
    }
  };

  const processBulkFileData = () => {
    bulkFileData.forEach((fileData, index) => {
      const customTagsArray = fileData.customTags
        .split(',')
        .map(tag => tag.trim())
        .filter(tag => tag.length > 0)
        .map(tag => tag.startsWith('#') ? tag : `#${tag}`);

      const workspaceFile: WorkspaceFile = {
        id: Date.now().toString() + Math.random() + index,
        name: fileData.file.name,
        type: fileData.file.type,
        size: fileData.file.size,
        url: URL.createObjectURL(fileData.file),
        uploadedAt: new Date(),
        linkedNodes: fileData.linkedNodes,
        attachedTasks: [],
        tags: [...fileData.tags, ...customTagsArray],
        source: 'local',
        metadata: {
          version: 1,
          annotations: []
        }
      };
      
      setFiles(prev => [...prev, workspaceFile]);
      
      // Add timeline event
      const timelineEvent: TimelineEvent = {
        id: Date.now().toString() + Math.random() + index,
        type: 'upload',
        timestamp: new Date(),
        fileId: workspaceFile.id,
        nodeId: fileData.linkedNodes[0] || undefined,
        description: `Uploaded ${fileData.file.name} with ${workspaceFile.tags.length} tags`,
        user: 'You'
      };
      setTimeline(prev => [timelineEvent, ...prev]);
    });

    setIsBulkUploadOpen(false);
    setBulkFileData([]);
    setBulkUploadFiles([]);
    setCurrentBulkFileIndex(0);

    toast({
      title: "Bulk upload complete",
      description: `${bulkFileData.length} files uploaded with detailed tagging and node linking`,
    });
  };

  const attachTaskToFile = () => {
    if (!selectedFile || !newTaskTitle.trim()) return;

    const targetNodeId = taskNodeSelection || selectedNodeId || (selectedFile.linkedNodes.length > 0 ? selectedFile.linkedNodes[0] : null);

    const task: FileTask = {
      id: Date.now().toString(),
      title: newTaskTitle,
      fileId: selectedFile.id,
      nodeId: targetNodeId || 0,
      status: 'todo',
      priority: taskPriority,
      assignedTo: taskAssignedTo || undefined,
      dueDate: taskDueDate ? new Date(taskDueDate) : undefined,
      createdAt: new Date()
    };

    setFileTasks(prev => [...prev, task]);
    
    // Update file with attached task
    setFiles(prev => prev.map(file => 
      file.id === selectedFile.id 
        ? { ...file, attachedTasks: [...file.attachedTasks, task.id] }
        : file
    ));

    // Add timeline event
    const timelineEvent: TimelineEvent = {
      id: Date.now().toString(),
      type: 'task_complete',
      timestamp: new Date(),
      fileId: selectedFile.id,
      taskId: task.id,
      description: `Task "${newTaskTitle}" attached to ${selectedFile.name}`,
      user: 'You'
    };
    setTimeline(prev => [timelineEvent, ...prev]);

    setNewTaskTitle('');
    setTaskDueDate('');
    setTaskAssignedTo('');
    setIsTaskDialogOpen(false);

    toast({
      title: "Task attached",
      description: `Task attached to ${selectedFile.name}`,
    });
  };

  const updateTaskStatus = (taskId: string, status: FileTask['status']) => {
    setFileTasks(prev => prev.map(task => 
      task.id === taskId 
        ? { ...task, status, completedAt: status === 'done' ? new Date() : undefined }
        : task
    ));

    const task = fileTasks.find(t => t.id === taskId);
    if (task && status === 'done') {
      // Add timeline event
      const timelineEvent: TimelineEvent = {
        id: Date.now().toString(),
        type: 'task_complete',
        timestamp: new Date(),
        taskId,
        fileId: task.fileId,
        description: `Completed task: ${task.title}`,
        user: 'You'
      };
      setTimeline(prev => [timelineEvent, ...prev]);
    }

    toast({
      title: "Task updated",
      description: `Task marked as ${status.replace('-', ' ')}`,
    });
  };

  const linkFileToNode = (fileId: string, nodeId: number) => {
    setFiles(prev => prev.map(file => 
      file.id === fileId 
        ? { ...file, linkedNodes: file.linkedNodes.includes(nodeId) ? file.linkedNodes : [...file.linkedNodes, nodeId] }
        : file
    ));

    const file = files.find(f => f.id === fileId);
    const node = nodes.find(n => n.id === nodeId);
    
    if (file && node) {
      const timelineEvent: TimelineEvent = {
        id: Date.now().toString(),
        type: 'link',
        timestamp: new Date(),
        fileId,
        nodeId,
        description: `Linked ${file.name} to ${node.title}`,
        user: 'You'
      };
      setTimeline(prev => [timelineEvent, ...prev]);
    }

    toast({
      title: "File linked",
      description: `File linked to ${node?.title}`,
    });
  };

  const executeIntegration = async (platform: string, action: string) => {
    // Simulate integration execution
    setTimeout(() => {
      toast({
        title: "Integration successful",
        description: `${action} executed in ${platform}`,
      });
    }, 1500);

    toast({
      title: "Integration started",
      description: `Executing ${action}...`,
    });
  };

  const createCustomFolder = () => {
    console.log('Creating custom folder:', { newFolderName, newFolderTags, newFolderFileType, newFolderColor });
    
    if (!newFolderName.trim()) {
      toast({
        variant: "destructive",
        title: "Folder name required",
        description: "Please provide a name for the smart folder.",
      });
      return;
    }

    const query = buildFolderQuery();
    const autoTags = newFolderTags.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0).map(tag => tag.startsWith('#') ? tag : `#${tag}`);
    
    const newFolder: SmartFolder = {
      id: Date.now().toString(),
      name: newFolderName,
      query,
      autoTags,
      files: [],
      color: newFolderColor
    };

    console.log('New folder object:', newFolder);

    setSmartFolders(prev => {
      const updated = [...prev, newFolder];
      console.log('Updated smart folders:', updated);
      return updated;
    });
    
    const timelineEvent: TimelineEvent = {
      id: Date.now().toString(),
      type: 'upload',
      timestamp: new Date(),
      description: `Created smart folder "${newFolderName}"`,
      user: 'You'
    };
    setTimeline(prev => [timelineEvent, ...prev]);

    toast({
      title: "Smart folder created",
      description: `"${newFolderName}" folder has been created successfully.`,
    });

    setIsCreateFolderOpen(false);
    setNewFolderName('');
    setNewFolderTags('');
    setNewFolderFileType('');
    setNewFolderColor('bg-blue-500');
  };

  const buildFolderQuery = () => {
    const conditions = [];
    if (newFolderFileType && newFolderFileType !== 'all') {
      conditions.push(`type:${newFolderFileType}`);
    }
    if (newFolderTags) {
      const tags = newFolderTags.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0);
      if (tags.length > 0) {
        conditions.push(`tags:${tags.join(',')}`);
      }
    }
    return conditions.length > 0 ? conditions.join(' AND ') : 'all';
  };

  const deleteCustomFolder = (folderId: string) => {
    setSmartFolders(prev => prev.filter(folder => folder.id !== folderId));
    if (selectedFolder === folderId) {
      setSelectedFolder('recent');
    }
    
    toast({
      title: "Smart folder deleted",
      description: "The custom folder has been removed.",
    });
  };

  const FilePreview = () => {
    if (!selectedFile) return null;

    return (
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="sm:max-w-[900px] sm:max-h-[700px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {getFileIcon(selectedFile.type)}
              {selectedFile.name}
              <Badge variant="outline">{selectedFile.source}</Badge>
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* File preview area */}
            <div className="bg-gray-100 rounded-lg p-8 text-center">
              <div className="text-gray-500">
                {selectedFile.type.includes('image') ? (
                  <img src={selectedFile.url} alt={selectedFile.name} className="max-w-full max-h-96 mx-auto rounded" />
                ) : selectedFile.type.includes('pdf') ? (
                  <div className="space-y-2">
                    <FileText className="h-16 w-16 mx-auto text-red-500" />
                    <p>PDF Preview</p>
                    <Button size="sm" variant="outline">Open PDF Viewer</Button>
                  </div>
                ) : selectedFile.type.includes('video') ? (
                  <div className="space-y-2">
                    <Video className="h-16 w-16 mx-auto text-purple-500" />
                    <p>Video Preview</p>
                    <Button size="sm" variant="outline">Play Video</Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {getFileIcon(selectedFile.type)}
                    <p>File Preview</p>
                    <Button size="sm" variant="outline">Download to View</Button>
                  </div>
                )}
              </div>
            </div>

            {/* File details and tasks */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium mb-2">File Details</h4>
                <div className="space-y-2 text-sm">
                  <div>Size: {(selectedFile.size / 1024).toFixed(1)} KB</div>
                  <div>Uploaded: {format(selectedFile.uploadedAt, 'MMM d, yyyy h:mm a')}</div>
                  <div>Linked Nodes: {selectedFile.linkedNodes.length}</div>
                  <div className="flex gap-1 flex-wrap">
                    {selectedFile.tags.map(tag => (
                      <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                    ))}
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-2">Attached Tasks ({selectedFileTasks.length})</h4>
                <div className="space-y-2">
                  {selectedFileTasks.map(task => (
                    <div key={task.id} className="flex items-center gap-2 p-2 bg-muted rounded">
                      <Checkbox
                        checked={task.status === 'done'}
                        onCheckedChange={(checked) => 
                          updateTaskStatus(task.id, checked ? 'done' : 'todo')
                        }
                      />
                      <span className={`flex-1 text-sm ${task.status === 'done' ? 'line-through text-muted-foreground' : ''}`}>
                        {task.title}
                      </span>
                      <Badge variant="outline" className="text-xs">{task.priority}</Badge>
                    </div>
                  ))}
                  <Button size="sm" variant="outline" onClick={() => setIsTaskDialogOpen(true)}>
                    <Plus className="h-3 w-3 mr-1" />
                    Add Task
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur-sm sticky top-0 z-30">
        <div className="p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Badge variant="secondary" className="bg-primary/10">
                File Coordinator
              </Badge>
            </div>
            
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" onClick={() => bulkFileInputRef.current?.click()}>
                <Layers className="h-4 w-4 mr-2" />
                Bulk Upload
              </Button>
              <Button size="sm" variant="outline">
                <Cloud className="h-4 w-4 mr-2" />
                Import
              </Button>
            </div>
          </div>

          {/* Navigation */}
          <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="files">Files & Tasks</TabsTrigger>
              <TabsTrigger value="tasks">Task Overview</TabsTrigger>
              <TabsTrigger value="timeline">Timeline</TabsTrigger>
              <TabsTrigger value="integrations">Integrations</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full flex">
          {/* Sidebar */}
          <div className="w-64 border-r bg-muted/30 overflow-y-auto">
            <div className="p-4 space-y-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search files..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>

              {/* Smart Folders */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-sm">Smart Folders</h3>
                  <Button 
                    size="icon" 
                    variant="ghost" 
                    className="h-6 w-6"
                    onClick={() => setIsCreateFolderOpen(true)}
                  >
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
                <div className="space-y-1">
                  {smartFolders.map(folder => (
                    <div key={folder.id} className="group flex items-center">
                      <Button
                        variant={selectedFolder === folder.id ? "secondary" : "ghost"}
                        size="sm"
                        className="flex-1 justify-start"
                        onClick={() => setSelectedFolder(folder.id)}
                      >
                        <div className={`w-3 h-3 rounded ${folder.color} mr-2`}></div>
                        {folder.name}
                        <Badge variant="outline" className="ml-auto text-xs">
                          {filteredFiles.length}
                        </Badge>
                      </Button>
                      {!['recent', 'documents', 'designs', 'pending'].includes(folder.id) && (
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-6 w-6 opacity-0 group-hover:opacity-100 ml-1"
                          onClick={() => deleteCustomFolder(folder.id)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Stats */}
              <Card className="p-3">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Total Files</span>
                    <span className="font-medium">{files.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pending Tasks</span>
                    <span className="font-medium">
                      {fileTasks.filter(t => t.status !== 'done').length}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Linked Nodes</span>
                    <span className="font-medium">
                      {new Set(files.flatMap(f => f.linkedNodes)).size}
                    </span>
                  </div>
                </div>
              </Card>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex-1 overflow-y-auto">
            <div className="p-6">
              {activeTab === 'files' && (
                <div className="space-y-4">
                  {/* Files Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filteredFiles.map(file => (
                      <Card key={file.id} className="hover:shadow-md transition-shadow cursor-pointer group">
                        <CardContent className="p-4">
                          <div className="space-y-3">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-2">
                                {getFileIcon(file.type)}
                                <div className="flex-1 min-w-0">
                                  <h4 className="font-medium text-sm truncate">{file.name}</h4>
                                  <p className="text-xs text-muted-foreground">
                                    {(file.size / 1024).toFixed(1)} KB • {format(file.uploadedAt, 'MMM d')}
                                  </p>
                                </div>
                              </div>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => { setSelectedFile(file); setIsPreviewOpen(true); }}>
                                    <Eye className="h-4 w-4 mr-2" />
                                    Preview
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => { setSelectedFile(file); setIsTaskDialogOpen(true); }}>
                                    <Plus className="h-4 w-4 mr-2" />
                                    Add Task
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => openFileLinkDialog(file)}>
                                    <LinkIcon className="h-4 w-4 mr-2" />
                                    Link to Node
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    <Download className="h-4 w-4 mr-2" />
                                    Download
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>

                            {/* Tags */}
                            <div className="flex gap-1 flex-wrap">
                              {file.tags.slice(0, 3).map(tag => (
                                <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                              ))}
                              {file.tags.length > 3 && (
                                <Badge variant="outline" className="text-xs">+{file.tags.length - 3}</Badge>
                              )}
                            </div>

                            {/* Attached Tasks */}
                            {file.attachedTasks.length > 0 && (
                              <div className="space-y-1">
                                <div className="text-xs text-muted-foreground">
                                  {file.attachedTasks.length} task(s)
                                </div>
                                {file.attachedTasks.slice(0, 2).map(taskId => {
                                  const task = fileTasks.find(t => t.id === taskId);
                                  return task ? (
                                    <div key={task.id} className="flex items-center gap-2 text-xs">
                                      <Checkbox
                                        checked={task.status === 'done'}
                                        onCheckedChange={(checked) => 
                                          updateTaskStatus(task.id, checked ? 'done' : 'todo')
                                        }
                                        className="h-3 w-3"
                                      />
                                      <span className={task.status === 'done' ? 'line-through text-muted-foreground' : ''}>
                                        {task.title}
                                      </span>
                                    </div>
                                  ) : null;
                                })}
                              </div>
                            )}

                            {/* Linked Nodes */}
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <LinkIcon className="h-3 w-3" />
                              {file.linkedNodes.length} node(s)
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {filteredFiles.length === 0 && (
                    <div className="text-center py-12">
                      <FolderOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">No files found</h3>
                      <p className="text-muted-foreground mb-4">
                        Upload files or import from cloud services to get started
                      </p>
                      <Button onClick={() => fileInputRef.current?.click()}>
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Files
                      </Button>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'tasks' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* To Do */}
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">To Do</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        {fileTasks.filter(t => t.status === 'todo').map(task => {
                          const file = files.find(f => f.id === task.fileId);
                          return (
                            <Card key={task.id} className="p-3">
                              <div className="space-y-2">
                                <h4 className="font-medium text-sm">{task.title}</h4>
                                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                  {getFileIcon(file?.type || '')}
                                  {file?.name}
                                </div>
                                <div className="flex items-center justify-between">
                                  <Badge variant="outline" className="text-xs">{task.priority}</Badge>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => updateTaskStatus(task.id, 'in-progress')}
                                  >
                                    <Play className="h-3 w-3" />
                                  </Button>
                                </div>
                              </div>
                            </Card>
                          );
                        })}
                      </CardContent>
                    </Card>

                    {/* In Progress */}
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">In Progress</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        {fileTasks.filter(t => t.status === 'in-progress').map(task => {
                          const file = files.find(f => f.id === task.fileId);
                          return (
                            <Card key={task.id} className="p-3 border-blue-200">
                              <div className="space-y-2">
                                <h4 className="font-medium text-sm">{task.title}</h4>
                                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                  {getFileIcon(file?.type || '')}
                                  {file?.name}
                                </div>
                                <div className="flex items-center justify-between">
                                  <Badge variant="outline" className="text-xs">{task.priority}</Badge>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => updateTaskStatus(task.id, 'done')}
                                  >
                                    <Check className="h-3 w-3" />
                                  </Button>
                                </div>
                              </div>
                            </Card>
                          );
                        })}
                      </CardContent>
                    </Card>

                    {/* Done */}
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">Done</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        {fileTasks.filter(t => t.status === 'done').map(task => {
                          const file = files.find(f => f.id === task.fileId);
                          return (
                            <Card key={task.id} className="p-3 border-green-200 opacity-80">
                              <div className="space-y-2">
                                <h4 className="font-medium text-sm line-through">{task.title}</h4>
                                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                  {getFileIcon(file?.type || '')}
                                  {file?.name}
                                </div>
                                <div className="flex items-center justify-between">
                                  <Badge variant="outline" className="text-xs border-green-500 text-green-600">{task.priority}</Badge>
                                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                                </div>
                              </div>
                            </Card>
                          );
                        })}
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}

              {activeTab === 'timeline' && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <History className="h-5 w-5" />
                      Workspace Timeline
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-96">
                      <div className="space-y-4">
                        {timeline.map(event => (
                          <div key={event.id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                            <div className="w-2 h-2 rounded-full bg-blue-500 mt-2"></div>
                            <div className="flex-1">
                              <p className="text-sm font-medium">{event.description}</p>
                              <p className="text-xs text-muted-foreground">
                                {event.user} • {format(event.timestamp, 'MMM d, h:mm a')}
                              </p>
                            </div>
                            <Badge variant="outline" className="text-xs">
                              {event.type}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              )}

              {activeTab === 'integrations' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {integrationPlatforms.map(platform => (
                    <Card key={platform.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          <div className="flex items-center gap-3">
                            <div className={`p-2 rounded text-white ${platform.color}`}>
                              {platform.icon}
                            </div>
                            <div>
                              <h3 className="font-medium text-sm">{platform.name}</h3>
                              <p className="text-xs text-muted-foreground">
                                {platform.actions.length} actions
                              </p>
                            </div>
                          </div>
                          <div className="space-y-1">
                            {platform.actions.map(action => (
                              <Button
                                key={action}
                                variant="outline"
                                size="sm"
                                className="w-full text-xs"
                                onClick={() => executeIntegration(platform.id, action)}
                              >
                                {action}
                              </Button>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Hidden file inputs */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={handleFileUpload}
      />
      <input
        ref={bulkFileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={handleBulkUpload}
      />

      {/* File Preview Dialog */}
      <FilePreview />

      {/* Task Attachment Dialog */}
      <Dialog open={isTaskDialogOpen} onOpenChange={setIsTaskDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Attach Task to File</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Task title (e.g., Review Proposal.pdf by Thursday)"
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
            />
            <div className="grid grid-cols-2 gap-4">
              <Select value={taskPriority} onValueChange={(value: FileTask['priority']) => setTaskPriority(value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
              <Input
                type="date"
                value={taskDueDate}
                onChange={(e) => setTaskDueDate(e.target.value)}
              />
            </div>
            <Input
              placeholder="Assign to..."
              value={taskAssignedTo}
              onChange={(e) => setTaskAssignedTo(e.target.value)}
            />
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsTaskDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={attachTaskToFile}>
                Attach Task
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Node Selector Dialog */}
      <Dialog open={isNodeSelectorOpen} onOpenChange={setIsNodeSelectorOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Select Node Context</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {nodes.map(node => (
              <Button
                key={node.id}
                variant={selectedNodeId === node.id ? "default" : "outline"}
                className="w-full justify-start"
                onClick={() => {
                  setSelectedNodeId(node.id);
                  setSelectedNode(node);
                  setIsNodeSelectorOpen(false);
                }}
              >
                {node.title}
              </Button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Enhanced Bulk Upload Dialog */}
      <Dialog open={isBulkUploadOpen} onOpenChange={setIsBulkUploadOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="text-lg">
              Upload File {currentBulkFileIndex + 1} of {bulkFileData.length}
            </DialogTitle>
            <p className="text-xs text-muted-foreground">
              Configure tags and linking for each file
            </p>
          </DialogHeader>
          
          {bulkFileData.length > 0 && bulkFileData[currentBulkFileIndex] && (
            <div className="space-y-3 max-h-[60vh] overflow-y-auto">
              {/* Progress Indicator */}
              <div className="w-full bg-gray-200 rounded-full h-1">
                <div 
                  className="bg-blue-600 h-1 rounded-full transition-all duration-300" 
                  style={{ width: `${((currentBulkFileIndex + 1) / bulkFileData.length) * 100}%` }}
                ></div>
              </div>

              {/* Current File Info */}
              <div className="border rounded p-2 bg-blue-50">
                <div className="flex items-center gap-2">
                  <File className="h-6 w-6 text-blue-600" />
                  <div>
                    <p className="font-medium text-sm">{bulkFileData[currentBulkFileIndex].file.name}</p>
                    <p className="text-xs text-gray-600">
                      {(bulkFileData[currentBulkFileIndex].file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
              </div>

              {/* File Description */}
              <div>
                <label className="text-xs font-medium mb-1 block">Description</label>
                <Input
                  className="h-8"
                  value={bulkFileData[currentBulkFileIndex].description}
                  onChange={(e) => {
                    const newData = [...bulkFileData];
                    newData[currentBulkFileIndex].description = e.target.value;
                    setBulkFileData(newData);
                  }}
                  placeholder="Brief description..."
                />
              </div>

              {/* Predefined Tags */}
              <div>
                <label className="text-xs font-medium mb-1 block">Tags</label>
                <div className="flex flex-wrap gap-1 mb-2">
                  {predefinedTags.slice(0, 8).map((tag) => (
                    <button
                      key={tag.value}
                      onClick={() => {
                        const newData = [...bulkFileData];
                        const currentTags = newData[currentBulkFileIndex].tags;
                        if (currentTags.includes(tag.value)) {
                          newData[currentBulkFileIndex].tags = currentTags.filter(t => t !== tag.value);
                        } else {
                          newData[currentBulkFileIndex].tags = [...currentTags, tag.value];
                        }
                        setBulkFileData(newData);
                      }}
                      className={`px-2 py-0.5 rounded text-xs font-medium border transition-colors ${
                        bulkFileData[currentBulkFileIndex].tags.includes(tag.value)
                          ? tag.color
                          : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                      }`}
                    >
                      {tag.label}
                    </button>
                  ))}
                </div>
                <Input
                  className="h-7"
                  value={bulkFileData[currentBulkFileIndex].customTags}
                  onChange={(e) => {
                    const newData = [...bulkFileData];
                    newData[currentBulkFileIndex].customTags = e.target.value;
                    setBulkFileData(newData);
                  }}
                  placeholder="Custom tags (comma-separated)"
                />
              </div>

              {/* Link to Nodes */}
              <div>
                <label className="text-xs font-medium mb-1 block">Link to Nodes</label>
                <div className="border rounded p-2 max-h-32 overflow-y-auto bg-gray-50">
                  <div className="space-y-1">
                    {nodes.slice(0, 6).map((node) => (
                      <div key={node.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`bulk-node-${node.id}`}
                          checked={bulkFileData[currentBulkFileIndex].linkedNodes.includes(node.id)}
                          onCheckedChange={(checked) => {
                            const newData = [...bulkFileData];
                            if (checked) {
                              newData[currentBulkFileIndex].linkedNodes = [
                                ...newData[currentBulkFileIndex].linkedNodes, 
                                node.id
                              ];
                            } else {
                              newData[currentBulkFileIndex].linkedNodes = 
                                newData[currentBulkFileIndex].linkedNodes.filter(id => id !== node.id);
                            }
                            setBulkFileData(newData);
                          }}
                        />
                        <label htmlFor={`bulk-node-${node.id}`} className="text-xs cursor-pointer flex-1">
                          {node.title}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Navigation and Actions */}
              <div className="flex justify-between items-center pt-3 border-t bg-white sticky bottom-0">
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    disabled={currentBulkFileIndex === 0}
                    onClick={() => setCurrentBulkFileIndex(prev => Math.max(0, prev - 1))}
                  >
                    Previous
                  </Button>
                  <Button 
                    variant="outline"
                    size="sm"
                    disabled={currentBulkFileIndex === bulkFileData.length - 1}
                    onClick={() => setCurrentBulkFileIndex(prev => Math.min(bulkFileData.length - 1, prev + 1))}
                  >
                    Next
                  </Button>
                </div>
                
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => {
                    setIsBulkUploadOpen(false);
                    setBulkFileData([]);
                    setBulkUploadFiles([]);
                    setCurrentBulkFileIndex(0);
                  }}>
                    Cancel
                  </Button>
                  <Button size="sm" onClick={processBulkFileData}>
                    Upload
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Detailed Upload Dialog */}
      <Dialog open={showDetailedUpload} onOpenChange={setShowDetailedUpload}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Upload File with Detailed Tagging</DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            {bulkUploadFiles[0] && (
              <div className="border rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <File className="h-8 w-8 text-blue-500" />
                  <div>
                    <p className="font-medium">{bulkUploadFiles[0].name}</p>
                    <p className="text-sm text-gray-500">{(bulkUploadFiles[0].size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                </div>
              </div>
            )}

            <div>
              <label className="text-sm font-medium">File Description</label>
              <Input
                value={fileDescription}
                onChange={(e) => setFileDescription(e.target.value)}
                placeholder="Brief description of this file..."
                className="mt-1"
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-3 block">Suggested Tags</label>
              <div className="flex flex-wrap gap-2 mb-3">
                {predefinedTags.map((tag) => (
                  <button
                    key={tag.value}
                    onClick={() => {
                      if (uploadTags.includes(tag.value)) {
                        setUploadTags(prev => prev.filter(t => t !== tag.value));
                      } else {
                        setUploadTags(prev => [...prev, tag.value]);
                      }
                    }}
                    className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                      uploadTags.includes(tag.value) 
                        ? tag.color 
                        : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                    }`}
                  >
                    {tag.label}
                  </button>
                ))}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Custom Tags (comma-separated)</label>
                <Input
                  value={customTags}
                  onChange={(e) => setCustomTags(e.target.value)}
                  placeholder="urgent, client-review, final-version"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-3 block">Link to Nodes</label>
              <div className="border rounded-lg p-3 max-h-40 overflow-y-auto">
                <div className="space-y-2">
                  {nodes.map((node) => (
                    <div key={node.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`node-${node.id}`}
                        checked={selectedLinkedNodes.includes(node.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedLinkedNodes(prev => [...prev, node.id]);
                          } else {
                            setSelectedLinkedNodes(prev => prev.filter(id => id !== node.id));
                          }
                        }}
                      />
                      <label htmlFor={`node-${node.id}`} className="text-sm cursor-pointer">
                        {node.title}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowDetailedUpload(false)}>
                Cancel
              </Button>
              <Button onClick={handleDetailedUpload}>
                Upload with Tags & Links
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* File Link Dialog */}
      <Dialog open={showFileLinkDialog} onOpenChange={setShowFileLinkDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Link File to Nodes</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {currentFileForLinking && (
              <div className="border rounded-lg p-3">
                <div className="flex items-center gap-3">
                  <File className="h-6 w-6 text-blue-500" />
                  <span className="font-medium">{currentFileForLinking.name}</span>
                </div>
              </div>
            )}

            <div>
              <label className="text-sm font-medium mb-3 block">Select Nodes to Link</label>
              <div className="border rounded-lg p-3 max-h-60 overflow-y-auto">
                <div className="space-y-2">
                  {nodes.map((node) => (
                    <div key={node.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`link-node-${node.id}`}
                        checked={currentFileForLinking?.linkedNodes.includes(node.id)}
                        onCheckedChange={(checked) => {
                          if (checked && currentFileForLinking) {
                            linkFileToNode(currentFileForLinking.id, node.id);
                          }
                        }}
                      />
                      <label htmlFor={`link-node-${node.id}`} className="text-sm cursor-pointer">
                        {node.title}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <Button onClick={() => setShowFileLinkDialog(false)}>
                Done
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      {/* Create Custom Smart Folder Dialog */}
      <Dialog open={isCreateFolderOpen} onOpenChange={setIsCreateFolderOpen}>
        <DialogContent className="sm:max-w-[500px]" aria-describedby="create-folder-description">
          <DialogHeader>
            <DialogTitle>Create Custom Smart Folder</DialogTitle>
            <p id="create-folder-description" className="text-sm text-muted-foreground">
              Create a smart folder that automatically organizes files based on your criteria
            </p>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Folder Name</label>
              <Input
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                placeholder="e.g., Client Documents, Design Assets"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">File Type Filter</label>
              <Select value={newFolderFileType} onValueChange={setNewFolderFileType}>
                <SelectTrigger>
                  <SelectValue placeholder="All file types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All file types</SelectItem>
                  <SelectItem value="pdf">PDF Documents</SelectItem>
                  <SelectItem value="image">Images (JPG, PNG, etc.)</SelectItem>
                  <SelectItem value="video">Videos</SelectItem>
                  <SelectItem value="doc,docx">Word Documents</SelectItem>
                  <SelectItem value="xls,xlsx">Spreadsheets</SelectItem>
                  <SelectItem value="ppt,pptx">Presentations</SelectItem>
                  <SelectItem value="zip,rar">Archives</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Tag Filters</label>
              <Input
                value={newFolderTags}
                onChange={(e) => setNewFolderTags(e.target.value)}
                placeholder="urgent, client, design (comma-separated)"
              />
              <p className="text-xs text-muted-foreground">
                Files with these tags will be automatically included
              </p>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Folder Color</label>
              <div className="flex gap-2">
                {[
                  'bg-blue-500',
                  'bg-green-500', 
                  'bg-purple-500',
                  'bg-orange-500',
                  'bg-red-500',
                  'bg-yellow-500',
                  'bg-pink-500',
                  'bg-gray-500'
                ].map((color) => (
                  <div
                    key={color}
                    onClick={() => setNewFolderColor(color)}
                    className={`w-6 h-6 rounded cursor-pointer border-2 ${color} ${
                      newFolderColor === color ? 'border-primary' : 'border-transparent'
                    }`}
                  />
                ))}
              </div>
            </div>
            
            <div className="flex justify-end gap-2 pt-4">
              <Button 
                variant="outline" 
                onClick={() => {
                  setIsCreateFolderOpen(false);
                  setNewFolderName('');
                  setNewFolderTags('');
                  setNewFolderFileType('');
                  setNewFolderColor('bg-blue-500');
                }}
              >
                Cancel
              </Button>
              <Button onClick={createCustomFolder}>
                Create Smart Folder
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}