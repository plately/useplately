import GraphProfiles from "./graph-profiles";

export default function Graph() {
  return <GraphProfiles />;
}