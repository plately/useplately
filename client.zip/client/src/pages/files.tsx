import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { 
  Upload, 
  Search, 
  MoreVertical, 
  Download, 
  Share2,
  Link as LinkIcon, 
  Eye,
  Trash2,
  File,
  Image,
  Video,
  FileText,
  Music,
  Paperclip,
  MessageSquare,
  GitBranch,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Files() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFile, setSelectedFile] = useState<any>(null);
  const [linkDialogOpen, setLinkDialogOpen] = useState(false);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [selectedNodeId, setSelectedNodeId] = useState("");
  const [selectedChannelId, setSelectedChannelId] = useState("");
  const [shareMessage, setShareMessage] = useState("");
  const [linkedFiles, setLinkedFiles] = useState<Set<number>>(new Set());
  const [sharedFiles, setSharedFiles] = useState<Set<number>>(new Set());
  
  const queryClient = useQueryClient();


  // Fetch files
  const { data: files = [], isLoading: filesLoading } = useQuery({
    queryKey: ["/api/files"],
  });

  // Fetch nodes for linking
  const { data: nodes = [] } = useQuery({
    queryKey: ["/api/nodes"],
  });

  // Fetch channels for sharing
  const { data: channels = [] } = useQuery({
    queryKey: ["/api/spaces/1/channels"],
  });

  // Link file to node mutation
  const linkMutation = useMutation({
    mutationFn: async ({ fileId, nodeId }: { fileId: number; nodeId: number }) => {
      const response = await apiRequest("/api/file-node-links", {
        method: "POST",
        body: { fileId, nodeId, linkType: "attachment" }
      });
      return response;
    },
    onSuccess: (data, variables) => {
      setLinkedFiles(prev => new Set([...prev, variables.fileId]));
      toast({
        title: "✅ Success!",
        description: `File linked to node in the knowledge graph`,
      });
      setLinkDialogOpen(false);
      setSelectedNodeId("");
      queryClient.invalidateQueries({ queryKey: ["/api/node-links"] });
    },
    onError: (error) => {
      console.error("Link error:", error);
      toast({
        title: "❌ Error",
        description: "Failed to link file to node",
        variant: "destructive",
      });
    },
  });

  // Share file in chat mutation
  const shareMutation = useMutation({
    mutationFn: async ({ fileId, channelId, message }: { fileId: number; channelId: number; message: string }) => {
      const response = await apiRequest("/api/notify-file-upload", {
        method: "POST",
        body: { fileId, channelId, message }
      });
      return response;
    },
    onSuccess: (data, variables) => {
      setSharedFiles(prev => new Set([...prev, variables.fileId]));
      toast({
        title: "✅ Shared!",
        description: "File shared in team chat successfully",
      });
      setShareDialogOpen(false);
      setSelectedChannelId("");
      setShareMessage("");
    },
    onError: (error) => {
      console.error("Share error:", error);
      toast({
        title: "❌ Error",
        description: "Failed to share file in chat",
        variant: "destructive",
      });
    },
  });

  // Handle link to node
  const handleLinkToNode = () => {
    if (!selectedFile || !selectedNodeId) {
      toast({
        title: "Please select a node",
        description: "Choose a node to link this file to",
        variant: "destructive",
      });
      return;
    }
    
    linkMutation.mutate({
      fileId: selectedFile.id,
      nodeId: parseInt(selectedNodeId),
    });
  };

  // Handle share in chat
  const handleShareInChat = () => {
    if (!selectedFile || !selectedChannelId) {
      toast({
        title: "Please select a channel",
        description: "Choose a channel to share this file in",
        variant: "destructive",
      });
      return;
    }
    
    shareMutation.mutate({
      fileId: selectedFile.id,
      channelId: parseInt(selectedChannelId),
      message: shareMessage || `📎 ${selectedFile.name} has been shared`,
    });
  };

  // Filter files
  const filteredFiles = files.filter((file: any) => 
    file.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getFileIcon = (mimeType: string) => {
    if (mimeType?.startsWith("image/")) return <Image className="w-4 h-4" style={{ color: "#38bdf8" }} />;
    if (mimeType?.startsWith("video/")) return <Video className="w-4 h-4" style={{ color: "#a78bfa" }} />;
    if (mimeType?.startsWith("audio/")) return <Music className="w-4 h-4" style={{ color: "#34d399" }} />;
    if (mimeType?.includes("pdf")) return <FileText className="w-4 h-4" style={{ color: "#fb923c" }} />;
    return <File className="w-4 h-4" style={{ color: "#818cf8" }} />;
  };

  const getFileAccent = (mimeType: string) => {
    if (mimeType?.startsWith("image/")) return "#38bdf8";
    if (mimeType?.startsWith("video/")) return "#a78bfa";
    if (mimeType?.startsWith("audio/")) return "#34d399";
    if (mimeType?.includes("pdf")) return "#fb923c";
    return "#818cf8";
  };

  // Format file size
  const formatFileSize = (bytes: number) => {
    if (!bytes) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return (bytes / Math.pow(k, i)).toFixed(1) + " " + sizes[i];
  };

  if (filesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0a0a0a" }}>
        <div className="w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const cardStyle = { background: "#111", border: "1px solid rgba(255,255,255,0.07)" };
  const dialogStyle = { background: "#111", border: "1px solid rgba(255,255,255,0.1)" };

  return (
    <div className="min-h-screen p-5 sm:p-6" style={{ background: "#0a0a0a" }}>
      <div className="max-w-6xl mx-auto space-y-5">

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-white tracking-tight">Files</h1>
            <p className="text-sm text-white/30 mt-0.5">{files.length} file{files.length !== 1 ? "s" : ""} in your workspace</p>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/25" />
            <Input
              placeholder="Search files…"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 h-9 w-full sm:w-56 text-sm text-white/70 placeholder:text-white/25 rounded-lg"
              style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
            />
          </div>
        </div>

        {/* Files Grid */}
        {filteredFiles.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredFiles.map((file: any) => {
              const isLinked = linkedFiles.has(file.id);
              const isShared = sharedFiles.has(file.id);
              const accent = getFileAccent(file.mimeType);
              return (
                <div
                  key={file.id}
                  className="rounded-xl p-4 flex flex-col gap-3 hover:border-white/[0.12] transition-colors"
                  style={cardStyle}
                >
                  {/* File header */}
                  <div className="flex items-start gap-3">
                    <div
                      className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ background: `${accent}18` }}
                    >
                      {getFileIcon(file.mimeType)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white/80 truncate" title={file.name}>{file.name}</p>
                      <p className="text-xs text-white/30 mt-0.5">{formatFileSize(file.size)} · {new Date(file.createdAt).toLocaleDateString()}</p>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button
                          className="w-7 h-7 rounded-md flex items-center justify-center text-white/30 hover:text-white hover:bg-white/[0.06] transition-colors flex-shrink-0"
                        >
                          <MoreVertical className="w-3.5 h-3.5" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="glass-dropdown text-sm">
                        <DropdownMenuItem onClick={() => setSelectedFile(file)} className="gap-2 text-white/70 focus:text-white focus:bg-white/[0.06]">
                          <Eye className="w-3.5 h-3.5" /> Preview
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => { setSelectedFile(file); setLinkDialogOpen(true); }} className="gap-2 text-white/70 focus:text-white focus:bg-white/[0.06]">
                          <LinkIcon className="w-3.5 h-3.5" /> Link to Node
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => { setSelectedFile(file); setShareDialogOpen(true); }} className="gap-2 text-white/70 focus:text-white focus:bg-white/[0.06]">
                          <Share2 className="w-3.5 h-3.5" /> Share in Chat
                        </DropdownMenuItem>
                        <DropdownMenuItem className="gap-2 text-white/70 focus:text-white focus:bg-white/[0.06]">
                          <Download className="w-3.5 h-3.5" /> Download
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  {/* Status badges */}
                  {(isLinked || isShared) && (
                    <div className="flex gap-2 flex-wrap">
                      {isLinked && (
                        <span className="flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full" style={{ background: "rgba(129,140,248,0.12)", color: "#818cf8" }}>
                          <GitBranch className="w-2.5 h-2.5" /> Linked to graph
                        </span>
                      )}
                      {isShared && (
                        <span className="flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full" style={{ background: "rgba(52,211,153,0.12)", color: "#34d399" }}>
                          <MessageSquare className="w-2.5 h-2.5" /> Shared in chat
                        </span>
                      )}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2 mt-auto">
                    <button
                      onClick={() => { setSelectedFile(file); setLinkDialogOpen(true); }}
                      disabled={linkMutation.isPending}
                      className="flex-1 flex items-center justify-center gap-1.5 text-xs font-medium py-2 rounded-lg transition-colors"
                      style={isLinked
                        ? { background: "rgba(129,140,248,0.12)", color: "#818cf8", border: "1px solid rgba(129,140,248,0.2)" }
                        : { background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.5)", border: "1px solid rgba(255,255,255,0.07)" }}
                    >
                      <LinkIcon className="w-3 h-3" />
                      {isLinked ? "Linked" : "Link to Graph"}
                    </button>
                    <button
                      onClick={() => { setSelectedFile(file); setShareDialogOpen(true); }}
                      disabled={shareMutation.isPending}
                      className="flex-1 flex items-center justify-center gap-1.5 text-xs font-medium py-2 rounded-lg transition-colors"
                      style={isShared
                        ? { background: "rgba(52,211,153,0.12)", color: "#34d399", border: "1px solid rgba(52,211,153,0.2)" }
                        : { background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.5)", border: "1px solid rgba(255,255,255,0.07)" }}
                    >
                      <Share2 className="w-3 h-3" />
                      {isShared ? "Shared" : "Share"}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4" style={{ background: "rgba(129,140,248,0.1)" }}>
              <File className="w-6 h-6 text-indigo-400" />
            </div>
            <p className="text-sm font-medium text-white/40">No files found</p>
            <p className="text-xs text-white/20 mt-1">Upload files to see them here</p>
          </div>
        )}
      </div>

      {/* File Preview Dialog */}
      {selectedFile && !linkDialogOpen && !shareDialogOpen && (
        <Dialog open={!!selectedFile} onOpenChange={() => setSelectedFile(null)}>
          <DialogContent className="w-[95vw] max-w-4xl" style={dialogStyle}>
            <DialogHeader>
              <DialogTitle className="text-white text-base">{selectedFile.name}</DialogTitle>
            </DialogHeader>
            <div className="mt-4">
              <div className="flex items-center justify-center h-80 rounded-xl overflow-hidden" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                {selectedFile.mimeType?.startsWith("image/") ? (
                  <img src={selectedFile.url} alt={selectedFile.name} className="max-h-full max-w-full object-contain rounded-lg" />
                ) : selectedFile.mimeType?.startsWith("video/") ? (
                  <video src={selectedFile.url} controls className="max-h-full max-w-full rounded-lg" />
                ) : selectedFile.mimeType === "application/pdf" ? (
                  <iframe src={selectedFile.url} className="w-full h-full rounded-lg" title={selectedFile.name} />
                ) : (
                  <div className="text-center text-white/40">
                    <File className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p className="text-sm mb-4">Preview not available</p>
                    <button
                      onClick={() => window.open(selectedFile.url, '_blank')}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium bg-indigo-600 hover:bg-indigo-500 text-white transition-colors mx-auto"
                    >
                      <Download className="w-4 h-4" /> Download to view
                    </button>
                  </div>
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Link to Node Dialog */}
      <Dialog open={linkDialogOpen} onOpenChange={setLinkDialogOpen}>
        <DialogContent style={dialogStyle}>
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2 text-base">
              <GitBranch className="w-4 h-4 text-indigo-400" /> Link to Knowledge Graph
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <p className="text-sm text-white/40">
              Connect <span className="text-white/70 font-medium">{selectedFile?.name}</span> to a node
            </p>
            <div>
              <Label className="text-xs text-white/40 uppercase tracking-widest font-medium">Select Node</Label>
              <Select value={selectedNodeId} onValueChange={setSelectedNodeId}>
                <SelectTrigger className="mt-2 h-10 text-sm text-white/70" style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)" }}>
                  <SelectValue placeholder="Choose a node…" />
                </SelectTrigger>
                <SelectContent className="glass-dropdown">
                  {nodes.map((node: any) => (
                    <SelectItem key={node.id} value={node.id.toString()}>
                      <span className="text-white/60">{node.nodeType} — </span>{node.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button onClick={() => setLinkDialogOpen(false)} className="px-3 py-2 text-sm text-white/40 hover:text-white/70 transition-colors rounded-lg" style={{ border: "1px solid rgba(255,255,255,0.07)" }}>
                Cancel
              </button>
              <button onClick={handleLinkToNode} disabled={linkMutation.isPending} className="px-4 py-2 text-sm font-medium rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors flex items-center gap-2">
                {linkMutation.isPending && <div className="w-3.5 h-3.5 border border-white/30 border-t-white rounded-full animate-spin" />}
                <LinkIcon className="w-3.5 h-3.5" /> Link to Graph
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Share in Chat Dialog */}
      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent style={dialogStyle}>
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2 text-base">
              <MessageSquare className="w-4 h-4 text-indigo-400" /> Share in Team Chat
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <p className="text-sm text-white/40">
              Share <span className="text-white/70 font-medium">{selectedFile?.name}</span> with your team
            </p>
            <div>
              <Label className="text-xs text-white/40 uppercase tracking-widest font-medium">Channel</Label>
              <Select value={selectedChannelId} onValueChange={setSelectedChannelId}>
                <SelectTrigger className="mt-2 h-10 text-sm text-white/70" style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)" }}>
                  <SelectValue placeholder="Choose a channel…" />
                </SelectTrigger>
                <SelectContent className="glass-dropdown">
                  {channels.map((channel: any) => (
                    <SelectItem key={channel.id} value={channel.id.toString()}>
                      # {channel.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-white/40 uppercase tracking-widest font-medium">Message (optional)</Label>
              <Textarea
                value={shareMessage}
                onChange={(e) => setShareMessage(e.target.value)}
                placeholder="Add a note with the file…"
                className="mt-2 text-sm text-white/70 placeholder:text-white/20 resize-none"
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)" }}
                rows={3}
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button onClick={() => setShareDialogOpen(false)} className="px-3 py-2 text-sm text-white/40 hover:text-white/70 transition-colors rounded-lg" style={{ border: "1px solid rgba(255,255,255,0.07)" }}>
                Cancel
              </button>
              <button onClick={handleShareInChat} disabled={shareMutation.isPending} className="px-4 py-2 text-sm font-medium rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors flex items-center gap-2">
                {shareMutation.isPending && <div className="w-3.5 h-3.5 border border-white/30 border-t-white rounded-full animate-spin" />}
                <Share2 className="w-3.5 h-3.5" /> Share
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}