import React, { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { consumeDeepLink } from '@/lib/deep-link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { apiRequest } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';
import { 
  Search, 
  Filter, 
  Plus, 
  MoreHorizontal, 
  Calendar,
  Users,
  BarChart3,
  Kanban,
  List,
  Play,
  Check,
  Pause,
  RotateCcw,
  XCircle,
  Clock,
  AlertTriangle,
  ListFilter,
  TrendingUp,
  Target,
  Activity,
  CheckCircle,
  Archive,
  ChevronDown,
  ChevronRight
} from 'lucide-react';
import AdvancedTaskForm from '@/components/advanced-task-form';
import UniversalNodeCreator from '@/components/universal-node-creator';
import ModernKanban from '@/components/modern-kanban';
import { Node } from '@shared/schema';

// Define the Task interface properly
interface TaskNode {
  id: number;
  title: string;
  content: string;
  nodeType: string;
  status: "todo" | "in-progress" | "done" | "blocked" | "saved" | "archived";
  assignee?: number;
  priority: "low" | "medium" | "high" | "critical";
  dueDate?: string;
  tags: string[];
  createdAt: Date;
  assignedUser?: {
    id: number;
    displayName: string;
    avatar?: string;
  };
  previousStatus?: string;
}

export default function Tasks() {
  const [view, setView] = useState<"kanban" | "list" | "timeline" | "analytics">("kanban");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [selectedTask, setSelectedTask] = useState<TaskNode | null>(null);
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [calendarView, setCalendarView] = useState<"week" | "month">("week");
  const [weekStart, setWeekStart] = useState<Date>(() => {
    const d = new Date();
    d.setDate(d.getDate() - d.getDay());
    d.setHours(0, 0, 0, 0);
    return d;
  });
  const [showArchived, setShowArchived] = useState(false);
  const queryClient = useQueryClient();

  // Fetch all nodes that are tasks
  const { data: nodes = [], isLoading } = useQuery<Node[]>({
    queryKey: ['/api/nodes'],
  });

  // Helper: open task panel by id (shared by both deep-link paths)
  const openTaskById = useRef<(id: number) => void>(() => {});
  openTaskById.current = (id: number) => {
    const found = nodes.find(n => n.id === id && n.nodeType === "task");
    if (!found) return;
    const props = (found.properties as any) || {};
    setSelectedTask({
      id: found.id,
      title: found.title,
      content: found.content || "",
      nodeType: found.nodeType,
      status: props.status || "todo",
      assignee: props.assignedTo ? 1 : undefined,
      priority: props.priority || "medium",
      dueDate: props.dueDate,
      tags: found.tags || [],
      createdAt: new Date(found.createdAt),
      assignedUser: props.assignedTo ? { id: 1, displayName: props.assignedTo, avatar: undefined } : undefined,
    });
  };

  // Deep-link on mount / when data loads (navigating FROM another page)
  useEffect(() => {
    if (isLoading) return;
    const link = consumeDeepLink();
    if (!link || link.type !== "task") return;
    openTaskById.current(link.id);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoading]);

  // Deep-link via event (already on this page when search fires)
  useEffect(() => {
    const handler = (e: Event) => {
      const link = (e as CustomEvent).detail;
      if (!link || link.type !== "task") return;
      consumeDeepLink(); // clear the store
      openTaskById.current(link.id);
    };
    window.addEventListener("desq:deeplink", handler);
    return () => window.removeEventListener("desq:deeplink", handler);
  }, []);

  // Transform nodes to task format, filtering only task type nodes
  const taskNodes = nodes.filter(node => node.nodeType === 'task');

  // Transform nodes to task format
  const realTasks: TaskNode[] = nodes
    .filter(node => node.nodeType === 'task')
    .map(node => {
      const props = node.properties as any || {};
      return {
        id: node.id,
        title: node.title,
        content: node.content || '',
        nodeType: node.nodeType,
        status: props.status || "todo",
        assignee: props.assignedTo ? 1 : undefined,
        priority: props.priority || "medium",
        dueDate: props.dueDate,
        tags: node.tags || [],
        createdAt: new Date(node.createdAt),
        assignedUser: props.assignedTo ? {
          id: 1,
          displayName: props.assignedTo,
          avatar: undefined
        } : undefined,
        previousStatus: props.previousStatus
      };
    });

  // Add demo tasks for better showcase when no real tasks exist
  const demoTasks: TaskNode[] = realTasks.length === 0 ? [
    {
      id: 999,
      title: "Design new dashboard UI",
      content: "Create wireframes and mockups for the updated dashboard interface",
      nodeType: "task",
      status: "in-progress",
      assignee: 1,
      priority: "high",
      dueDate: "2025-01-15",
      tags: ["design", "ui"],
      createdAt: new Date("2024-12-20"),
      assignedUser: {
        id: 1,
        displayName: "Sarah Chen",
        avatar: undefined
      }
    },
    {
      id: 998,
      title: "Implement user authentication",
      content: "Set up OAuth integration and session management",
      nodeType: "task", 
      status: "todo",
      assignee: 2,
      priority: "critical",
      dueDate: "2025-01-10",
      tags: ["backend", "security"],
      createdAt: new Date("2024-12-18"),
      assignedUser: {
        id: 2,
        displayName: "Alex Kumar",
        avatar: undefined
      }
    }
  ] : [];

  const tasks = [...realTasks, ...demoTasks];

  // Separate active and archived tasks
  const activeTasks = tasks.filter(task => task.status !== 'archived');
  const archivedTasks = tasks.filter(task => task.status === 'archived');

  // Filter active tasks
  const filteredTasks = activeTasks.filter(task => {
    const matchesSearch = searchQuery === "" || 
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.content.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === "all" 
      ? true 
      : task.status === statusFilter;
    
    const matchesPriority = priorityFilter !== "all" 
      ? task.priority === priorityFilter 
      : true;
    
    return matchesSearch && matchesStatus && matchesPriority;
  });

  // Filter archived tasks
  const filteredArchivedTasks = archivedTasks.filter(task => {
    const matchesSearch = searchQuery === "" || 
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.content.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesPriority = priorityFilter !== "all" 
      ? task.priority === priorityFilter 
      : true;
    
    return matchesSearch && matchesPriority;
  });

  // Group tasks by status
  const todoTasks = filteredTasks.filter(task => task.status === "todo");
  const inProgressTasks = filteredTasks.filter(task => task.status === "in-progress");
  const doneTasks = filteredTasks.filter(task => task.status === "done");
  const blockedTasks = filteredTasks.filter(task => task.status === "blocked");
  const savedTasks = filteredTasks.filter(task => task.status === "saved");

  // Calendar helper functions
  const getCalendarDays = () => {
    const firstDay = new Date(currentYear, currentMonth, 1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    const startDate = new Date(firstDay);
    const endDate = new Date(lastDay);
    
    // Get the first Sunday before or on the first day of the month
    startDate.setDate(startDate.getDate() - startDate.getDay());
    
    // Get the last Saturday after or on the last day of the month
    endDate.setDate(endDate.getDate() + (6 - endDate.getDay()));
    
    const days = [];
    const currentDate = new Date(startDate);
    
    while (currentDate <= endDate) {
      days.push(new Date(currentDate));
      currentDate.setDate(currentDate.getDate() + 1);
    }
    
    return days;
  };

  const getTasksForDate = (date: Date) => {
    if (!date) return [];
    return filteredTasks.filter(task => {
      const taskDate = task.dueDate ? new Date(task.dueDate) : new Date(task.createdAt);
      return taskDate.toDateString() === date.toDateString();
    });
  };

  const getWeekDays = (start: Date): Date[] => {
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      return d;
    });
  };

  const navigateWeek = (dir: number) => {
    setWeekStart(prev => {
      const d = new Date(prev);
      d.setDate(d.getDate() + dir * 7);
      return d;
    });
  };

  const goToToday = () => {
    const d = new Date();
    d.setDate(d.getDate() - d.getDay());
    d.setHours(0, 0, 0, 0);
    setWeekStart(d);
    setCurrentMonth(new Date().getMonth());
    setCurrentYear(new Date().getFullYear());
  };

  const weekDays = getWeekDays(weekStart);
  const weekEnd = weekDays[6];
  const weekLabel = weekStart.getMonth() === weekEnd.getMonth()
    ? `${weekStart.toLocaleDateString('en-US', { month: 'long' })} ${weekStart.getDate()}–${weekEnd.getDate()}, ${weekStart.getFullYear()}`
    : `${weekStart.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} – ${weekEnd.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;

  const priorityDot: Record<string, string> = {
    critical: "bg-red-500",
    high: "bg-orange-400",
    medium: "bg-yellow-400",
    low: "bg-green-500",
  };

  const statusLabel: Record<string, { label: string; cls: string }> = {
    "todo":        { label: "Todo",        cls: "bg-muted text-muted-foreground" },
    "in-progress": { label: "In Progress", cls: "bg-blue-500/15 text-blue-500" },
    "done":        { label: "Done",        cls: "bg-green-500/15 text-green-600" },
    "blocked":     { label: "Blocked",     cls: "bg-red-500/15 text-red-500" },
  };

  // Mutation to update task status
  const updateTaskStatus = useMutation({
    mutationFn: async ({ taskId, status }: { taskId: number, status: string }) => {
      return await apiRequest(`/api/nodes/${taskId}`, {
        method: 'PATCH',
        body: JSON.stringify({
          properties: { status }
        })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/nodes'] });
      toast({
        title: "Task updated",
        description: "Task status has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: "Failed to update task status.",
        variant: "destructive",
      });
    },
  });

  // Mutation to archive/unarchive tasks
  const archiveTask = useMutation({
    mutationFn: async ({ taskId, archive, currentStatus }: { taskId: number, archive: boolean, currentStatus?: string }) => {
      const task = tasks.find(t => t.id === taskId);
      const taskProps = nodes.find(n => n.id === taskId)?.properties as any || {};
      
      return await apiRequest(`/api/nodes/${taskId}`, {
        method: 'PATCH',
        body: JSON.stringify({
          properties: { 
            status: archive ? 'archived' : (taskProps.previousStatus || 'todo'),
            previousStatus: archive ? (task?.status || 'done') : undefined
          }
        })
      });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/nodes'] });
      toast({
        title: variables.archive ? "Task archived" : "Task restored",
        description: variables.archive 
          ? "Task has been moved to the archive." 
          : "Task has been restored to your active tasks.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: "Failed to archive/restore task.",
        variant: "destructive",
      });
    },
  });

  // Get priority color
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical": return "bg-red-500";
      case "high": return "bg-orange-500";
      case "medium": return "bg-yellow-500";
      case "low": return "bg-green-500";
      default: return "bg-gray-500";
    }
  };

  // Get node type color with priority
  const getNodeTypeColor = (nodeType: string, priority: string) => {
    const baseColors = {
      task: "bg-green-500",
      journal: "bg-blue-500",
      meeting: "bg-purple-500",
      document: "bg-orange-500",
      note: "bg-indigo-500",
      integration: "bg-pink-500"
    };
    
    if (priority === "critical") return "bg-red-500";
    if (priority === "high") return "bg-orange-500";
    
    return baseColors[nodeType as keyof typeof baseColors] || "bg-gray-500";
  };

  // Get status badge variant
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "todo": return "secondary";
      case "in-progress": return "default";
      case "done": return "default";
      case "blocked": return "destructive";
      default: return "secondary";
    }
  };





  return (
    <div className="h-full flex flex-col overflow-hidden bg-background">
      {/* Mobile-optimized Header with controls */}
      <div className="flex-shrink-0 border-b bg-background p-2 sm:p-3">
        <div className="flex flex-col gap-2 sm:gap-3">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-wrap">
            <h1 className="text-lg sm:text-xl font-semibold whitespace-nowrap">Tasks</h1>
            
            {/* Mobile search - always visible on mobile */}
            <div className="relative flex-1 sm:flex-initial">
              <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-3 w-3 text-muted-foreground" />
              <Input
                placeholder="Search tasks..."
                className="pl-8 w-full sm:w-32 md:w-48 h-8 text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            {/* Mobile-optimized Filters */}
            <div className="flex gap-1 sm:gap-2 flex-wrap w-full sm:w-auto">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-16 sm:w-20 md:w-28 h-8 text-xs sm:text-sm">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="todo">To Do</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="done">Done</SelectItem>
                  <SelectItem value="blocked">Blocked</SelectItem>
                  <SelectItem value="saved">Save for Later</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                <SelectTrigger className="w-16 sm:w-20 md:w-28 h-8 text-xs sm:text-sm">
                  <SelectValue placeholder="Priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Priority</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex items-center gap-1 sm:gap-2 flex-wrap justify-between sm:justify-end">
            {/* Mobile-optimized View toggles */}
            <div className="flex bg-muted rounded-md p-0.5 sm:p-1 w-full sm:w-auto justify-between sm:justify-start">
              <Button
                variant={view === "kanban" ? "default" : "ghost"}
                size="sm"
                onClick={() => setView("kanban")}
                className="h-6 sm:h-7 text-xs px-1 sm:px-2 flex-1 sm:flex-initial"
              >
                <Kanban className="h-3 w-3 sm:mr-1" />
                <span className="hidden xs:inline sm:inline">Kanban</span>
              </Button>
              <Button
                variant={view === "list" ? "default" : "ghost"}
                size="sm"
                onClick={() => setView("list")}
                className="h-6 sm:h-7 text-xs px-1 sm:px-2 flex-1 sm:flex-initial"
              >
                <List className="h-3 w-3 sm:mr-1" />
                <span className="hidden xs:inline sm:inline">List</span>
              </Button>
              <Button
                variant={view === "timeline" ? "default" : "ghost"}
                size="sm"
                onClick={() => setView("timeline")}
                className="h-6 sm:h-7 text-xs px-1 sm:px-2 flex-1 sm:flex-initial"
              >
                <Calendar className="h-3 w-3 sm:mr-1" />
                <span className="hidden xs:inline sm:inline">Timeline</span>
              </Button>
              <Button
                variant={view === "analytics" ? "default" : "ghost"}
                size="sm"
                onClick={() => setView("analytics")}
                className="h-6 sm:h-7 text-xs px-1 sm:px-2 flex-1 sm:flex-initial"
              >
                <BarChart3 className="h-3 w-3 sm:mr-1" />
                <span className="hidden xs:inline sm:inline">Analytics</span>
              </Button>
            </div>
            
            <Button size="sm" className="h-7 text-xs px-2" onClick={() => setShowTaskForm(true)}>
              <Plus className="h-3 w-3 sm:mr-1" />
              <span className="hidden sm:inline">Task</span>
            </Button>
            
            <UniversalNodeCreator 
              defaultType="task"
              size="sm"
              className="h-7 text-xs px-2"
              trigger={
                <Button variant="outline" size="sm" className="h-7 text-xs px-2">
                  <Plus className="h-3 w-3 sm:mr-1" />
                  <span className="hidden sm:inline">Node</span>
                </Button>
              }
            />
          </div>
        </div>
        
        {/* Mobile search bar */}
        <div className="sm:hidden mt-3">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-3 w-3 text-muted-foreground" />
            <Input
              placeholder="Search tasks..."
              className="pl-8 w-full h-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>
      
      {/* Tasks content */}
      <div className="flex-1 overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="animate-spin h-8 w-8 border-4 border-primary rounded-full border-t-transparent"></div>
          </div>
        ) : (
          <div className="h-full overflow-hidden">
            {view === "kanban" && (
              <ModernKanban 
                tasks={filteredTasks}
                onTaskClick={(task) => {
                  setSelectedTask(task);
                  setShowTaskForm(true);
                }}
                onCreateTask={(status) => {
                  // Handle creating task with specific status
                  setShowTaskForm(true);
                }}
              />
            )}
            
            {view === "timeline" && (
              <div className="h-full overflow-hidden flex flex-col m-2">
                <div className="bg-background rounded-xl border border-border overflow-hidden flex flex-col h-full">

                  {/* ── Calendar toolbar ── */}
                  <div className="px-4 py-3 border-b border-border flex items-center gap-3 flex-shrink-0">
                    {/* View toggle */}
                    <div className="flex items-center rounded-lg border border-border p-0.5 bg-muted/30 text-[12px] font-medium">
                      <button
                        onClick={() => setCalendarView("week")}
                        className={`px-3 py-1 rounded-md transition-colors ${calendarView === "week" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}
                      >Week</button>
                      <button
                        onClick={() => setCalendarView("month")}
                        className={`px-3 py-1 rounded-md transition-colors ${calendarView === "month" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}
                      >Month</button>
                    </div>

                    {/* Navigation */}
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => {
                          if (calendarView === "week") { navigateWeek(-1); return; }
                          if (currentMonth === 0) { setCurrentMonth(11); setCurrentYear(currentYear - 1); }
                          else setCurrentMonth(currentMonth - 1);
                        }}
                        className="h-7 w-7 rounded-lg border border-border flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-colors text-sm"
                      >‹</button>
                      <button
                        onClick={() => {
                          if (calendarView === "week") { navigateWeek(1); return; }
                          if (currentMonth === 11) { setCurrentMonth(0); setCurrentYear(currentYear + 1); }
                          else setCurrentMonth(currentMonth + 1);
                        }}
                        className="h-7 w-7 rounded-lg border border-border flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-colors text-sm"
                      >›</button>
                    </div>

                    <span className="text-sm font-semibold text-foreground">
                      {calendarView === "week"
                        ? weekLabel
                        : new Date(currentYear, currentMonth).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                    </span>

                    <button
                      onClick={goToToday}
                      className="ml-auto text-[12px] font-medium px-3 py-1.5 rounded-lg border border-border text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-colors"
                    >Today</button>
                  </div>

                  {/* ── WEEK VIEW ── */}
                  {calendarView === "week" && (
                    <div className="flex-1 overflow-hidden flex flex-col">
                      {/* Day header row */}
                      <div className="overflow-x-auto flex-shrink-0">
                        <div className="grid grid-cols-7 border-b border-border min-w-[420px]">
                        {weekDays.map((day, i) => {
                          const isToday = day.toDateString() === new Date().toDateString();
                          return (
                            <div key={i} className={`py-2 px-1 text-center border-r last:border-r-0 border-border ${isToday ? "bg-indigo-500/8" : ""}`}>
                              <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
                                {day.toLocaleDateString('en-US', { weekday: 'narrow' })}
                              </p>
                              <p className={`text-sm sm:text-base font-semibold mt-0.5 leading-none ${isToday ? "text-indigo-500" : "text-foreground"}`}>
                                {day.getDate()}
                              </p>
                            </div>
                          );
                        })}
                        </div>
                      </div>

                      {/* Day columns */}
                      <div className="flex-1 overflow-y-auto overflow-x-auto">
                        <div className="grid grid-cols-7 h-full divide-x divide-border min-w-[420px]">
                          {weekDays.map((day, i) => {
                            const tasks = getTasksForDate(day);
                            const isToday = day.toDateString() === new Date().toDateString();
                            return (
                              <div key={i} className={`p-2 space-y-1.5 min-h-[200px] ${isToday ? "bg-indigo-500/[0.04]" : ""}`}>
                                {tasks.length === 0 && (
                                  <p className="text-[10px] text-muted-foreground/40 text-center pt-4">—</p>
                                )}
                                {tasks.map(task => {
                                  const dot = priorityDot[task.priority] || "bg-muted-foreground/40";
                                  const st = statusLabel[task.status] || { label: task.status, cls: "bg-muted text-muted-foreground" };
                                  return (
                                    <button
                                      key={task.id}
                                      onClick={() => setSelectedTask(task)}
                                      className="w-full text-left rounded-lg border border-border bg-card hover:bg-accent/40 transition-colors p-2 group"
                                    >
                                      <div className="flex items-start gap-1.5">
                                        <div className={`w-1.5 h-1.5 rounded-full mt-[3px] flex-shrink-0 ${dot}`} />
                                        <p className="text-[11px] font-medium text-foreground leading-tight line-clamp-2 flex-1">
                                          {task.title}
                                        </p>
                                      </div>
                                      <span className={`mt-1.5 inline-block text-[9px] font-semibold px-1.5 py-0.5 rounded-full ${st.cls}`}>
                                        {st.label}
                                      </span>
                                    </button>
                                  );
                                })}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* ── MONTH VIEW ── */}
                  {calendarView === "month" && (
                    <div className="flex-1 overflow-hidden flex flex-col">
                      {/* Day-of-week headers */}
                      <div className="overflow-x-auto flex-shrink-0">
                        <div className="grid grid-cols-7 border-b border-border min-w-[360px]">
                        {['Su','Mo','Tu','We','Th','Fr','Sa'].map(d => (
                          <div key={d} className="py-2 text-center text-[10px] font-medium text-muted-foreground uppercase tracking-wide border-r last:border-r-0 border-border">
                            {d}
                          </div>
                        ))}
                        </div>
                      </div>

                      {/* Month grid */}
                      <div className="flex-1 overflow-y-auto overflow-x-auto">
                        <div className="grid grid-cols-7 auto-rows-[minmax(80px,1fr)] divide-x divide-y divide-border min-w-[360px]">
                          {getCalendarDays().map((date, idx) => {
                            const dayTasks = getTasksForDate(date);
                            const isToday = date?.toDateString() === new Date().toDateString();
                            const isCurrentMonth = date?.getMonth() === currentMonth;
                            return (
                              <div
                                key={idx}
                                className={`p-1.5 flex flex-col gap-1 ${isToday ? "bg-indigo-500/[0.06]" : ""} ${!isCurrentMonth ? "opacity-40" : ""}`}
                              >
                                <span className={`text-[11px] font-semibold w-5 h-5 flex items-center justify-center rounded-full flex-shrink-0 ${
                                  isToday ? "bg-indigo-500 text-white" : "text-foreground/70"
                                }`}>
                                  {date?.getDate()}
                                </span>
                                {dayTasks.slice(0, 3).map(task => {
                                  const dot = priorityDot[task.priority] || "bg-muted-foreground/40";
                                  return (
                                    <button
                                      key={task.id}
                                      onClick={() => setSelectedTask(task)}
                                      className="w-full text-left flex items-center gap-1 px-1.5 py-0.5 rounded bg-card border border-border hover:bg-accent/50 transition-colors"
                                    >
                                      <div className={`w-1 h-1 rounded-full flex-shrink-0 ${dot}`} />
                                      <span className="text-[10px] text-foreground/80 truncate">{task.title}</span>
                                    </button>
                                  );
                                })}
                                {dayTasks.length > 3 && (
                                  <span className="text-[9px] text-muted-foreground pl-1">+{dayTasks.length - 3} more</span>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  )}

                </div>
              </div>
            )}
            
            {view === "analytics" && (
              <div className="h-full overflow-hidden">
                <div className="h-full p-3 overflow-y-auto">
                  <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-3 min-h-full">
                    {/* Task Status Overview */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center text-base">
                          <Target className="h-4 w-4 mr-2" />
                          Task Status Overview
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-sm">To Do</span>
                            <span className="font-medium">{todoTasks.length}</span>
                          </div>
                          <Progress value={(todoTasks.length / filteredTasks.length) * 100} className="h-2" />
                          
                          <div className="flex justify-between items-center">
                            <span className="text-sm">In Progress</span>
                            <span className="font-medium">{inProgressTasks.length}</span>
                          </div>
                          <Progress value={(inProgressTasks.length / filteredTasks.length) * 100} className="h-2" />
                          
                          <div className="flex justify-between items-center">
                            <span className="text-sm">Done</span>
                            <span className="font-medium">{doneTasks.length}</span>
                          </div>
                          <Progress value={(doneTasks.length / filteredTasks.length) * 100} className="h-2" />
                          
                          <div className="flex justify-between items-center">
                            <span className="text-sm">Blocked</span>
                            <span className="font-medium">{blockedTasks.length}</span>
                          </div>
                          <Progress value={(blockedTasks.length / filteredTasks.length) * 100} className="h-2" />
                          
                          <div className="flex justify-between items-center">
                            <span className="text-sm">Save for Later</span>
                            <span className="font-medium">{savedTasks.length}</span>
                          </div>
                          <Progress value={(savedTasks.length / filteredTasks.length) * 100} className="h-2" />
                        </div>
                      </CardContent>
                    </Card>

                    {/* Priority Distribution */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center text-base">
                          <AlertTriangle className="h-4 w-4 mr-2" />
                          Priority Distribution
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {['critical', 'high', 'medium', 'low'].map(priority => {
                            const count = filteredTasks.filter(t => t.priority === priority).length;
                            const percentage = (count / filteredTasks.length) * 100;
                            return (
                              <div key={priority} className="space-y-2">
                                <div className="flex justify-between items-center">
                                  <span className="text-sm capitalize">{priority}</span>
                                  <span className="font-medium">{count}</span>
                                </div>
                                <Progress value={percentage} className="h-2" />
                              </div>
                            );
                          })}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Completion Rate */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center text-base">
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Completion Rate
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-center space-y-4">
                          <div className="text-3xl font-bold">
                            {filteredTasks.length > 0 ? Math.round((doneTasks.length / filteredTasks.length) * 100) : 0}%
                          </div>
                          <Progress value={filteredTasks.length > 0 ? (doneTasks.length / filteredTasks.length) * 100 : 0} className="h-3" />
                          <p className="text-sm text-muted-foreground">
                            {doneTasks.length} of {filteredTasks.length} tasks completed
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Activity Summary */}
                    <Card className="lg:col-span-2 xl:col-span-3">
                      <CardHeader>
                        <CardTitle className="flex items-center text-base">
                          <Activity className="h-4 w-4 mr-2" />
                          Task Activity
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-blue-600">{filteredTasks.length}</div>
                            <p className="text-sm text-muted-foreground">Total Tasks</p>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-green-600">{doneTasks.length}</div>
                            <p className="text-sm text-muted-foreground">Completed</p>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-orange-600">{inProgressTasks.length}</div>
                            <p className="text-sm text-muted-foreground">In Progress</p>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-red-600">{blockedTasks.length}</div>
                            <p className="text-sm text-muted-foreground">Blocked</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            )}
            
            {view === "list" && (
              <div className="h-full overflow-hidden">
                <div className="h-full p-3">
                  <div className="bg-background rounded-md border h-full overflow-hidden">
                    {/* List header */}
                    <div className="grid grid-cols-12 p-3 border-b text-sm font-medium text-muted-foreground">
                      <div className="col-span-6">Task</div>
                      <div className="col-span-2">Status</div>
                      <div className="col-span-2">Assignee</div>
                      <div className="col-span-1">Priority</div>
                      <div className="col-span-1">Due Date</div>
                    </div>
                    
                    <ScrollArea className="h-[calc(100%-40px)]">
                      <div className="space-y-4 p-3">
                        {/* Active Tasks Section */}
                        <div className="bg-background rounded-lg border">
                          <div className="grid grid-cols-12 p-3 border-b text-sm font-medium text-muted-foreground bg-muted/20">
                            <div className="col-span-5">Task</div>
                            <div className="col-span-2">Status</div>
                            <div className="col-span-2">Assignee</div>
                            <div className="col-span-1">Priority</div>
                            <div className="col-span-1">Due Date</div>
                            <div className="col-span-1"></div>
                          </div>
                          {filteredTasks.map(task => (
                            <div key={task.id} className="grid grid-cols-12 p-3 border-b last:border-b-0 hover:bg-accent/50 items-center relative group">
                              {/* Node indicator strip */}
                              <div className={`absolute left-0 top-0 bottom-0 w-1 ${getNodeTypeColor(task.nodeType, task.priority)}`}></div>
                              
                              <div className="col-span-5">
                                <div className="flex items-center">
                                  <div className={`h-2.5 w-2.5 rounded-full mr-2 ${getNodeTypeColor(task.nodeType, task.priority)}`}></div>
                                  <div>
                                    <div className="font-medium flex items-center">
                                      {task.title}
                                      <div className="text-[9px] text-muted-foreground bg-muted px-1 py-0.5 rounded ml-2 uppercase font-semibold tracking-wide">
                                        {task.nodeType}
                                      </div>
                                    </div>
                                    <div className="text-sm text-muted-foreground line-clamp-1">{task.content}</div>
                                  </div>
                                </div>
                              </div>
                              
                              <div className="col-span-2">
                                <Badge variant={getStatusBadgeVariant(task.status)} className="text-xs">
                                  {task.status.replace('-', ' ')}
                                </Badge>
                              </div>
                              
                              <div className="col-span-2">
                                {task.assignedUser && (
                                  <div className="flex items-center gap-2">
                                    <Avatar className="h-6 w-6">
                                      <AvatarImage src={task.assignedUser.avatar} />
                                      <AvatarFallback className="text-xs">{task.assignedUser.displayName.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                                    </Avatar>
                                    <span className="text-sm">{task.assignedUser.displayName}</span>
                                  </div>
                                )}
                              </div>
                              
                              <div className="col-span-1">
                                <div className="flex items-center gap-1">
                                  <div className={`h-2 w-2 rounded-full ${getPriorityColor(task.priority)}`}></div>
                                  <span className="text-xs capitalize">{task.priority}</span>
                                </div>
                              </div>
                              
                              <div className="col-span-1">
                                {task.dueDate ? (
                                  <span className="text-xs">{new Date(task.dueDate).toLocaleDateString()}</span>
                                ) : (
                                  <span className="text-xs text-muted-foreground">-</span>
                                )}
                              </div>

                              <div className="col-span-1 flex justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => archiveTask.mutate({ taskId: task.id, archive: true })}
                                  className="h-7 px-2"
                                  data-testid={`button-archive-${task.id}`}
                                >
                                  <Archive className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          ))}
                          {filteredTasks.length === 0 && (
                            <div className="p-8 text-center text-muted-foreground">
                              <CheckCircle className="h-12 w-12 mx-auto mb-3 opacity-20" />
                              <p className="text-sm">No active tasks</p>
                            </div>
                          )}
                        </div>

                        {/* Archived Tasks Section */}
                        {filteredArchivedTasks.length > 0 && (
                          <div className="bg-background rounded-lg border border-dashed">
                            <button
                              onClick={() => setShowArchived(!showArchived)}
                              className="w-full p-4 flex items-center justify-between hover:bg-accent/30 transition-colors rounded-t-lg"
                              data-testid="button-toggle-archived"
                            >
                              <div className="flex items-center gap-3">
                                <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                                  <Archive className="h-5 w-5 text-muted-foreground" />
                                </div>
                                <div className="text-left">
                                  <div className="font-semibold text-sm">Archived Tasks</div>
                                  <div className="text-xs text-muted-foreground">Completed and moved to archive</div>
                                </div>
                                <Badge variant="secondary" className="ml-2">{filteredArchivedTasks.length}</Badge>
                              </div>
                              {showArchived ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                            </button>
                            
                            {showArchived && (
                              <div>
                                <div className="grid grid-cols-12 p-3 border-t border-b text-sm font-medium text-muted-foreground bg-muted/10">
                                  <div className="col-span-5">Task</div>
                                  <div className="col-span-2">Status</div>
                                  <div className="col-span-2">Assignee</div>
                                  <div className="col-span-1">Priority</div>
                                  <div className="col-span-1">Due Date</div>
                                  <div className="col-span-1"></div>
                                </div>
                                {filteredArchivedTasks.map(task => (
                                  <div key={task.id} className="grid grid-cols-12 p-3 border-b last:border-b-0 hover:bg-accent/30 items-center relative group">
                                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-muted-foreground/40"></div>
                                    
                                    <div className="col-span-5">
                                      <div className="flex items-center">
                                        <div className="h-2.5 w-2.5 rounded-full mr-2 bg-muted-foreground/40"></div>
                                        <div>
                                          <div className="font-medium flex items-center opacity-60">
                                            {task.title}
                                            <div className="text-[9px] text-muted-foreground bg-muted px-1 py-0.5 rounded ml-2 uppercase font-semibold tracking-wide">
                                              {task.nodeType}
                                            </div>
                                          </div>
                                          <div className="text-sm text-muted-foreground line-clamp-1 opacity-60">{task.content}</div>
                                        </div>
                                      </div>
                                    </div>
                                    
                                    <div className="col-span-2">
                                      <div className="flex items-center gap-2">
                                        <Badge variant={task.previousStatus ? getStatusBadgeVariant(task.previousStatus as any) : "secondary"} className="text-xs opacity-70">
                                          {task.previousStatus ? task.previousStatus.replace('-', ' ') : 'done'}
                                        </Badge>
                                        <span className="text-xs text-muted-foreground">→ archived</span>
                                      </div>
                                    </div>
                                    
                                    <div className="col-span-2">
                                      {task.assignedUser && (
                                        <div className="flex items-center gap-2 opacity-60">
                                          <Avatar className="h-6 w-6">
                                            <AvatarImage src={task.assignedUser.avatar} />
                                            <AvatarFallback className="text-xs">{task.assignedUser.displayName.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                                          </Avatar>
                                          <span className="text-sm">{task.assignedUser.displayName}</span>
                                        </div>
                                      )}
                                    </div>
                                    
                                    <div className="col-span-1">
                                      <div className="flex items-center gap-1 opacity-60">
                                        <div className={`h-2 w-2 rounded-full ${getPriorityColor(task.priority)}`}></div>
                                        <span className="text-xs capitalize">{task.priority}</span>
                                      </div>
                                    </div>
                                    
                                    <div className="col-span-1">
                                      {task.dueDate ? (
                                        <span className="text-xs opacity-60">{new Date(task.dueDate).toLocaleDateString()}</span>
                                      ) : (
                                        <span className="text-xs text-muted-foreground">-</span>
                                      )}
                                    </div>

                                    <div className="col-span-1 flex justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => archiveTask.mutate({ taskId: task.id, archive: false })}
                                        className="h-7 px-2"
                                        data-testid={`button-restore-${task.id}`}
                                      >
                                        <RotateCcw className="h-3 w-3" />
                                      </Button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </ScrollArea>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Advanced Task Form */}
      <AdvancedTaskForm
        isOpen={showTaskForm}
        onClose={() => {
          setShowTaskForm(false);
          setSelectedTask(null);
        }}
        task={selectedTask}
        onSuccess={() => {
          setShowTaskForm(false);
          setSelectedTask(null);
        }}
      />
    </div>
  );
}