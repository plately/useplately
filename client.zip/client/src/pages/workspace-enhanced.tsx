import { useState, useRef, useCallback, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Node, File, FileCategory, FileNodeLink, User } from "@shared/schema";
import {
  Upload,
  FileText,
  Image,
  Video,
  Archive,
  Code,
  Download,
  Copy,
  Link,
  MoreHorizontal,
  Search,
  Filter,
  FolderOpen,
  Plus,
  X,
  Eye,
  Lock,
  Users,
  Shield,
  History,
  Tag,
  ChevronRight,
  FileIcon,
  ChevronDown,
  Calendar,
  User as UserIcon,
  Hash,
  Trash2,
  Edit,
  AlertCircle,
  CheckCircle2,
  Clock,
  ExternalLink,
  Paperclip,
  RefreshCw,
  FolderPlus,
  Database,
  FileCode,
  FileImage,
  FileVideo,
  FileAudio,
  FileSpreadsheet
} from "lucide-react";

interface EnhancedFile extends File {
  uploader?: User;
  category?: FileCategory;
  nodeLinks?: FileNodeLink[];
  downloadCount?: number;
}

interface FileUploadData {
  file: File;
  categoryId?: number;
  tags: string[];
  isConfidential: boolean;
  visibility: 'public' | 'node-members' | 'admins-only';
  nodeIds: number[];
}

export default function EnhancedWorkspace() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // State management
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<string>("all");
  const [selectedFiles, setSelectedFiles] = useState<number[]>([]);
  const [uploadQueue, setUploadQueue] = useState<FileUploadData[]>([]);
  const [currentUploadIndex, setCurrentUploadIndex] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<EnhancedFile | null>(null);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [showCategoryDialog, setShowCategoryDialog] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState("");
  const [newCategoryColor, setNewCategoryColor] = useState("#6B7280");
  const [newCategoryIcon, setNewCategoryIcon] = useState("folder");
  
  // Drag and drop state
  const [isDragging, setIsDragging] = useState(false);
  
  // Queries
  const { data: categories = [] } = useQuery<FileCategory[]>({
    queryKey: ['/api/file-categories']
  });
  
  const { data: files = [] } = useQuery<EnhancedFile[]>({
    queryKey: ['/api/files', { categoryId: selectedCategory, search: searchQuery, type: filterType }]
  });
  
  const { data: nodes = [] } = useQuery<Node[]>({
    queryKey: ['/api/nodes']
  });
  
  // Mutations
  const createCategoryMutation = useMutation({
    mutationFn: async (data: { name: string; color: string; icon: string }) => {
      return await apiRequest("POST", "/api/file-categories", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/file-categories'] });
      setShowCategoryDialog(false);
      setNewCategoryName("");
      toast({
        title: "Category created",
        description: "New file category has been created successfully."
      });
    }
  });
  
  const uploadFileMutation = useMutation({
    mutationFn: async (data: FormData) => {
      return await apiRequest("POST", "/api/files/upload", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
    }
  });
  
  const updateFileMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: number; [key: string]: any }) => {
      return await apiRequest("PATCH", `/api/files/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      toast({
        title: "File updated",
        description: "File information has been updated successfully."
      });
    }
  });
  
  const deleteFileMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/files/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      toast({
        title: "File deleted",
        description: "File has been deleted successfully."
      });
    }
  });
  
  const linkToNodeMutation = useMutation({
    mutationFn: async ({ fileId, nodeId }: { fileId: number; nodeId: number }) => {
      return await apiRequest("POST", `/api/files/${fileId}/link-node`, { nodeId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      toast({
        title: "File linked",
        description: "File has been linked to the node successfully."
      });
    }
  });
  
  // File type helpers
  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith('image/')) return <FileImage className="h-4 w-4" />;
    if (mimeType.startsWith('video/')) return <FileVideo className="h-4 w-4" />;
    if (mimeType.startsWith('audio/')) return <FileAudio className="h-4 w-4" />;
    if (mimeType.includes('pdf')) return <FileText className="h-4 w-4" />;
    if (mimeType.includes('spreadsheet') || mimeType.includes('excel')) return <FileSpreadsheet className="h-4 w-4" />;
    if (mimeType.includes('code') || mimeType.includes('javascript') || mimeType.includes('json')) return <FileCode className="h-4 w-4" />;
    if (mimeType.includes('zip') || mimeType.includes('archive')) return <Archive className="h-4 w-4" />;
    return <FileIcon className="h-4 w-4" />;
  };
  
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };
  
  // Drag and drop handlers
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);
  
  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);
  
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFiles = Array.from(e.dataTransfer.files);
    if (droppedFiles.length > 0) {
      handleFileSelect(droppedFiles);
    }
  }, []);
  
  // File handling
  const handleFileSelect = (selectedFiles: File[]) => {
    const fileData = selectedFiles.map(file => ({
      file,
      categoryId: undefined,
      tags: [],
      isConfidential: false,
      visibility: 'public' as const,
      nodeIds: []
    }));
    
    setUploadQueue(fileData);
    setCurrentUploadIndex(0);
    setShowUploadDialog(true);
  };
  
  const processFileUpload = async () => {
    setIsUploading(true);
    
    try {
      // Upload all files starting from current index
      for (let i = currentUploadIndex; i < uploadQueue.length; i++) {
        const currentFile = uploadQueue[i];
        
        const formData = new FormData();
        formData.append('file', currentFile.file);
        formData.append('categoryId', currentFile.categoryId?.toString() || '');
        formData.append('tags', JSON.stringify(currentFile.tags));
        formData.append('isConfidential', currentFile.isConfidential.toString());
        formData.append('visibility', currentFile.visibility);
        formData.append('nodeIds', JSON.stringify(currentFile.nodeIds));
        
        await uploadFileMutation.mutateAsync(formData);
      }
      
      // All uploads completed successfully
      setShowUploadDialog(false);
      setUploadQueue([]);
      setCurrentUploadIndex(0);
      toast({
        title: "Upload complete",
        description: `${uploadQueue.length} file(s) uploaded successfully.`
      });
      
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Failed to upload one or more files",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };
  
  // Remove automatic upload - make it manual only
  // useEffect(() => {
  //   if (showUploadDialog && currentUploadIndex < uploadQueue.length && !isUploading) {
  //     processFileUpload();
  //   }
  // }, [currentUploadIndex, showUploadDialog]);
  
  // Bulk actions
  const handleBulkAction = async (action: string) => {
    switch (action) {
      case 'delete':
        if (confirm(`Delete ${selectedFiles.length} files?`)) {
          for (const fileId of selectedFiles) {
            await deleteFileMutation.mutateAsync(fileId);
          }
          setSelectedFiles([]);
        }
        break;
      case 'tag':
        // Implement bulk tagging
        break;
      case 'move':
        // Implement bulk category move
        break;
    }
  };
  
  // Filter files based on search and category
  const filteredFiles = files.filter(file => {
    const matchesSearch = !searchQuery || 
      file.originalName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      file.tags?.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = !selectedCategory || file.categoryId === selectedCategory;
    
    const matchesType = filterType === 'all' || 
      (filterType === 'orphaned' && (!file.nodeLinks || file.nodeLinks.length === 0)) ||
      (filterType === 'confidential' && file.isConfidential);
    
    return matchesSearch && matchesCategory && matchesType;
  });
  
  // Default categories if none exist
  const defaultCategories = [
    { id: -1, name: "All Files", icon: "folder", color: "#6B7280" },
    { id: -2, name: "Orphaned Files", icon: "alert-circle", color: "#EF4444" },
    { id: -3, name: "Recent", icon: "clock", color: "#3B82F6" },
    { id: -4, name: "Confidential", icon: "lock", color: "#DC2626" }
  ];

  return (
    <div className="h-full flex flex-col lg:flex-row">
      {/* Left Sidebar - Categories */}
      <div className="w-full lg:w-64 border-b lg:border-b-0 lg:border-r bg-background/50 p-3 lg:p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-sm">Categories</h3>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setShowCategoryDialog(true)}
          >
            <FolderPlus className="h-4 w-4" />
          </Button>
        </div>
        
        <ScrollArea className="h-32 lg:h-[calc(100vh-12rem)]">
          <div className="space-y-1 flex lg:flex-col gap-2 lg:gap-0 overflow-x-auto lg:overflow-x-visible">
            {defaultCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id < 0 ? null : cat.id)}
                className={`flex-shrink-0 lg:w-full text-left px-3 py-2 rounded-md text-sm transition-colors whitespace-nowrap ${
                  (cat.id < 0 && !selectedCategory) || selectedCategory === cat.id
                    ? 'bg-accent text-accent-foreground'
                    : 'hover:bg-accent/50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: cat.color }}
                  />
                  <span>{cat.name}</span>
                </div>
              </button>
            ))}
            
            {categories.length > 0 && <Separator className="my-2" />}
            
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${
                  selectedCategory === category.id
                    ? 'bg-accent text-accent-foreground'
                    : 'hover:bg-accent/50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: category.color || '#6B7280' }}
                  />
                  <span>{category.name}</span>
                </div>
              </button>
            ))}
          </div>
        </ScrollArea>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="border-b p-3 lg:p-4">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 mb-4">
            <h2 className="text-xl lg:text-2xl font-bold">File Management</h2>
            <div className="flex items-center gap-2 flex-wrap">
              {selectedFiles.length > 0 && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm">
                      <MoreHorizontal className="h-4 w-4 mr-2" />
                      {selectedFiles.length} selected
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem onClick={() => handleBulkAction('delete')}>
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleBulkAction('tag')}>
                      <Tag className="h-4 w-4 mr-2" />
                      Add Tags
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleBulkAction('move')}>
                      <FolderOpen className="h-4 w-4 mr-2" />
                      Move to Category
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
              
              <Button
                onClick={() => fileInputRef.current?.click()}
                className="gap-2"
              >
                <Upload className="h-4 w-4" />
                Upload Files
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                className="hidden"
                onChange={(e) => {
                  if (e.target.files) {
                    handleFileSelect(Array.from(e.target.files));
                  }
                }}
              />
            </div>
          </div>
          
          {/* Search and Filter */}
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-3 lg:gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search files, tags, or linked nodes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-full lg:w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Files</SelectItem>
                <SelectItem value="orphaned">Orphaned</SelectItem>
                <SelectItem value="confidential">Confidential</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* File Grid/List */}
        <div
          className={`flex-1 p-4 overflow-auto ${isDragging ? 'bg-accent/10' : ''}`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          {isDragging && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/80 z-10">
              <div className="text-center">
                <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-lg font-medium">Drop files here to upload</p>
              </div>
            </div>
          )}
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredFiles.map((file) => (
              <Card
                key={file.id}
                className={`cursor-pointer transition-all hover:shadow-lg ${
                  selectedFiles.includes(file.id) ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => setSelectedFile(file)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      {getFileIcon(file.mimeType)}
                      <Checkbox
                        checked={selectedFiles.includes(file.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedFiles([...selectedFiles, file.id]);
                          } else {
                            setSelectedFiles(selectedFiles.filter(id => id !== file.id));
                          }
                        }}
                        onClick={(e) => e.stopPropagation()}
                      />
                    </div>
                    
                    <div className="flex items-center gap-1">
                      {file.isConfidential && (
                        <Lock className="h-3 w-3 text-destructive" />
                      )}
                      {file.isImmutable && (
                        <Shield className="h-3 w-3 text-warning" />
                      )}
                    </div>
                  </div>
                  
                  <h4 className="font-medium text-sm mb-1 truncate">
                    {file.originalName}
                  </h4>
                  
                  <p className="text-xs text-muted-foreground mb-3">
                    {formatFileSize(file.size)} • {file.createdAt ? format(new Date(file.createdAt), 'MMM d, yyyy') : 'Unknown date'}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex flex-wrap gap-1">
                      {file.tags?.slice(0, 2).map((tag, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                      {file.tags && file.tags.length > 2 && (
                        <Badge variant="secondary" className="text-xs">
                          +{file.tags.length - 2}
                        </Badge>
                      )}
                    </div>
                    
                    {file.nodeLinks && file.nodeLinks.length > 0 && (
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Link className="h-3 w-3" />
                        {file.nodeLinks.length}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
      
      {/* File Upload Dialog */}
      {showUploadDialog && uploadQueue.length > 0 && (
        <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                Configure Upload ({currentUploadIndex + 1} of {uploadQueue.length})
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">
                  {uploadQueue[currentUploadIndex]?.file.name}
                </h4>
                <p className="text-sm text-muted-foreground">
                  {formatFileSize(uploadQueue[currentUploadIndex]?.file.size || 0)}
                </p>
              </div>
              
              <div>
                <Label>Category</Label>
                <Select
                  value={uploadQueue[currentUploadIndex]?.categoryId?.toString() || ""}
                  onValueChange={(value) => {
                    const updated = [...uploadQueue];
                    if (updated[currentUploadIndex]) {
                      updated[currentUploadIndex].categoryId = parseInt(value);
                      setUploadQueue(updated);
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id.toString()}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label>Tags</Label>
                <Input
                  placeholder="Enter tags separated by commas"
                  value={uploadQueue[currentUploadIndex]?.tags?.join(', ') || ''}
                  onChange={(e) => {
                    const updated = [...uploadQueue];
                    if (updated[currentUploadIndex]) {
                      updated[currentUploadIndex].tags = e.target.value
                        .split(',')
                        .map(t => t.trim())
                        .filter(Boolean);
                      setUploadQueue(updated);
                    }
                  }}
                />
              </div>
              
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="confidential"
                    checked={uploadQueue[currentUploadIndex]?.isConfidential}
                    onCheckedChange={(checked) => {
                      const updated = [...uploadQueue];
                      if (updated[currentUploadIndex]) {
                        updated[currentUploadIndex].isConfidential = !!checked;
                        setUploadQueue(updated);
                      }
                    }}
                  />
                  <Label htmlFor="confidential">Confidential</Label>
                </div>
                
                <div className="flex items-center gap-2">
                  <Label>Visibility:</Label>
                  <Select
                    value={uploadQueue[currentUploadIndex]?.visibility}
                    onValueChange={(value: 'public' | 'node-members' | 'admins-only') => {
                      const updated = [...uploadQueue];
                      if (updated[currentUploadIndex]) {
                        updated[currentUploadIndex].visibility = value;
                        setUploadQueue(updated);
                      }
                    }}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="public">Public</SelectItem>
                      <SelectItem value="node-members">Node Members</SelectItem>
                      <SelectItem value="admins-only">Admins Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label>Link to Nodes</Label>
                <div className="border rounded-md p-3 max-h-40 overflow-y-auto">
                  {nodes.map((node) => (
                    <div key={node.id} className="flex items-center gap-2 py-1">
                      <Checkbox
                        checked={uploadQueue[currentUploadIndex]?.nodeIds.includes(node.id)}
                        onCheckedChange={(checked) => {
                          const updated = [...uploadQueue];
                          if (updated[currentUploadIndex]) {
                            if (checked) {
                              updated[currentUploadIndex].nodeIds.push(node.id);
                            } else {
                              updated[currentUploadIndex].nodeIds = updated[currentUploadIndex].nodeIds
                                .filter(id => id !== node.id);
                            }
                            setUploadQueue(updated);
                          }
                        }}
                      />
                      <Label className="text-sm cursor-pointer">
                        {node.title}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
              
              {isUploading && (
                <Progress value={(currentUploadIndex / uploadQueue.length) * 100} />
              )}
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setShowUploadDialog(false);
                  setUploadQueue([]);
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  if (currentUploadIndex < uploadQueue.length - 1) {
                    // Move to next file
                    setCurrentUploadIndex(prev => prev + 1);
                  } else {
                    // This is the last file, trigger upload process
                    processFileUpload();
                  }
                }}
                disabled={isUploading}
              >
                {isUploading ? 'Uploading...' : (currentUploadIndex < uploadQueue.length - 1 ? 'Next' : 'Upload & Finish')}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {/* File Details Modal */}
      {selectedFile && (
        <Dialog open={!!selectedFile} onOpenChange={() => setSelectedFile(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                {getFileIcon(selectedFile.mimeType)}
                {selectedFile.originalName}
              </DialogTitle>
            </DialogHeader>
            
            <Tabs defaultValue="details">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="preview">Preview</TabsTrigger>
                <TabsTrigger value="history">History</TabsTrigger>
              </TabsList>
              
              <TabsContent value="details" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground">Size</Label>
                    <p>{formatFileSize(selectedFile.size)}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Type</Label>
                    <p>{selectedFile.mimeType}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Uploaded</Label>
                    <p>{selectedFile.createdAt ? format(new Date(selectedFile.createdAt), 'MMM d, yyyy h:mm a') : 'Unknown date'}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Category</Label>
                    <p>{selectedFile.category?.name || 'Uncategorized'}</p>
                  </div>
                </div>
                
                <div>
                  <Label className="text-muted-foreground">Tags</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {selectedFile.tags?.map((tag, idx) => (
                      <Badge key={idx} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div>
                  <Label className="text-muted-foreground">Linked Nodes</Label>
                  <div className="space-y-2 mt-2">
                    {selectedFile.nodeLinks?.map((link) => (
                      <div key={link.id} className="flex items-center justify-between p-2 border rounded">
                        <span className="text-sm">{link.nodeId}</span>
                        <Button size="sm" variant="ghost">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button className="flex-1" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                  <Button className="flex-1" variant="outline">
                    <Copy className="h-4 w-4 mr-2" />
                    Copy Link
                  </Button>
                  <Button
                    className="flex-1"
                    variant="destructive"
                    onClick={() => {
                      deleteFileMutation.mutate(selectedFile.id);
                      setSelectedFile(null);
                    }}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="preview">
                <div className="border rounded-lg p-8 text-center text-muted-foreground">
                  <FileIcon className="h-16 w-16 mx-auto mb-4" />
                  <p>Preview not available for this file type</p>
                </div>
              </TabsContent>
              
              <TabsContent value="history">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 p-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">File uploaded</span>
                    <span className="text-xs text-muted-foreground ml-auto">
                      {selectedFile.createdAt ? format(new Date(selectedFile.createdAt), 'MMM d, yyyy h:mm a') : 'Unknown date'}
                    </span>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Create Category Dialog */}
      <Dialog open={showCategoryDialog} onOpenChange={setShowCategoryDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create File Category</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label>Category Name</Label>
              <Input
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                placeholder="Enter category name"
              />
            </div>
            
            <div>
              <Label>Color</Label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={newCategoryColor}
                  onChange={(e) => setNewCategoryColor(e.target.value)}
                  className="h-10 w-20"
                />
                <span className="text-sm text-muted-foreground">{newCategoryColor}</span>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCategoryDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                createCategoryMutation.mutate({
                  name: newCategoryName,
                  color: newCategoryColor,
                  icon: newCategoryIcon
                });
              }}
              disabled={!newCategoryName}
            >
              Create Category
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}