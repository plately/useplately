import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Bot, Wifi, WifiOff, CheckCircle2, XCircle, Trash2, Link2,
  CheckSquare, CalendarDays, BookOpen, Share2, MessageSquare, ExternalLink,
  Plus, RefreshCw,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface DiscordConfig {
  connected: boolean;
  botTag: string | null;
  clientId: string | null;
  inviteUrl: string | null;
  guilds: { id: string; name: string }[];
  mappings: { nodeosChannelId: number; discordChannelId: string }[];
  categoryChannels: {
    tasks?: string;
    calendar?: string;
    journal?: string;
    graph?: string;
  };
}

interface Channel { id: number; name: string; spaceId: number; }
interface Space   { id: number; name: string; }

// ─── Category config ──────────────────────────────────────────────────────────

const CATEGORIES = [
  {
    key: "tasks" as const,
    label: "Tasks",
    icon: CheckSquare,
    color: "text-blue-500",
    description: "Posts to Discord when a task is created or its status changes (To Do → In Progress → Done, etc.).",
    events: ["Task created", "Status changed", "Task archived"],
  },
  {
    key: "calendar" as const,
    label: "Calendar",
    icon: CalendarDays,
    color: "text-violet-500",
    description: "Posts to Discord when calendar events (meetings) are created, updated, or rescheduled.",
    events: ["Event created", "Event updated", "Event rescheduled"],
  },
  {
    key: "journal" as const,
    label: "Journal",
    icon: BookOpen,
    color: "text-amber-500",
    description: "Mirrors journal entries to Discord — creates a post with a preview whenever an entry is written or updated.",
    events: ["New journal entry", "Journal entry updated"],
  },
  {
    key: "graph" as const,
    label: "Graph",
    icon: Share2,
    color: "text-green-500",
    description: "Posts a change history to Discord whenever a node is created, updated, or linked in the knowledge graph.",
    events: ["Node created", "Node updated", "Nodes linked", "Link removed"],
  },
] as const;

// ─── Reusable category channel card ──────────────────────────────────────────

function CategoryChannelCard({
  category, label, icon: Icon, color, description, events,
  currentChannelId, onSave, onRemove, isSaving,
}: {
  category: string; label: string; icon: React.ElementType; color: string;
  description: string; events: readonly string[];
  currentChannelId?: string;
  onSave: (id: string) => void; onRemove: () => void; isSaving: boolean;
}) {
  const [input, setInput] = useState(currentChannelId ?? "");

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-muted">
              <Icon className={`h-4 w-4 ${color}`} />
            </div>
            <div>
              <CardTitle className="text-base">{label} Notifications</CardTitle>
              <CardDescription className="text-xs mt-0.5">{description}</CardDescription>
            </div>
          </div>
          {currentChannelId ? (
            <Badge className="shrink-0 bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400 border-green-200">
              <CheckCircle2 className="h-3 w-3 mr-1" /> Linked
            </Badge>
          ) : (
            <Badge variant="outline" className="shrink-0 text-muted-foreground">Not linked</Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap gap-1.5">
          {events.map(e => (
            <span key={e} className="text-[11px] bg-muted px-2 py-0.5 rounded-full text-muted-foreground">{e}</span>
          ))}
        </div>

        {currentChannelId && (
          <div className="flex items-center justify-between rounded-md bg-green-50 dark:bg-green-950/20 border border-green-100 dark:border-green-900 px-3 py-2">
            <div className="flex items-center gap-2 text-xs">
              <Bot className="h-3.5 w-3.5 text-[#5865F2]" />
              <span className="text-muted-foreground">Discord channel</span>
              <code className="font-mono bg-background border rounded px-1.5 py-0.5">{currentChannelId}</code>
            </div>
            <Button variant="ghost" size="sm" className="h-6 px-2 text-xs text-destructive hover:text-destructive hover:bg-destructive/10" onClick={onRemove}>
              <Trash2 className="h-3 w-3 mr-1" /> Unlink
            </Button>
          </div>
        )}

        <div className="flex gap-2">
          <Input
            placeholder="Paste Discord channel ID…"
            value={input}
            onChange={e => setInput(e.target.value)}
            className="h-9 text-sm font-mono"
          />
          <Button
            size="sm"
            onClick={() => { if (input.trim()) { onSave(input.trim()); } }}
            disabled={!input.trim() || input.trim() === currentChannelId || isSaving}
            className="h-9 shrink-0"
          >
            {isSaving ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : currentChannelId ? "Update" : <><Plus className="h-3.5 w-3.5 mr-1" />Link</>}
          </Button>
        </div>
        <p className="text-[11px] text-muted-foreground">
          In Discord: User Settings → Advanced → enable <strong>Developer Mode</strong>, then right-click a channel → <strong>Copy Channel ID</strong>
        </p>
      </CardContent>
    </Card>
  );
}

// ─── Add chat mapping row ─────────────────────────────────────────────────────

function AddChatMappingRow({
  channels, spaces, existingMappings, onSave, isSaving,
}: {
  channels: Channel[]; spaces: Space[];
  existingMappings: { nodeosChannelId: number; discordChannelId: string }[];
  onSave: (nodeosChannelId: number, discordChannelId: string) => void;
  isSaving: boolean;
}) {
  const [selectedChannelId, setSelectedChannelId] = useState<string>("");
  const [discordId, setDiscordId] = useState("");
  const unmapped = channels.filter(c => !existingMappings.find(m => m.nodeosChannelId === c.id));

  if (unmapped.length === 0) return null;

  return (
    <div className="border rounded-lg p-4 space-y-3 bg-muted/30">
      <p className="text-sm font-medium">Link another chat channel</p>
      <div className="flex gap-2 flex-wrap">
        <select
          className="h-9 flex-1 min-w-[140px] text-sm rounded-md border border-input bg-background px-3 py-1"
          value={selectedChannelId}
          onChange={e => setSelectedChannelId(e.target.value)}
        >
          <option value="">Select a NodeOS channel…</option>
          {unmapped.map(ch => {
            const space = spaces.find(s => s.id === ch.spaceId);
            return <option key={ch.id} value={ch.id}>#{ch.name}{space ? ` · ${space.name}` : ""}</option>;
          })}
        </select>
        <Input
          placeholder="Discord channel ID"
          value={discordId}
          onChange={e => setDiscordId(e.target.value)}
          className="h-9 text-sm font-mono flex-1 min-w-[160px]"
        />
        <Button
          size="sm"
          className="h-9 shrink-0"
          disabled={!selectedChannelId || !discordId.trim() || isSaving}
          onClick={() => { onSave(parseInt(selectedChannelId), discordId.trim()); setSelectedChannelId(""); setDiscordId(""); }}
        >
          <Plus className="h-3.5 w-3.5 mr-1" /> Link
        </Button>
      </div>
    </div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function Integrations() {
  const { toast } = useToast();

  const { data: discordConfig, refetch: refetchConfig } = useQuery<DiscordConfig>({
    queryKey: ['/api/discord/config'],
    refetchInterval: 30000,
  });

  const { data: spaces } = useQuery<Space[]>({ queryKey: ['/api/spaces'] });
  const { data: allChannels } = useQuery<Channel[]>({ queryKey: ['/api/channels'] });

  const saveCategoryMutation = useMutation({
    mutationFn: async ({ category, discordChannelId }: { category: string; discordChannelId: string }) =>
      apiRequest('/api/discord/categories', { method: 'POST', body: JSON.stringify({ category, discordChannelId }) }),
    onSuccess: (_d, vars) => {
      queryClient.invalidateQueries({ queryKey: ['/api/discord/config'] });
      refetchConfig();
      toast({ title: `${vars.category.charAt(0).toUpperCase() + vars.category.slice(1)} channel linked` });
    },
    onError: () => toast({ variant: "destructive", title: "Failed to link channel" }),
  });

  const removeCategoryMutation = useMutation({
    mutationFn: async (category: string) =>
      apiRequest(`/api/discord/categories/${category}`, { method: 'DELETE' }),
    onSuccess: (_d, category) => {
      queryClient.invalidateQueries({ queryKey: ['/api/discord/config'] });
      refetchConfig();
      toast({ title: `${category.charAt(0).toUpperCase() + category.slice(1)} channel unlinked` });
    },
  });

  const saveChatMutation = useMutation({
    mutationFn: async ({ nodeosChannelId, discordChannelId }: { nodeosChannelId: number; discordChannelId: string }) =>
      apiRequest('/api/discord/config', { method: 'POST', body: JSON.stringify({ nodeosChannelId, discordChannelId }) }),
    onSuccess: () => { refetchConfig(); toast({ title: "Chat channel linked" }); },
    onError: () => toast({ variant: "destructive", title: "Failed to link chat channel" }),
  });

  const removeChatMutation = useMutation({
    mutationFn: async (nodeosChannelId: number) =>
      apiRequest('/api/discord/config', { method: 'POST', body: JSON.stringify({ nodeosChannelId, remove: true }) }),
    onSuccess: () => { refetchConfig(); toast({ title: "Chat channel unlinked" }); },
  });

  const categoryChannels = discordConfig?.categoryChannels ?? {};
  const chatMappings = discordConfig?.mappings ?? [];
  const linkedCount = Object.keys(categoryChannels).length + chatMappings.length;

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-background">
      {/* Header */}
      <div className="px-6 py-4 border-b shrink-0">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Integrations</h1>
            <p className="text-sm text-muted-foreground mt-0.5">Connect NodeOS sections to Discord for automatic cross-sync</p>
          </div>
          <div className="flex items-center gap-2">
            {discordConfig?.connected ? (
              <Badge className="bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400 border-green-200">
                <Wifi className="h-3 w-3 mr-1" /> {discordConfig.botTag}
              </Badge>
            ) : (
              <Badge variant="outline" className="text-muted-foreground">
                <WifiOff className="h-3 w-3 mr-1" /> Bot offline
              </Badge>
            )}
            {linkedCount > 0 && (
              <Badge variant="secondary">{linkedCount} channel{linkedCount !== 1 ? "s" : ""} linked</Badge>
            )}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <div className="p-6 max-w-4xl mx-auto space-y-6">

          {/* Bot status card */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-[#5865F2]/10">
                  <Bot className="h-5 w-5 text-[#5865F2]" />
                </div>
                <div>
                  <CardTitle>Discord Bot</CardTitle>
                  <CardDescription>NodeOS syncs with Discord via a bot that posts and receives messages</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className={`flex items-center gap-2.5 rounded-lg px-4 py-3 ${discordConfig?.connected ? 'bg-green-50 dark:bg-green-950/20 border border-green-100 dark:border-green-900' : 'bg-amber-50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900'}`}>
                {discordConfig?.connected ? (
                  <>
                    <CheckCircle2 className="h-4 w-4 text-green-600 shrink-0" />
                    <div className="text-sm">
                      <span className="font-medium text-green-800 dark:text-green-300">Connected</span>
                      <span className="text-green-600 dark:text-green-400 ml-2">as <strong>{discordConfig.botTag}</strong></span>
                      {discordConfig.guilds.length > 0 && (
                        <span className="text-green-600 dark:text-green-400 ml-1">
                          · in {discordConfig.guilds.map(g => g.name).join(", ")}
                        </span>
                      )}
                    </div>
                  </>
                ) : (
                  <>
                    <XCircle className="h-4 w-4 text-amber-600 shrink-0" />
                    <div className="text-sm text-amber-700 dark:text-amber-400">
                      Bot offline — check that <code className="bg-amber-100 dark:bg-amber-900/50 px-1 rounded text-xs">DISCORD_BOT_TOKEN</code> is set correctly
                    </div>
                  </>
                )}
              </div>
              {discordConfig?.inviteUrl && (
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">Need to add the bot to a server?</p>
                  <a
                    href={discordConfig.inviteUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium bg-[#5865F2] hover:bg-[#4752c4] text-white transition-colors"
                  >
                    <Bot className="h-3.5 w-3.5" />
                    Invite to Server
                    <ExternalLink className="h-3 w-3 ml-0.5 opacity-70" />
                  </a>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Channel configuration tabs */}
          <Tabs defaultValue="categories">
            <TabsList className="w-full grid grid-cols-2">
              <TabsTrigger value="categories" className="gap-1.5">
                <Bot className="h-3.5 w-3.5" />
                Section Channels
                {Object.keys(categoryChannels).length > 0 && (
                  <Badge variant="secondary" className="ml-1 h-4 text-[10px] px-1">{Object.keys(categoryChannels).length}</Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="chat" className="gap-1.5">
                <MessageSquare className="h-3.5 w-3.5" />
                Chat Channels
                {chatMappings.length > 0 && (
                  <Badge variant="secondary" className="ml-1 h-4 text-[10px] px-1">{chatMappings.length}</Badge>
                )}
              </TabsTrigger>
            </TabsList>

            {/* Section Channels */}
            <TabsContent value="categories" className="mt-4 space-y-4">
              <p className="text-sm text-muted-foreground">
                Each NodeOS section can post updates to its own dedicated Discord channel automatically.
              </p>
              {CATEGORIES.map(cat => (
                <CategoryChannelCard
                  key={cat.key}
                  category={cat.key}
                  label={cat.label}
                  icon={cat.icon}
                  color={cat.color}
                  description={cat.description}
                  events={cat.events}
                  currentChannelId={categoryChannels[cat.key]}
                  onSave={id => saveCategoryMutation.mutate({ category: cat.key, discordChannelId: id })}
                  onRemove={() => removeCategoryMutation.mutate(cat.key)}
                  isSaving={saveCategoryMutation.isPending}
                />
              ))}
            </TabsContent>

            {/* Chat Channels */}
            <TabsContent value="chat" className="mt-4 space-y-4">
              <p className="text-sm text-muted-foreground">
                Two-way sync between NodeOS chat channels and Discord — messages flow both directions in real-time.
              </p>

              {chatMappings.length > 0 && (
                <div className="space-y-2">
                  {chatMappings.map(mapping => {
                    const channel = allChannels?.find(c => c.id === mapping.nodeosChannelId);
                    const space = channel ? spaces?.find(s => s.id === channel.spaceId) : null;
                    return (
                      <div key={mapping.nodeosChannelId} className="flex items-center justify-between rounded-lg border px-4 py-3 bg-card">
                        <div className="flex items-center gap-3">
                          <div className="p-1.5 rounded bg-[#5865F2]/10">
                            <MessageSquare className="h-3.5 w-3.5 text-[#5865F2]" />
                          </div>
                          <div>
                            <div className="text-sm font-medium">
                              #{channel?.name ?? `Channel ${mapping.nodeosChannelId}`}
                              {space && <span className="text-muted-foreground text-xs ml-1">· {space.name}</span>}
                            </div>
                            <div className="flex items-center gap-1 mt-0.5">
                              <Link2 className="h-3 w-3 text-muted-foreground" />
                              <code className="text-xs font-mono text-muted-foreground">{mapping.discordChannelId}</code>
                            </div>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-xs text-destructive hover:text-destructive hover:bg-destructive/10"
                          onClick={() => removeChatMutation.mutate(mapping.nodeosChannelId)}
                        >
                          <Trash2 className="h-3 w-3 mr-1" /> Unlink
                        </Button>
                      </div>
                    );
                  })}
                </div>
              )}

              {chatMappings.length === 0 && (
                <div className="text-center py-10 text-muted-foreground border rounded-lg">
                  <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">No chat channels linked yet.</p>
                  <p className="text-xs mt-1 max-w-xs mx-auto">Open any chat channel and click the Discord icon in the header to link it, or add one below.</p>
                </div>
              )}

              {allChannels && (
                <AddChatMappingRow
                  channels={allChannels}
                  spaces={spaces ?? []}
                  existingMappings={chatMappings}
                  onSave={(nodeosChannelId, discordChannelId) => saveChatMutation.mutate({ nodeosChannelId, discordChannelId })}
                  isSaving={saveChatMutation.isPending}
                />
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
