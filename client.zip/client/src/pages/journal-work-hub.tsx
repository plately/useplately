import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format, startOfDay, isToday } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Node, InsertNode } from "@shared/schema";
import {
  Calendar,
  Clock,
  CheckCircle2,
  Circle,
  Plus,
  FileText,
  Upload,
  Mic,
  Video,
  Palette,
  Link,
  Hash,
  MessageCircle,
  Brain,
  Target,
  BarChart3,
  ChevronDown,
  ChevronRight,
  Paperclip,
  Users,
  Zap,
  Settings,
  Sun,
  CloudDrizzle,
  Moon,
  Coffee,
  Lightbulb
} from "lucide-react";

interface TimeBlock {
  id: string;
  title: string;
  timeRange: string;
  icon: React.ReactNode;
  color: string;
  entries: WorkEntry[];
}

interface WorkEntry {
  id: string;
  type: 'note' | 'task' | 'checkin' | 'file' | 'voice' | 'meeting';
  content: string;
  timestamp: Date;
  completed?: boolean;
  tags: string[];
  linkedNodes: string[];
  mood?: 'great' | 'good' | 'neutral' | 'stressed' | 'blocked';
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  attachments?: string[];
}

interface SmartTask {
  id: string;
  title: string;
  description?: string;
  status: 'todo' | 'doing' | 'done';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  tags: string[];
  dueDate?: Date;
  linkedNodes: string[];
  subtasks: string[];
  assignee?: string;
  estimatedTime?: number;
}

const timeBlocks: TimeBlock[] = [
  {
    id: 'morning',
    title: 'Morning Focus',
    timeRange: '6:00 - 12:00',
    icon: <Sun className="h-4 w-4" />,
    color: 'bg-yellow-50 border-yellow-200',
    entries: []
  },
  {
    id: 'midday',
    title: 'Midday Flow',
    timeRange: '12:00 - 17:00',
    icon: <CloudDrizzle className="h-4 w-4" />,
    color: 'bg-blue-50 border-blue-200',
    entries: []
  },
  {
    id: 'evening',
    title: 'Evening Wrap',
    timeRange: '17:00 - 23:00',
    icon: <Moon className="h-4 w-4" />,
    color: 'bg-purple-50 border-purple-200',
    entries: []
  }
];

const moodIcons = {
  great: '😊',
  good: '🙂',
  neutral: '😐',
  stressed: '😰',
  blocked: '😤'
};

const priorityColors = {
  low: 'bg-green-100 text-green-800',
  medium: 'bg-yellow-100 text-yellow-800',
  high: 'bg-orange-100 text-orange-800',
  urgent: 'bg-red-100 text-red-800'
};

export default function JournalWorkHub() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [activeBlock, setActiveBlock] = useState('morning');
  const [tasks, setTasks] = useState<SmartTask[]>([]);
  const [newEntry, setNewEntry] = useState('');
  const [entryType, setEntryType] = useState<WorkEntry['type']>('note');
  const [isAddingEntry, setIsAddingEntry] = useState(false);
  const [selectedMood, setSelectedMood] = useState<WorkEntry['mood']>('neutral');
  const [entryTags, setEntryTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');
  const [isAIDialogOpen, setIsAIDialogOpen] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [expandedBlocks, setExpandedBlocks] = useState<Set<string>>(new Set(['morning']));
  const [dailyReflection, setDailyReflection] = useState('');
  const [workBlocks, setWorkBlocks] = useState<TimeBlock[]>(timeBlocks);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Query for nodes to use in linking
  const { data: nodes = [] } = useQuery<Node[]>({
    queryKey: ['/api/nodes'],
  });

  // Create node mutation
  const createNodeMutation = useMutation({
    mutationFn: (nodeData: InsertNode) => apiRequest('/api/nodes', {
      method: 'POST',
      body: JSON.stringify(nodeData),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/nodes'] });
      toast({
        title: "Node created",
        description: "Your idea has been turned into a node",
      });
    },
  });

  const toggleBlockExpansion = (blockId: string) => {
    const newExpanded = new Set(expandedBlocks);
    if (newExpanded.has(blockId)) {
      newExpanded.delete(blockId);
    } else {
      newExpanded.add(blockId);
    }
    setExpandedBlocks(newExpanded);
  };

  const addWorkEntry = (blockId: string) => {
    if (!newEntry.trim()) return;

    const entry: WorkEntry = {
      id: Date.now().toString(),
      type: entryType,
      content: newEntry,
      timestamp: new Date(),
      tags: entryTags,
      linkedNodes: [],
      mood: entryType === 'checkin' ? selectedMood : undefined,
      completed: entryType === 'task' ? false : undefined,
    };

    setWorkBlocks(prev => prev.map(block => 
      block.id === blockId 
        ? { ...block, entries: [...block.entries, entry] }
        : block
    ));

    // Reset form
    setNewEntry('');
    setEntryTags([]);
    setIsAddingEntry(false);
    
    toast({
      title: "Entry added",
      description: `${entryType} added to ${blockId} block`,
    });
  };

  const addTag = () => {
    if (newTag.trim() && !entryTags.includes(newTag.trim())) {
      setEntryTags([...entryTags, newTag.trim()]);
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setEntryTags(entryTags.filter(tag => tag !== tagToRemove));
  };

  const createNodeFromEntry = (entry: WorkEntry) => {
    createNodeMutation.mutate({
      title: entry.content.substring(0, 50) + (entry.content.length > 50 ? '...' : ''),
      content: entry.content,
      nodeType: entry.type === 'task' ? 'task' : 'note',
      tags: entry.tags,
      createdBy: 1, // Default user
    });
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      // In a real app, you'd upload to a file service
      const fileNames = Array.from(files).map(file => file.name);
      
      const fileEntry: WorkEntry = {
        id: Date.now().toString(),
        type: 'file',
        content: `Uploaded files: ${fileNames.join(', ')}`,
        timestamp: new Date(),
        tags: ['file-upload'],
        linkedNodes: [],
        attachments: fileNames,
      };

      setWorkBlocks(prev => prev.map(block => 
        block.id === activeBlock 
          ? { ...block, entries: [...block.entries, fileEntry] }
          : block
      ));

      toast({
        title: "Files uploaded",
        description: `${fileNames.length} file(s) added to workspace`,
      });
    }
  };

  const toggleTaskCompletion = (blockId: string, entryId: string) => {
    setWorkBlocks(prev => prev.map(block => 
      block.id === blockId 
        ? {
            ...block,
            entries: block.entries.map(entry => 
              entry.id === entryId 
                ? { ...entry, completed: !entry.completed }
                : entry
            )
          }
        : block
    ));
  };

  const addSmartTask = () => {
    const newTask: SmartTask = {
      id: Date.now().toString(),
      title: 'New Task',
      status: 'todo',
      priority: 'medium',
      tags: [],
      linkedNodes: [],
      subtasks: [],
    };
    setTasks([...tasks, newTask]);
  };

  const moveTask = (taskId: string, newStatus: SmartTask['status']) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, status: newStatus } : task
    ));
  };

  const getTasksByStatus = (status: SmartTask['status']) => {
    return tasks.filter(task => task.status === status);
  };

  const getTodayProgress = () => {
    const allEntries = workBlocks.flatMap(block => block.entries);
    const completedTasks = allEntries.filter(entry => entry.type === 'task' && entry.completed).length;
    const totalTasks = allEntries.filter(entry => entry.type === 'task').length;
    return totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
  };

  const getDailyStats = () => {
    const allEntries = workBlocks.flatMap(block => block.entries);
    return {
      totalEntries: allEntries.length,
      tasksCompleted: allEntries.filter(entry => entry.type === 'task' && entry.completed).length,
      totalTasks: allEntries.filter(entry => entry.type === 'task').length,
      nodesCreated: 0, // Would track actual node creation
      filesUploaded: allEntries.filter(entry => entry.type === 'file').length,
      timeSpent: Math.floor(Math.random() * 480), // Mock time tracking
    };
  };

  const stats = getDailyStats();

  return (
    <div className="min-h-screen flex flex-col space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Work Hub</h1>
          <p className="text-muted-foreground">
            {format(selectedDate, 'EEEE, MMMM d, yyyy')}
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="flex items-center space-x-1">
            <Target className="h-3 w-3" />
            <span>{Math.round(getTodayProgress())}% Complete</span>
          </Badge>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsAIDialogOpen(true)}
            className="flex items-center space-x-1"
          >
            <Brain className="h-4 w-4" />
            <span>AI Assistant</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 flex-1">
        {/* Main Timeline */}
        <div className="lg:col-span-3 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="h-5 w-5" />
                <span>Daily Work Timeline</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-[800px] overflow-y-auto">
                  {workBlocks.map((block) => (
                    <Card key={block.id} className={`${block.color} border-2`}>
                      <Collapsible 
                        open={expandedBlocks.has(block.id)}
                        onOpenChange={() => toggleBlockExpansion(block.id)}
                      >
                        <CollapsibleTrigger asChild>
                          <CardHeader className="cursor-pointer hover:bg-white/50 transition-colors">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                {block.icon}
                                <div>
                                  <CardTitle className="text-lg">{block.title}</CardTitle>
                                  <p className="text-sm text-muted-foreground">{block.timeRange}</p>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Badge variant="secondary">
                                  {block.entries.length} entries
                                </Badge>
                                {expandedBlocks.has(block.id) ? (
                                  <ChevronDown className="h-4 w-4" />
                                ) : (
                                  <ChevronRight className="h-4 w-4" />
                                )}
                              </div>
                            </div>
                          </CardHeader>
                        </CollapsibleTrigger>

                        <CollapsibleContent>
                          <CardContent className="space-y-3">
                            {/* Existing entries */}
                            {block.entries.map((entry) => (
                              <div key={entry.id} className="p-3 bg-white rounded-lg border">
                                <div className="flex items-start justify-between">
                                  <div className="flex-1">
                                    <div className="flex items-center space-x-2 mb-2">
                                      {entry.type === 'task' && (
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          onClick={() => toggleTaskCompletion(block.id, entry.id)}
                                          className="h-6 w-6 p-0"
                                        >
                                          {entry.completed ? (
                                            <CheckCircle2 className="h-4 w-4 text-green-600" />
                                          ) : (
                                            <Circle className="h-4 w-4" />
                                          )}
                                        </Button>
                                      )}
                                      <Badge variant="outline" className="text-xs">
                                        {entry.type}
                                      </Badge>
                                      {entry.mood && (
                                        <span className="text-sm">
                                          {moodIcons[entry.mood]}
                                        </span>
                                      )}
                                      <span className="text-xs text-muted-foreground">
                                        {format(entry.timestamp, 'HH:mm')}
                                      </span>
                                    </div>
                                    <p className={`text-sm ${entry.completed ? 'line-through text-muted-foreground' : ''}`}>
                                      {entry.content}
                                    </p>
                                    {entry.tags.length > 0 && (
                                      <div className="flex flex-wrap gap-1 mt-2">
                                        {entry.tags.map((tag) => (
                                          <Badge key={tag} variant="secondary" className="text-xs">
                                            #{tag}
                                          </Badge>
                                        ))}
                                      </div>
                                    )}
                                  </div>
                                  <div className="flex items-center space-x-1">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => createNodeFromEntry(entry)}
                                      className="h-8 w-8 p-0"
                                      title="Turn into node"
                                    >
                                      <Lightbulb className="h-3 w-3" />
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-8 w-8 p-0"
                                      title="Link to node"
                                    >
                                      <Link className="h-3 w-3" />
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            ))}

                            {/* Add new entry */}
                            {isAddingEntry && activeBlock === block.id ? (
                              <div className="p-3 bg-white rounded-lg border-2 border-dashed border-primary">
                                <div className="space-y-3">
                                  <div className="flex items-center space-x-2">
                                    <Tabs value={entryType} onValueChange={(value) => setEntryType(value as WorkEntry['type'])}>
                                      <TabsList className="grid w-full grid-cols-5">
                                        <TabsTrigger value="note">Note</TabsTrigger>
                                        <TabsTrigger value="task">Task</TabsTrigger>
                                        <TabsTrigger value="checkin">Check-in</TabsTrigger>
                                        <TabsTrigger value="meeting">Meeting</TabsTrigger>
                                        <TabsTrigger value="file">File</TabsTrigger>
                                      </TabsList>
                                    </Tabs>
                                  </div>

                                  <Textarea
                                    placeholder={`Add a ${entryType}...`}
                                    value={newEntry}
                                    onChange={(e) => setNewEntry(e.target.value)}
                                    className="min-h-[80px]"
                                  />

                                  {entryType === 'checkin' && (
                                    <div className="flex items-center space-x-2">
                                      <span className="text-sm">Mood:</span>
                                      {Object.entries(moodIcons).map(([mood, icon]) => (
                                        <Button
                                          key={mood}
                                          variant={selectedMood === mood ? "default" : "ghost"}
                                          size="sm"
                                          onClick={() => setSelectedMood(mood as WorkEntry['mood'])}
                                          className="h-8 w-8 p-0"
                                        >
                                          {icon}
                                        </Button>
                                      ))}
                                    </div>
                                  )}

                                  <div className="flex items-center space-x-2">
                                    <Input
                                      placeholder="Add tags..."
                                      value={newTag}
                                      onChange={(e) => setNewTag(e.target.value)}
                                      onKeyPress={(e) => e.key === 'Enter' && addTag()}
                                      className="flex-1"
                                    />
                                    <Button onClick={addTag} size="sm">
                                      <Hash className="h-4 w-4" />
                                    </Button>
                                  </div>

                                  {entryTags.length > 0 && (
                                    <div className="flex flex-wrap gap-1">
                                      {entryTags.map((tag) => (
                                        <Badge
                                          key={tag}
                                          variant="secondary"
                                          className="cursor-pointer"
                                          onClick={() => removeTag(tag)}
                                        >
                                          #{tag} ×
                                        </Badge>
                                      ))}
                                    </div>
                                  )}

                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center space-x-2">
                                      <input
                                        type="file"
                                        multiple
                                        ref={fileInputRef}
                                        onChange={handleFileUpload}
                                        className="hidden"
                                      />
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => fileInputRef.current?.click()}
                                      >
                                        <Paperclip className="h-4 w-4" />
                                      </Button>
                                      <Button variant="ghost" size="sm">
                                        <Mic className="h-4 w-4" />
                                      </Button>
                                      <Button variant="ghost" size="sm">
                                        <Video className="h-4 w-4" />
                                      </Button>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                      <Button
                                        variant="ghost"
                                        onClick={() => setIsAddingEntry(false)}
                                      >
                                        Cancel
                                      </Button>
                                      <Button onClick={() => addWorkEntry(block.id)}>
                                        Add {entryType}
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            ) : (
                              <Button
                                variant="outline"
                                className="w-full border-dashed"
                                onClick={() => {
                                  setActiveBlock(block.id);
                                  setIsAddingEntry(true);
                                }}
                              >
                                <Plus className="h-4 w-4 mr-2" />
                                Add to {block.title}
                              </Button>
                            )}
                          </CardContent>
                        </CollapsibleContent>
                      </Collapsible>
                    </Card>
                  ))}
                </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Sidebar */}
        <div className="space-y-4">
          {/* Smart Task Capsule */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <CheckCircle2 className="h-5 w-5" />
                <span>Smart Tasks</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="text-center">
                    <div className="font-medium">To Do</div>
                    <div className="text-muted-foreground">
                      {getTasksByStatus('todo').length}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="font-medium">Doing</div>
                    <div className="text-muted-foreground">
                      {getTasksByStatus('doing').length}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="font-medium">Done</div>
                    <div className="text-muted-foreground">
                      {getTasksByStatus('done').length}
                    </div>
                  </div>
                </div>
                <Button onClick={addSmartTask} className="w-full" size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Task
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Daily Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="h-5 w-5" />
                <span>Today's Progress</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Tasks Complete</span>
                  <span>{stats.tasksCompleted}/{stats.totalTasks}</span>
                </div>
                <Progress value={getTodayProgress()} className="h-2" />
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="text-center">
                  <div className="font-medium">{stats.totalEntries}</div>
                  <div className="text-muted-foreground">Entries</div>
                </div>
                <div className="text-center">
                  <div className="font-medium">{stats.filesUploaded}</div>
                  <div className="text-muted-foreground">Files</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Node Integration */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="h-5 w-5" />
                <span>Node Links</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {nodes.slice(0, 3).map((node) => (
                  <div key={node.id} className="flex items-center space-x-2 p-2 rounded-lg border">
                    <div className="w-2 h-2 rounded-full bg-blue-500" />
                    <span className="text-sm truncate">{node.title}</span>
                  </div>
                ))}
                <Button variant="ghost" size="sm" className="w-full">
                  <Link className="h-4 w-4 mr-2" />
                  Link Node
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* AI Assistant Dialog */}
      <Dialog open={isAIDialogOpen} onOpenChange={setIsAIDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Brain className="h-5 w-5" />
              <span>AI Assistant</span>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder="Ask about your day, get suggestions, or request analysis..."
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              className="min-h-[120px]"
            />
            <div className="flex flex-wrap gap-2">
              {[
                "What are today's major unfinished thoughts?",
                "Summarize my week's progress",
                "What's a good next step from these ideas?",
                "Generate daily report"
              ].map((suggestion) => (
                <Button
                  key={suggestion}
                  variant="outline"
                  size="sm"
                  onClick={() => setAiPrompt(suggestion)}
                >
                  {suggestion}
                </Button>
              ))}
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="ghost" onClick={() => setIsAIDialogOpen(false)}>
                Cancel
              </Button>
              <Button>
                <Zap className="h-4 w-4 mr-2" />
                Ask AI
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}