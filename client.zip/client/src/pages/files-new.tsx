import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Upload, 
  Search, 
  MoreVertical, 
  Download, 
  Share, 
  Link as LinkIcon, 
  Eye,
  FileIcon,
  ImageIcon,
  VideoIcon,
  FileTextIcon,
  MusicIcon,
  Paperclip,
  MessageSquare,
  Zap,
  Star,
  Sparkles
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function FilesNew() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFile, setSelectedFile] = useState<any>(null);
  const [linkDialogOpen, setLinkDialogOpen] = useState(false);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [selectedNodeId, setSelectedNodeId] = useState("");
  const [selectedChannelId, setSelectedChannelId] = useState("");
  const [shareMessage, setShareMessage] = useState("");
  const [linkedFiles, setLinkedFiles] = useState<Set<number>>(new Set());
  const [sharedFiles, setSharedFiles] = useState<Set<number>>(new Set());
  
  const queryClient = useQueryClient();

  // Log to confirm new component loads
  useEffect(() => {
    console.log("🎉 NEW FILES COMPONENT LOADED SUCCESSFULLY!");
  }, []);

  // Fetch files
  const { data: files = [], isLoading: filesLoading } = useQuery({
    queryKey: ["/api/files"],
  });

  // Fetch nodes for linking
  const { data: nodes = [] } = useQuery({
    queryKey: ["/api/nodes"],
  });

  // Fetch channels for sharing
  const { data: channels = [] } = useQuery({
    queryKey: ["/api/spaces/1/channels"],
  });

  // Link file to node mutation
  const linkMutation = useMutation({
    mutationFn: async ({ fileId, nodeId }: { fileId: number; nodeId: number }) => {
      const response = await apiRequest("/api/file-node-links", {
        method: "POST",
        body: { fileId, nodeId, linkType: "attachment" }
      });
      return response;
    },
    onSuccess: (data, variables) => {
      setLinkedFiles(prev => new Set([...prev, variables.fileId]));
      toast({
        title: "🎉 AMAZING SUCCESS!",
        description: `File is now LINKED to the knowledge graph!`,
      });
      setLinkDialogOpen(false);
      setSelectedNodeId("");
      queryClient.invalidateQueries({ queryKey: ["/api/node-links"] });
    },
    onError: (error) => {
      console.error("Link error:", error);
      toast({
        title: "❌ Oops!",
        description: "Failed to link file to node",
        variant: "destructive",
      });
    },
  });

  // Share file in chat mutation
  const shareMutation = useMutation({
    mutationFn: async ({ fileId, channelId, message }: { fileId: number; channelId: number; message: string }) => {
      const response = await apiRequest("/api/notify-file-upload", {
        method: "POST",
        body: { fileId, channelId, message }
      });
      return response;
    },
    onSuccess: (data, variables) => {
      setSharedFiles(prev => new Set([...prev, variables.fileId]));
      toast({
        title: "🚀 SHARED SUCCESSFULLY!",
        description: "File shared with your team in chat!",
      });
      setShareDialogOpen(false);
      setSelectedChannelId("");
      setShareMessage("");
    },
    onError: (error) => {
      console.error("Share error:", error);
      toast({
        title: "❌ Error",
        description: "Failed to share file in chat",
        variant: "destructive",
      });
    },
  });

  // Handle link to node
  const handleLinkToNode = () => {
    if (!selectedFile || !selectedNodeId) {
      toast({
        title: "Please select a node",
        description: "Choose a node to link this file to",
        variant: "destructive",
      });
      return;
    }
    
    linkMutation.mutate({
      fileId: selectedFile.id,
      nodeId: parseInt(selectedNodeId),
    });
  };

  // Handle share in chat
  const handleShareInChat = () => {
    if (!selectedFile || !selectedChannelId) {
      toast({
        title: "Please select a channel",
        description: "Choose a channel to share this file in",
        variant: "destructive",
      });
      return;
    }
    
    shareMutation.mutate({
      fileId: selectedFile.id,
      channelId: parseInt(selectedChannelId),
      message: shareMessage || `📎 ${selectedFile.name} has been shared`,
    });
  };

  // Filter files
  const filteredFiles = files.filter((file: any) => 
    file.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Get file icon with colors
  const getFileIcon = (mimeType: string) => {
    if (mimeType?.startsWith("image/")) return <ImageIcon className="w-6 h-6 text-white" />;
    if (mimeType?.startsWith("video/")) return <VideoIcon className="w-6 h-6 text-white" />;
    if (mimeType?.startsWith("audio/")) return <MusicIcon className="w-6 h-6 text-white" />;
    if (mimeType?.includes("pdf")) return <FileTextIcon className="w-6 h-6 text-white" />;
    return <FileIcon className="w-6 h-6 text-white" />;
  };

  // Format file size
  const formatFileSize = (bytes: number) => {
    if (!bytes) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return (bytes / Math.pow(k, i)).toFixed(1) + " " + sizes[i];
  };

  if (filesLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-yellow-400"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* GIANT HEADER */}
        <div className="text-center space-y-6 py-12">
          <div className="flex items-center justify-center gap-4 mb-6">
            <Sparkles className="w-12 h-12 text-yellow-400 animate-bounce" />
            <h1 className="text-8xl font-black bg-gradient-to-r from-yellow-400 via-pink-500 to-cyan-400 bg-clip-text text-transparent">
              REVAMPED FILES
            </h1>
            <Sparkles className="w-12 h-12 text-yellow-400 animate-bounce" />
          </div>
          <p className="text-3xl text-white font-bold animate-pulse">
            🔥 Link to Knowledge Graph • Share in Chat • See Visual Status! 🔥
          </p>
        </div>

        {/* HUGE Search Bar */}
        <div className="relative max-w-4xl mx-auto">
          <Search className="absolute left-8 top-1/2 transform -translate-y-1/2 text-yellow-400 w-8 h-8" />
          <Input
            placeholder="🔍 Search your incredible files..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-20 h-20 text-2xl bg-gradient-to-r from-purple-600/40 to-pink-600/40 backdrop-blur-lg border-4 border-yellow-400/60 text-white placeholder:text-yellow-100 rounded-full shadow-2xl shadow-yellow-400/20"
          />
        </div>

        {/* Files Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredFiles.map((file: any) => {
            const isLinked = linkedFiles.has(file.id);
            const isShared = sharedFiles.has(file.id);
            
            return (
              <Card key={file.id} className="bg-gradient-to-br from-purple-600/40 to-pink-600/40 backdrop-blur-lg border-4 border-yellow-400/40 hover:border-yellow-400/80 hover:shadow-2xl hover:shadow-yellow-400/30 transition-all duration-700 rounded-3xl overflow-hidden transform hover:scale-110">
                <CardHeader className="pb-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-4 flex-1 min-w-0">
                      <div className="p-4 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-3xl shadow-lg">
                        {getFileIcon(file.mimeType)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-black text-white truncate text-2xl" title={file.name}>
                          {file.name}
                        </h3>
                        <p className="text-xl text-yellow-200 font-bold">{formatFileSize(file.size)}</p>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="lg" className="h-12 w-12 rounded-full bg-white/20 hover:bg-white/30">
                          <MoreVertical className="w-6 h-6" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-gray-800 border-gray-600">
                        <DropdownMenuItem onClick={() => setSelectedFile(file)}>
                          <Eye className="w-4 h-4 mr-2" />
                          Preview
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardHeader>
                
                <CardContent className="pt-0">
                  {/* MASSIVE Status Indicators */}
                  <div className="flex flex-col gap-4 mb-8">
                    {isLinked && (
                      <Badge className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white border-0 flex items-center gap-3 px-6 py-3 text-xl font-black animate-pulse rounded-2xl">
                        <Zap className="w-6 h-6" />
                        ⚡ LINKED TO KNOWLEDGE GRAPH! ⚡
                      </Badge>
                    )}
                    {isShared && (
                      <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0 flex items-center gap-3 px-6 py-3 text-xl font-black animate-pulse rounded-2xl">
                        <MessageSquare className="w-6 h-6" />
                        💬 SHARED IN TEAM CHAT! 💬
                      </Badge>
                    )}
                  </div>

                  {/* GIANT Action Buttons */}
                  <div className="grid grid-cols-1 gap-6">
                    <Button
                      size="lg"
                      onClick={() => {
                        setSelectedFile(file);
                        setLinkDialogOpen(true);
                      }}
                      className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white border-0 h-20 text-2xl font-black shadow-2xl transform hover:scale-105 transition-all rounded-2xl"
                      disabled={linkMutation.isPending}
                    >
                      <LinkIcon className="w-8 h-8 mr-3" />
                      {isLinked ? "🔗 ALREADY LINKED!" : "🔗 LINK TO GRAPH NOW"}
                    </Button>
                    
                    <Button
                      size="lg"
                      onClick={() => {
                        setSelectedFile(file);
                        setShareDialogOpen(true);
                      }}
                      className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white border-0 h-20 text-2xl font-black shadow-2xl transform hover:scale-105 transition-all rounded-2xl"
                      disabled={shareMutation.isPending}
                    >
                      <Share className="w-8 h-8 mr-3" />
                      {isShared ? "💬 ALREADY SHARED!" : "💬 SHARE IN CHAT NOW"}
                    </Button>
                  </div>

                  {/* File Info */}
                  <div className="mt-6 text-lg text-yellow-100 space-y-2 font-semibold">
                    <div>📅 {new Date(file.uploadedAt || file.createdAt).toLocaleDateString()}</div>
                    <div>📊 {file.downloadCount || 0} downloads</div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredFiles.length === 0 && (
          <div className="text-center py-20">
            <FileIcon className="w-24 h-24 text-yellow-400 mx-auto mb-6" />
            <h3 className="text-4xl text-white mb-4 font-bold">No files found</h3>
            <p className="text-2xl text-gray-300">Upload some files to get started</p>
          </div>
        )}
      </div>

      {/* File Preview Dialog */}
      {selectedFile && !linkDialogOpen && !shareDialogOpen && (
        <Dialog open={!!selectedFile} onOpenChange={() => setSelectedFile(null)}>
          <DialogContent className="max-w-5xl bg-gray-900/95 border-gray-700 backdrop-blur-md">
            <DialogHeader>
              <DialogTitle className="text-white text-2xl">{selectedFile.name}</DialogTitle>
            </DialogHeader>
            <div className="mt-6">
              <div className="flex items-center justify-center h-96 bg-gray-800/50 rounded-xl border border-gray-600">
                {selectedFile.mimeType?.startsWith("image/") ? (
                  <img 
                    src={selectedFile.url} 
                    alt={selectedFile.name}
                    className="max-h-full max-w-full object-contain rounded-lg"
                  />
                ) : selectedFile.mimeType?.startsWith("video/") ? (
                  <video 
                    src={selectedFile.url} 
                    controls 
                    className="max-h-full max-w-full rounded-lg"
                  />
                ) : selectedFile.mimeType === "application/pdf" ? (
                  <iframe 
                    src={selectedFile.url} 
                    className="w-full h-full rounded-lg"
                    title={selectedFile.name}
                  />
                ) : (
                  <div className="text-center text-gray-400">
                    <FileIcon className="w-16 h-16 mx-auto mb-4" />
                    <p className="text-lg mb-4">Preview not available</p>
                    <Button onClick={() => window.open(selectedFile.url, '_blank')}>
                      <Download className="w-4 h-4 mr-2" />
                      Download to view
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Link to Node Dialog */}
      <Dialog open={linkDialogOpen} onOpenChange={setLinkDialogOpen}>
        <DialogContent className="bg-gray-900/95 border-gray-700 backdrop-blur-md">
          <DialogHeader>
            <DialogTitle className="text-white text-2xl flex items-center gap-3">
              <LinkIcon className="w-6 h-6" />
              🔗 Link to Knowledge Graph
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6 mt-6">
            <div className="text-gray-300 text-lg">
              Connect <span className="font-bold text-blue-400">{selectedFile?.name}</span> to a node in your knowledge graph
            </div>
            
            <div>
              <Label className="text-white text-lg">Select Node</Label>
              <Select value={selectedNodeId} onValueChange={setSelectedNodeId}>
                <SelectTrigger className="mt-3 bg-gray-800 border-gray-600 text-white h-14 text-lg">
                  <SelectValue placeholder="Choose a node to link to..." />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  {nodes.map((node: any) => (
                    <SelectItem key={node.id} value={node.id.toString()}>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="text-xs">
                          {node.nodeType}
                        </Badge>
                        <span>{node.title}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex justify-end space-x-4">
              <Button variant="outline" onClick={() => setLinkDialogOpen(false)} size="lg">
                Cancel
              </Button>
              <Button 
                onClick={handleLinkToNode}
                disabled={linkMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700"
                size="lg"
              >
                {linkMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Linking...
                  </>
                ) : (
                  <>
                    <LinkIcon className="w-5 h-5 mr-2" />
                    Link to Graph
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Share in Chat Dialog */}
      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent className="bg-gray-900/95 border-gray-700 backdrop-blur-md">
          <DialogHeader>
            <DialogTitle className="text-white text-2xl flex items-center gap-3">
              <Share className="w-6 h-6" />
              💬 Share in Team Chat
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6 mt-6">
            <div className="text-gray-300 text-lg">
              Share <span className="font-bold text-green-400">{selectedFile?.name}</span> with your team
            </div>
            
            <div>
              <Label className="text-white text-lg">Select Channel</Label>
              <Select value={selectedChannelId} onValueChange={setSelectedChannelId}>
                <SelectTrigger className="mt-3 bg-gray-800 border-gray-600 text-white h-14 text-lg">
                  <SelectValue placeholder="Choose a channel to share in..." />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  {channels.map((channel: any) => (
                    <SelectItem key={channel.id} value={channel.id.toString()}>
                      # {channel.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="text-white text-lg">Message (optional)</Label>
              <Textarea
                value={shareMessage}
                onChange={(e) => setShareMessage(e.target.value)}
                placeholder="Add a message with the file..."
                className="mt-3 bg-gray-800 border-gray-600 text-white text-lg"
                rows={3}
              />
            </div>
            
            <div className="flex justify-end space-x-4">
              <Button variant="outline" onClick={() => setShareDialogOpen(false)} size="lg">
                Cancel
              </Button>
              <Button 
                onClick={handleShareInChat}
                disabled={shareMutation.isPending}
                className="bg-green-600 hover:bg-green-700"
                size="lg"
              >
                {shareMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Sharing...
                  </>
                ) : (
                  <>
                    <Share className="w-5 h-5 mr-2" />
                    Share in Chat
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}