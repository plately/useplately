import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { apiRequest } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';
import { 
  Search, 
  Filter, 
  Plus, 
  MoreHorizontal, 
  Calendar,
  Users,
  BarChart3,
  Kanban,
  List,
  Play,
  Check,
  Pause,
  RotateCcw,
  XCircle,
  Clock,
  AlertTriangle,
  ListFilter
} from 'lucide-react';
import AdvancedTaskForm from '@/components/advanced-task-form';
import { Node } from '@shared/schema';

// Define the Task interface to match the Node structure
interface Task extends Node {
  properties: {
    status: "todo" | "in-progress" | "done" | "blocked";
    assignee: number;
    priority: "low" | "medium" | "high" | "critical";
    dueDate?: string;
  }
  assignedUser?: {
    id: number;
    displayName: string;
    avatar?: string;
  }
}

export default function Tasks() {
  const [view, setView] = useState<"kanban" | "list" | "timeline" | "analytics">("kanban");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const queryClient = useQueryClient();

  // Fetch all nodes that are tasks
  const { data: nodes, isLoading } = useQuery({
    queryKey: ['/api/nodes'],
    select: (data) => data?.filter(node => node.nodeType === 'task') || []
  });

  // Transform nodes to tasks with proper typing
  const tasks = nodes?.map(node => ({
    ...node,
    properties: {
      status: node.properties?.status || "todo",
      assignee: node.properties?.assignee || 1,
      priority: node.properties?.priority || "medium",
      dueDate: node.properties?.dueDate
    },
    assignedUser: {
      id: 1,
      displayName: "John Doe",
      avatar: undefined
    }
  })) as Task[] || [];

  // Filter tasks
  const filteredTasks = tasks?.filter(task => {
    const matchesSearch = searchQuery 
      ? task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        task.content?.toLowerCase().includes(searchQuery.toLowerCase())
      : true;
    
    const matchesStatus = statusFilter !== "all" 
      ? task.properties.status === statusFilter 
      : true;
    
    const matchesPriority = priorityFilter !== "all" 
      ? task.properties.priority === priorityFilter 
      : true;
    
    return matchesSearch && matchesStatus && matchesPriority;
  }) || [];

  // Group tasks by status
  const todoTasks = filteredTasks?.filter(task => task.properties.status === "todo") || [];
  const inProgressTasks = filteredTasks?.filter(task => task.properties.status === "in-progress") || [];
  const doneTasks = filteredTasks?.filter(task => task.properties.status === "done") || [];
  const blockedTasks = filteredTasks?.filter(task => task.properties.status === "blocked") || [];

  // Mutation to update task status
  const updateTaskStatus = useMutation({
    mutationFn: async ({ taskId, status }: { taskId: number, status: string }) => {
      return await apiRequest(`/api/nodes/${taskId}`, {
        method: 'PATCH',
        body: JSON.stringify({
          properties: { status }
        })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/nodes'] });
      toast({
        title: "Task updated",
        description: "Task status has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: "Failed to update task status.",
        variant: "destructive",
      });
    },
  });

  // Get priority color
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical": return "bg-red-500";
      case "high": return "bg-orange-500";
      case "medium": return "bg-yellow-500";
      case "low": return "bg-green-500";
      default: return "bg-gray-500";
    }
  };

  // Get node type color with priority
  const getNodeTypeColor = (nodeType: string, priority: string) => {
    const baseColors = {
      task: "bg-green-500",
      journal: "bg-blue-500",
      meeting: "bg-purple-500",
      document: "bg-orange-500",
      note: "bg-indigo-500",
      integration: "bg-pink-500"
    };
    
    if (priority === "critical") return "bg-red-500";
    if (priority === "high") return "bg-orange-500";
    
    return baseColors[nodeType as keyof typeof baseColors] || "bg-gray-500";
  };

  // Get status badge variant
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "todo": return "secondary";
      case "in-progress": return "default";
      case "done": return "default";
      case "blocked": return "destructive";
      default: return "secondary";
    }
  };

  // Get status actions for a task
  const getStatusActions = (task: Task) => {
    const actions = [];
    
    switch (task.properties.status) {
      case "todo":
        actions.push({
          icon: <Play className="h-3 w-3" />,
          label: "Start",
          action: () => updateTaskStatus.mutate({ taskId: task.id, status: "in-progress" }),
          variant: "default" as const
        });
        break;
      case "in-progress":
        actions.push({
          icon: <Check className="h-3 w-3" />,
          label: "Complete",
          action: () => updateTaskStatus.mutate({ taskId: task.id, status: "done" }),
          variant: "default" as const
        });
        actions.push({
          icon: <Pause className="h-3 w-3" />,
          label: "Pause",
          action: () => updateTaskStatus.mutate({ taskId: task.id, status: "todo" }),
          variant: "outline" as const
        });
        break;
      case "done":
        actions.push({
          icon: <RotateCcw className="h-3 w-3" />,
          label: "Reopen",
          action: () => updateTaskStatus.mutate({ taskId: task.id, status: "todo" }),
          variant: "outline" as const
        });
        break;
      case "blocked":
        actions.push({
          icon: <Play className="h-3 w-3" />,
          label: "Unblock",
          action: () => updateTaskStatus.mutate({ taskId: task.id, status: "todo" }),
          variant: "default" as const
        });
        break;
    }
    
    return actions;
  };

  // Render task card with hover actions
  const renderTaskCard = (task: Task) => (
    <Card key={task.id} className="mb-2 group hover:shadow-md transition-all duration-200 cursor-pointer relative overflow-visible">
      <CardContent className="p-3">
        {/* Node indicator strip */}
        <div className={`absolute left-0 top-0 bottom-0 w-1 ${getNodeTypeColor(task.nodeType, task.properties.priority)}`}></div>
        
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0 pr-2">
            <div className="flex items-center mb-1">
              <h4 className="font-medium text-sm truncate">{task.title}</h4>
              <div className="text-[9px] text-muted-foreground bg-muted px-1 py-0.5 rounded ml-2 uppercase font-semibold tracking-wide">
                {task.nodeType}
              </div>
            </div>
            <Badge variant={getStatusBadgeVariant(task.properties.status)} className="text-xs mb-2">
              {task.properties.status.replace('-', ' ')}
            </Badge>
          </div>
          
          {/* Hover action buttons */}
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            {getStatusActions(task).map((action, index) => (
              <Button
                key={index}
                variant={action.variant}
                size="icon"
                className="h-6 w-6"
                onClick={(e) => {
                  e.stopPropagation();
                  action.action();
                }}
                title={action.label}
              >
                {action.icon}
              </Button>
            ))}
            <DropdownMenu modal={false}>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-6 w-6 opacity-60 hover:opacity-100">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent 
                align="end" 
                className="z-[60]" 
                sideOffset={5}
                avoidCollisions={true}
                collisionPadding={20}
              >
                <DropdownMenuItem onClick={() => setSelectedTask(task)}>
                  Edit Task
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => updateTaskStatus.mutate({ taskId: task.id, status: "blocked" })}
                  className="text-red-600"
                >
                  <XCircle className="h-4 w-4 mr-2" />
                  Mark as Blocked
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        
        <div className="mt-2 text-xs text-muted-foreground line-clamp-2">
          {task.content}
        </div>
        
        <div className="flex items-center justify-between mt-3">
          <div className="flex items-center gap-2">
            <div className={`h-2 w-2 rounded-full ${getPriorityColor(task.properties.priority)}`}></div>
            <span className="text-xs text-muted-foreground capitalize">{task.properties.priority}</span>
            {task.properties.dueDate && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                {new Date(task.properties.dueDate).toLocaleDateString()}
              </div>
            )}
          </div>
          
          {task.assignedUser && (
            <Avatar className="h-5 w-5">
              <AvatarImage src={task.assignedUser.avatar} />
              <AvatarFallback className="text-xs">{task.assignedUser.displayName.split(' ').map(n => n[0]).join('')}</AvatarFallback>
            </Avatar>
          )}
        </div>
      </CardContent>
    </Card>
  );
  
  // Render Kanban column
  const renderKanbanColumn = (title: string, icon: React.ReactNode, tasks: Task[] = []) => (
    <div 
      className="w-56 sm:w-64 md:w-60 lg:w-64 xl:w-72 flex-shrink-0" 
      style={{ scrollSnapAlign: 'start' }}
    >
      <div className="bg-background rounded-md border flex flex-col h-full">
        <div className="p-3 border-b flex items-center justify-between">
          <div className="flex items-center">
            {icon}
            <h3 className="font-medium ml-2">{title}</h3>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded-full">{tasks.length}</span>
            <Button variant="ghost" size="icon" className="h-6 w-6">
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <div className="flex-1 p-2 overflow-y-auto">
          {tasks?.map(renderTaskCard)}
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Header with controls */}
      <div className="border-b bg-background p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-semibold">Tasks</h1>
            
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search tasks..."
                className="pl-10 w-64"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            {/* Filters */}
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="todo">To Do</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="done">Done</SelectItem>
                <SelectItem value="blocked">Blocked</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priority</SelectItem>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center gap-2">
            {/* View toggles */}
            <div className="flex bg-muted rounded-md p-1">
              <Button
                variant={view === "kanban" ? "default" : "ghost"}
                size="sm"
                onClick={() => setView("kanban")}
                className="h-8"
              >
                <Kanban className="h-4 w-4 mr-1" />
                Kanban
              </Button>
              <Button
                variant={view === "list" ? "default" : "ghost"}
                size="sm"
                onClick={() => setView("list")}
                className="h-8"
              >
                <List className="h-4 w-4 mr-1" />
                List
              </Button>
            </div>
            
            <Button size="sm" variant="outline">
              <Filter className="h-4 w-4 mr-1" />
              Filter
            </Button>
            <Button size="sm" variant="outline">
              <ListFilter className="h-4 w-4 mr-1" />
              Group
            </Button>
            <Button size="sm" className="h-8" onClick={() => setShowTaskForm(true)}>
              <Plus className="h-4 w-4 mr-1" />
              New Task Node
            </Button>
          </div>
        </div>
      </div>
      
      {/* Tasks content */}
      <div className="flex-1">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="animate-spin h-8 w-8 border-4 border-primary rounded-full border-t-transparent"></div>
          </div>
        ) : (
          <div className="h-full">
            {view === "kanban" && (
              <div className="relative h-full">
                {/* Scroll indicator */}
                <div className="absolute top-2 right-2 z-10 bg-background/80 backdrop-blur-sm border rounded px-2 py-1 text-xs text-muted-foreground">
                  ← Scroll horizontally →
                </div>
                
                <div 
                  className="w-full h-full overflow-x-auto overflow-y-hidden p-2 scroll-smooth"
                  style={{ 
                    scrollSnapType: 'x mandatory',
                    WebkitOverflowScrolling: 'touch'
                  }}
                >
                  <div className="flex space-x-2 pb-4 h-full" style={{ width: 'max-content', minWidth: '100%' }}>
                    {renderKanbanColumn(
                      "To Do", 
                      <div className="h-4 w-4 md:h-5 md:w-5 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                        <div className="h-2 w-2 md:h-2.5 md:w-2.5 rounded-full bg-gray-400 dark:bg-gray-500"></div>
                      </div>, 
                      todoTasks
                    )}
                    
                    {renderKanbanColumn(
                      "In Progress", 
                      <div className="h-4 w-4 md:h-5 md:w-5 rounded-full bg-blue-500 flex items-center justify-center">
                        <div className="h-2 w-2 md:h-2.5 md:w-2.5 rounded-full bg-white"></div>
                      </div>, 
                      inProgressTasks
                    )}
                    
                    {renderKanbanColumn(
                      "Done", 
                      <div className="h-4 w-4 md:h-5 md:w-5 rounded-full bg-green-500 flex items-center justify-center">
                        <div className="h-2 w-2 md:h-2.5 md:w-2.5 rounded-full bg-white"></div>
                      </div>, 
                      doneTasks
                    )}
                    
                    {renderKanbanColumn(
                      "Blocked", 
                      <div className="h-4 w-4 md:h-5 md:w-5 rounded-full bg-red-500 flex items-center justify-center">
                        <div className="h-2 w-2 md:h-2.5 md:w-2.5 rounded-full bg-white"></div>
                      </div>, 
                      blockedTasks
                    )}
                    
                    {/* Add Column - Desktop only */}
                    <div className="hidden md:flex w-72 flex-shrink-0 border rounded-md border-dashed items-center justify-center">
                      <Button variant="ghost">
                        <Plus className="h-4 w-4 mr-1" />
                        Add Column
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {view === "list" && (
              <div className="h-full p-4">
                <div className="bg-background rounded-md border h-full overflow-hidden">
                  {/* List header */}
                  <div className="grid grid-cols-12 p-3 border-b text-sm font-medium text-muted-foreground">
                    <div className="col-span-6">Task</div>
                    <div className="col-span-2">Status</div>
                    <div className="col-span-2">Assignee</div>
                    <div className="col-span-1">Priority</div>
                    <div className="col-span-1">Due Date</div>
                  </div>
                  
                  <ScrollArea className="h-[calc(100%-40px)]">
                    {filteredTasks?.map(task => (
                      <div key={task.id} className="grid grid-cols-12 p-3 border-b hover:bg-accent/50 items-center relative">
                        {/* Node indicator strip */}
                        <div className={`absolute left-0 top-0 bottom-0 w-1 ${getNodeTypeColor(task.nodeType, task.properties.priority)}`}></div>
                        
                        <div className="col-span-6">
                          <div className="flex items-center">
                            <div className={`h-2.5 w-2.5 rounded-full mr-2 ${getNodeTypeColor(task.nodeType, task.properties.priority)}`}></div>
                            <div>
                              <div className="font-medium flex items-center">
                                {task.title}
                                <div className="text-[9px] text-muted-foreground bg-muted px-1 py-0.5 rounded ml-2 uppercase font-semibold tracking-wide">
                                  {task.nodeType}
                                </div>
                              </div>
                              <div className="text-sm text-muted-foreground line-clamp-1">{task.content}</div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="col-span-2">
                          <Badge variant={getStatusBadgeVariant(task.properties.status)} className="text-xs">
                            {task.properties.status.replace('-', ' ')}
                          </Badge>
                        </div>
                        
                        <div className="col-span-2">
                          {task.assignedUser && (
                            <div className="flex items-center gap-2">
                              <Avatar className="h-6 w-6">
                                <AvatarImage src={task.assignedUser.avatar} />
                                <AvatarFallback className="text-xs">{task.assignedUser.displayName.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                              </Avatar>
                              <span className="text-sm">{task.assignedUser.displayName}</span>
                            </div>
                          )}
                        </div>
                        
                        <div className="col-span-1">
                          <div className="flex items-center gap-1">
                            <div className={`h-2 w-2 rounded-full ${getPriorityColor(task.properties.priority)}`}></div>
                            <span className="text-xs capitalize">{task.properties.priority}</span>
                          </div>
                        </div>
                        
                        <div className="col-span-1">
                          {task.properties.dueDate ? (
                            <div className="text-xs text-muted-foreground">
                              {new Date(task.properties.dueDate).toLocaleDateString()}
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground">-</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </ScrollArea>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Advanced Task Form */}
      <AdvancedTaskForm
        isOpen={showTaskForm}
        onClose={() => {
          setShowTaskForm(false);
          setSelectedTask(null);
        }}
        task={selectedTask}
        onSuccess={() => {
          setShowTaskForm(false);
          setSelectedTask(null);
        }}
      />
    </div>
  );
}