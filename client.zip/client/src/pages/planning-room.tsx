import React, { useState, useRef, useCallback, useEffect, useContext } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

import { Separator } from '@/components/ui/separator';
import { apiRequest } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';
import UniversalNodeCreator from '@/components/universal-node-creator';
import { ThemeContext } from '@/components/theme-provider';
import { 
  Plus, 
  Search, 
  Star, 
  StarOff,
  Lightbulb, 
  CheckSquare, 
  Paperclip, 
  Link, 
  Calendar, 
  MessageCircle,
  Move,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Grid,
  MousePointer,
  Maximize,
  Download,
  Upload,
  Trash2,
  Copy,
  Lock,
  Unlock,
  Edit2,
  Undo,
  Camera,
  Users,
  Palette,
  Settings,
  Home,
  Target,
  Layers,
  MoreHorizontal,
  Sun,
  Moon,
  Map as MapIcon,
  Save,
  Share2
} from 'lucide-react';

// Planning Room interfaces
interface PlanningRoom {
  id: number;
  name: string;
  description?: string;
  template: string;
  starred: boolean;
  createdAt: Date;
  updatedAt: Date;
  blocks: PlanningBlock[];
  connections: BlockConnection[];
  collaborators?: number[]; // User IDs who can access this room
  createdBy?: number; // User ID of the creator
}

interface PlanningBlock {
  id: string;
  type: 'idea' | 'task' | 'file' | 'node' | 'timeline' | 'comment' | 'email';
  x: number;
  y: number;
  width: number;
  height: number;
  title: string;
  content: string;
  color: string;
  locked: boolean;
  assignedTo?: number;
  graphProfiles?: number[]; // Array of graph profile IDs this block belongs to
  metadata?: Record<string, any>;
  scheduleDate?: string; // ISO date string for when to execute this block
  scheduleTime?: string; // Time in HH:MM format
}

interface BlockConnection {
  id: string;
  sourceId: string;
  targetId: string;
  label: string;
  type: 'depends_on' | 'relates_to' | 'blocks' | 'enables';
}

interface CanvasState {
  zoom: number;
  offsetX: number;
  offsetY: number;
  selectedBlocks: string[];
  isDragging: boolean;
  dragStart: { x: number; y: number } | null;
  mode: 'select' | 'draw' | 'connect';
  snapToGrid: boolean;
}

const GRID_SIZE = 20;
const BLOCK_COLORS = [
  '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', 
  '#06B6D4', '#84CC16', '#F97316', '#EC4899', '#6366F1'
];

const TEMPLATES = [
  { id: 'project_kickoff', name: 'Project Kickoff', description: 'Initial planning and stakeholder alignment' },
  { id: 'sprint_planning', name: 'Sprint Planning', description: 'Agile sprint setup and task breakdown' },
  { id: 'product_launch', name: 'Product Launch', description: 'Go-to-market and launch checklist' },
  { id: 'client_onboarding', name: 'Client Onboarding', description: 'New client setup and requirements gathering' },
  { id: 'resource_planning', name: 'Resource Planning', description: 'Team allocation and capacity management' },
  { id: 'blank', name: 'Blank Canvas', description: 'Start from scratch' }
];

export default function PlanningRoom() {
  const [selectedRoom, setSelectedRoom] = useState<PlanningRoom | null>(null);
  const [canvasState, setCanvasState] = useState<CanvasState>({
    zoom: 1,
    offsetX: 0,
    offsetY: 0,
    selectedBlocks: [],
    isDragging: false,
    dragStart: null,
    mode: 'select',
    snapToGrid: true
  });
  const [showNewRoomDialog, setShowNewRoomDialog] = useState(false);
  const [showBlockEditor, setShowBlockEditor] = useState(false);
  const [selectedBlock, setSelectedBlock] = useState<PlanningBlock | null>(null);
  const [showConnectionEditor, setShowConnectionEditor] = useState(false);
  const [selectedConnection, setSelectedConnection] = useState<BlockConnection | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [newRoomName, setNewRoomName] = useState("");
  const [newRoomDescription, setNewRoomDescription] = useState("");
  const [newRoomTemplate, setNewRoomTemplate] = useState("blank");
  const [showMiniMap, setShowMiniMap] = useState(true);
  const [connectionStart, setConnectionStart] = useState<string | null>(null);
  const [tempConnection, setTempConnection] = useState<{x: number, y: number} | null>(null);
  const [undoStack, setUndoStack] = useState<PlanningRoom[]>([]);
  const [editingRoomId, setEditingRoomId] = useState<number | null>(null);
  const [editingRoomName, setEditingRoomName] = useState("");
  const [showCollaboratorsDialog, setShowCollaboratorsDialog] = useState(false);
  const [selectedCollaborators, setSelectedCollaborators] = useState<number[]>([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  
  // Get global theme
  const { theme } = useContext(ThemeContext);
  const isDarkMode = theme === 'dark';

  // Query for graph profiles
  const { data: graphProfiles } = useQuery<any[]>({
    queryKey: ['/api/graph-profiles'],
    enabled: true
  });

  // Query for channels (for comment blocks)
  const { data: channels } = useQuery<any[]>({
    queryKey: ['/api/channels'],
    enabled: true
  });

  // Query for users (for task assignment)
  const { data: users } = useQuery<any[]>({
    queryKey: ['/api/users'],
    enabled: true
  });

  // Query for nodes (for linking blocks to existing nodes)
  const { data: allNodes } = useQuery<any[]>({
    queryKey: ['/api/nodes'],
    enabled: true
  });

  // Load rooms from localStorage on mount
  const [rooms, setRooms] = useState<PlanningRoom[]>([]);

  useEffect(() => {
    const savedRooms = localStorage.getItem('planning-rooms');
    if (savedRooms) {
      setRooms(JSON.parse(savedRooms));
    } else {
      // Initialize with default room
      const defaultRooms: PlanningRoom[] = [
    {
      id: 1,
      name: "Q1 2025 Project Kickoff",
      description: "Strategic planning and team alignment",
      template: "project_kickoff",
      starred: true,
      createdAt: new Date(),
      updatedAt: new Date(),
      blocks: [
        {
          id: 'block-1',
          type: 'idea',
          x: 100,
          y: 100,
          width: 200,
          height: 120,
          title: 'Project Goals',
          content: 'Define objectives, success criteria, and key deliverables',
          color: '#3B82F6',
          locked: false,
          graphProfiles: [1] // Default to "Everything" profile
        },
        {
          id: 'block-2',
          type: 'task',
          x: 400,
          y: 100,
          width: 200,
          height: 120,
          title: 'Stakeholder Meeting',
          content: 'Schedule and conduct initial alignment meeting',
          color: '#10B981',
          locked: false,
          graphProfiles: [1] // Default to "Everything" profile
        },
        {
          id: 'block-3',
          type: 'timeline',
          x: 250,
          y: 300,
          width: 250,
          height: 100,
          title: 'Project Timeline',
          content: 'Establish key milestones and delivery dates',
          color: '#F59E0B',
          locked: false,
          graphProfiles: [1] // Default to "Everything" profile
        }
      ],
      connections: [
        {
          id: 'conn-1',
          sourceId: 'block-1',
          targetId: 'block-2',
          label: 'enables',
          type: 'enables'
        },
        {
          id: 'conn-2',
          sourceId: 'block-2',
          targetId: 'block-3',
          label: 'contributes to',
          type: 'relates_to'
        }
      ]
    },
    {
      id: 2,
      name: "Sprint 12 Planning",
      description: "Development sprint setup and task breakdown",
      template: "sprint_planning",
      starred: false,
      createdAt: new Date(),
      updatedAt: new Date(),
      blocks: [],
      connections: []
    }
  ];
      setRooms(defaultRooms);
      localStorage.setItem('planning-rooms', JSON.stringify(defaultRooms));
    }
  }, []);

  const filteredRooms = rooms.filter(room => 
    searchQuery === "" || 
    room.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    room.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Canvas drawing and interaction logic
  const drawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !selectedRoom) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();

    // Apply zoom and offset
    ctx.scale(canvasState.zoom, canvasState.zoom);
    ctx.translate(canvasState.offsetX, canvasState.offsetY);

    // Draw clean background
    ctx.fillStyle = isDarkMode ? '#0a0a0a' : '#f7f7f8';
    const canvasWidth = canvas.width / canvasState.zoom;
    const canvasHeight = canvas.height / canvasState.zoom;
    ctx.fillRect(-canvasState.offsetX, -canvasState.offsetY, canvasWidth, canvasHeight);
    
    // Draw subtle grid
    if (canvasState.snapToGrid) {
      ctx.strokeStyle = isDarkMode ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.04)';
      ctx.lineWidth = 1;
      
      const gridSpacing = GRID_SIZE;
      const startX = Math.floor(-canvasState.offsetX / gridSpacing) * gridSpacing;
      const startY = Math.floor(-canvasState.offsetY / gridSpacing) * gridSpacing;
      const endX = startX + (canvas.width / canvasState.zoom) + gridSpacing;
      const endY = startY + (canvas.height / canvasState.zoom) + gridSpacing;

      for (let x = startX; x < endX; x += gridSpacing) {
        ctx.beginPath();
        ctx.moveTo(x, startY);
        ctx.lineTo(x, endY);
        ctx.stroke();
      }

      for (let y = startY; y < endY; y += gridSpacing) {
        ctx.beginPath();
        ctx.moveTo(startX, y);
        ctx.lineTo(endX, y);
        ctx.stroke();
      }
    }

    // Draw connections
    selectedRoom.connections.forEach(connection => {
      const sourceBlock = selectedRoom.blocks.find(b => b.id === connection.sourceId);
      const targetBlock = selectedRoom.blocks.find(b => b.id === connection.targetId);
      
      if (sourceBlock && targetBlock) {
        ctx.strokeStyle = isDarkMode ? '#6B7280' : '#9CA3AF';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        
        const sourceX = sourceBlock.x + sourceBlock.width / 2;
        const sourceY = sourceBlock.y + sourceBlock.height / 2;
        const targetX = targetBlock.x + targetBlock.width / 2;
        const targetY = targetBlock.y + targetBlock.height / 2;
        
        ctx.beginPath();
        ctx.moveTo(sourceX, sourceY);
        ctx.lineTo(targetX, targetY);
        ctx.stroke();
        
        // Draw arrow
        const angle = Math.atan2(targetY - sourceY, targetX - sourceX);
        const arrowLength = 10;
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.moveTo(targetX, targetY);
        ctx.lineTo(
          targetX - arrowLength * Math.cos(angle - Math.PI / 6),
          targetY - arrowLength * Math.sin(angle - Math.PI / 6)
        );
        ctx.moveTo(targetX, targetY);
        ctx.lineTo(
          targetX - arrowLength * Math.cos(angle + Math.PI / 6),
          targetY - arrowLength * Math.sin(angle + Math.PI / 6)
        );
        ctx.stroke();
        
        // Draw label with background (clickable)
        if (connection.label) {
          const labelX = (sourceX + targetX) / 2;
          const labelY = (sourceY + targetY) / 2;
          
          // Draw label background with hover effect
          ctx.fillStyle = isDarkMode ? 'rgba(31, 41, 55, 0.9)' : 'rgba(255, 255, 255, 0.9)';
          ctx.font = '12px system-ui';
          ctx.textAlign = 'center';
          const metrics = ctx.measureText(connection.label);
          const padding = 6;
          const labelBounds = {
            x: labelX - metrics.width / 2 - padding,
            y: labelY - 8,
            width: metrics.width + padding * 2,
            height: 16
          };
          
          // Store label bounds for click detection
          (connection as any).labelBounds = labelBounds;
          
          ctx.fillRect(labelBounds.x, labelBounds.y, labelBounds.width, labelBounds.height);
          
          // Draw border for clickable indication
          ctx.strokeStyle = isDarkMode ? '#374151' : '#E5E7EB';
          ctx.lineWidth = 1;
          ctx.setLineDash([]);
          ctx.strokeRect(labelBounds.x, labelBounds.y, labelBounds.width, labelBounds.height);
          
          // Draw label text
          ctx.fillStyle = isDarkMode ? '#F3F4F6' : '#1F2937';
          ctx.fillText(connection.label, labelX, labelY + 4);
        }
      }
    });

    // Draw temporary connection in connect mode
    if (connectionStart && tempConnection) {
      const sourceBlock = selectedRoom.blocks.find(b => b.id === connectionStart);
      if (sourceBlock) {
        ctx.strokeStyle = isDarkMode ? '#60A5FA' : '#3B82F6';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        
        const sourceX = sourceBlock.x + sourceBlock.width / 2;
        const sourceY = sourceBlock.y + sourceBlock.height / 2;
        
        ctx.beginPath();
        ctx.moveTo(sourceX, sourceY);
        ctx.lineTo(tempConnection.x, tempConnection.y);
        ctx.stroke();
        
        // Draw temp arrow
        const angle = Math.atan2(tempConnection.y - sourceY, tempConnection.x - sourceX);
        const arrowLength = 10;
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.moveTo(tempConnection.x, tempConnection.y);
        ctx.lineTo(
          tempConnection.x - arrowLength * Math.cos(angle - Math.PI / 6),
          tempConnection.y - arrowLength * Math.sin(angle - Math.PI / 6)
        );
        ctx.moveTo(tempConnection.x, tempConnection.y);
        ctx.lineTo(
          tempConnection.x - arrowLength * Math.cos(angle + Math.PI / 6),
          tempConnection.y - arrowLength * Math.sin(angle + Math.PI / 6)
        );
        ctx.stroke();
      }
    }

    // Helper function for rounded rectangles
    const roundRect = (x: number, y: number, width: number, height: number, radius: number) => {
      ctx.beginPath();
      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + width - radius, y);
      ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
      ctx.lineTo(x + width, y + height - radius);
      ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
      ctx.lineTo(x + radius, y + height);
      ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
    };

    // Draw blocks
    selectedRoom.blocks.forEach(block => {
      const isSelected = canvasState.selectedBlocks.includes(block.id);
      const borderRadius = 12;
      
      // Enhanced shadow for better depth
      ctx.shadowColor = isDarkMode ? 'rgba(0, 0, 0, 0.4)' : 'rgba(0, 0, 0, 0.15)';
      ctx.shadowBlur = isDarkMode ? 20 : 16;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = isDarkMode ? 6 : 4;
      
      // Block background with rounded corners
      ctx.fillStyle = block.color;
      roundRect(block.x, block.y, block.width, block.height, borderRadius);
      ctx.fill();
      
      // Reset shadow
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;
      
      // Add subtle border to all blocks for better definition
      ctx.strokeStyle = isDarkMode ? 'rgba(255, 255, 255, 0.15)' : 'rgba(0, 0, 0, 0.1)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([]);
      roundRect(block.x, block.y, block.width, block.height, borderRadius);
      ctx.stroke();
      
      // Selection border
      if (isSelected) {
        ctx.strokeStyle = isDarkMode ? '#60A5FA' : '#3B82F6';
        ctx.lineWidth = 3;
        ctx.setLineDash([]);
        roundRect(block.x - 1.5, block.y - 1.5, block.width + 3, block.height + 3, borderRadius + 1);
        ctx.stroke();
      }
      
      // Block content with text shadow for better readability
      ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
      ctx.shadowBlur = 2;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 1;
      
      ctx.fillStyle = 'white';
      ctx.font = '700 15px Inter, system-ui, -apple-system';
      ctx.textAlign = 'left';
      ctx.fillText(block.title, block.x + 14, block.y + 26);
      
      ctx.font = '500 13px Inter, system-ui, -apple-system';
      ctx.fillStyle = 'rgba(255, 255, 255, 0.98)';
      const words = block.content.split(' ');
      let line = '';
      let y = block.y + 48;
      
      for (let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + ' ';
        const metrics = ctx.measureText(testLine);
        const testWidth = metrics.width;
        
        if (testWidth > block.width - 24 && n > 0) {
          ctx.fillText(line, block.x + 12, y);
          line = words[n] + ' ';
          y += 16;
        } else {
          line = testLine;
        }
        
        if (y > block.y + block.height - 12) break;
      }
      ctx.fillText(line, block.x + 12, y);
      
      // Reset text shadow
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;
      
      // Block type icon
      const iconX = block.x + block.width - 24;
      const iconY = block.y + 8;
      ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
      ctx.font = '18px system-ui';
      ctx.textAlign = 'center';
      
      let icon = '💡';
      switch (block.type) {
        case 'idea': icon = '💡'; break;
        case 'task': icon = '✅'; break;
        case 'file': icon = '📎'; break;
        case 'node': icon = '🔗'; break;
        case 'timeline': icon = '📅'; break;
        case 'comment': icon = '💬'; break;
        case 'email': icon = '📧'; break;
      }
      ctx.fillText(icon, iconX, iconY + 12);
      
      // For comment blocks, show channel indicator
      if (block.type === 'comment' && block.metadata?.channelId) {
        const channel = channels?.find(c => c.id === block.metadata?.channelId);
        if (channel) {
          ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
          ctx.beginPath();
          ctx.moveTo(block.x, block.y + block.height - 20);
          ctx.lineTo(block.x + block.width, block.y + block.height - 20);
          ctx.lineTo(block.x + block.width, block.y + block.height - borderRadius);
          ctx.quadraticCurveTo(block.x + block.width, block.y + block.height, block.x + block.width - borderRadius, block.y + block.height);
          ctx.lineTo(block.x + borderRadius, block.y + block.height);
          ctx.quadraticCurveTo(block.x, block.y + block.height, block.x, block.y + block.height - borderRadius);
          ctx.lineTo(block.x, block.y + block.height - 20);
          ctx.fill();
          
          ctx.fillStyle = 'white';
          ctx.font = '500 10px Inter, system-ui';
          ctx.textAlign = 'left';
          ctx.fillText(`📄 ${channel.name}`, block.x + 8, block.y + block.height - 8);
        }
      }

      // For email blocks, show email indicator
      if (block.type === 'email') {
        ctx.fillStyle = 'rgba(37, 99, 235, 0.8)';
        ctx.beginPath();
        ctx.moveTo(block.x, block.y + block.height - 20);
        ctx.lineTo(block.x + block.width, block.y + block.height - 20);
        ctx.lineTo(block.x + block.width, block.y + block.height - borderRadius);
        ctx.quadraticCurveTo(block.x + block.width, block.y + block.height, block.x + block.width - borderRadius, block.y + block.height);
        ctx.lineTo(block.x + borderRadius, block.y + block.height);
        ctx.quadraticCurveTo(block.x, block.y + block.height, block.x, block.y + block.height - borderRadius);
        ctx.lineTo(block.x, block.y + block.height - 20);
        ctx.fill();
        
        ctx.fillStyle = 'white';
        ctx.font = '500 10px Inter, system-ui';
        ctx.textAlign = 'left';
        const emailText = block.metadata?.toEmail ? `📧 ${block.metadata.toEmail}` : '📧 Email';
        ctx.fillText(emailText, block.x + 8, block.y + block.height - 8);
      }

      // Show scheduling indicator for all scheduled blocks
      if (block.scheduleDate || block.scheduleTime) {
        ctx.fillStyle = 'rgba(251, 146, 60, 0.95)';
        ctx.beginPath();
        ctx.moveTo(block.x + block.width - 60, block.y);
        ctx.lineTo(block.x + block.width - borderRadius, block.y);
        ctx.quadraticCurveTo(block.x + block.width, block.y, block.x + block.width, block.y + borderRadius);
        ctx.lineTo(block.x + block.width, block.y + 18);
        ctx.lineTo(block.x + block.width - 60, block.y + 18);
        ctx.closePath();
        ctx.fill();
        
        ctx.fillStyle = 'white';
        ctx.font = '500 9px Inter, system-ui';
        ctx.textAlign = 'center';
        
        let scheduleText = '⏰ Scheduled';
        if (block.scheduleDate && block.scheduleTime) {
          const date = new Date(block.scheduleDate + 'T' + block.scheduleTime);
          scheduleText = `⏰ ${date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} ${block.scheduleTime}`;
        } else if (block.scheduleDate) {
          const date = new Date(block.scheduleDate);
          scheduleText = `⏰ ${date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`;
        } else if (block.scheduleTime) {
          scheduleText = `⏰ ${block.scheduleTime}`;
        }
        
        ctx.fillText(scheduleText, block.x + block.width - 30, block.y + 12);
      }
    });

    ctx.restore();
  }, [selectedRoom, canvasState, isDarkMode]);

  // Handle canvas events
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!selectedRoom || !canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / canvasState.zoom - canvasState.offsetX;
    const y = (e.clientY - rect.top) / canvasState.zoom - canvasState.offsetY;
    
    // Check if clicking on a block
    const clickedBlock = selectedRoom.blocks.find(block => 
      x >= block.x && x <= block.x + block.width &&
      y >= block.y && y <= block.y + block.height
    );
    
    // Check if clicking on connection label
    const clickedConnection = selectedRoom.connections.find(conn => {
      const labelBounds = (conn as any).labelBounds;
      return labelBounds && 
        x >= labelBounds.x && x <= labelBounds.x + labelBounds.width &&
        y >= labelBounds.y && y <= labelBounds.y + labelBounds.height;
    });

    if (clickedConnection) {
      // Edit connection
      setSelectedConnection(clickedConnection);
      setShowConnectionEditor(true);
      return;
    }

    if (canvasState.mode === 'connect' && clickedBlock) {
      // Connection mode - start or complete connection
      if (connectionStart === null) {
        setConnectionStart(clickedBlock.id);
        setTempConnection({ x, y });
      } else if (connectionStart !== clickedBlock.id) {
        // Create connection between blocks
        const newConnection: BlockConnection = {
          id: `conn-${Date.now()}`,
          sourceId: connectionStart,
          targetId: clickedBlock.id,
          label: 'relates to',
          type: 'relates_to'
        };
        
        setSelectedRoom(prev => {
          if (!prev) return prev;
          return {
            ...prev,
            connections: [...prev.connections, newConnection]
          };
        });
        
        setConnectionStart(null);
        setTempConnection(null);
        
        // Open connection editor for new connection
        setSelectedConnection(newConnection);
        setShowConnectionEditor(true);
        
        toast({
          title: "Connection created",
          description: "Edit the connection label and type.",
        });
      }
    } else if (canvasState.mode === 'select') {
      // Select mode - normal selection and dragging
      if (clickedBlock) {
        setCanvasState(prev => ({
          ...prev,
          selectedBlocks: [clickedBlock.id],
          isDragging: true,
          dragStart: { x, y }
        }));
      } else {
        setCanvasState(prev => ({
          ...prev,
          selectedBlocks: [],
          isDragging: true,
          dragStart: { x, y }
        }));
      }
    }
    
    // Cancel connection if clicking empty space in connect mode
    if (!clickedBlock && canvasState.mode === 'connect') {
      setConnectionStart(null);
      setTempConnection(null);
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / canvasState.zoom - canvasState.offsetX;
    const y = (e.clientY - rect.top) / canvasState.zoom - canvasState.offsetY;
    
    // Update temporary connection in connect mode
    if (canvasState.mode === 'connect' && connectionStart) {
      setTempConnection({ x, y });
    }
    
    if (!canvasState.isDragging || !canvasState.dragStart) return;
    
    const deltaX = x - canvasState.dragStart.x;
    const deltaY = y - canvasState.dragStart.y;
    
    if (canvasState.selectedBlocks.length > 0 && canvasState.mode === 'select') {
      // Move selected blocks only in select mode
      setSelectedRoom(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          blocks: prev.blocks.map(block => {
            if (canvasState.selectedBlocks.includes(block.id) && !block.locked) {
              let newX = block.x + deltaX;
              let newY = block.y + deltaY;
              
              if (canvasState.snapToGrid) {
                newX = Math.round(newX / GRID_SIZE) * GRID_SIZE;
                newY = Math.round(newY / GRID_SIZE) * GRID_SIZE;
              }
              
              return { ...block, x: newX, y: newY };
            }
            return block;
          })
        };
      });
      
      setCanvasState(prev => ({
        ...prev,
        dragStart: { x, y }
      }));
    } else if (canvasState.selectedBlocks.length === 0 && canvasState.mode === 'select') {
      // Pan canvas
      setCanvasState(prev => ({
        ...prev,
        offsetX: prev.offsetX + deltaX,
        offsetY: prev.offsetY + deltaY,
        dragStart: { x, y }
      }));
    }
  };

  const handleCanvasMouseUp = () => {
    setCanvasState(prev => ({
      ...prev,
      isDragging: false,
      dragStart: null
    }));
  };

  // Canvas click handling based on mode
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!selectedRoom || !canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / canvasState.zoom - canvasState.offsetX;
    const y = (e.clientY - rect.top) / canvasState.zoom - canvasState.offsetY;
    
    // Check if clicking on existing block
    const clickedBlock = selectedRoom.blocks.find(block => 
      x >= block.x && x <= block.x + block.width &&
      y >= block.y && y <= block.y + block.height
    );
    
    if (canvasState.mode === 'draw') {
      // Draw mode - create new block at click position
      if (!clickedBlock) {
        createNewBlock(x, y);
      }
    } else if (clickedBlock) {
      // Edit existing block on any mode
      setSelectedBlock(clickedBlock);
      setShowBlockEditor(true);
    }
  };

  // Canvas double-click to edit blocks
  const handleCanvasDoubleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!selectedRoom || !canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / canvasState.zoom - canvasState.offsetX;
    const y = (e.clientY - rect.top) / canvasState.zoom - canvasState.offsetY;
    
    // Check if double-clicking on existing block
    const clickedBlock = selectedRoom.blocks.find(block => 
      x >= block.x && x <= block.x + block.width &&
      y >= block.y && y <= block.y + block.height
    );
    
    if (clickedBlock) {
      // Edit existing block
      setSelectedBlock(clickedBlock);
      setShowBlockEditor(true);
    } else if (canvasState.mode === 'select') {
      // Create new block on double-click in select mode
      createNewBlock(x, y);
    }
  };

  // Zoom controls
  const handleZoomIn = () => {
    setCanvasState(prev => ({ ...prev, zoom: Math.min(prev.zoom * 1.2, 3) }));
  };

  const handleZoomOut = () => {
    setCanvasState(prev => ({ ...prev, zoom: Math.max(prev.zoom / 1.2, 0.1) }));
  };

  const handleResetView = () => {
    setCanvasState(prev => ({ ...prev, zoom: 1, offsetX: 0, offsetY: 0 }));
  };

  // Canvas setup and drawing
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const resizeCanvas = () => {
      canvas.width = container.clientWidth;
      canvas.height = container.clientHeight;
      drawCanvas();
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    return () => window.removeEventListener('resize', resizeCanvas);
  }, [drawCanvas]);

  useEffect(() => {
    drawCanvas();
  }, [drawCanvas]);

  // Save room as node mutation
  const saveAsNodeMutation = useMutation({
    mutationFn: async (room: PlanningRoom) => {
      const nodeData = {
        title: room.name,
        content: generateRoomContent(room),
        nodeType: 'planning',
        tags: ['planning', room.template],
        properties: {
          roomId: room.id,
          template: room.template,
          blocksCount: room.blocks.length,
          connectionsCount: room.connections.length,
          planningData: {
            blocks: room.blocks,
            connections: room.connections
          }
        }
      };
      
      return await apiRequest('/api/nodes', {
        method: 'POST',
        body: JSON.stringify(nodeData)
      });
    },
    onSuccess: (newNode) => {
      queryClient.invalidateQueries({ queryKey: ['/api/nodes'] });
      toast({
        title: "Plan saved as node",
        description: `${selectedRoom?.name} has been saved to your graph and is ready to execute.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error saving plan",
        description: "Failed to save planning room as node. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Generate content from room data
  const generateRoomContent = (room: PlanningRoom) => {
    let content = `# ${room.name}\n\n`;
    content += `**Template:** ${room.template}\n`;
    content += `**Created:** ${room.createdAt.toLocaleDateString()}\n\n`;
    
    if (room.description) {
      content += `## Description\n${room.description}\n\n`;
    }
    
    content += `## Planning Overview\n`;
    content += `- **Total Blocks:** ${room.blocks.length}\n`;
    content += `- **Connections:** ${room.connections.length}\n\n`;
    
    // Group blocks by type
    const blocksByType = room.blocks.reduce((acc, block) => {
      if (!acc[block.type]) acc[block.type] = [];
      acc[block.type].push(block);
      return acc;
    }, {} as Record<string, PlanningBlock[]>);
    
    Object.entries(blocksByType).forEach(([type, blocks]) => {
      content += `### ${type.charAt(0).toUpperCase() + type.slice(1)} Blocks\n`;
      blocks.forEach(block => {
        content += `- **${block.title}:** ${block.content}\n`;
      });
      content += '\n';
    });
    
    if (room.connections.length > 0) {
      content += `## Connections\n`;
      room.connections.forEach(conn => {
        const sourceBlock = room.blocks.find(b => b.id === conn.sourceId);
        const targetBlock = room.blocks.find(b => b.id === conn.targetId);
        if (sourceBlock && targetBlock) {
          content += `- ${sourceBlock.title} **${conn.label}** ${targetBlock.title}\n`;
        }
      });
    }
    
    return content;
  };

  // Auto-save planning room state
  useEffect(() => {
    if (!selectedRoom) return;
    
    const saveTimer = setTimeout(() => {
      // Auto-save planning room state locally
      localStorage.setItem(`planning-room-${selectedRoom.id}`, JSON.stringify(selectedRoom));
    }, 2000);
    
    return () => clearTimeout(saveTimer);
  }, [selectedRoom]);

  // Save state for undo functionality
  const saveStateForUndo = () => {
    if (selectedRoom) {
      setUndoStack(prev => [...prev.slice(-9), selectedRoom]); // Keep last 10 states
    }
  };

  // Undo last action
  const undoLastAction = () => {
    if (undoStack.length > 0 && selectedRoom) {
      const lastState = undoStack[undoStack.length - 1];
      setSelectedRoom(lastState);
      setUndoStack(prev => prev.slice(0, -1));
      
      // Update localStorage
      setRooms(prev => {
        const updatedRooms = prev.map(room => 
          room.id === lastState.id ? lastState : room
        );
        localStorage.setItem('planning-rooms', JSON.stringify(updatedRooms));
        return updatedRooms;
      });
      
      toast({
        title: "Action undone",
        description: "Last change has been reverted.",
      });
    }
  };

  // Delete selected blocks
  const deleteSelectedBlocks = () => {
    if (canvasState.selectedBlocks.length > 0) {
      saveStateForUndo(); // Save state before deletion
      
      setSelectedRoom(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          blocks: prev.blocks.filter(block => !canvasState.selectedBlocks.includes(block.id)),
          connections: prev.connections.filter(conn => 
            !canvasState.selectedBlocks.includes(conn.sourceId) && 
            !canvasState.selectedBlocks.includes(conn.targetId)
          )
        };
      });
      setCanvasState(prev => ({ ...prev, selectedBlocks: [] }));
      toast({
        title: "Blocks deleted",
        description: `Deleted ${canvasState.selectedBlocks.length} block(s) and their connections.`,
      });
    }
  };

  // Delete planning room
  const deletePlanningRoom = (roomId: number) => {
    setRooms(prev => {
      const updatedRooms = prev.filter(room => room.id !== roomId);
      localStorage.setItem('planning-rooms', JSON.stringify(updatedRooms));
      return updatedRooms;
    });
    
    // Remove from localStorage
    localStorage.removeItem(`planning-room-${roomId}`);
    
    // If the deleted room was selected, clear selection
    if (selectedRoom?.id === roomId) {
      setSelectedRoom(null);
    }
    
    toast({
      title: "Room deleted",
      description: "Planning room has been permanently deleted.",
      variant: "destructive",
    });
  };

  // Rename planning room
  const renameRoom = (roomId: number, newName: string) => {
    if (!newName.trim()) return;
    
    setRooms(prev => {
      const updatedRooms = prev.map(room => 
        room.id === roomId 
          ? { ...room, name: newName.trim(), updatedAt: new Date() }
          : room
      );
      localStorage.setItem('planning-rooms', JSON.stringify(updatedRooms));
      return updatedRooms;
    });
    
    // Update selected room if it's the one being renamed
    if (selectedRoom?.id === roomId) {
      setSelectedRoom(prev => prev ? { ...prev, name: newName.trim() } : null);
    }
    
    setEditingRoomId(null);
    setEditingRoomName("");
    
    toast({
      title: "Room renamed",
      description: `Room renamed to "${newName.trim()}".`,
    });
  };

  // Start editing room name
  const startEditingRoom = (room: PlanningRoom) => {
    setEditingRoomId(room.id);
    setEditingRoomName(room.name);
  };

  // Take snapshot of the canvas
  const takeCanvasSnapshot = () => {
    if (!selectedRoom || !containerRef.current) return;
    
    // Create a temporary canvas for the snapshot
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set canvas size (adjust as needed)
    canvas.width = 1200;
    canvas.height = 800;
    
    // Fill with white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Draw blocks
    selectedRoom.blocks.forEach(block => {
      // Draw block background
      ctx.fillStyle = block.color;
      ctx.fillRect(block.x, block.y, block.width, block.height);
      
      // Draw block border
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 2;
      ctx.strokeRect(block.x, block.y, block.width, block.height);
      
      // Draw block title
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 14px Arial';
      ctx.fillText(block.title, block.x + 10, block.y + 25);
      
      // Draw block content (truncated)
      ctx.fillStyle = '#ffffff';
      ctx.font = '12px Arial';
      const contentLines = block.content.split('\n').slice(0, 3);
      contentLines.forEach((line, index) => {
        const truncated = line.length > 25 ? line.substring(0, 25) + '...' : line;
        ctx.fillText(truncated, block.x + 10, block.y + 45 + (index * 15));
      });
    });
    
    // Draw connections
    selectedRoom.connections.forEach(conn => {
      const sourceBlock = selectedRoom.blocks.find(b => b.id === conn.sourceId);
      const targetBlock = selectedRoom.blocks.find(b => b.id === conn.targetId);
      
      if (sourceBlock && targetBlock) {
        ctx.strokeStyle = '#666666';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        
        const startX = sourceBlock.x + sourceBlock.width / 2;
        const startY = sourceBlock.y + sourceBlock.height / 2;
        const endX = targetBlock.x + targetBlock.width / 2;
        const endY = targetBlock.y + targetBlock.height / 2;
        
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.lineTo(endX, endY);
        ctx.stroke();
        ctx.setLineDash([]);
      }
    });
    
    // Add title
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 24px Arial';
    ctx.fillText(selectedRoom.name, 20, 40);
    
    // Convert to blob and download
    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${selectedRoom.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_snapshot.png`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        toast({
          title: "Snapshot saved",
          description: `Canvas snapshot saved as ${a.download}`,
        });
      }
    }, 'image/png');
  };

  // Create new block
  const createNewBlock = (x: number = 400, y: number = 300) => {
    if (!selectedRoom) return;
    
    saveStateForUndo(); // Save state before creating new block
    
    const newBlock: PlanningBlock = {
      id: `block-${Date.now()}`,
      type: 'idea',
      x: canvasState.snapToGrid ? Math.round(x / GRID_SIZE) * GRID_SIZE : x,
      y: canvasState.snapToGrid ? Math.round(y / GRID_SIZE) * GRID_SIZE : y,
      width: 200,
      height: 120,
      title: 'New Block',
      content: 'Click to edit this block',
      color: BLOCK_COLORS[Math.floor(Math.random() * BLOCK_COLORS.length)],
      locked: false,
      graphProfiles: [1] // Default to "Everything" profile
    };
    
    setSelectedRoom(prev => {
      if (!prev) return prev;
      return { ...prev, blocks: [...prev.blocks, newBlock] };
    });
    
    // Immediately open editor for new block
    setSelectedBlock(newBlock);
    setShowBlockEditor(true);
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'n' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        createNewBlock();
      }
      
      if (e.key === 'z' && (e.ctrlKey || e.metaKey) && !e.shiftKey) {
        e.preventDefault();
        undoLastAction();
      }
      
      if (e.key === 'Delete' && canvasState.selectedBlocks.length > 0) {
        deleteSelectedBlocks();
      }
      
      if (e.key === 'Escape') {
        // Cancel connection mode
        if (canvasState.mode === 'connect') {
          setConnectionStart(null);
          setTempConnection(null);
        }
        // Clear selections
        setCanvasState(prev => ({ ...prev, selectedBlocks: [] }));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedRoom, canvasState.selectedBlocks, canvasState.mode, undoStack]);

  const templateMeta: Record<string, { emoji: string; accent: string }> = {
    project_kickoff:   { emoji: '🚀', accent: '#3B82F6' },
    sprint_planning:   { emoji: '⚡', accent: '#10B981' },
    product_launch:    { emoji: '🎯', accent: '#F59E0B' },
    client_onboarding: { emoji: '🤝', accent: '#8B5CF6' },
    resource_planning: { emoji: '📊', accent: '#06B6D4' },
    blank:             { emoji: '✨', accent: '#6366F1' },
  };

  const renderRoomsList = () => (
    <div className="w-60 border-r border-border/50 bg-background/95 flex flex-col min-h-0" style={{ height: 'calc(100vh - 60px)' }}>
      {/* Header */}
      <div className="px-3 pt-4 pb-3 border-b border-border/40">
        <div className="flex items-center justify-between mb-3">
          <span className="text-[13px] font-semibold text-foreground tracking-tight">Planning Rooms</span>
          <button
            onClick={() => setShowNewRoomDialog(true)}
            className="h-6 w-6 rounded-md flex items-center justify-center bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
            title="New room"
          >
            <Plus className="h-3.5 w-3.5" />
          </button>
        </div>
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            placeholder="Search rooms…"
            className="pl-8 h-7 text-xs rounded-lg"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          {filteredRooms.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <Layers className="h-8 w-8 mx-auto mb-2 opacity-20" />
              <p className="text-xs">No rooms yet</p>
              <button
                onClick={() => setShowNewRoomDialog(true)}
                className="mt-2 text-xs text-primary hover:underline"
              >
                Create one →
              </button>
            </div>
          )}
          {filteredRooms.map((room) => {
            const meta = templateMeta[room.template] || templateMeta.blank;
            const isActive = selectedRoom?.id === room.id;
            return (
              <div
                key={room.id}
                onClick={() => setSelectedRoom(room)}
                className={`group relative rounded-xl px-3 py-2.5 cursor-pointer transition-all ${
                  isActive
                    ? 'bg-accent shadow-sm'
                    : 'hover:bg-accent/50'
                }`}
              >
                {/* Active accent bar */}
                {isActive && (
                  <div className="absolute left-0 top-2 bottom-2 w-0.5 rounded-full" style={{ backgroundColor: meta.accent }} />
                )}
                <div className="flex items-start gap-2.5">
                  {/* Emoji icon */}
                  <div
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-sm flex-shrink-0 mt-0.5"
                    style={{ background: `${meta.accent}18` }}
                  >
                    {meta.emoji}
                  </div>
                  <div className="flex-1 min-w-0">
                    {/* Title row */}
                    <div className="flex items-center gap-1">
                      {editingRoomId === room.id ? (
                        <Input
                          value={editingRoomName}
                          onChange={(e) => setEditingRoomName(e.target.value)}
                          onBlur={() => renameRoom(room.id, editingRoomName)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') renameRoom(room.id, editingRoomName);
                            else if (e.key === 'Escape') { setEditingRoomId(null); setEditingRoomName(""); }
                          }}
                          className="h-5 text-xs font-medium px-1"
                          autoFocus
                          onClick={(e) => e.stopPropagation()}
                        />
                      ) : (
                        <p className="text-[12px] font-medium text-foreground truncate leading-snug">
                          {room.name}
                        </p>
                      )}
                      {room.starred && <Star className="h-2.5 w-2.5 fill-yellow-400 text-yellow-400 flex-shrink-0" />}
                    </div>
                    {/* Meta row */}
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="text-[10px] text-muted-foreground">{room.blocks.length} block{room.blocks.length !== 1 ? 's' : ''}</span>
                      {room.connections.length > 0 && (
                        <>
                          <span className="text-muted-foreground/40">·</span>
                          <span className="text-[10px] text-muted-foreground">{room.connections.length} link{room.connections.length !== 1 ? 's' : ''}</span>
                        </>
                      )}
                    </div>
                  </div>
                  {/* Actions (show on hover) */}
                  <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
                    <button
                      onClick={(e) => { e.stopPropagation(); startEditingRoom(room); }}
                      className="h-5 w-5 rounded flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                      title="Rename"
                    >
                      <Edit2 className="h-3 w-3" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (window.confirm(`Delete "${room.name}"? This cannot be undone.`)) deletePlanningRoom(room.id);
                      }}
                      className="h-5 w-5 rounded flex items-center justify-center text-muted-foreground hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );

  const renderCanvas = () => (
    <div className="flex-1 flex flex-col min-h-0" style={{ height: 'calc(100vh - 120px)' }}>
      {/* Modern Canvas Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 p-4 border-b border-border/40 bg-background/95 backdrop-blur-sm">
        <div className="flex items-center gap-3 min-w-0">
          {selectedRoom && (
            <>
              <h1 className="text-[20px] font-semibold text-foreground truncate tracking-tight">{selectedRoom.name}</h1>
              <Badge variant="outline" className="text-[11px] font-medium px-2 py-0.5 rounded-md border-border/60">{selectedRoom.template}</Badge>
            </>
          )}
        </div>
        
        <div className="flex items-center gap-2 flex-wrap">
          {/* Mode: Select / Connect */}
          <div className="flex items-center gap-0.5 bg-muted/60 rounded-lg p-0.5">
            <button
              onClick={() => setCanvasState(prev => ({ ...prev, mode: 'select' }))}
              title="Select & move blocks (V)"
              className={`flex items-center gap-1.5 h-7 px-2.5 rounded-md text-xs font-medium transition-all ${
                canvasState.mode === 'select'
                  ? 'bg-background text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <MousePointer className="h-3 w-3" />
              <span className="hidden sm:inline">Select</span>
            </button>
            <button
              onClick={() => setCanvasState(prev => ({ ...prev, mode: 'connect' }))}
              title="Draw connections between blocks (C)"
              className={`flex items-center gap-1.5 h-7 px-2.5 rounded-md text-xs font-medium transition-all ${
                canvasState.mode === 'connect'
                  ? 'bg-background text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Link className="h-3 w-3" />
              <span className="hidden sm:inline">Connect</span>
            </button>
          </div>

          <div className="w-px h-5 bg-border/60" />

          {/* Zoom controls */}
          <div className="flex items-center border border-border/50 rounded-lg overflow-hidden">
            <button onClick={handleZoomOut} title="Zoom out" className="h-7 w-7 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors">
              <ZoomOut className="h-3 w-3" />
            </button>
            <span className="text-[11px] text-muted-foreground px-2 min-w-[38px] text-center border-x border-border/50 select-none">
              {Math.round(canvasState.zoom * 100)}%
            </span>
            <button onClick={handleZoomIn} title="Zoom in" className="h-7 w-7 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors">
              <ZoomIn className="h-3 w-3" />
            </button>
          </div>
          <button onClick={handleResetView} title="Fit to view" className="h-7 w-7 border border-border/50 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors">
            <Target className="h-3 w-3" />
          </button>
          <button
            onClick={() => setCanvasState(prev => ({ ...prev, snapToGrid: !prev.snapToGrid }))}
            title={canvasState.snapToGrid ? 'Snap on' : 'Snap off'}
            className={`h-7 w-7 border rounded-lg flex items-center justify-center transition-colors ${
              canvasState.snapToGrid ? 'border-primary/50 bg-primary/10 text-primary' : 'border-border/50 text-muted-foreground hover:text-foreground hover:bg-muted/60'
            }`}
          >
            <Grid className="h-3 w-3" />
          </button>
          <button
            onClick={() => setShowMiniMap(!showMiniMap)}
            title="Toggle mini-map"
            className={`h-7 w-7 border rounded-lg flex items-center justify-center transition-colors ${
              showMiniMap ? 'border-primary/50 bg-primary/10 text-primary' : 'border-border/50 text-muted-foreground hover:text-foreground hover:bg-muted/60'
            }`}
          >
            <MapIcon className="h-3 w-3" />
          </button>

          <div className="w-px h-5 bg-border/60" />

          {/* Edit actions */}
          <button
            onClick={undoLastAction}
            disabled={undoStack.length === 0}
            title={`Undo (Ctrl+Z) — ${undoStack.length} step${undoStack.length !== 1 ? 's' : ''}`}
            className="h-7 w-7 border border-border/50 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/60 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
          >
            <Undo className="h-3 w-3" />
          </button>
          <button
            onClick={deleteSelectedBlocks}
            disabled={canvasState.selectedBlocks.length === 0}
            title={canvasState.selectedBlocks.length > 0 ? `Delete ${canvasState.selectedBlocks.length} block(s) (Del)` : 'Select blocks to delete'}
            className="h-7 border border-border/50 rounded-lg flex items-center gap-1 px-2 text-muted-foreground hover:text-red-600 hover:border-red-300/60 hover:bg-red-50 dark:hover:bg-red-950/30 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
          >
            <Trash2 className="h-3 w-3" />
            {canvasState.selectedBlocks.length > 0 && (
              <span className="text-[10px] font-semibold">{canvasState.selectedBlocks.length}</span>
            )}
          </button>

          <div className="w-px h-5 bg-border/60" />

          {/* Save / share */}
          <button
            onClick={saveRoom}
            disabled={!selectedRoom}
            title="Save draft"
            className="h-7 flex items-center gap-1.5 px-2.5 border border-border/50 rounded-lg text-[11px] font-medium text-muted-foreground hover:text-foreground hover:bg-muted/60 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
          >
            <Save className="h-3 w-3" />
            <span className="hidden md:inline">Save</span>
          </button>
          {selectedRoom && (
            <button
              onClick={() => { setSelectedCollaborators(selectedRoom.collaborators || []); setShowCollaboratorsDialog(true); }}
              title="Share with team"
              data-testid="button-manage-collaborators"
              className="h-7 flex items-center gap-1.5 px-2.5 border border-border/50 rounded-lg text-[11px] font-medium text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors"
            >
              <Users className="h-3 w-3" />
              <span className="hidden md:inline">Share</span>
              {selectedRoom.collaborators && selectedRoom.collaborators.length > 0 && (
                <span className="ml-0.5 text-[9px] font-bold bg-primary text-primary-foreground rounded-full w-3.5 h-3.5 flex items-center justify-center">
                  {selectedRoom.collaborators.length}
                </span>
              )}
            </button>
          )}
          <button
            onClick={takeCanvasSnapshot}
            disabled={!selectedRoom}
            title="Export as image"
            className="h-7 w-7 border border-border/50 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/60 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
          >
            <Camera className="h-3 w-3" />
          </button>

          <div className="w-px h-5 bg-border/60" />

          {/* Launch Plan — primary CTA */}
          {selectedRoom && (
            <button
              onClick={launchPlan}
              disabled={launchPlanMutation.isPending || selectedRoom.blocks.length === 0}
              className="h-7 flex items-center gap-1.5 px-3 rounded-lg text-[11px] font-semibold bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 text-white shadow-sm disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              title={selectedRoom.blocks.length === 0 ? 'Add blocks first' : 'Convert plan to real tasks & nodes'}
            >
              {launchPlanMutation.isPending ? (
                <div className="h-3 w-3 animate-spin rounded-full border-2 border-white border-t-transparent" />
              ) : (
                <Target className="h-3 w-3" />
              )}
              <span className="hidden sm:inline">Launch Plan</span>
            </button>
          )}
        </div>
      </div>
      
      {/* Canvas Area */}
      <div className="flex-1 relative overflow-hidden min-h-[400px]" ref={containerRef} style={{ minHeight: 'calc(100vh - 200px)' }}>
        {selectedRoom ? (
          <>
            <canvas
              ref={canvasRef}
              className="absolute inset-0 cursor-crosshair"
              onMouseDown={handleCanvasMouseDown}
              onMouseMove={handleCanvasMouseMove}
              onMouseUp={handleCanvasMouseUp}
              onDoubleClick={handleCanvasDoubleClick}
            />
            
            {/* Mini-map */}
            {showMiniMap && (
              <div className="absolute top-4 right-4 w-48 h-32 rounded-2xl overflow-hidden shadow-lg" style={{ background: "#111", border: "1px solid rgba(255,255,255,0.08)" }}>
                <div className="p-3">
                  <div className="text-[10px] font-semibold mb-2 text-white/40 tracking-wider uppercase">Mini Map</div>
                  <div className="w-full h-20 rounded-lg relative" style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)" }}>
                    {selectedRoom.blocks.map(block => (
                      <div
                        key={block.id}
                        className="absolute w-2 h-2 rounded-sm opacity-60"
                        style={{
                          backgroundColor: block.color,
                          left: `${(block.x / 1000) * 100}%`,
                          top: `${(block.y / 600) * 100}%`
                        }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}
            
            {/* Block Palette — left floating panel */}
            <div
              className="absolute left-3 top-3 rounded-2xl shadow-xl flex flex-col overflow-hidden"
              style={{ background: "rgba(15,15,20,0.92)", border: "1px solid rgba(255,255,255,0.09)", backdropFilter: "blur(12px)", width: 148 }}
            >
              {/* Header */}
              <div className="px-3 pt-3 pb-2 border-b border-white/[0.07]">
                <p className="text-[10px] font-semibold tracking-widest uppercase text-white/30">Add Block</p>
                <p className="text-[9px] text-white/20 mt-0.5">Click to place on canvas</p>
              </div>
              {/* Block types */}
              <div className="p-2 flex flex-col gap-1">
                {[
                  { type: 'idea',     icon: <Lightbulb className="h-3.5 w-3.5" />,     label: 'Idea',      desc: 'Capture thoughts',   accent: '#3B82F6', bg: 'rgba(59,130,246,0.15)'  },
                  { type: 'task',     icon: <CheckSquare className="h-3.5 w-3.5" />,   label: 'Task',      desc: 'Assign & track',     accent: '#10B981', bg: 'rgba(16,185,129,0.15)'  },
                  { type: 'timeline', icon: <Calendar className="h-3.5 w-3.5" />,      label: 'Timeline',  desc: 'Set milestones',     accent: '#6366F1', bg: 'rgba(99,102,241,0.15)'  },
                  { type: 'comment',  icon: <MessageCircle className="h-3.5 w-3.5" />, label: 'Discussion',desc: 'Post to chat',        accent: '#F97316', bg: 'rgba(249,115,22,0.15)'  },
                  { type: 'node',     icon: <Link className="h-3.5 w-3.5" />,          label: 'Node Link', desc: 'Link existing node',  accent: '#8B5CF6', bg: 'rgba(139,92,246,0.15)'  },
                  { type: 'file',     icon: <Paperclip className="h-3.5 w-3.5" />,     label: 'File',      desc: 'Attach a document',  accent: '#64748B', bg: 'rgba(100,116,139,0.15)' },
                ].map(({ type, icon, label, desc, accent, bg }) => (
                  <button
                    key={type}
                    onClick={() => {
                      setSelectedRoom(prev => {
                        if (!prev) return prev;
                        const count = prev.blocks.length;
                        const col = count % 3;
                        const row = Math.floor(count / 3);
                        const containerW = containerRef.current?.clientWidth ?? 800;
                        const containerH = containerRef.current?.clientHeight ?? 600;
                        const cx = (containerW / 2 - canvasState.offsetX) / canvasState.zoom + col * 320 - 320;
                        const cy = (containerH / 2 - canvasState.offsetY) / canvasState.zoom + row * 160 - 80;
                        const newBlock: PlanningBlock = {
                          id: `block-${Date.now()}`,
                          type: type as PlanningBlock['type'],
                          x: Math.max(20, cx),
                          y: Math.max(20, cy),
                          width: 260,
                          height: 130,
                          title: label,
                          content: '',
                          color: accent,
                          locked: false,
                          graphProfiles: [1],
                        };
                        return { ...prev, blocks: [...prev.blocks, newBlock] };
                      });
                    }}
                    className="group flex items-center gap-2.5 px-2.5 py-2 rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98] text-left w-full"
                    style={{ background: 'transparent' }}
                    onMouseEnter={e => (e.currentTarget.style.background = bg)}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                  >
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ background: bg, color: accent }}
                    >
                      {icon}
                    </div>
                    <div className="min-w-0">
                      <p className="text-[11px] font-semibold text-white/80 leading-tight">{label}</p>
                      <p className="text-[9px] text-white/30 leading-tight truncate">{desc}</p>
                    </div>
                  </button>
                ))}
              </div>
              {/* Hint */}
              <div className="px-3 py-2 border-t border-white/[0.06]">
                <p className="text-[9px] text-white/20 leading-relaxed">
                  <span className="text-white/35 font-semibold">C</span> = connect mode<br />
                  <span className="text-white/35 font-semibold">Del</span> = remove block
                </p>
              </div>
            </div>

            {/* Empty canvas hint */}
            {selectedRoom.blocks.length === 0 && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
                <div className="text-center space-y-2 opacity-40">
                  <div className="w-14 h-14 rounded-2xl border-2 border-dashed border-current mx-auto flex items-center justify-center text-muted-foreground">
                    <Plus className="h-6 w-6" />
                  </div>
                  <p className="text-sm font-medium text-muted-foreground">Click a block on the left to start</p>
                  <p className="text-xs text-muted-foreground">Or double-click anywhere on the canvas</p>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center space-y-3 max-w-xs">
              <div className="w-16 h-16 rounded-2xl bg-muted/40 border border-border/50 mx-auto flex items-center justify-center">
                <Layers className="h-7 w-7 text-muted-foreground" />
              </div>
              <div>
                <h3 className="text-base font-semibold text-foreground mb-1">No room selected</h3>
                <p className="text-sm text-muted-foreground">Pick a room from the sidebar, or create a new one to begin planning.</p>
              </div>
              <button
                onClick={() => setShowNewRoomDialog(true)}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors shadow-sm"
              >
                <Plus className="h-4 w-4" />
                New Planning Room
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  // Save current room
  const saveRoom = () => {
    if (!selectedRoom) return;
    
    // Update the room in the rooms array and persist
    const updatedRooms = rooms.map(room => 
      room.id === selectedRoom.id ? selectedRoom : room
    );
    setRooms(updatedRooms);
    localStorage.setItem('planning-rooms', JSON.stringify(updatedRooms));
    
    toast({
      title: "Room saved",
      description: `${selectedRoom.name} has been saved successfully.`,
    });
  };

  // Launch plan as node in Graph
  const launchPlanMutation = useMutation({
    mutationFn: async (room: PlanningRoom) => {
      const results = {
        tasks: 0,
        ideas: 0,
        notes: 0,
        files: 0,
        meetings: 0,
        comments: 0,
        emails: 0,
        scheduled: 0,
        plan: 1
      };

      // Separate blocks into immediate and scheduled
      const immediateBlocks = room.blocks.filter(block => !block.scheduleDate && !block.scheduleTime);
      const scheduledBlocks = room.blocks.filter(block => block.scheduleDate || block.scheduleTime);
      
      // Create individual nodes for immediate blocks
      const createdNodes = [];
      for (const block of immediateBlocks) {
        let nodeType: string;
        let priority = undefined;
        let status = undefined;
        
        // Handle email blocks by sending emails
        if (block.type === 'email') {
          try {
            // For demo purposes, we'll just create a log entry
            // In production, this would integrate with SendGrid or similar service
            console.log('Email would be sent:', {
              from: block.metadata?.fromEmail || 'noreply@company.com',
              to: block.metadata?.toEmail,
              subject: block.metadata?.subject || block.title,
              content: block.content,
              type: block.metadata?.emailType || 'notification'
            });
            
            results.emails++;
            continue; // Skip creating a node for emails
          } catch (error) {
            console.error(`Failed to send email ${block.title}:`, error);
          }
        }

        // Handle comment blocks differently - post to chat channels
        if (block.type === 'comment') {
          try {
            // Post comment to chat channel
            const channelId = block.metadata?.channelId || 1;
            const commentType = block.metadata?.commentType || 'discussion';
            const commentIcons = {
              discussion: '💬',
              question: '❓',
              announcement: '📢', 
              reminder: '⏰',
              feedback: '💭'
            } as const;
            const commentIcon = commentIcons[commentType as keyof typeof commentIcons] || '💬';
            
            await apiRequest('/api/messages', {
              method: 'POST',
              body: JSON.stringify({
                channelId: channelId,
                userId: 1, // Current user
                content: `${commentIcon} **${block.title}**\n\n${block.content}\n\n_Posted from planning room: ${room.name}_`
              })
            });
            
            results.comments++;
            continue; // Skip creating a node for comments
          } catch (error) {
            console.error(`Failed to post comment ${block.title} to chat:`, error);
          }
        }

        // Map other block types to node types and set appropriate properties
        switch (block.type) {
          case 'task':
            nodeType = 'task';
            priority = block.metadata?.priority || 'medium';
            status = block.metadata?.status || 'todo';
            results.tasks++;
            break;
          case 'idea':
            nodeType = 'idea';
            results.ideas++;
            break;
          case 'file':
            nodeType = 'file';
            results.files++;
            break;
          case 'timeline':
            nodeType = 'note';
            results.notes++;
            break;
          case 'email':
            // Emails should have been handled above, but just in case
            nodeType = 'note';
            results.notes++;
            break;
          default:
            nodeType = 'note';
            results.notes++;
        }

        const nodeData: any = {
          title: block.title,
          content: block.content || '',
          nodeType: nodeType,
          tags: ['planning', room.template, `from-${room.name.toLowerCase().replace(/\s+/g, '-')}`],
          properties: {
            source: 'planning-room',
            roomId: room.id,
            roomName: room.name,
            blockId: block.id,
            originalType: block.type,
            position: { x: block.x, y: block.y },
            color: block.color
          },
          graphProfiles: block.graphProfiles || [1] // Use block's graph profiles or default to "Everything"
        };

        // Add task-specific fields
        if (nodeType === 'task') {
          nodeData.properties = {
            ...nodeData.properties,
            priority,
            status,
            assignee: block.metadata?.assignee,
            assigneeName: block.metadata?.assigneeName
          };
          if (block.metadata?.dueDate) {
            nodeData.scheduledFor = new Date(block.metadata.dueDate).toISOString();
          }
        }

        try {
          const createdNode: any = await apiRequest('/api/nodes', {
            method: 'POST',
            body: JSON.stringify(nodeData)
          });
          createdNodes.push({ ...createdNode, blockId: block.id });
        } catch (error) {
          console.error(`Failed to create node for block ${block.title}:`, error);
        }
      }

      // Create node links based on planning room connections
      const blockToNodeMap = new Map();
      createdNodes.forEach((node: any) => {
        blockToNodeMap.set(node.blockId, node.id);
      });

      for (const connection of room.connections) {
        const sourceNodeId = blockToNodeMap.get(connection.sourceId);
        const targetNodeId = blockToNodeMap.get(connection.targetId);
        
        if (sourceNodeId && targetNodeId) {
          try {
            await apiRequest('/api/node-links', {
              method: 'POST',
              body: JSON.stringify({
                sourceId: sourceNodeId,
                targetId: targetNodeId,
                label: connection.label || '',
                type: connection.type || 'related'
              })
            });
          } catch (error) {
            console.error(`Failed to create link between nodes:`, error);
          }
        }
      }

      // Create links to existing nodes for blocks that have linkedNodeIds
      for (const node of createdNodes) {
        const block = immediateBlocks.find(b => b.id === node.blockId);
        if (block?.metadata?.linkedNodeIds && Array.isArray(block.metadata.linkedNodeIds)) {
          for (const linkedNodeId of block.metadata.linkedNodeIds) {
            try {
              await apiRequest('/api/node-links', {
                method: 'POST',
                body: JSON.stringify({
                  sourceId: node.id,
                  targetId: linkedNodeId,
                  label: 'linked from planning',
                  type: 'related'
                })
              });
            } catch (error) {
              console.error(`Failed to create link to existing node:`, error);
            }
          }
        }
      }

      // Handle scheduled blocks - store them for future execution
      if (scheduledBlocks.length > 0) {
        try {
          // In a real implementation, this would save to a scheduled tasks table
          // For now, we'll create a note about the scheduled tasks
          const scheduledInfo = scheduledBlocks.map(block => {
            const scheduledTime = block.scheduleDate && block.scheduleTime 
              ? `${block.scheduleDate}T${block.scheduleTime}:00.000Z`
              : block.scheduleDate 
                ? `${block.scheduleDate}T00:00:00.000Z`
                : `${new Date().toISOString().split('T')[0]}T${block.scheduleTime}:00.000Z`;
            
            return {
              blockId: block.id,
              title: block.title,
              content: block.content,
              type: block.type,
              scheduledFor: scheduledTime,
              metadata: block.metadata,
              graphProfiles: block.graphProfiles
            };
          });

          console.log('Scheduled blocks for future execution:', scheduledInfo);
          results.scheduled = scheduledBlocks.length;
        } catch (error) {
          console.error('Failed to schedule blocks:', error);
        }
      }

      // Create a master plan node that links to all created nodes
      const planContent = `# ${room.name}

**Template:** ${room.template}
**Description:** ${room.description || 'No description'}
**Launched:** ${new Date().toLocaleString()}

## Summary
- **Tasks Created:** ${results.tasks}
- **Ideas Created:** ${results.ideas}  
- **Notes Created:** ${results.notes}
- **Files Created:** ${results.files}
- **Comments Posted:** ${results.comments}
- **Emails Sent:** ${results.emails}
- **Items Scheduled:** ${results.scheduled}

## Original Planning Structure

${room.blocks.map(block => `
### ${block.title}
**Type:** ${block.type}
**Content:** ${block.content}
**Location:** ${block.x}, ${block.y}
${block.scheduleDate || block.scheduleTime ? `**Scheduled:** ${block.scheduleDate || 'Today'} ${block.scheduleTime || 'No specific time'}` : '**Executed:** Immediately'}
`).join('\n')}

## Block Connections

${room.connections.map(conn => {
  const source = room.blocks.find(b => b.id === conn.sourceId);
  const target = room.blocks.find(b => b.id === conn.targetId);
  return `- **${source?.title || conn.sourceId}** ${conn.label} **${target?.title || conn.targetId}**`;
}).join('\n')}

---
*This plan has been launched and all blocks have been converted to individual nodes in their respective sections.*
`;

      const masterPlan = await apiRequest('/api/nodes', {
        method: 'POST',
        body: JSON.stringify({
          title: `${room.name} - Master Plan`,
          content: planContent,
          nodeType: 'plan',
          tags: ['planning', 'master-plan', room.template],
          properties: {
            roomId: room.id,
            template: room.template,
            blocksCount: room.blocks.length,
            connectionsCount: room.connections.length,
            createdNodesIds: createdNodes.map((n: any) => n.id)
          },
          graphProfiles: [1] // Master plan always goes to "Everything" profile
        })
      });

      return { masterPlan, createdNodes, results };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/nodes'] });
      queryClient.invalidateQueries({ queryKey: ['/api/node-links'] });
      
      const { results } = data;
      const summary = [];
      if (results.tasks > 0) summary.push(`${results.tasks} task${results.tasks > 1 ? 's' : ''}`);
      if (results.ideas > 0) summary.push(`${results.ideas} idea${results.ideas > 1 ? 's' : ''}`);
      if (results.notes > 0) summary.push(`${results.notes} note${results.notes > 1 ? 's' : ''}`);
      if (results.files > 0) summary.push(`${results.files} file${results.files > 1 ? 's' : ''}`);
      if (results.comments > 0) summary.push(`${results.comments} comment${results.comments > 1 ? 's' : ''} posted to chat`);
      if (results.emails > 0) summary.push(`${results.emails} email${results.emails > 1 ? 's' : ''} sent`);
      if (results.scheduled > 0) summary.push(`${results.scheduled} item${results.scheduled > 1 ? 's' : ''} scheduled for later`);
      
      toast({
        title: "Plan launched successfully! 🚀",
        description: `Created ${summary.join(', ')} and a master plan. ${results.comments > 0 ? 'Comments posted to chat channels. ' : ''}${results.emails > 0 ? 'Emails sent. ' : ''}${results.scheduled > 0 ? 'Scheduled items will execute at their designated times.' : ''}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Launch failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const launchPlan = () => {
    if (!selectedRoom) return;
    launchPlanMutation.mutate(selectedRoom);
  };

  // Create new room
  const createRoom = () => {
    if (!newRoomName.trim()) {
      toast({
        title: "Room name required",
        description: "Please enter a name for the new room.",
        variant: "destructive",
      });
      return;
    }

    const newRoom: PlanningRoom = {
      id: Date.now(),
      name: newRoomName,
      description: newRoomDescription,
      template: newRoomTemplate,
      starred: false,
      createdAt: new Date(),
      updatedAt: new Date(),
      blocks: [],
      connections: []
    };

    // Add template blocks based on selected template
    if (newRoomTemplate !== 'blank') {
      const templateBlocks = getTemplateBlocks(newRoomTemplate);
      newRoom.blocks = templateBlocks;
    }

    // Update rooms list and persist
    const updatedRooms = [...rooms, newRoom];
    setRooms(updatedRooms);
    localStorage.setItem('planning-rooms', JSON.stringify(updatedRooms));
    
    setSelectedRoom(newRoom);
    setShowNewRoomDialog(false);
    setNewRoomName("");
    setNewRoomDescription("");
    setNewRoomTemplate("blank");

    toast({
      title: "Room created",
      description: `${newRoomName} planning room has been created.`,
    });
  };

  // Get template starter blocks
  const getTemplateBlocks = (template: string): PlanningBlock[] => {
    const baseBlocks = [];
    
    switch (template) {
      case 'project_kickoff':
        baseBlocks.push(
          {
            id: 'kickoff-1',
            type: 'idea' as const,
            x: 200,
            y: 150,
            width: 200,
            height: 120,
            title: 'Project Goals',
            content: 'Define objectives, success criteria, and key deliverables',
            color: '#3B82F6',
            locked: false,
            graphProfiles: [1]
          },
          {
            id: 'kickoff-2',
            type: 'task' as const,
            x: 500,
            y: 150,
            width: 200,
            height: 120,
            title: 'Stakeholder Meeting',
            content: 'Schedule and conduct initial alignment meeting',
            color: '#10B981',
            locked: false,
            graphProfiles: [1]
          },
          {
            id: 'kickoff-3',
            type: 'timeline' as const,
            x: 200,
            y: 320,
            width: 200,
            height: 120,
            title: 'Project Timeline',
            content: 'Establish key milestones and delivery dates',
            color: '#F59E0B',
            locked: false,
            graphProfiles: [1]
          }
        );
        break;
      case 'sprint_planning':
        baseBlocks.push(
          {
            id: 'sprint-1',
            type: 'task' as const,
            x: 200,
            y: 150,
            width: 200,
            height: 120,
            title: 'Sprint Goal',
            content: 'Define sprint objective and expected outcomes',
            color: '#8B5CF6',
            locked: false,
            graphProfiles: [1]
          },
          {
            id: 'sprint-2',
            type: 'task' as const,
            x: 500,
            y: 150,
            width: 200,
            height: 120,
            title: 'Story Breakdown',
            content: 'Break down user stories into actionable tasks',
            color: '#06B6D4',
            locked: false,
            graphProfiles: [1]
          },
          {
            id: 'sprint-3',
            type: 'task' as const,
            x: 800,
            y: 150,
            width: 200,
            height: 120,
            title: 'Capacity Planning',
            content: 'Allocate team resources and estimate velocity',
            color: '#84CC16',
            locked: false,
            graphProfiles: [1]
          }
        );
        break;
      case 'product_launch':
        baseBlocks.push(
          {
            id: 'launch-1',
            type: 'idea' as const,
            x: 200,
            y: 150,
            width: 200,
            height: 120,
            title: 'Launch Strategy',
            content: 'Define go-to-market approach and target channels',
            color: '#F97316',
            locked: false,
            graphProfiles: [1]
          },
          {
            id: 'launch-2',
            type: 'task' as const,
            x: 500,
            y: 150,
            width: 200,
            height: 120,
            title: 'Marketing Assets',
            content: 'Prepare promotional materials and landing page',
            color: '#EC4899',
            locked: false,
            graphProfiles: [1]
          },
          {
            id: 'launch-3',
            type: 'timeline' as const,
            x: 200,
            y: 320,
            width: 200,
            height: 120,
            title: 'Launch Timeline',
            content: 'Coordinate pre-launch, launch day, and follow-up',
            color: '#6366F1',
            locked: false,
            graphProfiles: [1]
          }
        );
        break;
      case 'client_onboarding':
        baseBlocks.push(
          {
            id: 'onboard-1',
            type: 'task' as const,
            x: 200,
            y: 150,
            width: 200,
            height: 120,
            title: 'Discovery Call',
            content: 'Understand client needs, goals, and constraints',
            color: '#3B82F6',
            locked: false,
            graphProfiles: [1]
          },
          {
            id: 'onboard-2',
            type: 'task' as const,
            x: 500,
            y: 150,
            width: 200,
            height: 120,
            title: 'Requirements Doc',
            content: 'Document scope, deliverables, and acceptance criteria',
            color: '#10B981',
            locked: false,
            graphProfiles: [1]
          },
          {
            id: 'onboard-3',
            type: 'task' as const,
            x: 800,
            y: 150,
            width: 200,
            height: 120,
            title: 'Project Setup',
            content: 'Configure tools, access, and communication channels',
            color: '#F59E0B',
            locked: false,
            graphProfiles: [1]
          }
        );
        break;
      case 'resource_planning':
        baseBlocks.push(
          {
            id: 'resource-1',
            type: 'task' as const,
            x: 200,
            y: 150,
            width: 200,
            height: 120,
            title: 'Team Assessment',
            content: 'Review current team capacity and skills',
            color: '#8B5CF6',
            locked: false,
            graphProfiles: [1]
          },
          {
            id: 'resource-2',
            type: 'task' as const,
            x: 500,
            y: 150,
            width: 200,
            height: 120,
            title: 'Task Allocation',
            content: 'Assign responsibilities based on availability',
            color: '#06B6D4',
            locked: false,
            graphProfiles: [1]
          },
          {
            id: 'resource-3',
            type: 'timeline' as const,
            x: 200,
            y: 320,
            width: 200,
            height: 120,
            title: 'Workload Timeline',
            content: 'Map out team commitments and deadlines',
            color: '#84CC16',
            locked: false,
            graphProfiles: [1]
          }
        );
        break;
    }
    
    return baseBlocks;
  };

  const renderConnectionEditor = () => {
    if (!selectedConnection) return null;

    const updateConnection = (updates: Partial<BlockConnection>) => {
      setSelectedRoom(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          connections: prev.connections.map(conn => 
            conn.id === selectedConnection.id ? { ...conn, ...updates } : conn
          )
        };
      });
      setSelectedConnection(prev => prev ? { ...prev, ...updates } : null);
    };

    const deleteConnection = () => {
      setSelectedRoom(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          connections: prev.connections.filter(conn => conn.id !== selectedConnection.id)
        };
      });
      setShowConnectionEditor(false);
      setSelectedConnection(null);
      toast({
        title: "Connection deleted",
        description: "The connection has been removed.",
      });
    };

    return (
      <Dialog open={showConnectionEditor} onOpenChange={setShowConnectionEditor}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Connection</DialogTitle>
            <DialogDescription>
              Customize the relationship between your blocks.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Relationship Label</label>
              <Input
                value={selectedConnection.label}
                onChange={(e) => updateConnection({ label: e.target.value })}
                placeholder="e.g., depends on, leads to, enables..."
                className="mt-1"
              />
            </div>
            
            <div>
              <label className="text-sm font-medium">Connection Type</label>
              <Select 
                value={selectedConnection.type}
                onValueChange={(value) => updateConnection({ type: value as BlockConnection['type'] })}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="depends_on">Depends On</SelectItem>
                  <SelectItem value="relates_to">Relates To</SelectItem>
                  <SelectItem value="blocks">Blocks</SelectItem>
                  <SelectItem value="enables">Enables</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex justify-between pt-4">
            <Button 
              variant="destructive" 
              onClick={deleteConnection}
            >
              Delete Connection
            </Button>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowConnectionEditor(false);
                  setSelectedConnection(null);
                }}
              >
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  setShowConnectionEditor(false);
                  setSelectedConnection(null);
                  toast({
                    title: "Connection updated",
                    description: "The relationship has been updated.",
                  });
                }}
              >
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  const renderBlockEditor = () => {
    if (!selectedBlock) return null;

    const updateBlock = (updates: Partial<PlanningBlock>) => {
      setSelectedRoom(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          blocks: prev.blocks.map(block => 
            block.id === selectedBlock.id ? { ...block, ...updates } : block
          )
        };
      });
      setSelectedBlock(prev => prev ? { ...prev, ...updates } : null);
    };

    return (
      <Dialog open={showBlockEditor} onOpenChange={setShowBlockEditor}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Planning Block</DialogTitle>
            <DialogDescription>
              Design and refine your planning block content before launching your plan.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Block Type</label>
                <Select 
                  value={selectedBlock.type} 
                  onValueChange={(value) => updateBlock({ type: value as PlanningBlock['type'] })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="idea">💡 Idea</SelectItem>
                    <SelectItem value="task">✅ Task</SelectItem>
                    <SelectItem value="file">📎 File</SelectItem>
                    <SelectItem value="node">🔗 Node</SelectItem>
                    <SelectItem value="timeline">📅 Timeline</SelectItem>
                    <SelectItem value="comment">💬 Comment</SelectItem>
                    <SelectItem value="email">📧 Email</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium">Color</label>
                <div className="mt-1 flex gap-2">
                  {BLOCK_COLORS.map(color => (
                    <button
                      key={color}
                      className={`w-6 h-6 rounded border-2 ${
                        selectedBlock.color === color ? 'border-gray-800' : 'border-gray-300'
                      }`}
                      style={{ backgroundColor: color }}
                      onClick={() => updateBlock({ color })}
                    />
                  ))}
                </div>
              </div>
            </div>
            
            <div>
              <label className="text-sm font-medium">Title</label>
              <Input
                value={selectedBlock.title}
                onChange={(e) => updateBlock({ title: e.target.value })}
                placeholder="Enter block title..."
                className="mt-1"
              />
            </div>
            
            <div>
              <label className="text-sm font-medium">Content</label>
              <Textarea
                value={selectedBlock.content}
                onChange={(e) => updateBlock({ content: e.target.value })}
                placeholder="Describe your planning block content in detail..."
                className="mt-1 resize-none"
                rows={6}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Width</label>
                <Input
                  type="number"
                  value={selectedBlock.width}
                  onChange={(e) => updateBlock({ width: parseInt(e.target.value) || 200 })}
                  min="100"
                  max="500"
                  className="mt-1"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium">Height</label>
                <Input
                  type="number"
                  value={selectedBlock.height}
                  onChange={(e) => updateBlock({ height: parseInt(e.target.value) || 120 })}
                  min="80"
                  max="400"
                  className="mt-1"
                />
              </div>
            </div>
            
            {/* Graph Profile Assignment */}
            <div>
              <label className="text-sm font-medium">Graph Profiles</label>
              <div className="mt-1 space-y-2">
                <p className="text-xs text-muted-foreground">
                  Select which graph profiles this block should appear in
                </p>
                
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {graphProfiles?.map((profile) => (
                    <div key={profile.id} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`profile-${profile.id}`}
                        checked={selectedBlock.graphProfiles?.includes(profile.id) || false}
                        onChange={(e) => {
                          const currentProfiles = selectedBlock.graphProfiles || [1]; // Default to "Everything"
                          if (e.target.checked) {
                            updateBlock({ 
                              graphProfiles: [...currentProfiles, profile.id]
                            });
                          } else {
                            // Don't allow unchecking "Everything" profile
                            if (profile.id === 1) return;
                            updateBlock({ 
                              graphProfiles: currentProfiles.filter(id => id !== profile.id)
                            });
                          }
                        }}
                        className="rounded"
                      />
                      <label 
                        htmlFor={`profile-${profile.id}`} 
                        className="text-sm flex items-center gap-2"
                      >
                        <div 
                          className="w-3 h-3 rounded" 
                          style={{ backgroundColor: profile.color }}
                        />
                        {profile.name}
                        {profile.isDefault && (
                          <Badge variant="secondary" className="text-xs">Default</Badge>
                        )}
                      </label>
                    </div>
                  ))}
                </div>
                
                {(!selectedBlock.graphProfiles || selectedBlock.graphProfiles.length === 0) && (
                  <p className="text-xs text-orange-600">
                    ⚠️ This block will only appear in the "Everything" profile
                  </p>
                )}
              </div>
            </div>
            
            {selectedBlock.type === 'task' && (
              <div className="space-y-3 p-3 bg-blue-50 dark:bg-blue-950 rounded-lg border">
                <h4 className="font-medium text-sm">Task Details</h4>
                
                <div>
                  <label className="text-xs font-medium">Assigned To</label>
                  <Select 
                    value={selectedBlock.metadata?.assignee?.toString() || ''}
                    onValueChange={(value) => {
                      const userId = parseInt(value);
                      const user = users?.find(u => u.id === userId);
                      updateBlock({ 
                        metadata: { 
                          ...selectedBlock.metadata, 
                          assignee: userId,
                          assigneeName: user?.username || 'Unassigned'
                        }
                      });
                    }}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select assignee..." />
                    </SelectTrigger>
                    <SelectContent>
                      {users?.map((user) => (
                        <SelectItem key={user.id} value={user.id.toString()}>
                          👤 {user.username}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-medium">Priority</label>
                    <Select 
                      value={selectedBlock.metadata?.priority || 'medium'}
                      onValueChange={(value) => updateBlock({ 
                        metadata: { ...selectedBlock.metadata, priority: value }
                      })}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">🟢 Low</SelectItem>
                        <SelectItem value="medium">🟡 Medium</SelectItem>
                        <SelectItem value="high">🟠 High</SelectItem>
                        <SelectItem value="critical">🔴 Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="text-xs font-medium">Status</label>
                    <Select 
                      value={selectedBlock.metadata?.status || 'todo'}
                      onValueChange={(value) => updateBlock({ 
                        metadata: { ...selectedBlock.metadata, status: value }
                      })}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todo">📋 To Do</SelectItem>
                        <SelectItem value="in-progress">⚡ In Progress</SelectItem>
                        <SelectItem value="done">✅ Done</SelectItem>
                        <SelectItem value="blocked">🚫 Blocked</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div>
                  <label className="text-xs font-medium">Due Date</label>
                  <Input
                    type="date"
                    value={selectedBlock.metadata?.dueDate || ''}
                    onChange={(e) => updateBlock({ 
                      metadata: { ...selectedBlock.metadata, dueDate: e.target.value }
                    })}
                    className="mt-1"
                  />
                </div>
              </div>
            )}
            
            {selectedBlock.type === 'timeline' && (
              <div>
                <label className="text-sm font-medium">Target Date</label>
                <Input
                  type="date"
                  value={selectedBlock.metadata?.dueDate || ''}
                  onChange={(e) => updateBlock({ 
                    metadata: { ...selectedBlock.metadata, dueDate: e.target.value }
                  })}
                  className="mt-1"
                />
              </div>
            )}
            
            {selectedBlock.type === 'comment' && (
              <div className="space-y-4 p-4 bg-green-50 rounded-lg border">
                <h4 className="font-medium text-green-900">Comment Details</h4>
                
                <div>
                  <label className="text-sm font-medium">Target Channel</label>
                  <Select 
                    value={selectedBlock.metadata?.channelId?.toString() || ''}
                    onValueChange={(value) => {
                      const channelId = parseInt(value);
                      const selectedChannel = channels?.find(c => c.id === channelId);
                      updateBlock({ 
                        metadata: { 
                          ...selectedBlock.metadata, 
                          channelId: channelId,
                          channelName: selectedChannel?.name || 'Unknown',
                          spaceId: selectedChannel?.spaceId || 1,
                          spaceName: selectedChannel?.spaceName || 'Default Space'
                        }
                      });
                    }}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select chat channel..." />
                    </SelectTrigger>
                    <SelectContent>
                      {channels?.map((channel) => (
                        <SelectItem key={channel.id} value={channel.id.toString()}>
                          📄 {channel.name}
                        </SelectItem>
                      ))}
                      {(!channels || channels.length === 0) && (
                        <SelectItem value="1">📄 general (default)</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">
                    This comment will be posted to the selected chat channel when the plan is launched
                  </p>
                </div>
                
                <div>
                  <label className="text-sm font-medium">Comment Type</label>
                  <Select 
                    value={selectedBlock.metadata?.commentType || 'discussion'}
                    onValueChange={(value) => updateBlock({ 
                      metadata: { ...selectedBlock.metadata, commentType: value }
                    })}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="discussion">💬 Discussion</SelectItem>
                      <SelectItem value="question">❓ Question</SelectItem>
                      <SelectItem value="announcement">📢 Announcement</SelectItem>
                      <SelectItem value="reminder">⏰ Reminder</SelectItem>
                      <SelectItem value="feedback">💭 Feedback Request</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {selectedBlock.type === 'email' && (
              <div className="space-y-4 p-4 bg-blue-50 rounded-lg border">
                <h4 className="font-medium text-blue-900">Email Details</h4>
                
                <div>
                  <label className="text-sm font-medium">From Email Account</label>
                  <Select 
                    value={selectedBlock.metadata?.fromEmail || ''}
                    onValueChange={(value) => updateBlock({ 
                      metadata: { ...selectedBlock.metadata, fromEmail: value }
                    })}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select sending account..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="noreply@company.com">📧 noreply@company.com</SelectItem>
                      <SelectItem value="support@company.com">📧 support@company.com</SelectItem>
                      <SelectItem value="hello@company.com">📧 hello@company.com</SelectItem>
                      <SelectItem value="team@company.com">📧 team@company.com</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium">To Email</label>
                  <Input
                    value={selectedBlock.metadata?.toEmail || ''}
                    onChange={(e) => updateBlock({ 
                      metadata: { ...selectedBlock.metadata, toEmail: e.target.value }
                    })}
                    placeholder="recipient@example.com"
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium">Subject</label>
                  <Input
                    value={selectedBlock.metadata?.subject || selectedBlock.title}
                    onChange={(e) => updateBlock({ 
                      metadata: { ...selectedBlock.metadata, subject: e.target.value }
                    })}
                    placeholder="Email subject..."
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium">Email Type</label>
                  <Select 
                    value={selectedBlock.metadata?.emailType || 'notification'}
                    onValueChange={(value) => updateBlock({ 
                      metadata: { ...selectedBlock.metadata, emailType: value }
                    })}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="notification">📮 Notification</SelectItem>
                      <SelectItem value="reminder">⏰ Reminder</SelectItem>
                      <SelectItem value="update">📢 Update</SelectItem>
                      <SelectItem value="invitation">💌 Invitation</SelectItem>
                      <SelectItem value="newsletter">📰 Newsletter</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
            
            {/* Node Linking Section - Available for all blocks */}
            <div className="space-y-2 p-3 bg-purple-50 dark:bg-purple-950 rounded-lg border">
              <h4 className="font-medium text-sm">🔗 Link to Nodes</h4>
              <p className="text-xs text-muted-foreground">
                Connect this block to existing nodes in your graph
              </p>
              
              <div>
                <Select 
                  value=""
                  onValueChange={(value) => {
                    const nodeId = parseInt(value);
                    const linkedNodeIds = selectedBlock.metadata?.linkedNodeIds || [];
                    if (!linkedNodeIds.includes(nodeId)) {
                      updateBlock({ 
                        metadata: { 
                          ...selectedBlock.metadata, 
                          linkedNodeIds: [...linkedNodeIds, nodeId]
                        }
                      });
                    }
                  }}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select node to link..." />
                  </SelectTrigger>
                  <SelectContent>
                    {allNodes?.filter(node => 
                      !(selectedBlock.metadata?.linkedNodeIds || []).includes(node.id)
                    ).slice(0, 50).map((node) => (
                      <SelectItem key={node.id} value={node.id.toString()}>
                        {node.nodeType === 'task' ? '✅' : node.nodeType === 'idea' ? '💡' : '📝'} {node.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {selectedBlock.metadata?.linkedNodeIds && selectedBlock.metadata.linkedNodeIds.length > 0 && (
                <div className="space-y-1">
                  {selectedBlock.metadata.linkedNodeIds.map((nodeId: number) => {
                    const node = allNodes?.find(n => n.id === nodeId);
                    if (!node) return null;
                    return (
                      <div key={nodeId} className="flex items-center justify-between gap-2 p-2 rounded text-xs" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
                        <span className="truncate">
                          {node.nodeType === 'task' ? '✅' : node.nodeType === 'idea' ? '💡' : '📝'} {node.title}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            const linkedNodeIds = (selectedBlock.metadata?.linkedNodeIds || []).filter((id: number) => id !== nodeId);
                            updateBlock({ 
                              metadata: { ...selectedBlock.metadata, linkedNodeIds }
                            });
                          }}
                          className="h-5 w-5 p-0"
                        >
                          ✕
                        </Button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
            
            {/* Scheduling Section - Available for all blocks */}
            <div className="space-y-3 p-3 bg-orange-50 dark:bg-orange-950 rounded-lg border">
              <h4 className="font-medium text-sm">⏰ Schedule Execution</h4>
              <p className="text-xs text-muted-foreground">
                Schedule when this block should be executed during plan launch. Leave empty to execute immediately.
              </p>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium">Date</label>
                  <Input
                    type="date"
                    value={selectedBlock.scheduleDate || ''}
                    onChange={(e) => updateBlock({ scheduleDate: e.target.value })}
                    className="mt-1"
                    placeholder="Select date..."
                  />
                </div>
                
                <div>
                  <label className="text-xs font-medium">Time</label>
                  <Input
                    type="time"
                    value={selectedBlock.scheduleTime || ''}
                    onChange={(e) => updateBlock({ scheduleTime: e.target.value })}
                    className="mt-1"
                    placeholder="Select time..."
                  />
                </div>
              </div>
              
              {(selectedBlock.scheduleDate || selectedBlock.scheduleTime) && (
                <div className="flex items-center gap-2 p-2 rounded" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
                  <span className="text-sm">📅</span>
                  <span className="text-sm">
                    {selectedBlock.scheduleDate && selectedBlock.scheduleTime ? (
                      `Scheduled for ${new Date(selectedBlock.scheduleDate + 'T' + selectedBlock.scheduleTime).toLocaleDateString()} at ${selectedBlock.scheduleTime}`
                    ) : selectedBlock.scheduleDate ? (
                      `Scheduled for ${new Date(selectedBlock.scheduleDate).toLocaleDateString()}`
                    ) : selectedBlock.scheduleTime ? (
                      `Scheduled for ${selectedBlock.scheduleTime} today`
                    ) : ''}
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => updateBlock({ scheduleDate: undefined, scheduleTime: undefined })}
                    className="ml-auto h-6 w-6 p-0"
                  >
                    ✕
                  </Button>
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="locked"
                checked={selectedBlock.locked}
                onChange={(e) => updateBlock({ locked: e.target.checked })}
                className="rounded"
              />
              <label htmlFor="locked" className="text-sm">
                Lock block position (prevent accidental movement)
              </label>
            </div>
          </div>
          
          <div className="flex justify-end gap-2 pt-4">
            <Button 
              variant="outline" 
              onClick={() => {
                setShowBlockEditor(false);
                setSelectedBlock(null);
              }}
            >
              Cancel
            </Button>
            <Button 
              onClick={() => {
                setShowBlockEditor(false);
                setSelectedBlock(null);
                toast({
                  title: "Block updated",
                  description: "Your planning block has been updated successfully.",
                });
              }}
            >
              Save Changes
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  const renderCollaboratorsDialog = () => {
    const handleSaveCollaborators = () => {
      if (!selectedRoom) return;
      
      const updatedRoom = {
        ...selectedRoom,
        collaborators: selectedCollaborators
      };
      
      const updatedRooms = rooms.map(room => 
        room.id === selectedRoom.id ? updatedRoom : room
      );
      
      setRooms(updatedRooms);
      setSelectedRoom(updatedRoom);
      localStorage.setItem('planning-rooms', JSON.stringify(updatedRooms));
      
      setShowCollaboratorsDialog(false);
      toast({
        title: "Collaborators updated",
        description: `${selectedCollaborators.length} collaborator(s) now have access to this planning room.`,
      });
    };

    const toggleCollaborator = (userId: number) => {
      setSelectedCollaborators(prev => 
        prev.includes(userId) 
          ? prev.filter(id => id !== userId)
          : [...prev, userId]
      );
    };

    return (
      <Dialog open={showCollaboratorsDialog} onOpenChange={setShowCollaboratorsDialog}>
        <DialogContent className="sm:max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Manage Collaborators</DialogTitle>
            <DialogDescription>
              Choose who can view and edit this planning room
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {users && users.length > 0 ? (
              <div className="space-y-2">
                <div className="text-sm font-medium mb-3">Select Team Members</div>
                <ScrollArea className="h-[300px] rounded-md border p-4">
                  <div className="space-y-3">
                    {users.map((user: any) => (
                      <div 
                        key={user.id}
                        className="flex items-center justify-between p-3 rounded-lg hover:bg-accent/50 transition-colors cursor-pointer"
                        onClick={() => toggleCollaborator(user.id)}
                      >
                        <div className="flex items-center gap-3 flex-1">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-medium">
                            {user.displayName?.charAt(0).toUpperCase() || user.username?.charAt(0).toUpperCase() || 'U'}
                          </div>
                          <div className="flex-1">
                            <div className="font-medium text-sm">{user.displayName || user.username}</div>
                            <div className="text-xs text-muted-foreground">{user.email}</div>
                          </div>
                        </div>
                        <div 
                          className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${
                            selectedCollaborators.includes(user.id) 
                              ? 'bg-blue-600 border-blue-600' 
                              : 'border-border'
                          }`}
                        >
                          {selectedCollaborators.includes(user.id) && (
                            <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
                
                {selectedCollaborators.length > 0 && (
                  <div className="mt-3 p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                      <span className="text-blue-900 dark:text-blue-100 font-medium">
                        {selectedCollaborators.length} collaborator{selectedCollaborators.length !== 1 ? 's' : ''} selected
                      </span>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-3 opacity-20" />
                <p className="text-sm">No users available</p>
              </div>
            )}
            
            <div className="flex justify-end gap-2 pt-4 border-t">
              <Button variant="outline" onClick={() => setShowCollaboratorsDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveCollaborators} data-testid="button-save-collaborators">
                <Share2 className="h-4 w-4 mr-2" />
                Save & Share
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  const renderNewRoomDialog = () => {
    const templateCards = [
      { id: 'project_kickoff',   emoji: '🚀', name: 'Project Kickoff',    desc: 'Goals, stakeholders & kickoff tasks',  accent: '#3B82F6' },
      { id: 'sprint_planning',   emoji: '⚡', name: 'Sprint Planning',    desc: 'Backlog breakdown & sprint goals',      accent: '#10B981' },
      { id: 'product_launch',    emoji: '🎯', name: 'Product Launch',     desc: 'Go-to-market & launch checklist',       accent: '#F59E0B' },
      { id: 'client_onboarding', emoji: '🤝', name: 'Client Onboarding', desc: 'Setup steps & requirements gathering', accent: '#8B5CF6' },
      { id: 'resource_planning', emoji: '📊', name: 'Resource Planning',  desc: 'Team allocation & capacity',           accent: '#06B6D4' },
      { id: 'blank',             emoji: '✨', name: 'Blank Canvas',       desc: 'Start from scratch, your way',         accent: '#6366F1' },
    ];
    return (
      <Dialog open={showNewRoomDialog} onOpenChange={setShowNewRoomDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-lg">New Planning Room</DialogTitle>
            <DialogDescription className="text-sm">
              Name your room and pick a template to get started fast.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 pt-1">
            {/* Name */}
            <div>
              <label className="text-sm font-medium">Room name</label>
              <Input
                placeholder="e.g. Q3 Sprint Planning"
                className="mt-1.5"
                value={newRoomName}
                onChange={(e) => setNewRoomName(e.target.value)}
                autoFocus
              />
            </div>

            {/* Template grid */}
            <div>
              <label className="text-sm font-medium block mb-2">Start with a template</label>
              <div className="grid grid-cols-3 gap-2">
                {templateCards.map(t => {
                  const selected = newRoomTemplate === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setNewRoomTemplate(t.id)}
                      className={`group relative flex flex-col items-start gap-1.5 p-3 rounded-xl border text-left transition-all ${
                        selected
                          ? 'border-transparent shadow-sm'
                          : 'border-border/50 hover:border-border bg-card hover:bg-accent/30'
                      }`}
                      style={selected ? { background: `${t.accent}15`, borderColor: `${t.accent}60` } : {}}
                    >
                      {selected && (
                        <div className="absolute top-2 right-2 w-3.5 h-3.5 rounded-full flex items-center justify-center" style={{ background: t.accent }}>
                          <svg className="w-2 h-2 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                        </div>
                      )}
                      <span className="text-xl leading-none">{t.emoji}</span>
                      <div>
                        <p className="text-[11px] font-semibold text-foreground leading-snug">{t.name}</p>
                        <p className="text-[10px] text-muted-foreground leading-snug mt-0.5">{t.desc}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" size="sm" onClick={() => setShowNewRoomDialog(false)}>
                Cancel
              </Button>
              <Button size="sm" onClick={createRoom} disabled={!newRoomName.trim()}>
                <Plus className="h-3.5 w-3.5 mr-1.5" />
                Create Room
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  return (
    <div className="h-screen flex" style={{ height: 'calc(100vh - 60px)' }}>
      {renderRoomsList()}
      {renderCanvas()}
      {renderBlockEditor()}
      {renderConnectionEditor()}
      {renderNewRoomDialog()}
      {renderCollaboratorsDialog()}
    </div>
  );
}