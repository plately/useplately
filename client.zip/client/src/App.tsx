import { useState, useEffect } from "react";
import { Switch, Route, useLocation, Redirect } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { ErrorBoundary } from "@/components/error-boundary";
import { queryClient } from "./lib/queryClient";
import { useTheme } from "@/hooks/use-theme";
import { useAuth } from "@/hooks/useAuth";

// Layouts
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import GlobalSearch from "@/components/global-search";

// Pages
import Dashboard from "@/pages/dashboard";
import Workspace from "@/pages/workspace-enhanced";
import FilesPage from "@/pages/files-new";
import Chat from "@/pages/chat";
import Calendar from "@/pages/calendar";
import Tasks from "@/pages/tasks";
import Graph from "@/pages/graph";
import PlanningRoom from "@/pages/planning-room";
import Integrations from "@/pages/integrations";
import AdminDashboard from "@/pages/admin";
import ProfileSettings from "@/pages/profile-settings";
import NotFound from "@/pages/not-found";

// Auth Pages
import { WelcomePage } from "@/pages/welcome";
import { LoginPage } from "@/pages/auth/login";
import { RegisterPage } from "@/pages/auth/register";
import { ForgotPasswordPage } from "@/pages/auth/forgot-password";


function AppLayout({ children }: { children: React.ReactNode }) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [location] = useLocation();
  
  // Extract current page from location
  const currentPage = location === "/" ? "dashboard" : location.replace("/", "");

  // Check for mobile devices
  const [isMobile, setIsMobile] = useState(false);
  
  useEffect(() => {
    // Function to check screen width
    const checkScreenWidth = () => {
      const mobileWidth = 768; // Breakpoint for mobile devices
      const isMobileDevice = window.innerWidth < mobileWidth;
      setIsMobile(isMobileDevice);
      
      // Auto-collapse sidebar on mobile
      if (isMobileDevice) {
        setSidebarCollapsed(false); // Don't collapse on mobile, just hide
        setSidebarVisible(false);
      } else {
        setSidebarVisible(true);
        setSidebarCollapsed(false);
      }
    };
    
    // Initial check
    checkScreenWidth();
    
    // Add event listener for window resize
    window.addEventListener('resize', checkScreenWidth);
    
    // Cleanup
    return () => window.removeEventListener('resize', checkScreenWidth);
  }, []);

  // Toggle sidebar visibility (used for mobile)
  const toggleSidebarVisibility = () => {
    setSidebarVisible(!sidebarVisible);
  };

  return (
    <div className="flex h-screen overflow-hidden relative">
      {/* Global Cmd+K search — always mounted when authenticated */}
      <GlobalSearch />

      {/* Backdrop for mobile sidebar */}
      {isMobile && sidebarVisible && (
        <div 
          className="fixed inset-0 bg-black/40 z-40" 
          onClick={() => setSidebarVisible(false)}
        />
      )}
      
      {/* Sidebar - conditionally visible on mobile */}
      {(sidebarVisible || !isMobile) && (
        <div className={`${isMobile ? 'fixed inset-y-0 left-0 z-50 w-64' : ''}`}>
          <Sidebar 
            collapsed={isMobile ? false : sidebarCollapsed}
            onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} 
            currentPage={currentPage}
            onClose={isMobile ? () => setSidebarVisible(false) : undefined}
            isMobile={isMobile}
          />
        </div>
      )}
      
      <main className="flex-1 flex flex-col min-h-screen bg-background">
        <Header 
          onMenuClick={isMobile ? toggleSidebarVisibility : undefined} 
          showMenuButton={isMobile}
        />
        <div className="flex-1 overflow-auto">
          {children}
        </div>
      </main>
    </div>
  );
}

function AuthRouter() {
  return (
    <Switch>
      <Route path="/" component={WelcomePage} />
      <Route path="/auth/login" component={LoginPage} />
      <Route path="/auth/register" component={RegisterPage} />
      <Route path="/auth/forgot-password" component={ForgotPasswordPage} />
      <Route component={WelcomePage} />
    </Switch>
  );
}

function AppRouter() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/workspace" component={Workspace} />
        <Route path="/chat" component={Chat} />
        <Route path="/calendar" component={Calendar} />
        <Route path="/tasks" component={Tasks} />
        <Route path="/files" component={FilesPage} />
        <Route path="/graph" component={Graph} />
        <Route path="/planning" component={PlanningRoom} />
        <Route path="/integrations" component={Integrations} />
        <Route path="/admin" component={AdminDashboard} />
        <Route path="/profile-settings" component={ProfileSettings} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function Router() {
  const [location] = useLocation();
  const { user, isLoading } = useAuth();
  
  const isAuthRoute = location.startsWith("/auth") || location === "/";

  // While checking auth status, show a minimal loader
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-gray-500">Loading…</p>
        </div>
      </div>
    );
  }

  // If authenticated and on an auth/welcome route → send to dashboard
  if (user && isAuthRoute) {
    return <Redirect to="/dashboard" />;
  }

  // If not authenticated and trying to access the app → send to login
  if (!user && !isAuthRoute) {
    return <Redirect to="/auth/login" />;
  }

  if (isAuthRoute) {
    return <AuthRouter />;
  }

  return <AppRouter />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark" colorScheme="blue">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
