import { useState } from 'react';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Plus, Calendar as CalendarIcon, Globe, User, Users, Folder, Palette, Search, X, Link2, ArrowRight, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { GraphProfile, Node } from '@shared/schema';

interface UniversalNodeCreatorProps {
  trigger?: React.ReactNode;
  defaultType?: string;
  onSuccess?: (createdNode?: Node) => void;
  variant?: 'button' | 'icon' | 'custom';
  size?: 'sm' | 'default' | 'lg';
  className?: string;
  defaultGraphProfile?: number;
  channelContext?: {
    channelId: number;
    channelName: string;
    spaceId: number;
    spaceName: string;
  };
}

const nodeTypes = [
  { value: "journal", label: "Journal Entry", icon: "📔" },
  { value: "task", label: "Task", icon: "✅" },
  { value: "note", label: "Note", icon: "📝" },
  { value: "meeting", label: "Meeting", icon: "📅" },
  { value: "chat", label: "Chat Discussion", icon: "💬" },
  { value: "idea", label: "Idea", icon: "💡" },
  { value: "file", label: "File Reference", icon: "📎" },
  { value: "link", label: "Link", icon: "🔗" }
];

const priorities = [
  { value: "low", label: "Low" },
  { value: "medium", label: "Medium" },
  { value: "high", label: "High" },
  { value: "critical", label: "Critical" }
];

const profileIcons = {
  globe: Globe,
  user: User,
  users: Users,
  folder: Folder,
  palette: Palette
};

export default function UniversalNodeCreator({ 
  trigger, 
  defaultType = "note", 
  onSuccess,
  variant = "button",
  size = "default",
  className = "",
  defaultGraphProfile,
  channelContext
}: UniversalNodeCreatorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [createTitle, setCreateTitle] = useState("");
  const [createContent, setCreateContent] = useState("");
  const [createType, setCreateType] = useState(defaultType);
  const [createAssignedTo, setCreateAssignedTo] = useState("");
  const [createDueDate, setCreateDueDate] = useState<Date | undefined>(undefined);
  const [createPriority, setCreatePriority] = useState("medium");
  const [createTags, setCreateTags] = useState("");
  const [createDescription, setCreateDescription] = useState("");
  const [selectedChannel, setSelectedChannel] = useState(channelContext?.channelId || 0);
  const [selectedGraphProfiles, setSelectedGraphProfiles] = useState<number[]>(
    defaultGraphProfile ? [defaultGraphProfile, 1] : [1]
  ); // Default to "Everything" profile and passed default
  const [searchQuery, setSearchQuery] = useState("");
  const [showLinkDialog, setShowLinkDialog] = useState(false);
  const [linkLabel, setLinkLabel] = useState("");
  const [linkType, setLinkType] = useState("related");
  const [selectedLinkedNodes, setSelectedLinkedNodes] = useState<number[]>([]);
  const [meetingStartDate, setMeetingStartDate] = useState<Date | undefined>(undefined);
  const [meetingEndDate, setMeetingEndDate] = useState<Date | undefined>(undefined);
  const [meetingStartTime, setMeetingStartTime] = useState("09:00");
  const [meetingEndTime, setMeetingEndTime] = useState("10:00");
  const [meetingParticipants, setMeetingParticipants] = useState<number[]>([]);
  const [meetingPlatform, setMeetingPlatform] = useState("");
  const [meetingLink, setMeetingLink] = useState("");
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const queryClient = useQueryClient();

  // Query for graph profiles
  const { data: graphProfiles } = useQuery<GraphProfile[]>({
    queryKey: ['/api/graph-profiles'],
  });

  // Query for channels when chat type is selected
  const { data: channels } = useQuery<any[]>({
    queryKey: ['/api/spaces/1/channels'], // Default to first space for now
    enabled: createType === 'chat'
  });

  // Query for all nodes for linking
  const { data: allNodes = [] } = useQuery<Node[]>({
    queryKey: ['/api/nodes'],
    enabled: isOpen
  });

  // Query for users (for meeting participants)
  const { data: users = [] } = useQuery<any[]>({
    queryKey: ['/api/users'],
    enabled: isOpen && createType === 'meeting'
  });

  const createNodeMutation = useMutation({
    mutationFn: async (nodeData: any) => {
      const response = await fetch("/api/nodes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(nodeData),
      });
      
      if (!response.ok) {
        throw new Error("Failed to create node");
      }
      
      return response.json();
    },
    onSuccess: async (createdNode: Node) => {
      // Create links if any nodes were selected
      if (selectedLinkedNodes.length > 0) {
        try {
          await Promise.all(
            selectedLinkedNodes.map(targetNodeId =>
              apiRequest('/api/node-links', {
                method: 'POST',
                body: JSON.stringify({
                  sourceId: createdNode.id,
                  targetId: targetNodeId,
                  label: linkLabel || 'linked',
                  type: linkType
                })
              })
            )
          );
        } catch (error) {
          console.error('Failed to create some links:', error);
          toast({
            title: "Partial Success",
            description: "Node created but some links failed to create.",
            variant: "destructive",
          });
        }
      }
      
      queryClient.invalidateQueries({ queryKey: ['/api/nodes'] });
      queryClient.invalidateQueries({ queryKey: ['/api/node-links'] });
      toast({
        title: "Node Created",
        description: selectedLinkedNodes.length > 0 
          ? `Your node has been successfully created with ${selectedLinkedNodes.length} link(s)!`
          : "Your node has been successfully created!",
      });
      
      // Reset form
      setCreateTitle("");
      setCreateContent("");
      setCreateType(defaultType);
      setCreateAssignedTo("");
      setCreateDueDate(undefined);
      setCreatePriority("medium");
      setCreateTags("");
      setCreateDescription("");
      setSelectedChannel(channelContext?.channelId || 0);
      setSelectedGraphProfiles(defaultGraphProfile ? [defaultGraphProfile, 1] : [1]);
      setSelectedLinkedNodes([]);
      setSearchQuery("");
      setLinkLabel("");
      setLinkType("related");
      setShowLinkDialog(false);
      setMeetingStartDate(undefined);
      setMeetingEndDate(undefined);
      setMeetingStartTime("09:00");
      setMeetingEndTime("10:00");
      setMeetingParticipants([]);
      setMeetingPlatform("");
      setMeetingLink("");
      setUploadedFile(null);
      setIsOpen(false);
      
      if (onSuccess) {
        onSuccess(createdNode);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create node",
        variant: "destructive",
      });
    }
  });

  const handleCreateNode = () => {
    if (!createTitle.trim()) {
      toast({
        title: "Error",
        description: "Please enter a title for the node",
        variant: "destructive",
      });
      return;
    }
    
    // Build properties and metadata based on node type
    let properties: any = {};
    let metadata: any = {};
    
    if (createType === "task") {
      properties = {
        assignedTo: createAssignedTo,
        dueDate: createDueDate?.toISOString(),
        priority: createPriority,
        status: "todo"
      };
    } else if (createType === "chat") {
      const selectedChannelData = channels?.find(c => c.id === selectedChannel);
      properties = {
        discussionTopic: createTitle,
        channelId: selectedChannel,
        channelName: selectedChannelData?.name || 'general',
        spaceId: channelContext?.spaceId || 1,
        spaceName: channelContext?.spaceName || 'Default Space',
        participants: [],
        isOperational: true // Mark as operative for team workflow
      };
    } else if (createType === "meeting") {
      // Build start and end dates with times
      const startDateTime = meetingStartDate ? new Date(meetingStartDate) : new Date();
      const [startHour, startMin] = meetingStartTime.split(':').map(Number);
      startDateTime.setHours(startHour, startMin, 0, 0);
      
      const endDateTime = meetingEndDate ? new Date(meetingEndDate) : new Date(startDateTime);
      const [endHour, endMin] = meetingEndTime.split(':').map(Number);
      endDateTime.setHours(endHour, endMin, 0, 0);

      properties = {
        startTime: meetingStartTime,
        endTime: meetingEndTime,
        participants: meetingParticipants,
        invitees: meetingParticipants,
        meetingPlatform: meetingPlatform,
        meetingLink: meetingLink,
        status: "scheduled"
      };
      
      // Set scheduledFor for calendar display
      metadata.scheduledFor = startDateTime.toISOString();
    } else if (createType === "file") {
      properties = {
        fileName: uploadedFile?.name || "",
        fileSize: uploadedFile?.size || 0,
        fileType: uploadedFile?.type || "",
      };
    }
    
    // Build metadata for proper reflection in chat interface
    if (createType === "chat") {
      const selectedChannelData = channels?.find(c => c.id === selectedChannel);
      metadata = {
        channelId: selectedChannel,
        channelContext: {
          channelId: selectedChannel,
          channelName: selectedChannelData?.name || channelContext?.channelName || 'general',
          spaceId: channelContext?.spaceId || 1,
          spaceName: channelContext?.spaceName || 'Default Space'
        },
        discussionType: "operational",
        isOperational: true
      };
    }

    const newNode: any = {
      title: createTitle,
      content: createContent || createDescription || "",
      nodeType: createType,
      createdBy: 1,
      tags: createTags ? createTags.split(',').map(tag => tag.trim()).filter(Boolean) : [createType],
      properties,
      metadata,
      graphProfiles: selectedGraphProfiles
    };

    // Add scheduledFor for meeting nodes so they appear in calendar
    if (createType === "meeting" && metadata.scheduledFor) {
      newNode.scheduledFor = metadata.scheduledFor;
    }
    
    createNodeMutation.mutate(newNode);
  };

  const renderTrigger = () => {
    if (trigger) {
      return trigger;
    }



    return null;
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {renderTrigger()}
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-[450px] max-h-[90vh] overflow-y-auto glass-modal">
        <DialogHeader>
          <DialogTitle>Create New Node</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-3">
            <Label>Select Node Type</Label>
            <div className="grid grid-cols-4 gap-2">
              {nodeTypes.map((type) => (
                <button
                  key={type.value}
                  onClick={() => setCreateType(type.value)}
                  className={`flex flex-col items-center gap-1.5 p-3 rounded-lg border-2 transition-all ${
                    createType === type.value
                      ? 'border-primary bg-primary/10 shadow-sm'
                      : 'border-border hover:border-primary/50 hover:bg-accent/50'
                  }`}
                >
                  <span className="text-2xl">{type.icon}</span>
                  <span className="text-xs font-medium text-center leading-tight">{type.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              value={createTitle}
              onChange={(e) => setCreateTitle(e.target.value)}
              placeholder="Enter node title..."
              className="w-full"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={createDescription}
              onChange={(e) => setCreateDescription(e.target.value)}
              placeholder="Brief description of this node..."
              className="min-h-[60px]"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Content</Label>
            <Textarea
              id="content"
              value={createContent}
              onChange={(e) => setCreateContent(e.target.value)}
              placeholder="Enter detailed content..."
              className="min-h-[100px]"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tags">Tags (comma-separated)</Label>
            <Input
              id="tags"
              value={createTags}
              onChange={(e) => setCreateTags(e.target.value)}
              placeholder="e.g., project, meeting, urgent"
              className="w-full"
            />
          </div>

          {/* Chat-specific channel selection */}
          {createType === "chat" && (
            <div className="space-y-2 bg-accent/10 p-3 rounded-md">
              <Label htmlFor="channel">Chat Channel</Label>
              <Select value={selectedChannel.toString()} onValueChange={(value) => setSelectedChannel(parseInt(value))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select channel to reflect in..." />
                </SelectTrigger>
                <SelectContent>
                  {channels?.map((channel) => (
                    <SelectItem key={channel.id} value={channel.id.toString()}>
                      #{channel.name} - {channel.description || 'No description'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                This discussion will be associated with the selected channel for operational team workflow
              </p>
            </div>
          )}

          {/* Graph Profiles Selection */}
          <div className="space-y-2">
            <Label>Graph Profiles</Label>
            <div className="space-y-2 max-h-32 overflow-y-auto border rounded-md p-2">
              {graphProfiles?.map((profile) => {
                const IconComponent = profileIcons[profile.icon as keyof typeof profileIcons] || Palette;
                const isSelected = selectedGraphProfiles.includes(profile.id);
                
                return (
                  <div key={profile.id} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`profile-${profile.id}`}
                      checked={isSelected}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedGraphProfiles(prev => [...prev, profile.id]);
                        } else {
                          setSelectedGraphProfiles(prev => prev.filter(id => id !== profile.id));
                        }
                      }}
                      className="w-4 h-4"
                    />
                    <label 
                      htmlFor={`profile-${profile.id}`}
                      className="flex items-center gap-2 cursor-pointer flex-1"
                    >
                      <IconComponent 
                        className="h-4 w-4" 
                        style={{ color: profile.color || '#3b82f6' }} 
                      />
                      <span className="text-sm">{profile.name}</span>
                      {profile.isDefault && (
                        <Badge variant="secondary" className="text-xs">Default</Badge>
                      )}
                    </label>
                  </div>
                );
              })}
            </div>
            <p className="text-xs text-muted-foreground">
              Select which graph profiles this node should appear in
            </p>
          </div>

          {/* Node Linking Section */}
          <Separator className="my-4" />
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Links & Connections</Label>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowLinkDialog(!showLinkDialog)}
                className="h-8"
              >
                <Plus className="h-3 w-3 mr-1" />
                Add Link
              </Button>
            </div>

            {/* Show selected linked nodes */}
            {selectedLinkedNodes.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs text-muted-foreground">
                  {selectedLinkedNodes.length} node(s) will be linked:
                </p>
                <div className="space-y-1 max-h-24 overflow-y-auto">
                  {selectedLinkedNodes.map(nodeId => {
                    const linkedNode = allNodes.find(n => n.id === nodeId);
                    if (!linkedNode) return null;
                    
                    return (
                      <div key={nodeId} className="flex items-center justify-between p-2 bg-accent/10 rounded-md text-sm">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <Link2 className="h-3 w-3 text-primary flex-shrink-0" />
                          <span className="truncate">{linkedNode.title}</span>
                          <Badge variant="outline" className="text-xs flex-shrink-0">
                            {linkedNode.nodeType}
                          </Badge>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0 ml-2"
                          onClick={() => setSelectedLinkedNodes(prev => prev.filter(id => id !== nodeId))}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Link Dialog */}
            {showLinkDialog && (
              <div className="border rounded-lg p-3 space-y-3 bg-accent/5">
                <div className="space-y-2">
                  <Label htmlFor="linkSearch" className="text-xs">Search Nodes</Label>
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="linkSearch"
                      placeholder="Search for a node to link..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="linkType" className="text-xs">Connection Type</Label>
                  <Select value={linkType} onValueChange={setLinkType}>
                    <SelectTrigger id="linkType">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="related">Related</SelectItem>
                      <SelectItem value="depends_on">Depends On</SelectItem>
                      <SelectItem value="blocks">Blocks</SelectItem>
                      <SelectItem value="references">References</SelectItem>
                      <SelectItem value="parent">Parent</SelectItem>
                      <SelectItem value="child">Child</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="linkLabel" className="text-xs">Label (optional)</Label>
                  <Input
                    id="linkLabel"
                    placeholder="e.g., 'implements', 'continues from'..."
                    value={linkLabel}
                    onChange={(e) => setLinkLabel(e.target.value)}
                  />
                </div>

                {/* Available Nodes List */}
                <div className="space-y-2">
                  <Label className="text-xs">Available Nodes</Label>
                  <ScrollArea className="h-48 border rounded-md">
                    <div className="p-2 space-y-1">
                      {allNodes
                        .filter(n => 
                          (searchQuery === '' || n.title.toLowerCase().includes(searchQuery.toLowerCase())) &&
                          !selectedLinkedNodes.includes(n.id)
                        )
                        .slice(0, 50)
                        .map(node => (
                          <Button
                            key={node.id}
                            variant="ghost"
                            className="w-full justify-start text-left h-auto py-2"
                            onClick={() => {
                              setSelectedLinkedNodes(prev => [...prev, node.id]);
                              setSearchQuery("");
                            }}
                          >
                            <div className="flex items-center gap-2 w-full">
                              <Link2 className="h-3 w-3 text-primary" />
                              <div className="flex-1 min-w-0">
                                <div className="font-medium text-sm truncate">{node.title}</div>
                                <div className="text-xs text-muted-foreground">
                                  {node.nodeType}
                                </div>
                              </div>
                              <Plus className="h-3 w-3 text-muted-foreground" />
                            </div>
                          </Button>
                        ))}
                      {allNodes.filter(n => 
                        (searchQuery === '' || n.title.toLowerCase().includes(searchQuery.toLowerCase())) &&
                        !selectedLinkedNodes.includes(n.id)
                      ).length === 0 && (
                        <p className="text-xs text-muted-foreground text-center py-4">
                          {searchQuery ? 'No nodes found matching your search' : 'No nodes available to link'}
                        </p>
                      )}
                    </div>
                  </ScrollArea>
                </div>
              </div>
            )}
          </div>
          <Separator className="my-4" />

          {/* Task-specific fields */}
          {createType === "task" && (
            <>
              <div className="space-y-2">
                <Label htmlFor="assignedTo">Assigned To</Label>
                <Input
                  id="assignedTo"
                  value={createAssignedTo}
                  onChange={(e) => setCreateAssignedTo(e.target.value)}
                  placeholder="Enter assignee name..."
                />
              </div>

              <div className="space-y-2">
                <Label>Due Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {createDueDate ? format(createDueDate, "PPP") : "Select due date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={createDueDate}
                      onSelect={setCreateDueDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label htmlFor="priority">Priority</Label>
                <Select value={createPriority} onValueChange={setCreatePriority}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent>
                    {priorities.map((priority) => (
                      <SelectItem key={priority.value} value={priority.value}>
                        {priority.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </>
          )}

          {/* Meeting-specific fields */}
          {createType === "meeting" && (
            <>
              {/* Start and End Time */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Start Date & Time</Label>
                  <div className="space-y-2">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start">
                          <CalendarIcon className="h-4 w-4 mr-2" />
                          {meetingStartDate ? format(meetingStartDate, 'MMM d, yyyy') : 'Select date'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={meetingStartDate}
                          onSelect={(date: Date | undefined) => {
                            if (date) {
                              setMeetingStartDate(date);
                              if (!meetingEndDate || meetingEndDate < date) {
                                setMeetingEndDate(date);
                              }
                            }
                          }}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <Input 
                      type="time"
                      value={meetingStartTime}
                      onChange={(e) => setMeetingStartTime(e.target.value)}
                      className="w-full"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>End Date & Time</Label>
                  <div className="space-y-2">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start">
                          <CalendarIcon className="h-4 w-4 mr-2" />
                          {meetingEndDate ? format(meetingEndDate, 'MMM d, yyyy') : 'Select date'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={meetingEndDate}
                          onSelect={(date: Date | undefined) => date && setMeetingEndDate(date)}
                          disabled={(date: Date) => meetingStartDate ? date < meetingStartDate : false}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <Input 
                      type="time"
                      value={meetingEndTime}
                      onChange={(e) => setMeetingEndTime(e.target.value)}
                      className="w-full"
                    />
                  </div>
                </div>
              </div>

              {/* Meeting Link */}
              <div className="space-y-2">
                <Label htmlFor="meeting-link">Meeting Link</Label>
                <Select value={meetingPlatform} onValueChange={setMeetingPlatform}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select meeting platform or add custom link" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="zoom">Zoom Meeting</SelectItem>
                    <SelectItem value="teams">Microsoft Teams</SelectItem>
                    <SelectItem value="meet">Google Meet</SelectItem>
                    <SelectItem value="outlook">Outlook/Skype</SelectItem>
                    <SelectItem value="custom">Custom Link</SelectItem>
                  </SelectContent>
                </Select>
                <Input 
                  id="meeting-link"
                  value={meetingLink}
                  onChange={(e) => setMeetingLink(e.target.value)}
                  placeholder="Enter meeting link (zoom.us/j/123456789, meet.google.com/xxx-xxx-xxx, etc.)"
                  className="w-full"
                />
              </div>

              {/* Participants */}
              <div className="space-y-2">
                <Label>Who to Invite</Label>
                <div className="border rounded-lg p-3 space-y-2 max-h-48 overflow-y-auto">
                  {users.map((user: any) => (
                    <div key={user.id} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`user-${user.id}`}
                        checked={meetingParticipants.includes(user.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setMeetingParticipants([...meetingParticipants, user.id]);
                          } else {
                            setMeetingParticipants(meetingParticipants.filter(id => id !== user.id));
                          }
                        }}
                        className="rounded border-gray-300"
                      />
                      <label htmlFor={`user-${user.id}`} className="text-sm cursor-pointer flex-1">
                        {user.username || user.email}
                      </label>
                    </div>
                  ))}
                  {users.length === 0 && (
                    <p className="text-xs text-muted-foreground text-center py-2">
                      No users available
                    </p>
                  )}
                </div>
                {meetingParticipants.length > 0 && (
                  <p className="text-xs text-muted-foreground">
                    {meetingParticipants.length} participant(s) selected
                  </p>
                )}
              </div>
            </>
          )}

          {/* File-specific fields */}
          {createType === "file" && (
            <div className="space-y-2">
              <Label htmlFor="fileUpload">Upload File</Label>
              <Input
                id="fileUpload"
                type="file"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    setUploadedFile(file);
                    if (!createTitle) {
                      setCreateTitle(file.name);
                    }
                  }
                }}
                className="cursor-pointer"
              />
              {uploadedFile && (
                <div className="flex items-center gap-2 p-2 bg-accent/10 rounded-md">
                  <FileText className="h-4 w-4 text-primary" />
                  <span className="text-sm flex-1 truncate">{uploadedFile.name}</span>
                  <span className="text-xs text-muted-foreground">
                    {(uploadedFile.size / 1024).toFixed(1)} KB
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() => setUploadedFile(null)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              )}
            </div>
          )}

          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="outline" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleCreateNode}
              disabled={createNodeMutation.isPending}
            >
              {createNodeMutation.isPending ? "Creating..." : "Create Node"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}